package com.ibm.Ereg2SCN.Loader;

import java.io.Serializable;

public class IdFileData implements Serializable{
	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	private String Domain;
	private String Shortname;
	private String uid;
	private byte[] idFileBinary;
	private String password;
	private Boolean uploadSuccessfull = new Boolean(false);
	
	
	
	
	public String getDomain() {
		return Domain;
	}
	public void setDomain(String domain) {
		Domain = domain;
	}
	public String getShortname() {
		return Shortname;
	}
	public void setShortname(String shortname) {
		Shortname = shortname;
	}
	public Boolean getUploadSuccessfull() {
		return uploadSuccessfull;
	}
	public void setUploadSuccessfull(Boolean uploadSuccessfull) {
		this.uploadSuccessfull = uploadSuccessfull;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public byte[] getIdFileBinary() {
		return idFileBinary;
	}
	public void setIdFileBinary(byte[] idFileBinary) {
		this.idFileBinary = idFileBinary;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
