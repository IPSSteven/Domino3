package com.ibm.Ereg2SCN.Loader;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import com.ibm.Ereg2SCN.SCNApi;
import com.ibm.Ereg2SCN.SCNUploadResponse;
import com.ibm.ereg.common.CommonFunctions;

import com.ibm.ereg.config.ConfigObjMailDomainServer;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.config.ConfigObjSCNAPI;
import com.ibm.ereg.config.ConfigObjUploadSCN;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.EmbeddedObject;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.RichTextItem;
import lotus.domino.Session;
import lotus.domino.View;


public class LoadFromNCOUAR2SCN extends NotesThread {
	//private final String EDCServer = "D06EDC10";
	//private final String EDCfilePath = "dircat/edcww.nsf";
	//private final String[] domains = {"IBMAT", "IBMGR", "IBMHU" };
	//private final String[] domains = {"IBM"};
	private  String[] domains;
	private String stpw;
	private final String tmpDir = "C:\\ereg\\temp\\";

	private Database dbLog;
	private InputOutputLogger log;
	private ConfigObjNCOUAR cfgNcouar;

	private Database dbEDC;
	private SCNApi SCNApi;
	private Session session;
	private HashMap<String, String> MailDomainServer;
	private HashMap<String,NabData> DomainNabData;
	private boolean bFullUpload;
	private boolean bUploadMailSystem;
	private DocumentCollection dccDom;
	//private View vwByShortname;

	private class NabData {
		String internetAddress;
		String MailSystem;
		public String getInternetAddress() {
			return internetAddress;
		}
		public void setInternetAddress(String internetAddress) {
			this.internetAddress = internetAddress;
		}
		public String getMailSystem() {
			return MailSystem;
		}
		public void setMailSystem(String mailSystem) {
			MailSystem = mailSystem;
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoadFromNCOUAR2SCN lf = new LoadFromNCOUAR2SCN();
		lf.stpw = args[0];
		/*
		int i = 0;
		lf.domains = new String[args.length -1];
		for(String s:args){
			if (i== 0){
				lf.stpw = args[0];
			}else{
				lf.domains[i-1] = s;
			}
			i++;
		}
		 */
		lf.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();

		session = NotesFactory.createSessionWithFullAccess(stpw);
		process(session);

	}


	private boolean getConfig()	{

		try {
			cfgNcouar = new ConfigObjNCOUAR(session, log);
			ConfigObjMailDomainServer cfgMailMailDomainServer = new ConfigObjMailDomainServer(session);
			this.MailDomainServer = cfgMailMailDomainServer.getNabServers_domain();
			ConfigObjUploadSCN UlScn = new ConfigObjUploadSCN(session,"12>UpLoadSCN");
			domains = UlScn.getDomains()[0].split(",");
			bFullUpload = UlScn.getFullUpload();
			bUploadMailSystem = UlScn.getUploadMailSystem2UAR();
			ConfigObjSCNAPI confSCN = new ConfigObjSCNAPI(session, "12>SCNAPI", log);

			SCNApi = new SCNApi(confSCN.getSCNAccount(), confSCN.getSCNAccountPassword());
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage());
			return false;
		}

	}

	private String isIDinVault(Document docUAR, NabData nd){

		String stEmail;

		try {

			stEmail = nd.getInternetAddress();
			if(stEmail == null){
				return "Short name not filled";
			}else{
				if (SCNApi.isIDinSCN(stEmail)){
					return "Y";
				}else{
					return "N";
				}
			}

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Excpetion: " + e.getLocalizedMessage();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Excpetion: " + e.getLocalizedMessage();
		}
	}

	private boolean upload2Vault(Document docUar, NabData nd){

		Vector<String> vShortname;
		String fileName = null;
		String pw;
		String searchkey = null;
		boolean bFound = false;
		String eMail = null;
		SCNUploadResponse bRes = null;
		try {

			eMail = nd.getInternetAddress();

			//vShortname = docEDC.getItemValue("ShortName");
			//if(vShortname.size() > 1){
			//	searchkey = docEDC.getItemValueString("MailDomain") + vShortname.elementAt(vShortname.size()-1);
			//	docNOUAR = vwNCOUAR.getDocumentByKey(searchkey.toUpperCase());
			RichTextItem ri = (RichTextItem)docUar.getFirstItem("IdFile");
			if (ri == null){
				log.logActionLevel(LogLevel.SEVERE, "Error:id - file for " + nd.getInternetAddress() + "  can not be dettached. It is empty.");
				return false;
			}else{
				Vector<EmbeddedObject> emobj = ri.getEmbeddedObjects();
				Iterator<EmbeddedObject> it = emobj.iterator();
				while(it.hasNext()){
					EmbeddedObject eobj = it.next();
					if(eobj.getType() == EmbeddedObject.EMBED_ATTACHMENT){
						fileName = tmpDir + eobj.getName();
						eobj.extractFile(fileName);
						bFound = true;
					}
				}
			}


			if(!bFound){
				log.logActionLevel(LogLevel.SEVERE, "Error:id - file can not be detached");
				// TL
				
				return false;
			}
			pw = docUar.getItemValueString("Password");

			bRes = SCNApi.uploadIDinSCN(fileName, eMail, pw);

			if(bFound){
				File f = new File(fileName);
				f.delete();

			}
			if (bRes != null){
				if (bRes.isUpLoadSuccessfull()){
					log.logActionLevel(LogLevel.INFO, "IdFile uploaded successful for " +eMail );
					
					// TL
					return true;
				}else{
					log.logActionLevel(LogLevel.SEVERE, "IdFile Not uploaded successful for "+  eMail);
					log.logActionLevel(LogLevel.SEVERE, "Error code: " + bRes.getCode() + " -- Error message: " + bRes.getMessage());
					//TL
					return false;
				}
			}else{
				log.logActionLevel(LogLevel.SEVERE, "result of upload");
				return false;
			}




		} catch (NotesException e) {
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, "Notes error while upload: " + e.getLocalizedMessage());
			log.logActionLevel(LogLevel.SEVERE, "id handle: shortname: " +  eMail + " searchkey:" + searchkey);
			return false;
		}
	}

	public void process ( Session s){
		View vwNCOUAR = null;
		Database dbNCOUAR  = null;
		String LNShortName;
		Document docUar;
		Document docRecyle;
		long lCountInVault =0;
		long lCountUpload = 0;
		long lCountUploudFailed =0;
		String iiV;
		NabData nd; 

		if (this.session == null) session = s; 
		// get the logger
		try {
			dbLog = CommonFunctions.getLogDB(session);
			log = new InputOutputLogger(session, dbLog, "Load ids from NCOUAR to vault", LogLevel.FINEST);
			log.logActionLevel(LogLevel.INFO, "Start Loader try to gather config ");
			if (getConfig()) {
				log.logActionLevel(LogLevel.INFO, "Configuration found ok ");
			}else{
				log.logActionLevel(LogLevel.SEVERE, "Error while try to get configuration - exit");
				LogDocStatus lds = new LogDocStatus(log.getDocLog());
				log.closeLog(lds);
				return;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}


		for(String stDom:domains){

			// get Data from Nab
			if (!getNabData(stDom)){
				log.logActionLevel(LogLevel.SEVERE, "Error while get the NAB data for " + stDom);
				continue;
			}


			vwNCOUAR = cfgNcouar.getVwITIMEXPORT(stDom);
			try {
				dbNCOUAR = vwNCOUAR.getParent();
				//String stSearch = "(Form = \"User\") & (State != \"Out\") & (@Created > [09.04.2019])";
				//dccDom = dbNCOUAR.search( stSearch);
				dccDom = vwNCOUAR.getAllDocumentsByKey(stDom);
				log.logActionLevel(LogLevel.INFO, "Found for " + dccDom.getCount() + " documents");
				

				if (dccDom == null){
					log.logActionLevel(LogLevel.INFO, "No documents found for " + stDom);
				}else{
					log.logActionLevel(LogLevel.INFO, "Found " + dccDom.getCount() + " uar documents found for " + stDom);
				}
				docUar =dccDom.getFirstDocument();
				// docUar = vwNCOUAR.getDocumentByKey("PE078500");
				while(docUar != null){

					LNShortName = docUar.getItemValueString("LNShortName");

					nd = DomainNabData.get(LNShortName);
					if (nd == null){
						log.logActionLevel(LogLevel.SEVERE, "Error:No NabData found for " + LNShortName);
						docRecyle = docUar;
						docUar = dccDom.getNextDocument(docUar);
						docRecyle.recycle();
						continue;
					}

					// Handle SCM
					if (bFullUpload || (!docUar.hasItem("idFileInVault")) ){
						iiV = isIDinVault(docUar, nd);
						if(iiV.equals("N")){
							log.logActionLevel(LogLevel.INFO, "IdFile for " + nd.getInternetAddress() + " is not in vault -- try to upload");
							try {
								if(upload2Vault(docUar, nd)){
									lCountUpload++;
									docUar.replaceItemValue("idFileInVault", "1");
									docUar.save();
								}else{
									lCountUploudFailed++;
									docUar.replaceItemValue("idFileInVault", "0");
									docUar.save();
								}
							}catch(Exception e1){
								System.out.println("Upload failed");
								log.logActionLevel(LogLevel.SEVERE, "Upload of id - File for " + nd.getInternetAddress() + " failed with :" + e1.getLocalizedMessage());
								lCountUploudFailed++;
							}

						}else if(iiV.equals("Y")){
							log.logActionLevel(LogLevel.INFO, "IdFile for " +nd.getInternetAddress()+ " is already in vault");
							docUar.replaceItemValue("idFileInVault", "1");
							docUar.save();
						}else{
							log.logActionLevel(LogLevel.SEVERE,"check for id file failed " + iiV );
						}
					}else{
						if(docUar.getItemValueString("idFileInVault").equals("0")){
							try {
								if(upload2Vault(docUar, nd)){
									lCountUpload++;
									docUar.replaceItemValue("idFileInVault", "1");
									docUar.save();
								}else{
									lCountUploudFailed++;
									docUar.replaceItemValue("idFileInVault", "0");
									docUar.save();
								}
							}catch(Exception e1){
								System.out.println("Upload failed");
								log.logActionLevel(LogLevel.SEVERE, "IdFile for " + docUar.getItemValueString("LNShortName")+ " failed with :" + e1.getLocalizedMessage());
								lCountUploudFailed++;
							}

						}	
					}
					// set mailSystem
					if(bUploadMailSystem){
						docUar.replaceItemValue("MailSystem", nd.getMailSystem());
						docUar.replaceItemValue("InternetAddress", nd.getInternetAddress());
						docUar.save();
					}

					docRecyle = docUar;
					docUar = dccDom.getNextDocument(docUar);
					docRecyle.recycle();
					//docUar = null;
				}

			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			log.logActionLevel(LogLevel.INFO, "Result: Ids in Vault=" +lCountInVault + " Ids uploaded=" + lCountUpload + " Ids upload failed=" + lCountUploudFailed);
			
			try {
				if (dccDom != null)dccDom.recycle();
				if(vwNCOUAR != null)vwNCOUAR.recycle();
				if(dbNCOUAR != null)dbNCOUAR.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		



		if (log != null){
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKDone();
			log.closeLog(lds);
		}
	}

	private boolean getNabData(String stDom){
		Document docNab;
		Vector<String> vShortName;
		Document docRecyle;
		String Server;
		int iCount = 0;
		int iBorder = 1000;
		long tmStart = System.currentTimeMillis();
		try {

			Server = MailDomainServer.get(stDom);
			dbEDC = CommonFunctions.getDatabase(session, Server, "names.nsf");

			DomainNabData = new HashMap<String, NabData>();

			//dccDom = dbEDC.search("Type = \"Person\" & MailDomain = \"" + stDom + "\" & @Created > [08.04.2019]");
			dccDom = dbEDC.search("Type = \"Person\" & MailDomain = \"" + stDom + "\"");
			log.logActionLevel(LogLevel.INFO, "Found " + dccDom.getCount() + " Nab documents" );
			//vwByShortname =dbEDC.getView("People\\People by ShortName");
			//log.logActionLevel(LogLevel.INFO, "Found " + vwByShortname.getEntryCount() + " Nab documents found for " + stDom);

			//docNab = dccDom.getFirstDocument();
			// undo docNab = vwByShortname.getFirstDocument();

			//docNab = vwByShortname.getDocumentByKey("pe078500");
			docNab = dccDom.getFirstDocument();
			while(docNab != null){
				vShortName = docNab.getItemValue("ShortName");
				if (vShortName != null && vShortName.size() >0){
					LoadFromNCOUAR2SCN.NabData nabData = new LoadFromNCOUAR2SCN.NabData();
					nabData.setInternetAddress(docNab.getItemValueString("ShortName"));
					nabData.setMailSystem(docNab.getItemValueString("MailSystem"));
					DomainNabData.put(vShortName.lastElement().toString(), nabData);
				}
				iCount ++;
				if(iCount % iBorder == 0){
					log.logActionLevel(LogLevel.FINER, "Still alive working on " + iCount + " document");
					System.out.println("Still alive working on " + iCount + " document after "  + (System.currentTimeMillis()- tmStart)/1000 + " sec");
				}
				docRecyle = docNab;
				docNab = dccDom.getNextDocument(docNab);
				// undodocNab = vwByShortname.getNextDocument(docNab);

				docRecyle.recycle();
				//docNab = null;// undo	
			}
			if(dccDom != null)dccDom.recycle();
			//	if (vwByShortname != null)vwByShortname.recycle();
			if (dbEDC != null) dbEDC.recycle();
			return true;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				dbEDC.recycle();
			} catch (NotesException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return false;
		}

	}
}
