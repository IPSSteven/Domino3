package com.ibm.Ereg2SCN.Loader;

import java.io.File;
import java.rmi.RemoteException;
import java.util.Iterator;
import java.util.Vector;

import com.ibm.Ereg2SCN.SCNApi;
import com.ibm.Ereg2SCN.SCNUploadResponse;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.TraceLogger;
import com.ibm.samlrest.scn.SamlRestClientException;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.EmbeddedObject;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.RichTextItem;
import lotus.domino.Session;
import lotus.domino.View;

public class ProcessUarThread extends NotesThread {

	private final String component = "NOTES_VAULT_UPLOAD";
	private final String processName = "GID Daily Upload To Vault";
	private final String transactionParameterSCN = "GID_To_SCN";
	private final String transactionParameterGW = "GID_To_GATEWAY";

	private String DatabaseServer = null;
	private String DatabaseFilePath = null;
	private String TheView = null;
	private String  ScnApiAccount = null;
	private String ScnAPipassword = null;

	private String passWord4Session = null;
	private int iStartAt = -1;
	private int iStackSize = -1;
	private VaultLoaderDataSingleton vlds = null;
	private String Domain;
	private InputOutputLogger log;
	private String logUnid;
	private Integer ThreadNumber;
	private boolean bFullUpload ;
	private String tmpDir;
	private SCNApi SCNApi;
	private boolean bUploadMailSystem;
	private IdFileDataExportHandler IdDExport;
	private TraceLogger tlSN;
	private TraceLogger tlGW;

	public ProcessUarThread() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		long lstart = System.currentTimeMillis();
		IdDExport = new IdFileDataExportHandler();
		Session s = NotesFactory.createSessionWithFullAccess(passWord4Session);
		vlds = VaultLoaderDataSingleton.getInstance();
		iStackSize = VaultLoaderDataSingleton.HEAPSIZE_UAR;
		NabDataForVault ndfv = null;
		String LNShortName;
		String iiV;
		String stMailSystem;
		int iCountUpload = 0;
		int iCountUploadFailed = 0;
		int iCountUploadGateWay = 0;
		int iCountUploadGateWayFailed = 0;

		// init the trace loger

		try {

			tlSN = new TraceLogger(processName, component, transactionParameterSCN);
			tlGW = new TraceLogger(processName, component, transactionParameterGW);


		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, "Error while initialise trace log");

		}

		try {

			SCNApi = new SCNApi(ScnApiAccount, ScnAPipassword);
			Database dbNouar = CommonFunctions.getDatabase(s, DatabaseServer, DatabaseFilePath);
			View vwNCOUAR = dbNouar.getView(TheView);

			Document docRecyle = null;
			int iCount = 0;
			Document docUar = vwNCOUAR.getNthDocument(iStartAt);

			while (docUar != null &&  iCount < iStackSize) {
				LNShortName = docUar.getItemValueString("LNShortName");

				// get the data for Nab in case of full load

				if(bFullUpload) {
					// save NAB data in UAE
					ndfv = getNotesDataForVault(docUar);
					if (ndfv == null){
						log.logActionLevel(LogLevel.SEVERE, "Error:No NAB Data found for ShortName " + LNShortName);
						traceLogSCN(tlSN.getRcError(),"Error:No NAB Data found for " + LNShortName);
						docRecyle = docUar;
						docUar =vwNCOUAR.getNextDocument(docUar);
						docRecyle.recycle();
						continue;
					}
					if(!ndfv.getOfficePhoneNumber().trim().isEmpty()) {
						log.logActionLevel(LogLevel.INFO, "Id not uploaded for shortName " + LNShortName + " because Office number is" +ndfv.getOfficePhoneNumber());
						traceLogSCN(tlSN.getRcSuccessWithWarnung(),"Id not uploaded for shortName " + LNShortName + " because Office number is" +ndfv.getOfficePhoneNumber());
						docRecyle = docUar;
						docUar =vwNCOUAR.getNextDocument(docUar);
						docRecyle.recycle();
						continue;
					}
					
					stMailSystem = ndfv.MailSystem;
					docUar.replaceItemValue("MailSystem", ndfv.getMailSystem());
					docUar.replaceItemValue("InternetAddress", ndfv.getInternetAddress());
					//docUar.removeItem("InternetAdddress");
					docUar.save();
				}else {
					if(!docUar.hasItem("MailSystem")){
						log.logActionLevel(LogLevel.SEVERE, "Error:No Mailsystem found in NCOUAR for " + LNShortName);
						traceLogSCN(tlSN.getRcError(),"Error:No Mailsystem found in NCOUAR for " + LNShortName);
						docRecyle = docUar;
						docUar =vwNCOUAR.getNextDocument(docUar);
						docRecyle.recycle();
						continue;
					}
					stMailSystem = docUar.getItemValueString("MailSystem");	
				}

				if(bFullUpload || !docUar.getItemValueString("idFileInVault").equals("1")) {
					// upload to gateway
					if (!stMailSystem.equals("1")) {
						log.logActionLevel(LogLevel.INFO, "no upload to SCN because  " + LNShortName+  " has NOT Notes mail system - try to upload to Gateway vault");


						if (upload2Vault(docUar, ndfv, true)) {
							iCountUploadGateWay++;
						}else{
							iCountUploadGateWayFailed++ ;
						};

						docRecyle = docUar;
						docUar =vwNCOUAR.getNextDocument(docUar);
						docRecyle.recycle();
						continue;  
					}

				// upload to SCN
				iiV = isIDinVault(docUar, ndfv);
				if(iiV.equals("N")){
					log.logActionLevel(LogLevel.INFO, "IdFile for " + ndfv.getInternetAddress() + " is not in vault -- try to upload");
					try {
						if(upload2Vault(docUar, ndfv,false)){
							iCountUpload++;
							docUar.replaceItemValue("idFileInVault", "1");
							docUar.save();
							iCountUpload ++;
						}else{
							docUar.replaceItemValue("idFileInVault", "0");
							docUar.save();
							iCountUploadFailed++;
						}
					}catch(Exception e1){
						System.out.println("Upload failed");
						log.logActionLevel(LogLevel.SEVERE, "Upload of id - File for " + ndfv.getInternetAddress() + " failed with :" + e1.getLocalizedMessage());
						iCountUploadFailed++;
					}

				}else if(iiV.equals("Y")){
					log.logActionLevel(LogLevel.INFO, "IdFile for " +ndfv.getInternetAddress()+ " is already in vault");
					docUar.replaceItemValue("idFileInVault", "1");
					docUar.save();
				}else{
					log.logActionLevel(LogLevel.SEVERE,"check for id file for id "+ ndfv.getInternetAddress() + " failed " + iiV );
				}
			}

			docRecyle = docUar;
			docUar = vwNCOUAR.getNextDocument(docUar);
			docRecyle.recycle();
			iCount++;		
		}

		if (vwNCOUAR != null)vwNCOUAR.recycle();
		if (s !=null)s.recycle(); 


		vlds.getThreadSuccessful().put(ThreadNumber, new Boolean(true));
		vlds.addUpload2VaultNotSuccessFul(iCountUploadFailed);
		vlds.addUpload2VaultSuccessFul(iCountUpload);
		vlds.addUpload2VaultGWNotSuccessFul(iCountUploadGateWayFailed);
		vlds.addUpload2VaultGWSuccessFul(iCountUploadGateWay);

		pln ("******Thread: " + ThreadNumber.toString() + " ended after " + ((System.currentTimeMillis() - lstart)/1000) +
				" sec - " + ((System.currentTimeMillis() - lstart)/60000) + " min*****"  );
		log.logActionLevel(LogLevel.INFO,"************Thread: " + ThreadNumber.toString() + " ended after " + ((System.currentTimeMillis() - lstart)/1000) +
				" sec - " + ((System.currentTimeMillis() - lstart)/60000) + " min********");

	} catch (Exception e) {
		// TODO Auto-generated catch block
		log.logActionLevel(LogLevel.SEVERE,"************Thread: " + ThreadNumber.toString() + " ended with Exception "+ e.getLocalizedMessage() + " after " + ((System.currentTimeMillis() - lstart)/1000) +
				" sec - " + ((System.currentTimeMillis() - lstart)/60000) + " min********");
		log.logActionLevel(LogLevel.SEVERE, e.getMessage());
		e.printStackTrace();
	}

}

private String isIDinVault(Document docUAR, NabDataForVault nd){

	String stEmail;

	try {

		stEmail = nd.getInternetAddress();
		if(stEmail == null){
			return "Short name not filled";
		}else{
			if (SCNApi.isIDinSCN(stEmail)){
				return "Y";
			}else{
				return "N";
			}
		}

	} catch (NotesException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Exception: " + e.getLocalizedMessage();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return "Exception: " + e.getLocalizedMessage();
	}
}

private boolean upload2Vault(Document docUar, NabDataForVault nd, boolean bGateway){

	String fileName = null;
	String pw;
	String searchkey = null;
	boolean bFound = false;
	String eMail = null;
	File f = null;
	boolean bRet = false;
	RichTextItem ri = null;

	SCNUploadResponse bRes = null;




	//vShortname = docEDC.getItemValue("ShortName");
	//if(vShortname.size() > 1){
	//	searchkey = docEDC.getItemValueString("MailDomain") + vShortname.elementAt(vShortname.size()-1);
	//	docNOUAR = vwNCOUAR.getDocumentByKey(searchkey.toUpperCase());

	// 1. get the id file
	try {

		if (bFullUpload) {
			eMail = nd.getInternetAddress();
		}else {
			eMail = docUar.getItemValueString("InternetAddress");
		}

		ri = (RichTextItem)docUar.getFirstItem("IdFile");
		if (ri == null){
			log.logActionLevel(LogLevel.SEVERE, "Error:id - file for " + nd.getInternetAddress() + "  can not be detached. rtf is empty.");
			//TL
			return false;
		}else{
			Vector<EmbeddedObject> emobj = ri.getEmbeddedObjects();
			Iterator<EmbeddedObject> it = emobj.iterator();
			while(it.hasNext()){
				EmbeddedObject eobj = it.next();
				if(eobj.getType() == EmbeddedObject.EMBED_ATTACHMENT){
					fileName = tmpDir + eobj.getName();
					eobj.extractFile(fileName);
					bFound = true;
				}
			}
		}
		if(ri != null) ri.recycle();

	}catch(NotesException ne) {
		log.logActionLevel(LogLevel.SEVERE, "Error:id - file for " + nd.getInternetAddress() + "  can not be detached: Notesexception:" + ne.getMessage());
		traceLogSCN(tlSN.getRcError(),"Error:id - file for " + nd.getInternetAddress() + "  can not be detached: Notesexception: " + ne.getMessage());

	}



	if(!bFound){
		log.logActionLevel(LogLevel.SEVERE, "Error:id - file can not be detached");
		traceLogSCN(tlSN.getRcError(),"Error:id - file can not be detached");
		return false;
	}

	// Get the password
	try {
		pw = docUar.getItemValueString("Password");
		// upload to SCN or gateway vault
		if (bGateway) {
			f = new File(fileName);
			// only serialize the data to disk. Upload agent will pick up from there
			bRet = IdDExport.save2MediatorFolder(docUar.getItemValueString("Domain"),docUar.getItemValueString("LNShortName"),docUar.getItemValueString("Dept_Id"), pw, f, docUar.getUniversalID());
			if(bRet) {
				log.logActionLevel(LogLevel.INFO, "IdFile  exported successful for "+  eMail);
				traceLogGW(tlGW.getRcSuccess(),"IdFile  exported successful for "+  eMail);

			}else {
				log.logActionLevel(LogLevel.SEVERE, "IdFile NOT exported successful "+  eMail);
				traceLogGW(tlGW.getRcError(),"IdFile NOT exported successful "+  eMail);
			}



		}else {
			bRes = SCNApi.uploadIDinSCN(fileName, eMail, pw);
			if (bRes != null){
				if (bRes.isUpLoadSuccessfull()){
					log.logActionLevel(LogLevel.INFO, "IdFile uploaded successful for " +eMail );
					traceLogSCN(tlSN.getRcSuccess(),"IdFile uploaded successful for " +eMail);
					bRet = true;
				}else{
					
					// here the SSL protocol exception takes place
					
					
					log.logActionLevel(LogLevel.SEVERE, "IdFile Not uploaded successful for "+  eMail);
					log.logActionLevel(LogLevel.SEVERE, "Error code: " + bRes.getCode() + " -- Error message: " + bRes.getMessage());
					traceLogSCN(tlSN.getRcError(),"Error code: " + bRes.getCode() + " -- Error message: " + bRes.getMessage());
					bRet = false;
					// try to renew the connection
					try {
						log.logActionLevel(LogLevel.SEVERE, "Try to establih a new connection");
						SCNApi = new SCNApi(ScnApiAccount, ScnAPipassword);
					} catch (SamlRestClientException e) {
						// TODO Auto-generated catch block
						log.logActionLevel(LogLevel.SEVERE, "New connection failed with " + e.getMessage());
						e.printStackTrace();
					}
				}
			}else{
				log.logActionLevel(LogLevel.SEVERE, "Result of upload is null");
				traceLogSCN(tlSN.getRcError(),"Result of upload is null");

				bRet =false;
			}

		}
	} catch (NotesException e) {
		// TODO Auto-generated catch block
		log.logActionLevel(LogLevel.SEVERE, "Error:while get password/shortname of " + nd.getInternetAddress());
		//TL
		e.printStackTrace();
	}




	if(bFound){
		f = new File(fileName);
		f.delete();

	}

	return bRet;



}


public String getDatabaseServer() {
	return DatabaseServer;
}

public void setDatabaseServer(String databaseServer) {
	DatabaseServer = databaseServer;
}

public String getDatabaseFilePath() {
	return DatabaseFilePath;
}

public void setDatabaseFilePath(String databaseFilePath) {
	DatabaseFilePath = databaseFilePath;
}

public String getTheView() {
	return TheView;
}

public void setTheView(String theView) {
	TheView = theView;
}

public String getScnApiAccount() {
	return ScnApiAccount;
}

public void setScnApiAccount(String scnApiAccount) {
	ScnApiAccount = scnApiAccount;
}

public String getScnAPipassword() {
	return ScnAPipassword;
}

public void setScnAPipassword(String scnAPipassword) {
	ScnAPipassword = scnAPipassword;
}

public SCNApi getSCNApi() {
	return SCNApi;
}

public void setSCNApi(SCNApi sCNApi) {
	SCNApi = sCNApi;
}

public String getPassWord4Session() {
	return passWord4Session;
}

public void setPassWord4Session(String passWord) {
	this.passWord4Session = passWord;
}

public int getiStartAt() {
	return iStartAt;
}

public void setiStartAt(int iStartAt) {
	this.iStartAt = iStartAt;
}

public int getiStackSize() {
	return iStackSize;
}

public void setiStackSize(int iStackSize) {
	this.iStackSize = iStackSize;
}



public InputOutputLogger getLog() {
	return log;
}

public void setLog(InputOutputLogger log) {
	this.log = log;
}

public Integer getThreadNumber() {
	return ThreadNumber;
}

public void setThreadNumber(Integer threadNumber) {
	ThreadNumber = threadNumber;
}

public String getDomain() {
	return Domain;
}

public void setDomain(String domain) {
	Domain = domain;
}

public boolean isbFullUpload() {
	return bFullUpload;
}

public void setbFullUpload(boolean bFullUpload) {
	this.bFullUpload = bFullUpload;
}

public String getTmpDir() {
	return tmpDir;
}

public void setTmpDir(String tmpDir) {
	this.tmpDir = tmpDir;
}

private void pln(String s) {
	System.out.println(s);
}

public boolean isbUploadMailSystem() {
	return bUploadMailSystem;
}

public void setbUploadMailSystem(boolean bUploadMailSystem) {
	this.bUploadMailSystem = bUploadMailSystem;
}

public String getLogUnid() {
	return logUnid;
}

public void setLogUnid(String logUnid) {
	this.logUnid = logUnid;
}


private NabDataForVault getNotesDataForVault(Document docUar) {
	try {
		String LNShortName = docUar.getItemValueString("LNShortName");
		if (bFullUpload) {
			return vlds.getDomainNabData().get(LNShortName);
		}else {
			NabDataForVault ndfV = new NabDataForVault();

			ndfV.setInternetAddress(docUar.getItemValueString("InternetAddress"));
			ndfV.setMailSystem(docUar.getItemValueString("MailSystem"));
			if (ndfV.isValid()) return ndfV;
			else return null;

		}

	} catch (NotesException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}
}
private void traceLogSCN(byte bErr, String stLog) {
	if(tlSN == null) {
		try {
			tlSN = new TraceLogger(processName, component, transactionParameterSCN);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, "Error while traceloggingSCN: "+ e.getMessage());

		}
	}
	tlSN.logActionLevel(bErr, stLog);
}
private void traceLogGW(byte bErr, String stLog) {
	if(tlGW == null) {
		try {
			tlGW = new TraceLogger(processName, component, transactionParameterGW);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, "Error while traceloggingGW: " + e.getMessage() );

		}
	}
	tlGW.logActionLevel(bErr, stLog);


}

}
