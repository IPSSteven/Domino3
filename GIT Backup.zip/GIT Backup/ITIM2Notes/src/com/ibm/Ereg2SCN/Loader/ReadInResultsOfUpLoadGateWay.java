package com.ibm.Ereg2SCN.Loader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.config.ConfigObjUploadSCN;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class ReadInResultsOfUpLoadGateWay extends NotesThread {
	private Database dbLog;
	private InputOutputLogger log;


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReadInResultsOfUpLoadGateWay rir = new ReadInResultsOfUpLoadGateWay();
		rir.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("go2bechtle.");
		process(s);
		
	}
	
	public void process(Session s) {
		FileInputStream fis;
		IdFileData ifd;
		String sKey;
		View vwISIMExport;
		Document docUar;
		ObjectInputStream ois = null;
		String sDir;
		ConfigObjNCOUAR cfgNCOUR;
		int iCounter = 0;
		pln ("Start with the Agent");
			
			try {
				dbLog = CommonFunctions.getLogDB(s);
				log = new InputOutputLogger(s, dbLog, "Get Reult from GatewayUpload >>", LogLevel.FINEST);
				log.logActionLevel(LogLevel.INFO, "Start Reader ... ");
				
				cfgNCOUR = new ConfigObjNCOUAR(s, log);
				
				
				ConfigObjUploadSCN UlScn = new ConfigObjUploadSCN(s,"12>UpLoadSCN");
				sDir = UlScn.getTemporyDir4Uload()[0];
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return;
			}
			
			
			
			File f = new File(sDir);
			File [] fs = f.listFiles();
			pln("Found " + fs.length + " files");
			for(File f1: fs) {
				if(f1.getName().endsWith(".txt")) continue; // don't execute txt files
				log.logActionLevel(LogLevel.INFO, "Reading " + f1.getName());
				
				try {
					log.logActionLevel(LogLevel.INFO, "Reading " + f1.getName()+ " ");
					fis = new FileInputStream(f1.getAbsolutePath());
					ois = new ObjectInputStream(fis);
					ifd = (IdFileData)ois.readObject();
					log.logActionLevel(LogLevel.INFO, "Object found Short Name:" + ifd.getShortname() + " id upload successful = " + ifd.getUploadSuccessfull().booleanValue() );
					sKey = ifd.getDomain() + ifd.getShortname();
					vwISIMExport = cfgNCOUR.getVwITIMEXPORT(ifd.getDomain());
					if (vwISIMExport != null) {
						docUar = vwISIMExport.getDocumentByKey(sKey);
						if (docUar != null) {
							if(ifd.getUploadSuccessfull().booleanValue()) {
								docUar.replaceItemValue("idFileInVault", "1");
							}else {
								docUar.replaceItemValue("idFileInVault", "0");
							}
							docUar.save();
						}
						log.logActionLevel(LogLevel.INFO, "UAR document: " + ifd.getShortname() + " updated successful" );
						
					}
					
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				if (ois != null) {
					try {
						ois.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				f1.delete();
				
				iCounter++;
		
				
			}
			
			log.logActionLevel(LogLevel.INFO, "Worked on " + iCounter + " files");
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKDone();
			log.closeLog(lds);
			
		
	}
	private void pln(String s) {
		System.out.println(s);
	}

}
