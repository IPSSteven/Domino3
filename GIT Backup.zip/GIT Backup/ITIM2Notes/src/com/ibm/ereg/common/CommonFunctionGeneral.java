package com.ibm.ereg.common;

import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.Map;

public class CommonFunctionGeneral {
	private static GregorianCalendar  calNow = null;
	public static String getActDate(){
		if (calNow == null) calNow = new GregorianCalendar();
		calNow.setTimeInMillis(System.currentTimeMillis());
		String stRunDateString = Integer.toString(calNow.get(Calendar.YEAR))+ "/" +
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.MONTH)+1),2) + "/" +
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.DATE)),2) + " " +
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.HOUR_OF_DAY)),2) + ":" +
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.MINUTE)),2)+ ":" +
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.SECOND)),2);
		return stRunDateString;
	}

	
	public static String joinStringArray(String[] arr, String sep){
		if(arr == null ) return null;
		StringBuilder sb = new StringBuilder();
		String sRes;

		for(String s: arr){
			sb.append(s);
			sb.append(sep);
		}
		sRes = sb.toString();
		sRes = sRes.substring(0, sRes.length() -1);
		return sRes;

	}
	
	public static void showenv() {
		Map<String,String> hm = System.getenv();
		Iterator<String> it = hm.keySet().iterator();
		String key;
		String value;
		while(it.hasNext()) {
			key = it.next();
			value = hm.get(key);
			System.out.println("EnvKey=" + key + "-------------------" + "EnvValue=" + value);
		}
		
		
		
	}

	public static <T> T[] concatArrays(T[] one, T[] two) {
		T[] result = Arrays.copyOf(one, one.length + two.length);
		System.arraycopy(two, 0, result, one.length, two.length);
		return result;
	}
	public static boolean isNumeric(String s){
		if(s == null || s.length() == 0)return false;
		for (int i = 0; i < s.length(); i++){
			if(! Character.isDigit(s.charAt(i))){
				return false;
			}
		}
		return true;
	}
}
