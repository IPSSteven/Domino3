package com.ibm.ereg.config;

import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Session;

public class ConfigObjAdminpAlert extends ConfigObj {
	private InputOutputLogger log = null;
	public ConfigObjAdminpAlert(Session sess, String stType, AbstractLogger logger) throws Exception {
		super(sess, stType, logger);
		this.log = (InputOutputLogger)logger;
		// TODO Auto-generated constructor stub
	}
	
	public String[] getTypes(){
		try {
			return(getValue("V1"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Error during read of configuration V1");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	public String[] getTimeLinits(){
		try {
			return(getValue("V2"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Error during read of configuration V2");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	public String [] getRecipients(){
		try {
			return(getValue("V3"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Error during read of configuration V3");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	public String [] getRecipientsCC(){
		try {
			return(getValue("V4"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Error during read of configuration V3");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			return null;
		}
	}


}
