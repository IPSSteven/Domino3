package com.ibm.ereg.config;

import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.Session;

public class ConfigObjAgent extends ConfigObj {
	private String Type;
	private String Machine;

	public ConfigObjAgent(Session sess, String stType, String stMachine) throws Exception {
		super(sess);
		// TODO Auto-generated constructor stub
		this.Type = stType;
		this.Machine = stMachine;
		if (!getConfigDocument()) {
			throw new Exception("Config Document not found->" + stType);
		}
		
	}

	@Override
	protected boolean getConfigDocument() {
		// TODO Auto-generated method stub
		 
		try {
			DocumentCollection dcc = vwConfig.getAllDocumentsByKey(Type);
			Document docRecyle = null;
			if (dcc == null) return false;
			docConfig = dcc.getFirstDocument();
			while(docConfig != null){
				if (docConfig.getItemValueString("V2").equals(Machine)){
					return true;
				}
				docRecyle = docConfig;
				docConfig = dcc.getNextDocument(docConfig);
				docRecyle.recycle();
			}
			return false;

		} catch (NotesException e) {
			if (Log != null){
				Log.logActionLevel(LogLevel.SEVERE,
						"Error +++ Configuration document not found");
			}
			e.printStackTrace();
			return false;
		}
	}
	
	public String [] getParameter (String v) throws Exception {
		return getValue(v);
	}
	
	public void setParameter(String param, String value) throws NotesException {
		if(docConfig != null) {
			docConfig.replaceItemValue(param, value);
			docConfig.save();
		}
	}
	

}
