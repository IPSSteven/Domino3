package com.ibm.ereg.config;


import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;

//import com.ibm.ereg.common.*;

public abstract class ConfigObjBase {
	protected Session session = null;
	protected Database confDB;
	private String sMachineKey;
	protected View vwConfig = null;
	protected Document docConfig = null;
	private Document docMachineProf = null;
	protected String st_type;

	public String getSMachineKey() {
		return sMachineKey;
	}
	
	public ConfigObjBase(Session sess)throws Exception{
		initClass(sess);
	}
	public ConfigObjBase(Session sess, String stType)
			throws Exception {
		this.st_type = stType;
		initClass(sess);
	}
	public View getVwConfig() {
		return vwConfig;
	}
	
	protected abstract boolean getConfigDocument();

	protected void initClass(Session sess) throws Exception {
		session = sess;
		
		
		// Get the environment variables and the ereg Config DB
		sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);
		String sEregToolServer = session
				.getEnvironmentString(AllConstants.EREGTOOLSERVER);
		String sEregToolDb = session
				.getEnvironmentString(AllConstants.EREGTOOLDB);

		// open the config database
		//cf = new CommonFunctions(session);
		confDB = CommonFunctions.getDatabase(sess, sEregToolServer, sEregToolDb);
		if (confDB == null) {
			throw new NotesException();
		}
		
		vwConfig = confDB.getView(AllConstants.EREGTOOLVIEW);
		//vwConfig = confDB.getView("($TypeSubject)");
		if (vwConfig == null) {
			// Log.logActionLevel(LogLevel.SEVERE,
			// "Error +++ Configuration view could not be opened");
			throw new Exception("Config view not found");
		}
		// get the MachineProfile document
		docMachineProf = vwConfig.getDocumentByKey("1>" + sMachineKey);
		if (docMachineProf == null) {
			throw new Exception("Machine Profile not found");
		}
	}

	@SuppressWarnings("unchecked")
	protected String[] getValue(String stField) throws Exception {
		String[] result;
		Vector<String> vec_result;
		if (docConfig == null) {
			if (!getConfigDocument()) {
				throw new Exception("Config document not found for " + st_type);
				// result = new String[1];
				// result[0] = "";
				// return result;
			}
		}
		try {
			vec_result = docConfig.getItemValue(stField);
			int iLength = vec_result.size();
			if (iLength == 0) {
				result = new String[1];
				result[0] = "";
			} else {
				result = new String[iLength];
				for (int i = 0; i < iLength; i++) {
					result[i] = (String) vec_result.elementAt(i);
				}
			}
			return result;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = new String[1];
			result[0] = "";
			return result;
		}
	
	}
	public void recycle() {
		// TODO Auto-generated method stub
		
			try {
				if (confDB != null) confDB.recycle();
				if (vwConfig != null) vwConfig.recycle();
				if (docConfig != null) docConfig.recycle();
				if (docMachineProf != null) docMachineProf.recycle();
				
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	

}
