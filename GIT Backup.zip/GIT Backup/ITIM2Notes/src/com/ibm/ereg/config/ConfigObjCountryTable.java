/**
 * 
 */
package com.ibm.ereg.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.Session;

import com.ibm.ereg.constants.AllConstants;
/**
 * @author Kurt Raiser
 *
 */
public class ConfigObjCountryTable extends ConfigObjBase {

	/**
	 * @param sess
	 * @throws Exception
	 */
	private static HashMap<String, String> CountryCodeNumber = null;
	private static HashMap<String, String> CountryNumberCode = null;
	private static HashMap<String, String> OrgDomain = null;
	private static HashMap<String,String> CountryName_IBMCodes = null;
	public ConfigObjCountryTable(Session sess) throws Exception {
		super(sess);

		// TODO Auto-generated constructor stub
		st_type = AllConstants.TYPE_COUNTRY;

		if ((CountryCodeNumber == null) ||  (CountryNumberCode == null) || (OrgDomain == null) || (CountryName_IBMCodes == null) ) {
			CountryCodeNumber = new HashMap<String, String>();
			CountryNumberCode = new HashMap<String, String>();
			OrgDomain = new HashMap<String, String>();
			CountryName_IBMCodes = new HashMap<String, String>();
			
			CountryName_IBMCodes.clear();
			CountryCodeNumber.clear();
			CountryNumberCode.clear();
			OrgDomain.clear();
			initClass();

		}

	}
	private void initClass(){
		String stNumber = null;
		String stCodeIBM = null;
		String stDomain = null;
		String stCountryName = null;
		DocumentCollection dccCountries;
		Document docRec = null;
		//String stdummy;
		try {
			dccCountries = this.vwConfig.getAllDocumentsByKey(st_type+">", false);
			Document docCountry = dccCountries.getFirstDocument();

			while (docCountry != null){
				//stdummy = Integer.toString(docCountry.getItemValueInteger("Type"));
				//stdummy = docCountry.generateXML();
				if (Integer.toString(docCountry.getItemValueInteger("Type")).equals(st_type)){
					stNumber = docCountry.getItemValueString("V3"); // 767, 724 etc
					stCodeIBM = docCountry.getItemValueString("V1"); //GBMAE, IBMKW,IBMKZ etc
					stDomain = docCountry.getItemValueString("V2"); // IBMZA, IBMGMSR, IBMAE
					stCountryName = docCountry.getItemValueString("Subject"); // Germany, Kuwait ...
					
					CountryCodeNumber.put(stCodeIBM, stNumber);
					CountryNumberCode.put(stNumber, stCodeIBM);
					OrgDomain.put(stCodeIBM, stDomain);
					CountryName_IBMCodes.put(stCountryName, stCodeIBM); // Germany, IBMDE
					
				}
				docRec = docCountry; 
				docCountry = dccCountries.getNextDocument(docCountry);
				if (docRec != null) docRec.recycle();
			}
			dccCountries.recycle();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	

	}
	public String getCountryCode(String StCountryNumber){
		if (CountryNumberCode == null) initClass();
		return CountryNumberCode.get(StCountryNumber);
	}
	public String getCountryNumber(String stCountryCode){
		if(CountryCodeNumber == null) initClass();
		return CountryCodeNumber.get(stCountryCode);
	}
	public String getMailDomain (String stOrg){
		if(OrgDomain == null) initClass();
		return OrgDomain.get(stOrg);
		
	}
	public String getIBMCodeByCountryName(String stCountryname){
		if (CountryName_IBMCodes == null) initClass();
		return CountryName_IBMCodes.get(stCountryname);
	}
	public String getCountryNumberByCountry(String stCountryname){
		String stIBMCode = getIBMCodeByCountryName(stCountryname);
		if (stIBMCode == null) return null;
		//return getCountryCode(stIBMCode);
		return getCountryNumber(stIBMCode);
	}
	
	public HashSet<String> getAllOrgforDoamin(String domain) {
		HashSet <String>hsRet = new HashSet<String>();
		hsRet.add(domain);
		String key;
		String value;
		
		Iterator<String> it = OrgDomain.keySet().iterator();
		while (it.hasNext()) {
			key = it.next();
			value = OrgDomain.get(key);
			if(value.equals(domain)) {
				hsRet.add(key);
			}
		}
		return hsRet;
		
	}
	
	public String[] getAllPSC() {
		Set<String> psc = CountryNumberCode.keySet();
		String[] ret = psc.toArray(new String[psc.size()]);
		return ret;
	}
	

	/**
	 * @param sess
	 * @param stType
	 * @throws Exception
	 */


	/* (non-Javadoc)
	 * @see com.ibm.ereg.config.ConfigObjBase#getConfigDocument()
	 */
	@Override
	protected boolean getConfigDocument() {
		// TODO Auto-generated method stub
		return false;
	}

}
