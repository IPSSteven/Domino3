package com.ibm.ereg.config;

import java.util.Vector;

import lotus.domino.Session;

public class ConfigObjDatabase extends ConfigObjBase {
	private final String TYPE_DATABASE = "9>";
	private Vector<String> vecServer1Rep = null;
	private Vector<String> vecServer2Rep = null;

	public ConfigObjDatabase(Session sess, String stType) throws Exception {
		super(sess, stType);
		// TODO Auto-generated constructor stub
		docConfig = super.vwConfig.getDocumentByKey(stType);
		if (docConfig == null){
			throw new Exception("Config document not found !");
		}else{
			vecServer1Rep = docConfig.getItemValue("V1");
			vecServer2Rep = docConfig.getItemValue("V2");
		}
	}

	@Override
	protected boolean getConfigDocument() {
		// TODO Auto-generated method stub
		return false;
	}

	public String getServer(){
		if(vecServer1Rep == null ) return null;
		if(vecServer1Rep.size() ==2){
			return vecServer1Rep.get(0);
		}else{
			return "";
		}
	}

	public String getFilePath(){
		if(vecServer1Rep == null ) return null;
		if(vecServer1Rep.size() ==2){
			return vecServer1Rep.get(1);
		}
		if(vecServer1Rep.size() ==1){
			return  vecServer1Rep.get(0);

		}
		return null;
	}
	
	public String getServer1Rep(){
		if(vecServer2Rep == null ) return null;
		if(vecServer2Rep.size() ==2){
			return vecServer2Rep.get(0);
		}else{
			return "";
		}
	}

	public String getFilePath1Rep(){
		if(vecServer2Rep == null ) return null;
		if(vecServer2Rep.size() ==2){
			return vecServer2Rep.get(1);
		}
		if(vecServer1Rep.size() ==1){
			return  vecServer2Rep.get(0);

		}
		return null;
	}
}
