package com.ibm.ereg.config;

import lotus.domino.Session;

import com.ibm.ereg.logger.BasicLogger;

public class ConfigObjFTP_SSH extends ConfigObj {

	public ConfigObjFTP_SSH(Session sess, String stType, BasicLogger logger)
			throws Exception {
		super(sess, stType, logger);
		// TODO Auto-generated constructor stub
	}
	
	public String getHostAddress() throws Exception{
		return getValue("V1")[0];
	}
	public String getAccount() throws Exception{
		return getValue("V2")[0];
	}
	public String getPW() throws Exception{
		return getValue("V3")[0];
	}
	public String getDestination() throws Exception{
		return getValue("V4")[0];
	}
	public String getTimeOut() throws Exception{
		return getValue("V5")[0];
	}


}
