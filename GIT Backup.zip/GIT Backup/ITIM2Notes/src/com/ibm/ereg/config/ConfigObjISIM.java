package com.ibm.ereg.config;

import com.ibm.ereg.logger.AbstractLogger;

import lotus.domino.Session;

public class ConfigObjISIM extends ConfigObj {

	public ConfigObjISIM(Session sess, String stType, AbstractLogger logger) throws Exception {
		super(sess, stType, logger);
		// TODO Auto-generated constructor stub
	}

}
