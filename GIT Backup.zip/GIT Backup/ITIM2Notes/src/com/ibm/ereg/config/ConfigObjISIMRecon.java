package com.ibm.ereg.config;

import lotus.domino.Session;

public class ConfigObjISIMRecon extends ConfigObj {

	public ConfigObjISIMRecon(Session sess, String stType) throws Exception {
		super(sess, stType);
		// TODO Auto-generated constructor stub
	}
	
	public String getISIMUser() throws Exception {
		return (getValue("V2")[0]);
	}
	public String getPw() throws Exception {
		return (getValue("V3")[0]);
	}
	public String getPropertyFile() throws Exception {
		return (getValue("V4")[0]);
	}
	 public String getFormulaServicePrefix() throws Exception {
		 return (getValue("V5")[0]);
	 }

}
