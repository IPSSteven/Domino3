package com.ibm.ereg.config;

import java.util.HashMap;
import java.util.Vector;

import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

import com.ibm.ereg.logger.BasicLogger;

public class ConfigObjMailDomainServer extends ConfigObj {
	private HashMap<String, String> NabServers_domain = null;

	public ConfigObjMailDomainServer(Session sess, String stType, BasicLogger logger)
			throws Exception {
		super(sess, stType, logger);
		fillNabServerDomain();
		// TODO Auto-generated constructor stub
	}

	public ConfigObjMailDomainServer(Session sess) throws Exception {
		super(sess);
		fillNabServerDomain();
		// TODO Auto-generated constructor stub
	}

	public ConfigObjMailDomainServer(Session sess, String stType) throws Exception {
		super(sess, stType);
		fillNabServerDomain();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public HashMap<String, String> getNabServers_domain() {
		if (NabServers_domain == null){
			fillNabServerDomain();
		}
		return NabServers_domain;
	}

	private void fillNabServerDomain(){
		try {
			NabServers_domain = new HashMap<String, String>();
			View vwMaildomServer = this.confDB.getView("Single Types\\Type 4");
			ViewEntryCollection vec = vwMaildomServer.getAllEntries();
			if(vec != null){
				ViewEntry ve = vec.getFirstEntry();
				ViewEntry ve_old;
				Vector<String> veColumn  = null;
				while (ve != null){
					veColumn = ve.getColumnValues();
					if (veColumn != null && veColumn.size() >= 3){
						NabServers_domain.put(veColumn.elementAt(0).toString(), veColumn.elementAt(2).toString());
					}
					ve_old = ve;
					ve = vec.getNextEntry(ve);
					ve_old.recycle();
				}
				veColumn = null;
			vec.recycle();
			
			}
			vwMaildomServer.recycle();

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
