package com.ibm.ereg.config;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.common.NotesDatabaseReplicaHandler;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.LogLevel;

//public class ConfigObjNCOUAR extends ConfigObj {
public class ConfigObjNCOUAR{	
	private Session thisSession;
	private AbstractLogger log;
	private Database dbNCOUAR = null;
	private View vwByFullName = null;
	private View vwByShortName = null;
	private View vwITIMEXPORT = null;
	private Database dbNCOUAR2 = null;
	private View vwByFullName2 = null;
	private View vwByShortName2 = null;
	private View vwITIMEXPORT2 = null;
	private View vwIdFileWithoutIDinVault = null;
	private View vwIdFileWithoutIDinVault2 = null;
	private HashSet<String> hsDomainUAR = null;
	private HashSet<String> hsDomainUAR2 = null;
	private ConfigObj cfgUAR;
	private ConfigObj cfgUAR2;
	
	public Database getDbNCOUAR(String stDom) {
		if(hsDomainUAR != null && hsDomainUAR.contains(stDom)){
			return dbNCOUAR;
		}
		if(hsDomainUAR2 != null && hsDomainUAR2.contains(stDom)){
			return dbNCOUAR2;
		}
		return dbNCOUAR; // default if both is empty
		
	}

	public View getVwITIMEXPORT(String stDom) {
		
		
		if(hsDomainUAR != null && hsDomainUAR.contains(stDom)){
			return vwITIMEXPORT;
		}
		if(hsDomainUAR2 != null && hsDomainUAR2.contains(stDom)){
			return vwITIMEXPORT2;
		}	
		return vwITIMEXPORT;// default if both is empty
	}
	
	public View getVwITIMEXPORT(String stDom, Document docLog) {
		try {
			docLog.replaceItemValue("Domain", stDom);
			String stFormula =null;
			if(hsDomainUAR != null && hsDomainUAR.contains(stDom)){
				stFormula = cfgUAR.docConfig.getItemValueString("V7");
			}
			if(hsDomainUAR2 != null && hsDomainUAR2.contains(stDom)){
				stFormula = cfgUAR2.docConfig.getItemValueString("V7");
			}	
			if (stFormula == null || stFormula.isEmpty()) return  vwITIMEXPORT; // default
			
			Vector vRes =thisSession.evaluate(stFormula, docLog);
			if (vRes == null) return  vwITIMEXPORT;
			String stViewname = vRes.firstElement().toString();
		
			if ( hsDomainUAR != null && hsDomainUAR.contains(stDom) ) {
				if(stViewname.equalsIgnoreCase(vwITIMEXPORT.getName())) {
					return vwITIMEXPORT;
				}else {
					return dbNCOUAR.getView(stViewname);
				}
			}
			if ( hsDomainUAR2 != null &&  hsDomainUAR2.contains(stDom) ) {
				if (stViewname.equalsIgnoreCase(vwITIMEXPORT.getName())) {
					return vwITIMEXPORT2;
				}else {
					return dbNCOUAR2.getView(stViewname);
				}
				
			}
			return vwITIMEXPORT;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE," Error during get exportview :" + e.getMessage());
			e.printStackTrace();
			return null;
		}
	
	}
	

	public View getVwByFullName(String stDom) {
		if(hsDomainUAR != null && hsDomainUAR.contains(stDom)){
			return vwByFullName;
		}
		if(hsDomainUAR2 != null && hsDomainUAR2.contains(stDom)){
			return vwByFullName2;
		}	
		return vwByFullName;// default if both is empty
	}
	public View getVwByShortName(String stDom){
		if(hsDomainUAR != null && hsDomainUAR.contains(stDom)){
			return vwByShortName;
		}
		if(hsDomainUAR2 != null && hsDomainUAR2.contains(stDom)){
			return vwByShortName2;
		}	
		return vwByShortName;// default if both is empty
	}
	
	public View getVwNoIdfileInVault(String stDom) {
		if(hsDomainUAR != null && hsDomainUAR.contains(stDom)){
			return vwIdFileWithoutIDinVault;
		}
		if(hsDomainUAR2 != null && hsDomainUAR2.contains(stDom)){
			return vwIdFileWithoutIDinVault2;
		}	
		return vwIdFileWithoutIDinVault;// default if both is empty
	}
	
	//public ConfigObjNCOUAR(Session sess, String stType, BasicLogger logger) throws Exception {
	public ConfigObjNCOUAR(Session sess, AbstractLogger logger) throws Exception {	
		//super(sess, stType, logger);
		// TODO Auto-generated constructor stub
		Database dbTemp = null;
		String filePath = null;
		
		thisSession = sess;
		this.log = log;
		
		cfgUAR= new ConfigObj(sess, AllConstants.TYPE_DB + ">"+ AllConstants.UARSUBJECT,logger);
		cfgUAR2= new ConfigObj(sess, AllConstants.TYPE_DB + ">"+ AllConstants.UARSUBJECT2,logger);
		
		//get the domains which are handled by UAR
		Vector<String> itemValue = cfgUAR.docConfig.getItemValue("V8");
		if (!itemValue.isEmpty()){
			hsDomainUAR = new HashSet<String>();
			Iterator<String> it = itemValue.iterator();
			while(it.hasNext()){
				hsDomainUAR.add(it.next());
			}	
		}
		
		itemValue = cfgUAR2.docConfig.getItemValue("V8");
		if (!itemValue.isEmpty()){
			hsDomainUAR2 = new HashSet<String>();
			Iterator<String> it = itemValue.iterator();
			while(it.hasNext()){
				hsDomainUAR2.add(it.next());
			}	
		}
		
		// the UAR DB
		itemValue = cfgUAR.docConfig.getItemValue("V1");
		Iterator<String> it = itemValue.iterator();
		String stDummy [] = new String[2];
		int i = 0;
		while(it.hasNext() && i <2){
			stDummy = itemValue.toArray(stDummy);
			stDummy[i] = it.next();
			i++;
		}
		String stServer = stDummy[0];
		String stFilePath = stDummy[1];
		
		//get Database and view
		dbNCOUAR = CommonFunctions.getDatabase(sess, stServer, stFilePath);
		if (dbNCOUAR == null) {
			logger.logActionLevel(LogLevel.SEVERE, "NCOUAR database not found server: "+ stServer+ " path: "+ stFilePath );
			return;
		}
		
		// decide whether we need to use the replic
		if( this instanceof ConfigObjNCOUARReplic) {
			filePath = cfgUAR.docConfig.getItemValueString("V3");
			if(filePath.isEmpty()) {
				logger.logActionLevel(LogLevel.SEVERE, "file path not filled for replica on UAR2 config" );
			}else {
				logger.logActionLevel(LogLevel.SEVERE, "Try to create a replica for Ncouar on directory " + filePath );
				NotesDatabaseReplicaHandler rp = new NotesDatabaseReplicaHandler(sess, dbNCOUAR);
				dbTemp = rp.getLocalReplicaAndReplicate(true, filePath);
				logger.logActionLevel(LogLevel.SEVERE, "Replica for Ncouar created " + filePath );
				dbNCOUAR.recycle();
				dbNCOUAR = dbTemp;
			}
		}
		
		vwByFullName = dbNCOUAR.getView(AllConstants.NCOUARVIEWBYFULLNAME);
		if (vwByFullName == null) logger.logActionLevel(LogLevel.SEVERE, "View in NCOUAR database not found view " + AllConstants.NCOUARVIEWBYFULLNAME);
		vwByShortName = dbNCOUAR.getView(AllConstants.NCOUARVIEWBYSHORTNAME);
		if (vwByShortName == null) logger.logActionLevel(LogLevel.SEVERE, "View in NCOUAR database not found view " + AllConstants.NCOUARVIEWBYSHORTNAME);
		vwITIMEXPORT = dbNCOUAR.getView(AllConstants.NCOUARVIEWITIMEXPORT);
		if (vwITIMEXPORT == null) logger.logActionLevel(LogLevel.SEVERE, "View in NCOUAR database not found view " + AllConstants.NCOUARVIEWITIMEXPORT);
		vwIdFileWithoutIDinVault = dbNCOUAR.getView(AllConstants.NCOUARVIEWIDWITHOUTVAULTENRTRY);
		if (vwIdFileWithoutIDinVault == null) logger.logActionLevel(LogLevel.SEVERE, "View in NCOUAR database not found view " +AllConstants.NCOUARVIEWIDWITHOUTVAULTENRTRY);
		
		
		if(!(hsDomainUAR == null && hsDomainUAR2 == null)){
			// if both are empty we only need dbNCOUAR is default
			// the UAR DB
			itemValue = cfgUAR2.docConfig.getItemValue("V1");
			it = itemValue.iterator();
			stDummy = new String[2];
			i = 0;
			while(it.hasNext() && i <2){
				stDummy = itemValue.toArray(stDummy);
				stDummy[i] = it.next();
				i++;
			}
			
			stServer = stDummy[0];
			stFilePath = stDummy[1];
			//CommonFunctions cf = new CommonFunctions(sess);
			dbNCOUAR2 = CommonFunctions.getDatabase(sess, stServer, stFilePath);
			if (dbNCOUAR2 == null) {
				logger.logActionLevel(LogLevel.SEVERE, "NCOUAR2 database not found server: "+ stServer+ " path: "+ stFilePath );
				return;
			}
			if( this instanceof ConfigObjNCOUARReplic) {
				filePath = cfgUAR2.docConfig.getItemValueString("V3");
				if(filePath.isEmpty()) {
					logger.logActionLevel(LogLevel.SEVERE, "file path not filled for replica on UAR2 config" );
				}else {
					logger.logActionLevel(LogLevel.SEVERE, "Try to create a replica for Ncouar2 on directory " + filePath );
					NotesDatabaseReplicaHandler rp = new NotesDatabaseReplicaHandler(sess,dbNCOUAR2);
					dbTemp = rp.getLocalReplicaAndReplicate(true, filePath);
					logger.logActionLevel(LogLevel.SEVERE, "Replica for Ncouar2 created " + filePath );
					dbNCOUAR2.recycle();
					dbNCOUAR2 = dbTemp;
					
				}
			}
			
			vwByFullName2 = dbNCOUAR2.getView(AllConstants.NCOUARVIEWBYFULLNAME);
			if (vwByFullName2 == null) logger.logActionLevel(LogLevel.SEVERE, "View in NCOUAR2 database not found view " + AllConstants.NCOUARVIEWBYFULLNAME);
			vwByShortName2 = dbNCOUAR2.getView(AllConstants.NCOUARVIEWBYSHORTNAME);
			if (vwByShortName2 == null) logger.logActionLevel(LogLevel.SEVERE, "View in NCOUAR2 database not found view " + AllConstants.NCOUARVIEWBYSHORTNAME);
			vwITIMEXPORT2 = dbNCOUAR2.getView(AllConstants.NCOUARVIEWITIMEXPORT);
			if (vwITIMEXPORT2 == null) logger.logActionLevel(LogLevel.SEVERE, "View in NCOUAR2 database not found view " + AllConstants.NCOUARVIEWITIMEXPORT);
			vwIdFileWithoutIDinVault2 = dbNCOUAR2.getView(AllConstants.NCOUARVIEWIDWITHOUTVAULTENRTRY);
			if (vwIdFileWithoutIDinVault2 == null) logger.logActionLevel(LogLevel.SEVERE, "View in NCOUAR2 database not found view " +AllConstants.NCOUARVIEWIDWITHOUTVAULTENRTRY);
		
			
		}
		
	}
	public Database[] getUARDBs(){
		Database [] dbs = {dbNCOUAR, dbNCOUAR2};
		return dbs;
	}
	private void pln(String sout){
		System.out.println(sout);
	}
	
	public void recycle(){
		
	}


}
