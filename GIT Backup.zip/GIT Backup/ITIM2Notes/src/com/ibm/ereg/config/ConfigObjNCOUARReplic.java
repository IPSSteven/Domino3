package com.ibm.ereg.config;

import com.ibm.ereg.logger.AbstractLogger;

import lotus.domino.Session;

public class ConfigObjNCOUARReplic extends ConfigObjNCOUAR {

	public ConfigObjNCOUARReplic(Session sess, AbstractLogger logger) throws Exception {
		super(sess, logger);
		// TODO Auto-generated constructor stub
	}

}
