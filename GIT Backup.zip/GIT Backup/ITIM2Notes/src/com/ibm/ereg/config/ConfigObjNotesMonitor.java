/**
 * 
 */
package com.ibm.ereg.config;

import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.Session;

import com.ibm.ereg.logger.AbstractLogger;

/**
 * @author Kurt Raiser
 *
 */
public class ConfigObjNotesMonitor extends ConfigObjBase {

	final static private String TYPE = "42>NotesMonitor";
	private Document docConfig = null;
	
	
	
	public Document getDocConfig() {
		return docConfig;
	}
	
	
	public ConfigObjNotesMonitor(Session sess, AbstractLogger bl)
			throws Exception {
		super(sess, TYPE);
		// TODO Auto-generated constructor stub
		if ( !getConfigDocument()){
			throw new Exception("Config document not found");
		}
	}
	
	public boolean getConfigDocument() {
		// TODO Auto-generated method stub
		String stMachine = null;

		
		try {
			DocumentCollection dcc = this.vwConfig.getAllDocumentsByKey(this.st_type);
			if (dcc.getCount() == 0) return false;
			docConfig = dcc.getFirstDocument();
			while(docConfig != null){
				stMachine = docConfig.getItemValueString("V4");
				if(stMachine.equals(this.getSMachineKey())){
					return true;
				}
			}
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public String [] getDomains() throws Exception{
			return (getValue("V2"));
	}
}
