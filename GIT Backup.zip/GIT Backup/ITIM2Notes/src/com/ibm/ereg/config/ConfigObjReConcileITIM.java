package com.ibm.ereg.config;



import lotus.domino.Document;
import lotus.domino.Session;

import java.util.Vector;

import com.ibm.ereg.constants.AllConstants;
//import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.BasicLogger;
import com.ibm.ereg.logger.InputOutputLogger;


public class ConfigObjReConcileITIM extends ConfigObj {

	ConfigObj cfgP = null;

	public ConfigObjReConcileITIM(Session sess, String stType, InputOutputLogger logger)
			throws Exception {
		super(sess, stType, logger);


		// TODO Auto-generated constructor stub
	}


	public String [] getDomainList()throws Exception{
		return getValue("V1");
	}
	public String[] getFilterFormula()throws Exception{
		return getValue("V2");
	}

	public String[] getErrorMailRecipient()throws Exception{
		return getValue("V3");
	}
	public String[] getRMIDomin2SearchCorrectNCOUAR() throws Exception{
		
		return getValue("V4");
		
	}
	public String[] getSeparateDomains() throws Exception{
		return getValue("V5");
	}

	public boolean handleDomainSeparated(String stDom){
		String[] stHandledDom;
		String[] stSepDoms;
		try {
			stHandledDom = getDomainList(); // all the domains in the config document (v11)
			stSepDoms = getSeparateDomains(); // domain which should be handles sep.
			// dom needs to be in the handled doms
			for(String stDomEval:stHandledDom){
				if(stDom.equalsIgnoreCase(stDomEval)){// we found the domain in question stdom is the actual domain
					for(String stSepDom:stSepDoms){
						if (stDom.equalsIgnoreCase(stSepDom)){
							return true;
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	public String[] gethandleDenyAccessGroup() throws Exception{
		return getValue("V5");
	}
	public boolean useReplica4NCOUAR() throws Exception {
		String [] bVal = getValue("V6"); 
		boolean bRet  = false;
		if (bVal != null && bVal.length >0) {
			if(bVal[0].equalsIgnoreCase("yes")) {
				bRet = true;
			}
		}
		return bRet;
	}
	
	public String getInformErrorSystem() throws Exception {
		return getValue("V7")[0];	
	}

	public String[] getNabFilePathAndView(String domain) throws Exception {
		BasicLogger bLog = (BasicLogger)Log;
		Document docLog = bLog.getDocLog();
		docLog.replaceItemValue("CurrentDomain", domain);
		docLog.save();
		String formula = getValue("V8")[0];
		//Log.logActionLevel(LogLevel.INFO, "Domino2020: formula for Nab + view " + formula);
		Vector vRet = session.evaluate(formula,docLog);
		//Log.logActionLevel(LogLevel.INFO, "Domino2020: result for Nab + view " + vRet.toString());
		String [] ret = (String [])vRet.toArray(new String[vRet.size()]);
		if(ret.length != 2) {
			throw new Exception("Formula for Recon Parameter for Nab server not filled correct");
		}else {
			return ret;
		}
		
		/*String sDummy =  getValue("V8")[0];
		if (sDummy.trim().isEmpty()) {
			throw new Exception("recon Parameter for Nab server not filled");
		}else {
			String [] ret = sDummy.split(":");
			if(ret.length != 2) {
				throw new Exception("recon Parameter for Nab server not filled correct");
			}else {
				return ret;
			}

		}*/

	}
	public String [] getDomainsToStartISIMReconInEreg() throws Exception {
		
		if (cfgP == null) cfgP = new ConfigObj(session, AllConstants.RECONCILE_PARAMETER, Log);
		String DomainsToStartISIMReconInEreg[]  = cfgP.getValue("V1");
		//cfgP.recycle();
		return DomainsToStartISIMReconInEreg;
	}
	public int getNumberOfDataSetsToKeep() throws Exception {
		if (cfgP == null) cfgP = new ConfigObj(session, AllConstants.RECONCILE_PARAMETER, Log);
		String getND = cfgP.getValue("V2")[0];
		int iRet;
		if(getND == null || getND.isEmpty()) {
			iRet = -1;
		}else {
			try {
				iRet = Integer.parseInt(getND);
			}catch(NumberFormatException ne) {
				iRet = 3;
			}
		}
		
		return iRet;
	}

}
