package com.ibm.ereg.config;

import lotus.domino.Session;

import com.ibm.ereg.logger.BasicLogger;

public class ConfigObjRequest extends ConfigObj {

	public ConfigObjRequest(Session sess, String stType, BasicLogger logger)
			throws Exception {
		super(sess, stType, logger);
		// TODO Auto-generated constructor stub
	}

	public String[] getNextStartTime() throws Exception {
		return (getValue("V1"));
	}

	public String[] getPrio() throws Exception {
		return (getValue("V2"));
	}

	public String[] getMachineKeys() throws Exception {
		return (getValue("V3"));
	}
	public String[] getTarget() throws Exception {
		return (getValue("V4"));
	}
	public String[] getSendTo() throws Exception {
		return (getValue("V5"));
	}
	
}
