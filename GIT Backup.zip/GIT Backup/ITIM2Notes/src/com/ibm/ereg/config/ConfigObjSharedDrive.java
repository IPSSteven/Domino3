package com.ibm.ereg.config;

import java.util.Vector;

import lotus.domino.Document;
import lotus.domino.Session;

public class ConfigObjSharedDrive extends ConfigObj {

	public ConfigObjSharedDrive(Session sess, String stType) throws Exception {
		super(sess, stType);
		// TODO Auto-generated constructor stub
	}
	
	public String getDriveLetter() throws Exception {
		return getValue("V1")[0];
	}
	
	public String getSharedDrive() throws Exception{
		if(!getValue("V5")[0].trim().isEmpty()) {
			Document docTemp = docConfig.getParentDatabase().createDocument();			
			Vector <String>vR= super.session.evaluate(getValue("V5")[0],docTemp);
			docTemp.recycle();
			return(vR.firstElement().toString());
		}
		return getValue("V2")[0];
	}
	
	public String getSharedDriveUser() throws Exception{
		if(!getValue("V6")[0].trim().isEmpty()) {
			Document docTemp = docConfig.getParentDatabase().createDocument();			
			Vector <String>vR= super.session.evaluate(getValue("V6")[0],docTemp);
			docTemp.recycle();
			return(vR.firstElement().toString());
		}
		return getValue("V3")[0];
	}
	public String getSharedDriveUserPW() throws Exception{
		return getValue("V4")[0];
	}

}
