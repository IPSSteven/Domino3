package com.ibm.ereg.config;

import java.util.HashMap;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.InputOutputLogger;

import lotus.domino.Database;
import lotus.domino.Session;
import lotus.domino.View;

public class ConfigObjSyncNCOUAR extends ConfigObj {

	private String domain;
	private String cfgUar;
	private String NabDBfilePath;
	private HashMap<String,String> countrycodeTargetService = new HashMap<String, String>();


	private Database dbNab;

	public ConfigObjSyncNCOUAR(Session sess, String type, AbstractLogger log) throws Exception {
		super(sess,type,log);

		String [] dummy = getValue("V1")[0].split("->");
		if(dummy.length < 3 ) throw new Exception("Error paramater 1 in config SynNcouar");
		domain = dummy[0];
		cfgUar = dummy[1];
		NabDBfilePath = dummy[2];

		// get all country codes
		ConfigObjCountryTable cfgCt = new ConfigObjCountryTable(sess);
		String [] pscs =cfgCt.getAllPSC();

		// get the nab where the views are
		ConfigObj cfgMailDomain = new ConfigObj(sess, "4>"+ domain, log);
		String server = cfgMailDomain.getValue("V1")[0];
		String MachineKey = super.getSMachineKey();
		ConfigObjReConcileITIM cfgRecon = new ConfigObjReConcileITIM(sess,AllConstants.EREGTOOLRC_CONFIG + MachineKey , (InputOutputLogger) log);
		NabDBfilePath = cfgRecon.getValue("V8")[0];
		dummy = NabDBfilePath.split(":");
		NabDBfilePath =dummy [0];
		dbNab = CommonFunctions.getDatabase(sess, server, NabDBfilePath);

		// get the views
		String[] Assignment = getValue("V4");
		for(String ass: Assignment) {
			dummy = ass.split("->");
			String stView = dummy[0];
			String stService = dummy[1];
			View vw = dbNab.getView(stView);
			String stSelect = vw.getSelectionFormula();
			vw.recycle();
			for(String psc:pscs) {
				if (stSelect.indexOf(psc) >0) {
					countrycodeTargetService.put(psc, stService);
				}
			}

		}
		
		dbNab.recycle();




		// TODO Auto-generated constructor stub
	}

	public HashMap<String, String> getCountrycodeTargetService() {
		return countrycodeTargetService;
	}

	public Database getDbNab() {
		return dbNab;
	}
	
	public String getUseFormulaOrview() throws Exception {
		return getValue("V2")[0];
	}
	
	public String getFormulaView() throws Exception {
		return getValue("V3")[0];
	}

		


}
