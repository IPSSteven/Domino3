package com.ibm.ereg.constants;

public class AllConstants {
	public static final String MACHINEKEY = "MachineKey";
	public static final String EREGTOOLSERVER = "eRegToolServer";
	public static final String EREGTOOLDB = "eRegToolDB";
	public static final String EREGTOOLVIEW = "($TypeSubject)";
	public static final String EREGTOOLRC_CONFIG = "32>ReConcileParameterITIM->";
	public static final String NABDBNAME ="names.nsf";
	public static final String EXTENDED_DIRNEW ="edircat/scnedcww.nsf";
	public static final String EXTENDED_DIRNEW_SERVER ="D51HUB01/51/H/IBM";
	public static final String EXTENDED_DIRNEW_VIEW ="ID Mgmt\\Lookup";
	public static final String EXTENDED_DIR ="dircat/edcww.nsf";
	public static final String NABVIEWFORSYNCGATEWAY = "People\\IGAIBM";
	public static final String NABVIEWFORRECONCILE ="People\\People by Shortname";
	public static final String NABVIEWFORDENYACCESS ="Server\\Deny Access Groups";
	public static final String MEDIATORECONCILEDB ="45>ReconcileDBMediator";
	public static final String MEDIATORECONCILEDBBCK ="45>ReconcileDBMediatorBackup";
	public static final String MEDIATORECONCILECONF ="45>ReconcileConfMediator";
	public static final String MEDIATORECONCILECONFBCK ="45>ReconcileConfMediatorBackup";
	public static final String MEDIATOR_NOTES_NOREUSE_PPROP_FILE= "NoReuse.properties";
	public static final String MEDIATOR_NOTES_NOREUSE_SINGLEVAL = "45>Notes_NoReuse_SingleVal";
	public static final String MEDIATOR_NOTES_NOREUSE_SINGLEVAL_PPROP= "Notes.NoReuse.SingleVal.Cfg";
	public static final String MEDIATOR_NOTES_NOREUSE_MULTIVAL = "45>Notes_NoReuse_MultiVal";
	public static final String MEDIATOR_NOTES_NOREUSE_MULTIVAL_PPROP= "Notes.NoReuse.MultiVal.Cfg";
	public static final String MEDIATOR_NOTES_NOREUSE_IDS = "45>Notes_NoReuse_IDS";
	public static final String MEDIATOR_NOTES_NOREUSE_DOMAINS = "32>Notes_NoReuse_Domains->";
	public static final String MEDIATOR_NOTES_NOREUSE_NOEMA_DOMAINS = "32>Notes_NoReuse_NOEMEA_Domains";
	public static final String NOTES_NOREUSE_MASTERDATABASE = "9>Notes_NoReuse_Master_Database";
	//public static final String MEDIATORECONCILECONFBCK ="45>ReconcileConfMediatorBackup";
	public static final String MEDIATOREQUESTDB ="45>MediatorRequestDB_";
	
	
	public static final String ITIMREQUESTCHECK ="46>ITIM_RequestCheck_";	
	public static final String MAIL_SYSTEM = "46>MailSystem";
	public static final String MEDIATOREQUESTDBBCK ="45>MediatorRequestDBBackup_";
	
	public static final String RECONCILE_PARAMETER ="14>ReconcileParameter";
	public static final String TYPE_MACHINEPROFILE = "1";
	public static final String TYPE_AGENT = "2";
	public static final String TYPE_REQUEST = "3";
	public static final String TYPE_COUNTRY = "7";
	public static final String TYPE_DB = "9";
	public static final String TYPE_FTP = "12";
	public static final String TYPE_DRAFT = "13";
	public static final String TYPE_OSM_PARAM= "17";
	
	public static final String UARSUBJECT = "UAR";
	public static final String UARSUBJECT2 = "UAR2";
	
	public static final Object NCOUAR_ENCRYPTION_KEY = "NCOUAR_ITIM";
	public static final String NCOUARVIEWBYFULLNAME ="Person\\by Fullname";
	public static final String NCOUARVIEWBYSHORTNAME ="Person\\by Shortname";
	public static final String NCOUARVIEWITIMEXPORT ="(ITIMEXPORT)";
	public static final String NCOUARVIEWIDWITHOUTVAULTENRTRY ="(IdsWithoutIdFilesInVault)";
	public static final String SELECTVIEW = "\"MEDIATOR\".\"LNREQUEST";
	public static final String GROUPIDENTIFIER  = "Internet Address Reuse-";
	
	public static final String DB2PROPERTIES  = "db2properties.txt";
	public static final String CONFIG_PROPERTIES  = "config.properties";
	
	public static final String EREG_NOTESID_SHORTNAME = "ereg";
	public static final String EREG_NOTESID_DOMAIN ="IBMDE";
	
	public static final String ENVIRONMENT_AGENTNAME = "ENVAGENTNAME";
	public static final String ENVIRONMENT_NOTESUNID = "NOTESUNID";
	public static final String ADMINP_ALERT ="43>AdminpAlert";
	
	public static final String SYN_NCOUAR ="14>SyncNCOUAR";
}
