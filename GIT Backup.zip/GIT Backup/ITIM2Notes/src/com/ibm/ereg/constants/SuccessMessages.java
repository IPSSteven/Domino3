/**
 * 
 */
package com.ibm.ereg.constants;

import java.lang.reflect.Field;

/**
 * @author Kurt Raiser
 *
 */
public class SuccessMessages {
	final public static String AU = "Id created successfully";
	final public static String CP = "Id changed via CP successfully";
	final public static String HU = "Id changed via HU successfully";
	final public static String DU = "Id suspended successfully";
	final public static String KU = "Id deleted successfully";
	final public static String PW = "Password reset successfully";
	final public static String RB = "Id rebuilt successfully";
	final public static String RN = "Id renamed successfully";
	final public static String RS = "Id resumed successfully";
	final public static String RV = "Id revoked successfully";
	
	public static String getMsg(String stType){
		Class clazz = SuccessMessages.class;
		try {
			Field f = clazz.getDeclaredField(stType);
			Object o = f.get(null);
			return o.toString();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return "";
		} catch (NoSuchFieldException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		}
	}
	public static void main(String [] args){
		Class c = SuccessMessages.class;
		Field []fs = c.getDeclaredFields();
		for(Field f: fs){
			System.out.println(f.getName());
		}
		System.out.println(SuccessMessages.getMsg("AU"));
	}

}
