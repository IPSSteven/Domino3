package com.ibm.ereg.domino2020.sync;

public class NcouarBean {
	private String MailDomain;
	private String ShortName;
	private String FirstName;
	private String MiddleInitial;
	private String LastName;
	private String FullName;
	private String InternetAddress;
	private String MailSystem;
	private String Nabserial;
	private String NabPsc;
	private String Service;
	private String LNAdapeterCustom;
	private String Status;
	private String Classification;
	private String OwnerCountry;
	private String OwnerSerial;
	private String IdFileInVault;
	private String History;
	public String getMailDomain() {
		return MailDomain;
	}
	public void setMailDomain(String mailDomain) {
		MailDomain = mailDomain;
	}
	public String getShortName() {
		return ShortName;
	}
	public void setShortName(String shortName) {
		ShortName = shortName;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getMiddleInitial() {
		return MiddleInitial;
	}
	public void setMiddleInitial(String middleIntial) {
		MiddleInitial = middleIntial;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getFullName() {
		return FullName;
	}
	public void setFullName(String fullName) {
		FullName = fullName;
	}
	public String getInternetAddress() {
		return InternetAddress;
	}
	public void setInternetAddress(String internetAddress) {
		InternetAddress = internetAddress;
	}
	public String getMailSystem() {
		return MailSystem;
	}
	public void setMailSystem(String mailSystem) {
		MailSystem = mailSystem;
	}
	public String getService() {
		return Service;
	}
	public void setService(String service) {
		Service = service;
	}
	public String getLNAdapeterCustom() {
		return LNAdapeterCustom;
	}
	public void setLNAdapeterCustom(String lNAdapeterCustom) {
		LNAdapeterCustom = lNAdapeterCustom;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getClassification() {
		return Classification;
	}
	public void setClassification(String classification) {
		Classification = classification;
	}
	public String getOwnerCountry() {
		return OwnerCountry;
	}
	public void setOwnerCountry(String ownerCountry) {
		OwnerCountry = ownerCountry;
	}
	public String getOwnerSerial() {
		return OwnerSerial;
	}
	public void setOwnerSerial(String ownerSerial) {
		OwnerSerial = ownerSerial;
	}
	public String getIdFileInVault() {
		return IdFileInVault;
	}
	public void setIdFileInVault(String idFileInVault) {
		IdFileInVault = idFileInVault;
	}
	public String getHistory() {
		return History;
	}
	public void setHistory(String history) {
		History = history;
	}
	public String getNabserial() {
		return Nabserial;
	}
	public void setNabserial(String nabserial) {
		Nabserial = nabserial;
	}
	public String getNabPsc() {
		return NabPsc;
	}
	public void setNabPsc(String nabPsc) {
		NabPsc = nabPsc;
	}
	
	
}
