package com.ibm.ereg.domino2020.sync;

import java.util.HashMap;

import com.ibm.ereg.config.ConfigObjCountryTable;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.config.ConfigObjSyncNCOUAR;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.AbstractLogger;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.RichTextItem;
import lotus.domino.Session;
import lotus.domino.View;

public class NcouarFactory {
	
	private AbstractLogger log;
	private ConfigObjCountryTable cfgCt;
	private Session session;
	private static ConfigObjNCOUAR cfgUAR = null;
	private static HashMap<String, String> CountryCodeTargeService = null;
	
	public  NcouarFactory(Session s, AbstractLogger alog) throws Exception {
		this.session = s;
		this.log = alog;
		cfgCt = new ConfigObjCountryTable(session);
		if (CountryCodeTargeService == null) {
			ConfigObjSyncNCOUAR cfgSyncNcoar = new ConfigObjSyncNCOUAR(s, AllConstants.SYN_NCOUAR, alog);
			CountryCodeTargeService = cfgSyncNcoar.getCountrycodeTargetService();
			cfgSyncNcoar.recycle();
		}
		if (cfgUAR == null)cfgUAR = new ConfigObjNCOUAR(s, log);
	}
	
	public Document createNcouarDocument (Document docNab) {
		NcouarBean uarBean = new NcouarBean();
		String stCountry;
		String stPscCode;
		String service;
		try {
			
			uarBean.setMailDomain(docNab.getItemValueString("MailDomain"));
			
			
			uarBean.setShortName(docNab.getItemValue("ShortName").lastElement().toString());
			uarBean.setFirstName(docNab.getItemValueString("Firstname"));
			uarBean.setMiddleInitial(docNab.getItemValueString("MiddleInitial"));
			uarBean.setLastName(docNab.getItemValueString("LastName"));
			uarBean.setFullName(docNab.getItemValue("FullName").firstElement().toString());
			uarBean.setInternetAddress(docNab.getItemValueString("InternetAddress"));
			uarBean.setMailSystem(docNab.getItemValueString("MailSystem"));
			uarBean.setNabserial(docNab.getItemValueString("Empnum"));
			uarBean.setNabPsc(docNab.getItemValueString("Empcc"));
			stPscCode = docNab.getItemValueString("Empcc");
			service = CountryCodeTargeService.get(stPscCode);
			uarBean.setService(service);
			/*if (docNab.getItemValueString("MailDomain").equals(docNab.getItemValueString("NodeName"))){
				uarBean.setService(docNab.getItemValueString("MailDomain"));
			}else {
				uarBean.setService(docNab.getItemValueString("NodeName"));
			}
			if (uarBean.getFullName().indexOf("Contr/IBM")>0) {
				uarBean.setClassification("E");
			}else {
				uarBean.setClassification("I");
			}*/
			
			stCountry = cfgCt.getCountryNumber(docNab.getItemValueString("Empcc"));
			uarBean.setOwnerCountry(stCountry);
			uarBean.setOwnerSerial(uarBean.getNabserial()+uarBean.getNabPsc());
			uarBean.setIdFileInVault("0");
			createNcouarDocument(uarBean);
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public Document createNcouarDocument (NcouarBean uarBean) throws NotesException {
		
		
		Database dbUAR = cfgUAR.getDbNCOUAR( uarBean.getMailDomain());
		Document docUar = dbUAR.createDocument();
		docUar.replaceItemValue("Form", "User");
		docUar.replaceItemValue("Domain", uarBean.getMailDomain());
		docUar.replaceItemValue("LNShortname", uarBean.getShortName());
		docUar.replaceItemValue("Firstname", uarBean.getFirstName());
		docUar.replaceItemValue("MiddleInitial", uarBean.getMiddleInitial());
		docUar.replaceItemValue("LastName", uarBean.getLastName());
		docUar.replaceItemValue("InternetAddress", uarBean.getInternetAddress());
		docUar.replaceItemValue("InternetAddress", uarBean.getInternetAddress());
		docUar.replaceItemValue("MailSystem", uarBean.getMailSystem());
		docUar.replaceItemValue("EmpNo", uarBean.getNabserial());
		docUar.replaceItemValue("ASODomain", uarBean.getMailDomain());
		docUar.replaceItemValue("LNAdapterCustom", uarBean.getLNAdapeterCustom());
		docUar.replaceItemValue("State", uarBean.getStatus());
		docUar.replaceItemValue("Classification", uarBean.getClassification());
		docUar.replaceItemValue("Dept_id", uarBean.getOwnerSerial());
		docUar.replaceItemValue("idFileInVault", uarBean.getIdFileInVault());
		RichTextItem rtfHistory = docUar.createRichTextItem("History");
		DateTime dte = session.createDateTime("Today");
		dte.setNow();
		rtfHistory.appendText(dte.getDateOnly() + " "+ dte.getGMTTime() + ": " + "created Ncouar document durin 2020 migration by " +
		session.getUserName());
		docUar.save();
		rtfHistory.recycle();
		dte.recycle();
		docUar.recycle();
		return docUar;
		
	}
	
	
	public boolean setService(String Domain, String Shortname) {
		View vwSearch = cfgUAR.getVwITIMEXPORT(Domain);
		String stpsc ;
		String stService;
		try {
			Document docUar = vwSearch.getDocumentByKey(Domain+Shortname);
			if(docUar == null) {
				return false;
			}else {
				stpsc = docUar.getItemValueString("Empcc");
				stService = CountryCodeTargeService.get(stpsc);
				docUar.replaceItemValue(Domain, stService);
				docUar.save();
				docUar.recycle();
			}
			return true;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}

}
