package com.ibm.ereg.domino2020.sync;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjSyncNCOUAR;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

public class SyncNcour extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SyncNcour syNc = new SyncNcour();
		syNc.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();

		Session sess = NotesFactory.createSessionWithFullAccess("Used2know.");
		Database dbLog;
		Database dbNab;
		Document docNab;
		String stKey;
		String FormulaView;
		try {
			dbLog = CommonFunctions.getLogDB(sess);
			InputOutputLogger log = new InputOutputLogger(sess, dbLog,"SyncNcouar", LogLevel.INFO);
			ConfigObjSyncNCOUAR cfgSynUAR = new ConfigObjSyncNCOUAR(sess, AllConstants.SYN_NCOUAR, log);
			dbNab = cfgSynUAR.getDbNab();
			FormulaView = cfgSynUAR.getFormulaView();
			
			NcouarFactory nf = new NcouarFactory(sess, log);
			
			if(cfgSynUAR.getUseFormulaOrview().equalsIgnoreCase("F")) {
				DocumentCollection dccSync = dbNab.search(FormulaView);
				Document docRecyle;
				docNab = dccSync.getFirstDocument();
				while (docNab != null) {
					docRecyle = docNab;
					docNab = dccSync.getNextDocument(docNab);
					//docNab.getItemValueString("MailDomain").equals(docNab.getItemValueString("NodeName")) ?
					//		docNab.getItemValueString("MailDomain") : docNab.getItemValueString("NodeName");
					//docNab.getItemValue("ShortName").lastElement();
					nf.setService(docNab.getItemValueString("MailDomain").equals(docNab.getItemValueString("NodeName")) ?
							docNab.getItemValueString("MailDomain") : docNab.getItemValueString("NodeName"), docNab.getItemValue("ShortName").lastElement().toString());
					docRecyle.recycle();
				}
				
				
			}else {
				View vwSearch = dbNab.getView(FormulaView);
				ViewEntryCollection vecSync = vwSearch.getAllEntries();
				ViewEntry veRec;
				ViewEntry veNab = vecSync.getFirstEntry();
				while(veNab != null) {
					veRec = veNab;
					veRec = vecSync.getNextEntry(veNab);
					docNab = veRec.getDocument();
					nf.setService(docNab.getItemValueString("MailDomain").equals(docNab.getItemValueString("NodeName")) ?
							docNab.getItemValueString("MailDomain") : docNab.getItemValueString("NodeName"), docNab.getItemValue("ShortName").lastElement().toString());
					docNab.recycle();
					veRec.recycle();
				}
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}
	
	


}
