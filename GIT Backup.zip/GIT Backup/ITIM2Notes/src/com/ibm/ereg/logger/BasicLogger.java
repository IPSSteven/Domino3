package com.ibm.ereg.logger;


import java.util.Map;


import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.Item;
import lotus.domino.NotesException;
import lotus.domino.RichTextItem;
import lotus.domino.RichTextStyle;
import lotus.domino.Session;
import com.ibm.ereg.constants.AllConstants;

public abstract class BasicLogger extends AbstractLogger{
	Session sess;
	protected Database dbLog;
	protected Document docLog = null;
	protected DateTime dteNow;
	protected RichTextItem body = null;
	
	public BasicLogger(Session session, Database dbLog)
			throws Exception {
		// TODO Auto-generated constructor stub
		sess = session;
		pln("In the basic logger " );
		try {
			// check the log level
			dteNow = session.createDateTime("Today");
			this.dbLog = dbLog;
			pln("In the basic logger ...");
			// set up the log document
			if(session.getAgentContext() == null){
				Map<String, String> env = System.getenv();
				String unid = env.get(AllConstants.ENVIRONMENT_NOTESUNID);
				pln("Agent Context is null got he unid:" + " from env");
				try{
				docLog = dbLog.getDocumentByID(unid);
				}catch(NotesException ne){
					pln ("log document not found");
				}
				
			}else{
				pln("Agentcontext not null");
			}
			
			if (docLog == null){
				docLog = dbLog.createDocument();
				pln("log doc is created");
			}
			LogDocStatus lds = new LogDocStatus(docLog);
			lds.setRunStatus(LogDocStatus.RunStatusRunning);
			refreshLog(lds);
			
			docLog.replaceItemValue("Form", "Log");
			
			
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			logAction(e.toString());
			e.printStackTrace();
			throw e;
		}
	}
	public BasicLogger(Session session, Document docLog){
		try {
			sess = session;
			dteNow = session.createDateTime("Today");
			this.dbLog = docLog.getParentDatabase();
			this.docLog = docLog;
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Document getDocLog() {
		return docLog;
	}

	public Database getDbLog() {
		return dbLog;
	}

	public Session getSess() {
		return sess;
	}

	public void closeLog(LogDocStatus lds){
		try {
			refreshLog(lds);
			docLog.replaceItemValue("EndTime", dteNow);
			docLog.save();
		/*	if(docLog != null) docLog.recycle();
			
			if(dbLog != null) dbLog.recycle();
			if(dteNow != null) dteNow.recycle();
			if(sess != null) sess.recycle();	*/
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void refreshLog(LogDocStatus lds){
		try {
			docLog.replaceItemValue("ITIMResponseError",lds.getITIMResponseError());
			docLog.replaceItemValue("RunStatus", lds.getRunStatus());
			docLog.replaceItemValue("ReturnCode", lds.getReturnCode());
			docLog.replaceItemValue("Status", lds.getStatus());
			docLog.replaceItemValue("ErrorCode", lds.getErrorCode());
			docLog.replaceItemValue("FTPok", lds.getFTPok());
			docLog.save();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	protected boolean logAction(String stLog) {
		String content = null;
		
		RichTextStyle rts = null;
		Item item = null;
		try {
			try{
				dteNow.setNow(); // sometimes the date lose it object,
			}catch(NotesException e) {
				System.out.println(e.getLocalizedMessage());
				dteNow = sess.createDateTime("Today");
				dteNow.setNow();
			}
			if (docLog != null){
				//pln("Log not null");
				// find body
				item = docLog.getFirstItem("Body");
				if(item != null){
					//pln("item not null");
					if(item.getType() != Item.RICHTEXT){
						pln("item != rtv");
						content = item.getText();
						docLog.removeItem("Body");
						docLog.save();
						body = docLog.createRichTextItem("Body");
						rts = sess.createRichTextStyle();
						rts.setFont(RichTextStyle.FONT_HELV);
						rts.setFontSize(8);
						body.appendStyle(rts);
					}else{
						body = (RichTextItem)item;
						//pln("item = rtv");
					}
				}else{
					//pln("item = null");
					body = docLog.createRichTextItem("Body");
					rts = sess.createRichTextStyle();
					rts.setFont(RichTextStyle.FONT_HELV);
					rts.setFontSize(8);
					body.appendStyle(rts);
				}
				
				//append to body
				body.addNewLine();
				body.appendText( dteNow.getDateOnly() + " " + dteNow.getTimeOnly() + " >>>> " + stLog);
				docLog.save();
				body.recycle();
				if (item != null)item.recycle();
				if (rts != null)rts.recycle();
			}else{
				throw new Exception ("Log document not found");
			}
			return true;
		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			System.out.println("NotesExcepiton during log action in thread " + Thread.currentThread().getName());
			e1.printStackTrace();
			return false;
		} catch (Exception e){
			System.out.println("Logging not working");
			return false;
		}
		
	}
	private void pln(String stText){
		//System.out.println(stText);
	}

	public void logActionLevel(byte bLevel, String stLog) {
		//logAction("loglevels" + bLevel + ", "+ checkLogLevel + " " + (bLevel >= checkLogLevel));
		if (bLevel >= checkLogLevel) {
			//System.out.println ("loglevels" + bLevel + ", "+ checkLogLevel);
			logAction(stLog);
		}
	}
	
}
