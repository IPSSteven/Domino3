/**
 * 
 */
package com.ibm.ereg.logger;

import lotus.domino.Document;
import lotus.domino.NotesException;

/**
 * @author Kurt Raiser
 *
 */
public class LogDocStatus {
	public final static String RunStatusStopped = "Stopped";
	public final static String RunStatusRunning = "Running";
	public final static String RunStatusNull = "0";
	
	public final static String StatusDone = "done";
	public final static String StatusNew = "new";
	public final static String StatusPending = "Pending";
	
	public final static String ReturnCodePending = "";
	public final static String ReturnCodeOK = "0";
	
	public final static String ErrorCodeDB2Error = "Db2Error";
	public final static String ErrorCodeBlank = "";
	
	public final static String FTP_OK="1";
	public final static String FTP_NOT_OK="0";
	
	private String RunStatus;
	private String Status;
	private String ErrorCode;
	private String ReturnCode;
	private String ITIMResponseError;
	private String FTPok;

	
	
	public LogDocStatus(Document logdoc) {
	//public LogDocStatus() {
		super();
		try {
			RunStatus = logdoc.getItemValueString("RunStatus");
			Status = logdoc.getItemValueString("Status");
			ErrorCode = logdoc.getItemValueString("ErrorCode");
			ReturnCode = logdoc.getItemValueString("ReturnCode");
			FTPok = logdoc.getItemValueString("FTPok");
			ITIMResponseError = "";
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getITIMResponseError() {
		return ITIMResponseError;
	}

	public void setITIMResponseError(String iTIMResponseError) {
		ITIMResponseError = iTIMResponseError;
	}

	public String getRunStatus() {
		return RunStatus;
	}
	public void setRunStatus(String runStatus) {
		RunStatus = runStatus;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
		if (Status.equals(LogDocStatus.StatusPending)) ReturnCode = LogDocStatus.ReturnCodePending; 
	}
	public String getErrorCode() {
		return ErrorCode;
	}
	public void setErrorCode(String errorCode) {
		ErrorCode = errorCode;
	}
	
	public String getReturnCode() {
		return ReturnCode;
	}
	public void setReturnCode(String returnCode) {
		ReturnCode = returnCode;
	}
	public void setOKRunning(){
		setITIMResponseError("");
		setRunStatus(LogDocStatus.RunStatusRunning);
		
		//setStatus(LogDocStatus.StatusNew);
	}
	
	public void setOKDone(){
		setRunStatus(LogDocStatus.RunStatusNull);
		setStatus(LogDocStatus.StatusDone);
		setErrorCode(LogDocStatus.ErrorCodeBlank);
	}
	
	public void setRunning(){
		setRunStatus(LogDocStatus.RunStatusRunning);
		
		//setStatus(LogDocStatus.StatusNew);
	}

	public String getFTPok() {
		return FTPok;
	}

	public void setFTPok(String fTPok) {
		FTPok = fTPok;
	}
	
}
