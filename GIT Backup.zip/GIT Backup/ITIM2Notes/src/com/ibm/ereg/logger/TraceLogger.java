package com.ibm.ereg.logger;

import java.rmi.RemoteException;

import mediator.beans.LogEntry;
//import mediator.rmi.ExecutionCaller;
import mediator.rmi.TraceExecutionCallerSSL;

public class TraceLogger extends AbstractLogger {


	private LogEntry le;

	private final byte RcSuccess = (byte)0; 
	private final byte RcSuccessWithWarnung = (byte)4;
	private final byte RcError = (byte)8;
	private final String WorkingDir = "c:\\ereg\\Scheduler\\";


	public TraceLogger(String ProcessName, String ComponentName, String TransactionParam) throws RemoteException{
		le = new LogEntry();
		le.setProcessName(ProcessName);
		le.setComponentName(ComponentName);
		le.setTransaktionParam(TransactionParam);
	}

	public byte getRcSuccess() {
		return RcSuccess;
	}

	public byte getRcSuccessWithWarnung() {
		return RcSuccessWithWarnung;
	}

	public byte getRcError() {
		return RcError;
	}



	@Override
	public void logActionLevel(byte rcCode, String stLog) {
		if (le != null)le.setReturnCode(Byte.toString(rcCode));
		logAction(stLog);
	}

	@Override
	protected boolean logAction(String stLog) {
		// TODO Auto-generated method stub
		try{
		if (le != null)le.setLogEntry(stLog);
		else return false;
		TraceExecutionCallerSSL tec = new TraceExecutionCallerSSL();
		String stRet = tec.log(le, WorkingDir);
		//String stRet = ExecutionCaller.log(le);
		//String stRet ="0";
		if (stRet.contains("0")){
			return true;
		}else{
			return false;
		}
		}catch(RuntimeException re){
			System.out.println("Runtime Exception during ExecutionCaller in logger");
			re.printStackTrace();
			return false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

	}

}
