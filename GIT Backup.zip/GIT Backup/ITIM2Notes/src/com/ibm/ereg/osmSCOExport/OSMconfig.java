package com.ibm.ereg.osmSCOExport;

import java.util.HashMap;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.logger.BasicLogger;
import com.ibm.ereg.logger.LogLevel;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;

public class OSMconfig {
	private final String OSMDB = "osm.nsf";
	private final String OSMSERVCONF = "Server Configs";
	private Session session;
	private BasicLogger log;
	private HashMap<String,String> MailServerOSM;


	public OSMconfig(Session sess, String[]OsmServers, BasicLogger log) {
		super();
		this.session = sess;
		this.log = log;
		initClass(OsmServers);
		// TODO Auto-generated constructor stub
	} 
	
	private void initClass(String[] OsmServers){
		Database osmDB;
		String server;
		MailServerOSM = new HashMap<String, String>();
		for(String osmSer:OsmServers){
			
			osmDB = CommonFunctions.getDatabase(session, osmSer, OSMDB);
			try {
				View vwServ = osmDB.getView(OSMSERVCONF);
				Document docServ = vwServ.getFirstDocument();
				Document docRec;
				while(docServ != null){
					server = docServ.getItemValueString("Server");
					//System.out.println(server + ":" +osmSer);
					int pos = server.indexOf("/");
					server = (pos >0)?server.substring(0,pos):server;
					MailServerOSM.put(server, osmSer);
					docRec = docServ;
					docServ = vwServ.getNextDocument(docServ);
					docRec.recycle();
				}
				vwServ.recycle();
				osmDB.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, "OSM server config view not found");
				e.printStackTrace();
			}
			
			
			
		}
	}

	public HashMap<String, String> getMailServerOSM() {
		return MailServerOSM;
	}

}
