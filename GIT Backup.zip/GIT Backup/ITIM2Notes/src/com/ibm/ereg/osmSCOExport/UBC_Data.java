package com.ibm.ereg.osmSCOExport;

public class UBC_Data {
	private String Empcc;
	private String EmpNum;
	private String FullName;
	private String MailServer;
	private String MailFile;
	private String MailFileSize;
	private String ThresHold_3;
	public String getEmpcc() {
		return Empcc;
	}
	public void setEmpcc(String empcc) {
		Empcc = empcc;
	}
	public String getEmpNum() {
		return EmpNum;
	}
	public void setEmpNum(String empNum) {
		EmpNum = empNum;
	}
	public String getFullName() {
		return FullName;
	}
	public void setFullName(String fullName) {
		FullName = fullName;
	}
	public String getMailServer() {
		return MailServer;
	}
	public void setMailServer(String mailServer) {
		MailServer = mailServer;
	}
	public String getMailFile() {
		return MailFile;
	}
	public void setMailFile(String mailFile) {
		MailFile = mailFile;
	}
	public String getMailFileSize() {
		return MailFileSize;
	}
	public void setMailFileSize(String mailFileSize) {
		MailFileSize = mailFileSize;
	}
	public String getThresHold_3() {
		return ThresHold_3;
	}
	public void setThresHold_3(String thresHold_3) {
		ThresHold_3 = thresHold_3;
	}
	
	

}
