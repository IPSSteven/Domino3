package com.ibm.ereg.terminator;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class EregRequestTerminatorRunner extends NotesThread {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EregRequestTerminatorRunner ert = new EregRequestTerminatorRunner();
		ert.start();
	}
	

	
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("g02swim!");
		EregRequestTerminator ert = new EregRequestTerminator(s);
		ert.terminateRequests();
		ert.close();
		
	}
	
	

	
	

}
