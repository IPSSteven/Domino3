package com.ibm.ereg.test;

import java.util.regex.Pattern;

public class ApostropeTest {

	public final String allowedCharsGeneral = "[0-9a-zA-Z-.' ]*";
	public final String notAllowedCharsGeneral = "[^*]*";
	public final String allowedCharsFirstName = "[a-zA-Z-.' ]*";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApostropeTest at = new ApostropeTest();
		boolean bTest = at.isNameValid(at.allowedCharsGeneral, "O'reilly");
		System.out.println("test " + bTest);

	}
	
	private boolean isNameValid(String allowedChars, String sName){
		//not allowed chars are inverted by ^ which mean must not occur
		return (allowedChars == null || allowedChars.isEmpty() || sName == null || sName.isEmpty()) ? true : Pattern.matches(allowedChars,sName) & (Pattern.matches(notAllowedCharsGeneral,sName));	
	}

}
