package com.ibm.ereg.test;

import com.ibm.ereg.common.NotesDatabaseReplicaHandler;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class DatabaseReplicationTester extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DatabaseReplicationTester t = new DatabaseReplicationTester();
		t.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("go2bechtle.");
		try {
			NotesDatabaseReplicaHandler ndrd = new NotesDatabaseReplicaHandler(s, "D06DBL090","e_dir/eregtoo6.nsf");
			ndrd.getLocalReplicaAndReplicate(true, "Replica/eregToo6.nsf");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
