package com.ibm.ereg.test;

import com.ibm.ereg.config.ConfigObjMailSystem;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.FileLoger;
import com.ibm.mediator.eregreconcile.multithreading.ReconcileDataSingleton;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class MailSystemTester extends NotesThread{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MailSystemTester mt = new MailSystemTester();
		mt.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();

		Session s = NotesFactory.createSessionWithFullAccess("idjwmv89ja.");
		FileLoger flog = new FileLoger("c:\\temp\\loesch", "txt");

		try {
			ConfigObjMailSystem ms = new ConfigObjMailSystem(s, AllConstants.MAIL_SYSTEM, flog);

			ReconcileDataSingleton rs = ReconcileDataSingleton.getInstance();
			if(rs.getMailSystemReconcile() == null)	rs.setMailSystemReconcile(ms.getReconcileMailSystem());
			String mailSystem = rs.getMailSystemReconcile().get("");
			System.out.println(mailSystem);
			 mailSystem = rs.getMailSystemReconcile().get("1");
			 System.out.println(mailSystem);
			 mailSystem = rs.getMailSystemReconcile().get("3");
			 System.out.println(mailSystem);
			 mailSystem = rs.getMailSystemReconcile().get("5");
			 System.out.println(mailSystem);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}



}
