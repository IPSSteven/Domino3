package com.ibm.ereg.test;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class MailTest extends NotesThread {
	private String pw;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MailTest mt = new MailTest();
		mt.pw = args[0];
		mt.start();
	}
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess(pw);
		try {
			Database dblog = CommonFunctions.getLogDB(s);
			Document doc = dblog.createDocument();
			doc.replaceItemValue("Form", "Memo");
			doc.replaceItemValue("Subject", "Test.java");
			doc.replaceItemValue("SendTo", "Kurt Raiser1/Germany/Bechtle/IDE");
			doc.send();
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
