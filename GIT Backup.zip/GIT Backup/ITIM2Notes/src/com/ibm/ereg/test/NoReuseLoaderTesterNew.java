package com.ibm.ereg.test;


import com.ibm.mediator.NoReuseDataLoader.NoReuseLoaderRunnerNew;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class NoReuseLoaderTesterNew extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoReuseLoaderTesterNew nrt = new NoReuseLoaderTesterNew();
		nrt.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		String pw = "Used2know.";
		Session session = NotesFactory.createSessionWithFullAccess(pw);
		
		NoReuseLoaderRunnerNew nrr = new NoReuseLoaderRunnerNew(session,pw);
		nrr.setAgentName("(NoReuseLoaderRunner)|agNoReuseLoaderRunner");
		nrr.runLoader();

		
	}

}
