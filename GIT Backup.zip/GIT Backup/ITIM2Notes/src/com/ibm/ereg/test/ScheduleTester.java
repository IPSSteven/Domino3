package com.ibm.ereg.test;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.NotesException;
import lotus.domino.NotesThread;



public class ScheduleTester extends  NotesThread {
	private final long timeperiod = 10000; // 30 sec.

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long timeStart;
		long timeRemainUntilNextstart = 0;
		boolean bLoop = true;
		int i = 0;
		
		try {
			while (bLoop && i < 5){
				System.out.print("loop:"  +i+ "-");
				ScheduleTester st = new ScheduleTester();

				timeStart = System.currentTimeMillis();
				st.start();

				st.join(300000); // timeout after 5 minutes
				if(st.isAlive()){
					bLoop = false;
				}
				timeRemainUntilNextstart = st.timeperiod - System.currentTimeMillis() + timeStart;
				if (timeRemainUntilNextstart >0){
					Thread.sleep(timeRemainUntilNextstart);
				}
				i++;
				
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();

		System.out.println (CommonFunctions.getActDateRecon() + "-action");
	}


}
