package com.ibm.ereg.test;

import com.ibm.Ereg2Gateway.WSClient;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.config.ConfigObjSlack;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class SlackTest extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SlackTest st = new SlackTest();
		st.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("1Bestfriend!");
		try {
			ConfigObjSlack cfgSlack = new ConfigObjSlack(s, AllConstants.TYPE_DRAFT + ">Slack");
			String url =  cfgSlack.getProvUrl();
			String stText = cfgSlack.getText();
			Database dbEregLog = CommonFunctions.getDatabase(s, "D06DBL090", "e_dir/ereglog6.nsf");
			View vwBMach = dbEregLog.getView("Logs\\by Agent");
			Document docCheck = vwBMach.getDocumentByKey("ITIM_Recon");
			String stLink = docCheck.getNotesURL();
			int idxB = stLink.indexOf("@");
			int idxE = stLink.indexOf("/", idxB);
			String st2rep = stLink.substring(idxB, idxE);
			System.out.println(stLink);
			System.out.println(st2rep);
			stLink = stLink.replaceFirst(st2rep,"");
			System.out.println(stLink);
			String jsonStr = "{ \"text\": \"" +stText + stLink + "\"}" ;

			Database dbLog = CommonFunctions.getLogDB(s);
			//create the log document for the reconcile
			InputOutputLogger log = new InputOutputLogger(s, dbLog, "Reconcile ITIM - " + CommonFunctions.getActDateRecon(),
					LogLevel.FINEST);
			ConfigObjReConcileITIM cr = new ConfigObjReConcileITIM(s,
					AllConstants.EREGTOOLRC_CONFIG + "D", log);
			String informError = cr.getInformErrorSystem();
			if (informError != null && informError.toLowerCase().contains("slack")){
				WSClient wsClient = new WSClient() ;
				String reply = wsClient.doPost(url, jsonStr) ;
				System.out.println(reply);
			}

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}


		//String stLink = "Notes://"+ dbEregLog.getNotesURL() + "/" + dbEregLog.getFilePath()+ "/" +docCheck.getUniversalID() + "?OpenDocument";



		//String url =  "https://hooks.slack.com/services/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";

		try {

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
