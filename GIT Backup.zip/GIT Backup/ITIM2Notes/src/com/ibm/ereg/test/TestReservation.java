package com.ibm.ereg.test;

import java.rmi.RemoteException;

import com.ibm.ereg.logger.FileLoger;
import com.ibm.mediator.NoReuseData.ReservationData;
import com.ibm.mediator.NoReuseInterface.ResponseBasic;
import com.ibm.mediator.NoReuseLogic.NoReuseReservationHandler;
import com.ibm.mediator.connector.DB2ConnectData;

public class TestReservation {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub
		DB2ConnectData  db2Con= new DB2ConnectData();
		db2Con.setIPAddress("prdbcraw3gen05.w3-969.ibm.com");
		db2Con.setClass("com.ibm.db2.jcc.DB2Driver");
		db2Con.setDB2Database("MEDIATOR");
		db2Con.setURL("jdbc:db2://");
		db2Con.setPort(60000);
		db2Con.setdb2LookupView("NOREUSE.NOREUSE_LOOKUP");
		db2Con.setUserid("ereg");
		db2Con.setPassword("W0rkhard4themoney!");
		
		FileLoger fLog = new FileLoger("testRes", "log");
		
	
		ReservationData rdat = new ReservationData();
		rdat.setShortName("test");
		rdat.setCreationDate("2200623");
		rdat.setEMailAddress("LastNameOnly@ibm.com");
		//dummy = new String[]{"E1", "e2", "E3"} ;
		rdat.setEMailAlias(new String[]{"E1", "e2", "E3"});
		rdat.setFirstName("");
		rdat.setLastName("LastNameOnly");
		rdat.setFullName("LastNameOnly");
		
		rdat.setFullNameAlias(new String[] {"l1", "l2", "l3"});
		rdat.setSerialNumberPSC("123456724");
		
		
		NoReuseReservationHandler nrrh = new NoReuseReservationHandler(fLog, db2Con);
		try {
		ResponseBasic rb =	nrrh.createReservation(rdat);
		System.out.println("Error= " +rb.getErrDescription() + rb.getHasError());
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
				
	}

}
