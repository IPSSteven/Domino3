package com.ibm.ereg.test;

import com.ibm.Ereg2SCN.SCNApi;
import com.ibm.Ereg2SCN.SCNUploadResponse;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjSCNAPI;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.samlrest.scn.SamlRestClientException;

import lotus.domino.Agent;
import lotus.domino.AgentContext;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;



public class TestSCNUpload extends NotesThread {
	private Session session;
	private Database dbLog;
	private Document docLog;
	private RequestLogger log;
	private String idFile;
	private String pw; 
	private String InternetAddress;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TestSCNUpload tu = new TestSCNUpload();
		tu.start();

	}
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		session = NotesFactory.createSessionWithFullAccess("sum16mer.");
		try {
			getLogDoc();

			ConfigObjSCNAPI confSCN = new ConfigObjSCNAPI(session, "12>SCNAPI", log);
			String account = confSCN.getSCNAccount();
			String accountPassword = confSCN.getSCNAccountPassword();
			//AgentContext agentContext = session.getAgentContext();
			idFile = docLog.getItemValueString("GetIdFileLocal");
			pw = docLog.getItemValueString("Password");
			InternetAddress = docLog.getItemValueString("INTERNETADDRESS");
			if(checkData()){
				SCNApi scnAPI;

				scnAPI = new SCNApi(account,accountPassword);

				if(scnAPI.isIDinSCN(InternetAddress)){
					log.logActionLevel(LogLevel.SEVERE, "id - file already in SCN");
					docLog.replaceItemValue("GetUploadError", "id file not uploaded");
				}else{
					SCNUploadResponse res = scnAPI.uploadIDinSCN(idFile, InternetAddress, pw);
					if(res.isUpLoadSuccessfull()){
						log.logActionLevel(LogLevel.INFO, "id - file uploaded successful");
						docLog.replaceItemValue("GetUploadError", "0");
					}else{
						log.logActionLevel(LogLevel.SEVERE, "id - File not uploaded");
						log.logActionLevel(LogLevel.SEVERE, "Return code:" +  res.getCode());
						log.logActionLevel(LogLevel.SEVERE, "Return message:" +  res.getMessage());
						docLog.replaceItemValue("GetUploadError", "id file not uploaded");
					}
				}
				docLog.save();
			}
		} catch (SamlRestClientException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void getLogDoc() throws Exception{
		try {
			String stUnid;
			AgentContext agCon;
			Agent ag;

			dbLog  = CommonFunctions.getLogDB(session);
			agCon = session.getAgentContext();
			if (agCon == null){
				stUnid = "1296BDA";
				stUnid ="12D4C8A";
			}else{
				ag = agCon.getCurrentAgent();
				stUnid = ag.getParameterDocID();
			}

			docLog= dbLog.getDocumentByID(stUnid);
			log = new RequestLogger(session, docLog);

			log.setCheckLogLevel(LogLevel.FINEST);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
	}
	private boolean checkData(){
		if(InternetAddress.isEmpty()){
			log.logActionLevel(LogLevel.SEVERE, "Internet address is empty");
			return false;
		}

		if(idFile.isEmpty()){
			log.logActionLevel(LogLevel.SEVERE, "id file is empty");
			return false;
		}
		if (pw.isEmpty()){
			log.logActionLevel(LogLevel.SEVERE, "Password is empty");
			return false;
		}
		return true;
	}

}
