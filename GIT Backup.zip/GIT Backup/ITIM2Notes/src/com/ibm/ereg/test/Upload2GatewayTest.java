package com.ibm.ereg.test;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Map;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjUploadSCN;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class Upload2GatewayTest extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Upload2GatewayTest u2vt = new Upload2GatewayTest();
		u2vt.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("go2bechtle.");
		process(s);
	}
	
	private void process(Session s) {
		try {
			
		
			//ReconcileItimRunner rrr = new ReconcileItimRunner(sess);
			//rrr.runNotes();
			// new
			Database dbLog = CommonFunctions.getLogDB(s);
			InputOutputLogger log = new InputOutputLogger(s, dbLog, "Upload to Gateway vault" + CommonFunctions.getActDateRecon(),
					LogLevel.FINEST);
			//create the log document for the reconcile

			ConfigObjUploadSCN UlScn = new ConfigObjUploadSCN(s,"12>UpLoadSCN");
			String fp = UlScn.getPath2java();
			fp = "C:\\Notes\\jvm\\bin\\java";
			String tmpDir = UlScn.getTemporyDir4Uload()[0];
			log.logActionLevel(LogLevel.INFO, "Get Config is ready path 2 java" +  fp + " temp dir " + tmpDir);
			
			ArrayList<String> sComm = new ArrayList<String>();
			//sComm.add("cmd.exe");
			//sComm.add("/C");
			sComm.add(fp);
			//sComm.add("-version");	
			sComm.add("-Xmx1536m");
			sComm.add("-Xms1024m");
			sComm.add("-Dfile.encoding=UTF-8");
			
			sComm.add("com.ibm.Load2VaultGateWay.mediator.Upload2Gateway");
			sComm.add(tmpDir);
			 
			
			ProcessBuilder pb = new ProcessBuilder(sComm);
			//ProcessBuilder pb = new ProcessBuilder("C:\\Notes\\jvm\\bin\\java", "com.ibm.mediator.eregreconcile.multithreading.ReconcicleProccessRunner", pw);
			Map<String,String> environ = pb.environment();
			environ.put("Path", environ.get("Path")+ ";C:\\notes");
			//environ.put(AllConstants.ENVIRONMENT_NOTESUNID, log.getDocLog().getNoteID());
			//environ.put(AllConstants.ENVIRONMENT_AGENTNAME, agentContext.getCurrentAgent().getName());
			pb.redirectErrorStream(true);
			
			Process process = pb.start();
			
			InputStream is = process.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			String line;
			while((line= br.readLine()) != null){
				pln(line);
			//	log.logActionLevel(LogLevel.INFO, line);
			}
			br.close();
			pln("ready!");
			log.logActionLevel(LogLevel.INFO, "ready !");
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKDone();
			log.closeLog(lds);
			

		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	private void pln(String s){
		System.out.println(s);
	}

}
