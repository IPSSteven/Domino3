package com.ibm.mediator.NoReuseData;

import java.io.Serializable;

import com.ibm.ereg.common.CommonFunctions;

public class DeleteNoReuseData implements Serializable {

	private static final long serialVersionUID = -487997976789180521L;
	
	
	public class DeleteNoReuseDataInputResult implements Serializable{
		/**
		 * 
		 */
		private static final long serialVersionUID = 5127603679669160953L;
		private String stErrorDescription;
		private boolean bhasError;
		private DeleteNoReuseData.DeleteNoReuseDataInput Input;
		private String [] suppressedNames;
		
		
		public DeleteNoReuseData.DeleteNoReuseDataInput getInput() {
			return Input;
		}
		public void setInput(DeleteNoReuseData.DeleteNoReuseDataInput input) {
			Input = input;
		}
		public String getStErrorDescription() {
			return stErrorDescription;
		}
		public void setStErrorDescription(String stErrorDescription) {
			this.stErrorDescription = stErrorDescription;
		}
		public boolean isBhasError() {
			return bhasError;
		}
		public void setBhasError(boolean bhasError) {
			this.bhasError = bhasError;
		}
		public String[] getSuppressedNames() {
			return suppressedNames;
		}
		public void setSuppressedNames(String[] suppressedNames) {
			this.suppressedNames = suppressedNames;
		}
		
	}
	
	public class DeleteNoReuseDataInput implements Serializable{
		
		private static final long serialVersionUID = 622707214802654179L;
		
	
		String stName2Delete;
		String stRequestor;
		String stReason;
		String stDate;
		String stNoValidReason;
		
		public DeleteNoReuseDataInput(){
			stDate = CommonFunctions.getActDateRecon();
		}
		
		public String getStName2Delete() {
			return stName2Delete;
		}
		public void setStName2Delete(String stName2Delete) {
			this.stName2Delete = stName2Delete;
		}
		public String getStRequestor() {
			return stRequestor;
		}
		public String getStNoValidReason() {
			return stNoValidReason;
		}

		public void setStRequestor(String stRequestor) {
			this.stRequestor = stRequestor;
		}
		public String getStReason() {
			return stReason;
		}
		public void setStReason(String stReason) {
			this.stReason = stReason;
		}
		public String getStDate() {
			return stDate;
		}
		
		public boolean isValid(){
			
			if (stNoValidReason != null && !stNoValidReason.isEmpty() ){
				// we have already a novalid reason
				return false;
			}
			
			if(stName2Delete == null || stName2Delete.isEmpty()){
				stNoValidReason = "Name to delete not filled";
				return false;
			}
			if(stRequestor == null ||stRequestor.isEmpty()){
				stNoValidReason = "Requestor not filled";
				return false;
			}
			if(stReason == null || stReason.isEmpty()){
				stNoValidReason = "Reason not filled";
				return false;
			}
			
			return true;
			
		}
		
		
		
		
	}
}
