package com.ibm.mediator.NoReuseData;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.config.ConfigObjNoReuseReservationTable;
import com.ibm.mediator.connector.TheEregConnector;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;

public class GetReservationOrPorposalForEreg {
	private Session session ;
	private Document docLog;
	private String OwnerUID;
	private RequestLogger rl;
	private TheEregConnector theConnect;
	private ConfigObjMediatorDB cfgNotes_Noreuse_IDS;

	public GetReservationOrPorposalForEreg(Session s, AbstractLogger rl) {
		super();
		this.session = s;
		this.rl = (RequestLogger)rl;
		this.docLog = this.rl.getDocLog();
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public int getReservationVAL() throws Exception{
		int ihits = 0;
		rl.logActionLevel(LogLevel.INFO, "Try to get the config of NoReuse Single val");
		try {
			cfgNotes_Noreuse_IDS = new  ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_IDS, rl);
			rl.logActionLevel(LogLevel.INFO, "Got the config of NoReuse Single val - set loglevel");
			rl.setCheckLogLevel(Byte.parseByte(cfgNotes_Noreuse_IDS.getLogLevel()[0]));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			rl.logActionLevel(LogLevel.SEVERE, "Error while try to find the configuration");
			rl.logActionLevel(LogLevel.SEVERE,e.getMessage());
			try {
				docLog.replaceItemValue("ResGetSuccefull", Integer.toString(0));
				docLog.save();
			} catch (NotesException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				throw e1;
			}

			e.printStackTrace();
			throw e;
		}

		// Connector to DB2
		try {
			theConnect = new TheEregConnector(rl, cfgNotes_Noreuse_IDS);
			rl.logActionLevel(LogLevel.INFO, "Got the connector to DB");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			rl.logActionLevel(LogLevel.SEVERE, "Error while try to connect to db2");
			rl.logActionLevel(LogLevel.SEVERE,e.getMessage());
			docLog.replaceItemValue("ResGetSuccefull", Integer.toString(0));
			docLog.save();
			e.printStackTrace();
			throw e;
		}

		// get the ownerUID
		OwnerUID = docLog.getItemValueString("OwnerUID");
		rl.logActionLevel(LogLevel.INFO, "Got the owner ID: " + OwnerUID);

		// get SQL for the single value

		ConfigObjNoReuseReservationTable nrt = new ConfigObjNoReuseReservationTable();
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT T1.SERIALNUMBERPSC, T1.FIRSTNAME, T1.MIDDLEINITIAL, T1.LASTNAME,");
		sb.append(" T1.FULLNAME, T1.INTERNETADDRESS, T1.SHORTNAME, T2.FIELDNAME, T2.FIELDVALUE  FROM ");
		sb.append(nrt.getReservationSingleVal());
		sb.append(" AS T1 LEFT JOIN " );
		sb.append(nrt.getReservationMultiVal());
		sb.append(" AS T2 ON  T1.SERIALNUMBERPSC =  T2.SERIALNUMBERPSC WHERE LOWER(T1.SERIALNUMBERPSC) = '" );
		sb.append(OwnerUID.toLowerCase());
		sb.append("'");

		ReservationData rd = new ReservationData();

		// execute Query
		rl.logActionLevel(LogLevel.INFO, "Try to execute SQL :" + sb.toString());
		ResultSet rs = theConnect.excuteQuery(sb.toString());
		if (rs == null ){
			docLog.replaceItemValue("ResGetSuccefull", Integer.toString(0));
			rl.logActionLevel(LogLevel.SEVERE, "Error while get Reservation");
			docLog.save();
			theConnect.close(true);
			//docLog.recycle();
			//docLog = null;
			throw(new SQLException("Query can not be executed"));
		}

		//process the results
		rl.logActionLevel(LogLevel.INFO, "End the query sucessful" );
		Vector<String> vFullNameAlias = new Vector<String>();
		Vector<String> vEMailAlias = new Vector<String>();
		while (rs.next()){
			if(ihits==0){
				rd.setFirstName(rs.getString(2));
				rd.setMiddleInitial(rs.getString(3));
				rd.setLastName(rs.getString(4));
				rd.setFullName(rs.getString(5));
				rd.setEMailAddress(rs.getString(6));
				rd.setShortName(rs.getString(7));
			}
			System.out.println("FieldName" + rs.getString(8));
			System.out.println("FieldValue" + rs.getString(9));
			if(rs.getString(8) != null && rs.getString(8).trim().equals(ReservationDataPrepare.FIELNAME_EMAILALIAS)){
				System.out.println("added FieldName to vector " + rs.getString(8) + "-" );
				vEMailAlias.add(rs.getString(9));
			}
			if(rs.getString(8) != null && rs.getString(8).trim().equals(ReservationDataPrepare.FIELNAME_FULLNAMEALIAS)){
				System.out.println("added FieldName to vector " + rs.getString(8) + "-" );
				vFullNameAlias.add(rs.getString(9));
			}
			ihits++;
		}

		//write the result to the log document
		rl.logActionLevel(LogLevel.INFO, "Found " + ihits + " reservation(s) in single and multi value(s)" );
		if (ihits >0){
			rl.logActionLevel(LogLevel.INFO, "returned first name " +rd.getFirstName() );
			docLog.replaceItemValue("FirstName", rd.getFirstName());
			rl.logActionLevel(LogLevel.INFO, "returned middle initial " +rd.getMiddleInitial() );
			docLog.replaceItemValue("MiddleInitial", rd.getMiddleInitial());
			docLog.replaceItemValue("LastName", rd.getLastName());
			rl.logActionLevel(LogLevel.INFO, "returned last name " +rd.getLastName() );
			docLog.replaceItemValue("ReservedFullName", rd.getFullName());
			rl.logActionLevel(LogLevel.INFO, "returned reserved full name " +rd.getFullName());
			docLog.replaceItemValue("ReservedShortName", rd.getShortName());
			rl.logActionLevel(LogLevel.INFO, "returned reserved short name " +rd.getShortName());
			docLog.replaceItemValue("InterNetAddress", rd.getEMailAddress());
			rl.logActionLevel(LogLevel.INFO, "returned reserved e-mail address " +rd.getEMailAddress());
			if(!vFullNameAlias.isEmpty()) docLog.replaceItemValue("ReservedFullNameAlias", vFullNameAlias);
			else System.out.println("Fullnamealias empty");
			if(!vEMailAlias.isEmpty())docLog.replaceItemValue("ReservedEMailAlias", vEMailAlias); 
			else System.out.println("EMailalias empty");
		}
		docLog.replaceItemValue("ResGetSuccefull", Integer.toString(1));
		docLog.replaceItemValue("ResFound", Integer.toString(ihits));
		docLog.replaceItemValue("HasReservedValues",(ihits>0)? Integer.toString(1):Integer.toString(0) );
		docLog.save();
		theConnect.close(true);
		//docLog.recycle();
		return ihits;
	}

	/*@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
		if (docLog != null){
			docLog.recycle();
			docLog = null;
		}
		//session.recycle();
	}*/

}
