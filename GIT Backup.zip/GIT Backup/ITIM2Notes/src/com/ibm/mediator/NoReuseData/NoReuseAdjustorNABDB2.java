package com.ibm.mediator.NoReuseData;

import java.util.HashSet;
import java.util.Iterator;

public class NoReuseAdjustorNABDB2 {
	//private NoReuseDownLoaderNAB nrdlNAB = null;
//	private NoReuseDownLoaderDB2 nrdlDB2 =null;
	private NoReuseAdjustorData nrADat;
	private Iterator<String> it;
	private String stId;
	
	
	public NoReuseAdjustorNABDB2() {
		// TODO Auto-generated constructor stub
		
	}
	
	public NoReuseAdjustorData getAdjustDataNonEMEAGroups(NoReuseDownLoaderNAB nrdlNAB, NoReuseDownLoaderDB2 nrdlDB2){
		HashSet<String> hsNAB = nrdlNAB.getHsNoResuseInternetAddress();
		HashSet<String> hsDB2Active = nrdlDB2.getHsDB2IdsActive();
		HashSet<String> hsDB2Deleted = nrdlDB2.getHsDB2IdsDeleted();
		nrADat  = new NoReuseAdjustorData();
		//this.nrdlNAB = dlNab;
		//this.nrdlDB2 = dldb2;
		
		// 1. is id in NoReuse Group and not in  DB2? - create in DB2
		it = hsNAB.iterator();
		while(it.hasNext()){
			stId = it.next();
			if(!hsDB2Active.contains(stId)){
				// id is not in the active ids of db2.  Is the id in the deleted ID in db2
				if(hsDB2Deleted.contains(stId)){
					// id is in db2 deleted ids .. so the deletion date needs to be removed, beause is is again in Noreuse group
					nrADat.getId2Dif().add(stId);
				}else{
					// is not in db2 active and not in db2 deleted so it must be created
					nrADat.getId2add().add(stId);
				}
			}
		}
		
		// 2. id in DB2 but not in NoReuse group -- set deletion date
		it = hsDB2Active.iterator();
		while (it.hasNext()){
			stId =it.next();
			if (!hsNAB.contains(stId)){
				// update id set deletion date
				nrADat.getId2setDel().add(stId);
			}
		}
		return nrADat;
	}
	
	public  NoReuseAdjustorData getAdjustDataEMEAGroups(NoReuseDownLoaderNAB nrdlNAB, NoReuseDownLoaderDB2 nrdlDB2){
		
		// loop through all the ids which are deleted
		HashSet<String> hsDB2Deleted = nrdlDB2.getHsDB2IdsDeleted();
		HashSet<String> hsNAB = nrdlNAB.getHsNoResuseInternetAddress();
		HashSet<String> hsDB2Active = nrdlDB2.getHsDB2IdsActive();
		nrADat  = new NoReuseAdjustorData();
		//this.nrdlNAB = dlNab;
		//this.nrdlDB2 = dldb2;
	
		it = hsDB2Deleted.iterator();
		while(it.hasNext()){
			stId = it.next();
			if(!hsNAB.contains(stId)){
				nrADat.getId2add().add(stId); //to no Nab reuse group because the id is nogorup
			}
		}
		it  = hsNAB.iterator();
		while(it.hasNext()){
			stId = it.next();
			// is the id in db2 deleted ids
			if (!hsDB2Deleted.contains(stId)){
				// is it still active ?
				if (hsDB2Active.contains(stId)){
					// id is blocked because it is active already so nothing needs to be done ther
					//nrADat.getId2setDel().add(stId); //the id is marked as active needs to be changed
				}else{
					// the name does not exits in db2 and not in den NAB .. needs to be added to db2
					nrADat.getId2Dif().add(stId);
				}
			}
		}
		
		return nrADat;
	}

}
