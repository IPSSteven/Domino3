package com.ibm.mediator.NoReuseData;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;

import lotus.domino.Session;

import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnector;

public class NoReuseDownLoaderDB2 {
	TheEregConnector theConnect = null;
	InputOutputLogger log = null;
	String stDomain;
	Session session;
	HashSet<String> hsDB2IdsActive = null;
	HashSet<String> hsDB2IdsDeleted = null;

	public NoReuseDownLoaderDB2(Session s, TheEregConnector theCon, InputOutputLogger pLog, String Domain) {
		// TODO Auto-generated constructor stub
		session = s;
		theConnect = theCon;
		log = pLog;
		stDomain = Domain;
		initClass();
	}

	public HashSet<String> getHsDB2IdsActive() {
		return hsDB2IdsActive;
	}

	public HashSet<String> getHsDB2IdsDeleted() {
		return hsDB2IdsDeleted;
	}

	private void initClass(){
		// get the configuration
		// ConfigObjMediatorDB cfgNotes_Noreuse_IDS;
		ResultSet rs = null;;
		try {
			ConfigObjMediatorDB cfgNotes_NoReuseSingleval = new ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_SINGLEVAL, log);

			//cfgNotes_Noreuse_IDS = new  ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_IDS, log);

			//String stQuery = "Select INTERNETADDRESS, DELETIONDATE from " + cfgNotes_Noreuse_IDS.getTable()[0] + 
			//		 " where DOMAIN = '" + stDomain + "'";
			String stQuery = "Select INTERNETADDRESS, DELETIONDATE from " + cfgNotes_NoReuseSingleval.getTable()[0] + 
					" where DOMAIN = '" + stDomain + "' AND LOCKOUTONLY != 'T'";

			rs = theConnect.excuteQuery(stQuery);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		};


		if(rs != null){
			hsDB2IdsActive = new HashSet<String>();
			hsDB2IdsDeleted = new HashSet<String>();
			try {
				while (rs.next()){
					try {
						/*String stdummy = rs.getString(1);
						stdummy = rs.getString(2);
						stdummy = stdummy.trim();
						stdummy = stdummy.replaceAll(" ", "");*/
						if(rs.getString(2) == null | rs.getString(2).trim().equals("") ){ // DeletionDante
							hsDB2IdsActive.add(rs.getString(1).toLowerCase());
						}else{
							hsDB2IdsDeleted.add(rs.getString(1).toLowerCase());
						}

					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	private void logaction(byte ll, String stlogAction){
		if (this.log == null){
			System.out.println (stlogAction);
		}else{

			this.log.logActionLevel(ll, stlogAction);
		}
	}

}
