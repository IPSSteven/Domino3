package com.ibm.mediator.NoReuseData;




public class NoReuseLoadThreadData {
	private String password;
	private String domain;
	private String stMachineKey;
	private String stHandleDenyAccess;
	private String AgentName;
	

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getStMachineKey() {
		return stMachineKey;
	}

	public void setStMachineKey(String stMachineKey) {
		this.stMachineKey = stMachineKey;
	}

	public String getStHandleDenyAccess() {
		return stHandleDenyAccess;
	}

	public void setStHandleDenyAccess(String stHandleDenyAccess) {
		this.stHandleDenyAccess = stHandleDenyAccess;
	}

	public String getAgentName() {
		return AgentName;
	}

	public void setAgentName(String agentName) {
		AgentName = agentName;
	}

	

	

}
