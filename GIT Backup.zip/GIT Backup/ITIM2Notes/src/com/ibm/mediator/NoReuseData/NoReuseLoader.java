package com.ibm.mediator.NoReuseData;



import lotus.domino.AgentBase;

public class NoReuseLoader extends AgentBase {

	@Override
	public void NotesMain() {
		// TODO Auto-generated method stub
		//super.NotesMain();
		System.out.println("Start");
		NoReuseLoaderRunner nrur = new NoReuseLoaderRunner(getSession());
		//nrur.runLoader();
	}

}
