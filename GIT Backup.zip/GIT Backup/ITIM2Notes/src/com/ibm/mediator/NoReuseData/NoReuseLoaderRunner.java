package com.ibm.mediator.NoReuseData;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.Vector;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigNoReuseMasterDatabase;
import com.ibm.ereg.config.ConfigObjCountryTable;
import com.ibm.ereg.config.ConfigObjMailDomainServer;
import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.rmi.NotesRMIClient;
import com.ibm.ereg.rmi.ReceiveInterFace;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnector;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.Session;


public class NoReuseLoaderRunner {
	private Session session;
	private Database dbLog;
	private InputOutputLogger log;
	private String sMachineKey;
	private ConfigObjMediatorDB cfgNotes_Noreuse_SingleVal;
	private ConfigObjMediatorDB cfgNotes_Noreuse_Multival;
	private ConfigObjMailDomainServer cfgMailDomainServer;
	private static ConfigObjCountryTable cfgCountryTable;
	private TheEregConnector theConnect;
	private NoReuseDataHolder nrDH;
	private long linsertSingle;
	private long linsertMulti;
	private HashSet<String> denyListTermination = null;
	private Database dbNab;

	public NoReuseLoaderRunner(Session s) {
		super();
		session = s;
		runLoader();
		// TODO Auto-generated constructor stub
	}

	public  void runLoader(){
		LogDocStatus lds = null;
		String server = null;
		try {
			// 1. Get the Log
			dbLog  = CommonFunctions.getLogDB(session);
			log = new InputOutputLogger(session, dbLog, "Load ids for no reuse - " + CommonFunctions.getActDateRecon(),
					LogLevel.FINEST);
			//pln("Got the log.");
			sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);
			log.logActionLevel(LogLevel.INFO, "start No Reuse Loader on machine "+ sMachineKey);
			lds = new LogDocStatus(log.getDocLog());
			lds.setOKRunning();

			// 2. config data for DB2
			this.cfgNotes_Noreuse_SingleVal = new  ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_SINGLEVAL, log);
			this.cfgNotes_Noreuse_Multival = new  ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_MULTIVAL, log);
			this.theConnect = new TheEregConnector(log, cfgNotes_Noreuse_Multival);
			log.setCheckLogLevel(Byte.parseByte(cfgNotes_Noreuse_Multival.getLogLevel()[0]));

			// 3, get the configuration of the Domain server
			this.cfgMailDomainServer = new ConfigObjMailDomainServer(session);

			// 4. get the EMEA domains of the configuration 
			Set<String> oEMEADomains = this.cfgMailDomainServer.getNabServers_domain().keySet();
			String[] stEMEADom = (String[])oEMEADomains.toArray(new String [oEMEADomains.size()]);
			log.logActionLevel(LogLevel.INFO, "Found the all domains for EMEA");

			//5. get the configuration for the machine (domain which should be handle by this machine) s.
			ConfigObjReConcileITIM cr = new ConfigObjReConcileITIM(session,
					AllConstants.MEDIATOR_NOTES_NOREUSE_DOMAINS + sMachineKey, log);
			
			//5.1 get the non EMEA domains
			ConfigObjReConcileITIM crNoEMEA = new ConfigObjReConcileITIM(session,
					AllConstants.MEDIATOR_NOTES_NOREUSE_NOEMA_DOMAINS , log);
			String [] stNoEMEADom =	crNoEMEA.getDomainList();
			String [] stALLDom = new String[stEMEADom.length + stNoEMEADom.length];
			System.arraycopy(stEMEADom, 0, stALLDom, 0, stEMEADom.length);
			System.arraycopy(stNoEMEADom, 0, stALLDom, stEMEADom.length, stNoEMEADom.length);
			log.logActionLevel(LogLevel.INFO, "Domain List:" + stALLDom.toString());
			
			stEMEADom = null;
			stNoEMEADom = null;

			//6. get the country table
			try {
				cfgCountryTable = new ConfigObjCountryTable(session);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, "Error while loading country table");
				e1.printStackTrace();
				throw new Exception("Error while loading country table");
			}

			//7. loop through all domains and get the data from there
			for(String stDom:stALLDom){

				if (isDomainForMachine(stDom, cr.getDomainList())){
					log.logActionLevel(LogLevel.INFO, "Try to get the data from db2 for domain " + stDom);

					// 7.1 load 2 hashsets .. active an deleted ids
					if (bgetDatafromDB2(stDom)){
						if (oEMEADomains.contains(stDom)){
							server = this.cfgMailDomainServer.getNabServers_domain().get(stDom);
							dbNab = CommonFunctions.getDatabase(session, server,AllConstants.NABDBNAME);	
							
						}else{
							server = crNoEMEA.getRMIDomin2SearchCorrectNCOUAR()[0]; //ED
							dbNab = CommonFunctions.getDatabase(session, server,AllConstants.EXTENDED_DIR);
						}
						String stReplica = dbNab.getReplicaID();
						Database dbTemp = session.getDatabase(null, null);
						boolean b= dbTemp.openByReplicaID("", stReplica);
						if(b) {
							log.logActionLevel(LogLevel.INFO, "Found local replica for  " + stDom);
		
							dbNab.recycle();
							dbNab = dbTemp;
							dbTemp.replicate(server);
							
							log.logActionLevel(LogLevel.INFO, "Replicated with server for " + stDom);
						}else {
							log.logActionLevel(LogLevel.INFO, "Found  NO local replica for  " + stDom);
						}
						
						handleDomain(stDom);
						setDeletionDate();
					}
	
					// 8. the no reuse group put it NAB
					//if (stDom.equals("IBMEE")| stDom.equals("IBMLT")| stDom.equals("IBMLV")){
					//	handleNoReuseGroups(stDom, true);
					//}

				}//else{
				//log.logActionLevel(LogLevel.INFO, stDom + " is not handled by this machine");
				//}
			}
			

			// 7. the deny access list
			//if (denyListTermination == null) getDenyAccessList(cr, stDomains);
			// here we do get the deny access ids for all handle domains (we do this only once
		//	String stHandleDenyAccess = cr.gethandleDenyAccessGroup()[0];
		//	if (stHandleDenyAccess.equals("Y")){
		//		//if (denyListTermination == null) getDenyAccessList(cr, stALLDom);
		//		if (denyListTermination == null)getDeny
		//		getDatafromDenyAccess();
		//
		//	}
		

			//8. get the no reuse id from non EMEA domain
			/*	String stHandle =cr.getFilterFormula()[0];
			if(stHandle.equals("Y")){
				String [] stNoEmeaDom = getNoEMEADomains(oEMEADomains);
				for(String stDom:stNoEmeaDom){
					if(stDom.equals("IBMKR") || stDom.equals("IBMHK") ){
						handleNoReuseGroups(stDom, false);
					}
				}
			} */

			log.logActionLevel(LogLevel.INFO, "No Reuseloader finished");
			log.logActionLevel(LogLevel.INFO, "Good bye :)");
			lds.setOKDone();
			log.closeLog(lds);

		} catch (Exception e) {
			if (log != null){
				log.logActionLevel(LogLevel.SEVERE, "No Reuseloader finished NOT sucessful");
				log.logActionLevel(LogLevel.SEVERE, e.getMessage());
				log.logActionLevel(LogLevel.INFO, "Good bye :)");
				lds.setOKDone();
				log.closeLog(lds);
			}
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private boolean isDomainForMachine(String stDomain, String [] stDomList){
		for(String stDom:stDomList){
			if(stDom.endsWith("*")){
				if (stDomain.startsWith(stDom.substring(0,stDom.length()-1))){
					return true;
				}
			}else{
				if (stDom.equals(stDomain)) return true;
			}
		}
		return false;
	}
	private String getDomainForMachine(String stDomain, String [] stDomList){
		for(String stDom:stDomList){
			if(stDom.endsWith("*")){
				if (stDomain.startsWith(stDom.substring(0,stDom.length()-1))){
					return stDomain;
				}
			}else{
				if (stDom.equals(stDomain)) return stDomain;
			}
		}
		return null;
	}


	private void handleDomain(String sDom) throws Exception{

		//dbNab = CommonFunctions.getDatabase(session, "","ereg/namesLT.nsf");
		//dbNab = CommonFunctions.getDatabase(session, "D06EDC10","dircat/edcww.nsf");
		linsertMulti = 0;
		linsertSingle = 0;
		long lCount = 0;
		long lloop;

		// the admin ids have in most case no valid country number
		//String stCountryNumber = cfgCountryTable.getCountryNumber(sDom);
		//String stSelection = "SELECT Type = 'Person'"& Empcc = '" + stCountryNumber + "'";
		String stSelection = "Type = 'Person' & MailDomain = '" + sDom + "'" + " | NodeName = '" + sDom + "'" ;
		DocumentCollection dccNab = null;
		Document docNab = null;
		Document docDelete = null;

		// get the selection only Person documents
		try {
			log.logActionLevel(LogLevel.FINE, "Seach on NAB :" + stSelection);
			dccNab = dbNab.search(stSelection);	
			lCount = dccNab.getCount();
			log.logActionLevel(LogLevel.INFO, "Found " + lCount + " document(s) for the domain " + sDom + " in the NAB");
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE,"No nab entries found");
			log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
			//throw new Exception ("no Nab entries found");
		}

		// loop through the collection
		lloop = 0;
		if (dccNab != null){
			try {
				docNab = dccNab.getFirstDocument();
				while(docNab != null){
					checkNoReuseList(docNab, sDom);
					docDelete = docNab;
					docNab = dccNab.getNextDocument();
					docDelete.recycle();
					lloop ++;
					if(lloop%1000 == 0){
						log.logActionLevel(LogLevel.INFO, "Still alive working " + lloop + " document for the domain " + sDom + " in the NAB");
						pln("Still alive working " + lloop + " document for the domain " + sDom + " in the NAB");
					}
				}
				log.logActionLevel(LogLevel.INFO, "Inserted " + linsertSingle + " single values and " + linsertMulti + " multivalues for "+ sDom);

			} catch (NotesException e) {
				// TODO Auto-generated catch block
				if(docNab != null) docNab.recycle();;
				log.logActionLevel(LogLevel.SEVERE,"Error while looping throug the Nab docs");
				e.printStackTrace();
			}
		}

		if(dccNab != null){
			try {
				dccNab.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			dbNab.recycle();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private boolean bgetDatafromDB2(String Domain){
		String LeftTable;
		String RightTable;
		try {
			LeftTable = cfgNotes_Noreuse_SingleVal.getTable()[0];
			RightTable = cfgNotes_Noreuse_Multival.getTable()[0];
		} catch (Exception e) {
			log.logActionLevel(LogLevel.SEVERE, "Error while try to get the tables for db2 from configuration" );
			e.printStackTrace();
			return false;
		}
	
		long lRow = 0;

		this.nrDH = new NoReuseDataHolder();

		HashSet<String> hsUnidsDeleted= this.nrDH.gethsUnidsDeleted();
		HashSet<String> hsUnidsActive= this.nrDH.gethsUnidsActive();
		HashSet<String> hsAddress  = this.nrDH.gethsAddress();

		String sql = "Select " +
				LeftTable + ".FULLNAME, " +
				LeftTable + ".DOMAIN, " +
				LeftTable + ".PERSONUNID ," +
				LeftTable + ".DELETIONDATE ," +
				LeftTable + ".LOCKOUTONLY ," +
				RightTable + ".FIELDVALUE FROM " + LeftTable + " LEFT JOIN " +
				RightTable + " ON " + LeftTable + ".PERSONUNID = " + RightTable + ".PERSONUNID WHERE " +
				LeftTable + ".DOMAIN = '" + Domain + "'";
		//LeftTable + ".DOMAIN = '" + Domain + "'" + "AND DELETIONDATE = ''" ;
		log.logActionLevel(LogLevel.FINE, "Try to execute sql " + sql);
		ResultSet rs = this.theConnect.excuteQuery(sql);

		if ( rs == null){return false;
		}else{
			try {
				while (rs.next()){
					try{
					lRow++;
					/*String dummy = rs.getString(3);
					dummy = rs.getString(3);
					dummy = rs.getString(4);
					dummy = dummy.replaceAll("\\s", "");*/
					// getString (4) deletion data
					if (rs.getString(4) == null || rs.getString(4).trim().equals("")  ){ //deletion date and LOCKOUTONLY
						if(rs.getString(5) != null && rs.getString(5).equals("N")){
							hsUnidsActive.add(rs.getString(3)); // put the unid in the active hashset
							hsAddress.add(rs.getString(1)); // Fullname
							hsAddress.add(rs.getString(6)); // Fieldvalue (internetaddreses
						}

					}else{
						hsUnidsDeleted.add(rs.getString(3));
					}
					}catch(SQLException e){
						log.logActionLevel(LogLevel.SEVERE, "Error while reading data from row " + rs.toString()+  " -> " + e.getMessage());
						e.printStackTrace();
					}

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, "Error reading next from SQL Table ->" + e.getMessage());
				e.printStackTrace();
			}

		}
		log.logActionLevel(LogLevel.FINE, "Found " +lRow+ " entries for " + Domain + " in db2");
		return true;


	}
	
	/*
	private void getDenyAccessList(ConfigObjReConcileITIM cr, String[] stDomains){
		String stRMIServer;
		String stRMIPort;
		NotesRMIClient nrc;
		ReceiveInterFace nri;
	//	String stFullname;
	//	String stDom;
	//	Name notesName;
	//	String [] stNamepart;
	//	HashSet<String> handleDomains = new HashSet<String>();
	//	HashSet<String> handleDenyIds = new HashSet<String>();
		
		// get the domains, which are handled for this machine
/-		try {
			
			for(String stD: cr.getDomainList()){
				if( (stDom = getDomainForMachine(stD, stDomains)) != null){
					handleDomains.add(stDom);
				}
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
-/		
		//  connect to RMI server
		try {
			stRMIServer = cr.getRMIDomin2SearchCorrectNCOUAR()[0];
			stRMIPort = cr.getRMIPortDenyAccess()[0];
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"RMIServer not provided by configuration");
			log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			e.printStackTrace();
			return;

		}

		log.logActionLevel(LogLevel.INFO," Try to connect to RMIServer : " + stRMIServer + " RMIPort :" + stRMIPort);
		//System.out.println("RMIServer :" + stRMIServer + "RMIPort :" + stRMIPort);
		try {
			nrc = new NotesRMIClient(stRMIServer,stRMIPort);
			nri = nrc.notesRMIInterface;
			denyListTermination = nri.getDenyListTermination();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while connect to RMI Server");
			log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			e.printStackTrace();
			return;
		}
		log.logActionLevel(LogLevel.INFO," Connection to RMIServer : " + stRMIServer + " RMIPort :" + stRMIPort + " successful");
/-
		//loop through all deny list remove all domains which are not handled by this machine
		Iterator<String> it = denyListTermination.iterator();
		while(it.hasNext()){
			stFullname = it.next();
			try {
				notesName = session.createName(stFullname);
				if (notesName != null){
					stNamepart = notesName.getAbbreviated().split("/");
					// eg. namepart[1] = Germany -> we get IBMDE
					if(stNamepart.length >1)stDom = cfgCountryTable.getIBMCodeByCountryName(stNamepart[1]); else stDom = "";

					if(stDom !=null && !stDom.equals("") && handleDomains.contains(stDom)){
						handleDenyIds.add(stFullname);
					}
					notesName.recycle();
				}else{
					System.out.println("notesName = null");
				}
			} catch (NotesException e) {
				log.logActionLevel(LogLevel.SEVERE,"Error while building the Notes name");
				log.logActionLevel(LogLevel.SEVERE,e.getMessage());
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e){
				log.logActionLevel(LogLevel.SEVERE,"Error while geting Terminationlists");
				log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			}
		}
		denyListTermination = handleDenyIds; -/
	}
*/

	private void getDatafromDenyAccess(){
	//private void getDatafromDenyAccess(String stDomhandled){
		Iterator<String> it;
		Name notesName;
		String stName;
		Notes_Noreuse_SingleVal NrSv;
		String [] stNamepart;
		String stDom;
		long count = 0;
		String stTable;
		
		
		HashSet<String> hsDenyAccessIds = this.nrDH.gethsAddress();

		// get the existing data in db2 and put i on hsDenyAccess
		try {
			stTable = cfgNotes_Noreuse_SingleVal.getTable()[0];

			String sql = "Select " +
					stTable + ".FULLNAME FROM " + stTable + 
					" WHERE LOCKOUTONLY = 'T' ";

			ResultSet rs = this.theConnect.excuteQuery(sql);
			while (rs.next()){
				 hsDenyAccessIds.add(rs.getString(1));
			}

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while add deny access");
			log.logActionLevel(LogLevel.SEVERE,e1.getLocalizedMessage());
			e1.printStackTrace();
			return;
		}

		// loop through the list we have form RMI server and compare it with the list we got from DB2
		try {
			it = denyListTermination.iterator();
			
			while(it.hasNext()){
				stName = it.next();
				notesName = session.createName(stName);
				stNamepart = notesName.getAbbreviated().split("/");
				if(stNamepart.length >1)stDom = cfgCountryTable.getIBMCodeByCountryName(stNamepart[1]); else stDom = "";
				stName = notesName.getAbbreviated();
				//System.out.println(" result " + this.nrDH.getHsIdNoreUse().contains(stName));
				//if (stDom != null & stDom.equals(stDomhandled) && !this.nrDH.getHsIdNoreUse().contains(stName)){
				if (!hsDenyAccessIds.contains(stName)){
					NrSv = new Notes_Noreuse_SingleVal(cfgNotes_Noreuse_SingleVal);
					NrSv.setBlockDate("N/A");
					NrSv.setCreationDate(CommonFunctions.getActDateRecon());
					NrSv.setDeletionDate("");
					NrSv.setDomain(stDom);
					NrSv.setFullName(notesName.getAbbreviated());
					NrSv.setInternetAddress("N/A-Termination");
					NrSv.setPersonuinid("N/A-Termination- "+ count);
					NrSv.setLockOutOnly("T");
					theConnect.executeUpdate(NrSv.getsqlInsertState());
				}
				
				count++;
				
				if(count % 5000 == 0){
					System.out.println("Working on "+  count+ " record" );
				}
				notesName.recycle();
			}
			log.logActionLevel(LogLevel.INFO,"Added " + count + " ids from Deny Access List for the domain:");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while handling Deny Access" );
			log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			e.printStackTrace();
		}
	}

	private void checkNoReuseList(Document doc, String stDom){
		Name NotesName = null;
		Notes_Noreuse_SingleVal NrNa;
		Notes_NoReuse_MultiVal NrAl;
		String stShortNameAddress;
		HashSet<String> hsUnique;
		String stUniversalId = "";
		boolean bHandleMulti = true;

		// the fullname
		Vector<String> Itimvalue = null;
		try {
			
			
			Itimvalue = doc.getItemValue("FullName");
			if(Itimvalue == null) {
				return;
			}else if(Itimvalue.size() == 0) {
				return;
			}
			//Iterator it = Itimvalue.iterator();
			//while(it.hasNext()){
			//NotesName = session.createName((String)it.next());

			// The fullname
			try{
				
				NotesName = session.createName(Itimvalue.firstElement());
			}catch(NoSuchElementException e){
				log.logActionLevel(LogLevel.SEVERE,"Error while handling Fullname:" + Itimvalue == null? "N/A":Itimvalue.firstElement() );
				log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
				if (NotesName != null) NotesName.recycle();
				return;
			}

			stUniversalId = doc.getUniversalID();
			
			if (this.nrDH.gethsAddress().contains(NotesName.getAbbreviated())){
				nrDH.gethsUnidsActive().remove(stUniversalId); // remove it (remainder all deleted ids)
			}else{
				//if nrDH.
				try {
					if(nrDH.gethsUnidsDeleted().contains(stUniversalId)){
						// in this case the deletion date in the db2 is wrong !. It will be cleared. Short name should not be handled. They are not loaded
						nrDH.gethsUnidsDeleted().remove(stUniversalId);
						nrDH.gethsUnidsClearDeletionDate().add(stUniversalId);
						bHandleMulti= false;
					}else{
						// insert row in noreuse notes address
						linsertSingle ++;
						NrNa = new Notes_Noreuse_SingleVal(cfgNotes_Noreuse_SingleVal);
						NrNa.setBlockDate(CommonFunctions.getYYYYMMDD(doc.getCreated()));
						NrNa.setCreationDate(CommonFunctions.getActDateRecon());
						NrNa.setDeletionDate("");
						//NrNa.setDomain(stDom);
						NrNa.setDomain(doc.getItemValueString("MailDomain"));
						NrNa.setFullName(NotesName.getAbbreviated());
						NrNa.setInternetAddress(doc.getItemValueString("InternetAddress"));
						NrNa.setPersonuinid(doc.getUniversalID());
						NrNa.setLockOutOnly("N");
						NrNa.setSerialPSC(doc.getItemValueString("Empnum")+ doc.getItemValueString("Empcc") );
						theConnect.executeUpdate(NrNa.getsqlInsertState());
					}
				} catch (Exception e) {
					log.logActionLevel(LogLevel.SEVERE,"Error while handling Fullname:" + NotesName.getAbbreviated() );
					log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
					e.printStackTrace();
				}
			}
			if (NotesName != null) NotesName.recycle();
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while handling Fullname: " +Itimvalue == null? "N/A":Itimvalue.firstElement());
			log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		if (bHandleMulti){
			// the fullname multi values (aliases)
			try {
				hsUnique = new HashSet<String>();
				Itimvalue = doc.getItemValue("FullName");
				int size = Itimvalue.size();
				for(int i = 1; i <size; i++ ){ // get the 2 - last element
					NotesName = session.createName(Itimvalue.get(i));
					hsUnique.add(NotesName.getAbbreviated());
					NotesName.recycle();
				}
				String [] stFullNames = hsUnique.toArray(new String[hsUnique.size()]);
				for(String stFull:stFullNames){
					if (!this.nrDH.gethsAddress().contains(stFull)){
						// insert row multivalues
						try {
							NrAl = new Notes_NoReuse_MultiVal(cfgNotes_Noreuse_Multival);
							NrAl.setPersonUnid(doc.getUniversalID());
							NrAl.setFieldName("FNA");
							NrAl.setFieldValue(stFull);
							theConnect.executeUpdate(NrAl.getSqlInsertState());
							linsertMulti ++;
						} catch (Exception e) {
							log.logActionLevel(LogLevel.SEVERE,"Error while handling fullname alias " + stFull );
							log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
							e.printStackTrace();
						}

					}

				}
			} catch (NotesException e1) {
				log.logActionLevel(LogLevel.SEVERE,"Error while handling fullname alias" );
				log.logActionLevel(LogLevel.SEVERE,e1.getLocalizedMessage());
				e1.printStackTrace();
			}

			// the short name .. the multi values

			try {
				// short names are not all unique
				hsUnique = new HashSet<String>();
				Itimvalue = doc.getItemValue("ShortName");
				Iterator<String> it = Itimvalue.iterator();
				while(it.hasNext()){
					stShortNameAddress = (String)it.next();
					hsUnique.add(stShortNameAddress);
				}
				for( String stShort : (String[])hsUnique.toArray(new String[hsUnique.size()])){
					if (stShort.indexOf("@") > 0){
						if (!this.nrDH.gethsAddress().contains(stShort)){
							// insert row in noreuse internetaddress
							try {
								NrAl = new Notes_NoReuse_MultiVal(cfgNotes_Noreuse_Multival);
								NrAl.setPersonUnid(doc.getUniversalID());
								NrAl.setFieldName("SN");
								NrAl.setFieldValue(stShort);
								theConnect.executeUpdate(NrAl.getSqlInsertState());
								linsertMulti ++;
							} catch (Exception e) {
								log.logActionLevel(LogLevel.SEVERE,"Error while handling short name alias" );
								log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
								e.printStackTrace();
							}

						}
					}	
				}

			} catch (NotesException e) {
				log.logActionLevel(LogLevel.SEVERE,"Error while handling short name alias" );
				log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
				e.printStackTrace();
			}
		}

		// remvove the univeralid from Hset. The remaining universalids in the hashset are deleted documents (only if the deletion date is empty)
		//nrDH.getHsNABUnidsDeleted().remove(stUniversalId);

	}
	private void setDeletionDate(){
		Iterator<String> it = null;
		String stsql = null;
		HashSet<String> hsunids = nrDH.gethsUnidsActive();
		String stActdate =  CommonFunctions.getActDateRecon();
		int i = 0;
		String stSqlUpdate;
		StringBuffer stsqlb = null; 
		if (stActdate.length() > 8) stActdate = stActdate.substring(0,8); 
		try {
			stsql =  "UPDATE " + cfgNotes_Noreuse_SingleVal.getTable()[0] + " SET DELETIONDATE = '" +  stActdate + "' where PERSONUNID IN ('";
			it = hsunids.iterator();
			stsqlb = new StringBuffer();
			while (it.hasNext()){
				stsqlb.append(it.next() + "', '");
				// limit the update string
				if (i > 15) {
					stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.length()-3) + ")";
					theConnect.executeUpdate(stSqlUpdate);
					i = 0;
					stsqlb = new StringBuffer();
				}
				i++;

			}
			if (i >0 ){
				stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.length()-3) + ")";
				theConnect.executeUpdate(stSqlUpdate);
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			hsunids = nrDH.gethsUnidsClearDeletionDate();
			stsql =  "UPDATE " + cfgNotes_Noreuse_SingleVal.getTable()[0] + " SET DELETIONDATE = '' where PERSONUNID IN ('";
			it = hsunids.iterator();
			stsqlb = new StringBuffer();
			while (it.hasNext()){
				stsqlb.append(it.next() + "', '");
				// limit the update string
				if (i > 15) {
					if(stsqlb.toString().length() >3){
						stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.toString().length()-3) + ")";
						theConnect.executeUpdate(stSqlUpdate);
						i = 0;
					}
					stsqlb = new StringBuffer();
				}
				i++;

			}
			if (i >1 ){
				if(stsqlb.toString().length() >3){
					stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.toString().length()-3) + ")";
					theConnect.executeUpdate(stSqlUpdate);
				}
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(stsqlb.toString());
			e.printStackTrace();
		}
	}

	private void handleNoReuseGroups(String stDomain, boolean isEMEAGroup){

		NoReuseDownLoaderNAB nrDlNab = new NoReuseDownLoaderNAB(session, stDomain);
		NoReuseDownLoaderDB2 nrDlDb2 = new NoReuseDownLoaderDB2(session, theConnect, log, stDomain);
		NoReuseAdjustorNABDB2 nrAdjust = new NoReuseAdjustorNABDB2();
		Iterator <String>it;
		String stDom;
		String stId;

		if(isEMEAGroup){
			NoReuseAdjustorData nrDat = nrAdjust.getAdjustDataEMEAGroups(nrDlNab, nrDlDb2);

			// add  these id  to No reuse groups in NAB
			HashSet<String> hsIdAdd = nrDat.getId2add();
			String[] stIds = hsIdAdd.toArray(new String[hsIdAdd.size()]);
			nrDlNab.addAddress(stIds);

			//not needed
			// HashSet hsIdDel = nrDat.getId2setDel(); 

			// add these noReuse ids in DB2;
			HashSet hsIdDif = nrDat.getId2Dif();

		}else{
			NoReuseAdjustorData nrDat = nrAdjust.getAdjustDataNonEMEAGroups(nrDlNab, nrDlDb2);
			// add these to db2

			HashSet<String> hsIdAdd = nrDat.getId2add();
			it = hsIdAdd.iterator();
			Notes_Noreuse_SingleVal NrSv;
			try {
				NrSv = new Notes_Noreuse_SingleVal(cfgNotes_Noreuse_SingleVal);
				int count = 0;
				while (it.hasNext()){
					stId = it.next();
					NrSv.setCreationDate(CommonFunctions.getActDateRecon());
					NrSv.setBlockDate(CommonFunctions.getActDateRecon());
					NrSv.setDeletionDate("");
					if (stId.indexOf("@") >0 ){
						stDom = "IBM" + stId.split("@")[1].substring(0, 2).toUpperCase();
					}else{
						stDom = "N/A";
					}
					NrSv.setDomain(stDom);
					NrSv.setFullName(stId);
					NrSv.setInternetAddress(stId);
					NrSv.setPersonuinid("N/A-NoReuseInternet-"+ count);
					NrSv.setLockOutOnly("I");
					theConnect.executeUpdate(NrSv.getsqlInsertState());
					count ++;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// set deletion date. Id was in No reuse group, but is delete from there.
			HashSet<String> hsIdDel = nrDat.getId2setDel(); 
			try {
				setDeletionDateNoEMEA(hsIdDel, 'S');

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// remove deletion date
			HashSet<String> hsIdDif = nrDat.getId2Dif(); 
			setDeletionDateNoEMEA(hsIdDif, 'C');
		}

	}

	private void setDeletionDateNoEMEA(HashSet<String> hsIds2handle, char cAction ){
		// cAction can be S = Date, C for clear date

		String stsql = null;
		Iterator<String> it = null;
		String stActdate; 
		int i = 0;
		String stSqlUpdate;
		if (cAction == 'S'){
			stActdate =  CommonFunctions.getActDateRecon();
			if (stActdate.length() > 8) stActdate = stActdate.substring(0,8); 
		}else{
			stActdate = "";
		}

		try {
			//(FULLNAME, DOMAIN, PERSONUNID, INTERNETADDRESS
			stsql =  "UPDATE " + cfgNotes_Noreuse_SingleVal.getTable()[0] + " SET DELETIONDATE = '" +  stActdate + "' where FULLNAME IN ('";
			it =  hsIds2handle.iterator();
			StringBuffer stsqlb = new StringBuffer();
			while (it.hasNext()){
				stsqlb.append(it.next() + "', '");
				// limit the update string
				if (i > 15) {
					stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.length()-3) + ") AND INTERNETADDRESS IN (" +
							stsqlb.toString().substring(0,stsqlb.length()-3)  + ")";
					theConnect.executeUpdate(stSqlUpdate);
					i = 0;
					stsqlb = new StringBuffer();
				}
				i++;

			}
			if (i >0 ){
				stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.length()-3) + ")";
				theConnect.executeUpdate(stSqlUpdate);
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	private String [] getNoEMEADomains(Set<String> sEMEADomains){
		StringBuffer bufDom = new StringBuffer();
		ConfigNoReuseMasterDatabase cfgNoReuseMasterDB;
		Database dbNab;
		String stListName;
		Document docGroup;
		Document docRecyle;
		int ilen;
		int ilenIdent;
		HashSet<String> hsDom = new HashSet<String>();

		Iterator<String> it = sEMEADomains.iterator();
		while(it.hasNext()){
			bufDom.append("'"+ it.next() + "':");
		}
		String stSearch = "Type = 'Group' & GroupType = '3' & Form = 'Group' &  @Contains(ListName;'" +
				AllConstants.GROUPIDENTIFIER +"') & !@Contains(ListName;"+ bufDom.toString().substring(0,bufDom.length()-1)+
				")";
		try {
			cfgNoReuseMasterDB = new ConfigNoReuseMasterDatabase(session);
			dbNab = CommonFunctions.getDatabase(session, cfgNoReuseMasterDB.getStServer() ,cfgNoReuseMasterDB.getStFilePath());
			if (dbNab == null){
				dbNab = CommonFunctions.getDatabase(session, cfgNoReuseMasterDB.getStReplicServer() ,cfgNoReuseMasterDB.getStReplicFilePath());
			}
			if (dbNab == null){
				log.logActionLevel(LogLevel.SEVERE, "Source Database not found");
				throw(new Exception("Source database not found"));
			}
			ilenIdent = AllConstants.GROUPIDENTIFIER.length();
			DocumentCollection dccSearch = dbNab.search(stSearch);
			docGroup = dccSearch.getFirstDocument();
			while(docGroup != null){
				stListName = docGroup.getItemValueString("Listname");
				if(stListName != null && stListName.length() > ilenIdent){
					stListName = stListName.substring(ilenIdent, stListName.length());
					ilen = stListName.indexOf("-");
					//System.out.println(stListName);
					if(ilen >0){
						stListName = stListName.substring(0,ilen);
						if(!sEMEADomains.contains(stListName) && stListName.contains("IBM")){
							hsDom.add(stListName);
						}
					}
				}
				docRecyle = docGroup;
				docGroup = dccSearch.getNextDocument(docGroup);
				docRecyle.recycle();
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(hsDom.size()>0){
			return hsDom.toArray(new String[hsDom.size()]);
		}else{
			return null;
		}


	}


	private void pln(String s){
		System.out.println(s);
	}


}
