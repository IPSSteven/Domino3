package com.ibm.mediator.NoReuseData;

import com.ibm.mediator.config.ConfigObjMediatorDB;

public class Notes_NoReuse_MultiVal {
	private  final String TABLENAME;
	// = "NOTES_NOREUSE_MULTIVAL";
	private String PersonUnid;
	private String FieldName;
	private String FieldValue;
	private String sqlInsertState;
	private String SuppressFlag = "0";


	public Notes_NoReuse_MultiVal(ConfigObjMediatorDB cfg) throws Exception {
		super();
		TABLENAME = cfg.getTable()[0];
	}

	public String getPersonUnid() {
		return PersonUnid;
	}
	public void setPersonUnid(String personUnid) {
		PersonUnid = personUnid;
	}
	public String getFieldName() {
		return FieldName;
	}
	public void setFieldName(String fieldName) {
		FieldName = fieldName;
	}

	public String getFieldValue() {
		return FieldValue.replaceAll("'", "''");
	}

	public void setFieldValue(String fieldValue) {
		FieldValue = fieldValue;
	}

	public String getSqlInsertState() {
		sqlInsertState = "INSERT INTO " + TABLENAME + "(PERSONUNID, FIELDNAME, FIELDVALUE, SUPPRESSFLAG) VALUES ('" +
				getPersonUnid() + "', '"	+ getFieldName() + "', '" + getFieldValue() + "', '" + getSuppressFlag()  + "')";
		return sqlInsertState;
	}

	public String getSuppressFlag() {
		return SuppressFlag;
	}

	public void setSuppressFlag(String suppressFlag) {
		SuppressFlag = suppressFlag;
	}


}
