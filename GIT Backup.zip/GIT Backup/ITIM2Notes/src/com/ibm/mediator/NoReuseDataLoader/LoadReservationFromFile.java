package com.ibm.mediator.NoReuseDataLoader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Date;
import java.util.HashSet;
import java.util.Properties;
import java.util.Vector;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.FileLoger;
import com.ibm.mediator.NoReuseData.ReservationData;
import com.ibm.mediator.NoReuseInterface.ResponseBasic;
import com.ibm.mediator.NoReuseLogic.NoReuseReservationHandler;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.notes.secure.PasswordHandler;
import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class LoadReservationFromFile extends NotesThread {

	private Session session;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoadReservationFromFile lrf = new LoadReservationFromFile();
		lrf.start();

	}
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();

		session = NotesFactory.createSessionWithFullAccess("jac2mac.");
		Database dbEd = CommonFunctions.getDatabase(session, "D06HBRS1", "g_dir/dircats/edcww.nsf");
		View vwEd = dbEd.getView("($Users)");
		Document docEd ;
		ReservationData rd;
		HashSet<String> hs = null;
		int icount = 0;
		Name nFullName;
		String []eMailAlias = null;
		String []fullnameAlias = null;
		Vector <String>vFullname = null;
		Vector <String> vshortname = null;
		FileLoger flog = new FileLoger("c:/temp/log", "txt");
		DB2ConnectData db2Con = getdb2con();
		NoReuseReservationHandler nrH = new NoReuseReservationHandler(flog, db2Con);
		ResponseBasic rb = null;

		try {
			// file format : Current Internet Address,New Internet Address Choice #1,New Internet Address Choice #2,New Internet Address Choice #3,0
			FileReader fr = new FileReader("C:\\temp\\LoadRes1.txt");
			BufferedReader br = new BufferedReader(fr);
			String line;
			String [] data;
			String key;
			String fullname;

			boolean bfirst = true;
			while ((line = br.readLine()) != null){
				if (bfirst){
					bfirst = false;
					continue;
				}
				data = line.split(",");
				icount =0;
				hs = new HashSet<String>();

				// collect the e-mail
				for (String s: data){
					if (icount >0 && s.indexOf("@") >0){
						hs.add(s);
					}
					icount++;
				}

				key = data[0];
				docEd = vwEd.getDocumentByKey(key);
				if (docEd == null){
					pln(key + " not found");
				}else{
					pln(key + ":" + docEd.getItemValueString("Empnum") + docEd.getItemValueString("Empcc"));

					DateTime dt = session.createDateTime(new Date());
					rd = new ReservationData();
					rd.setSerialNumberPSC(docEd.getItemValueString("Empnum") + docEd.getItemValueString("Empcc"));
					vshortname =docEd.getItemValue("ShortName");
					rd.setShortName(vshortname.lastElement());
					rd.setCreationDate(CommonFunctions.getYYYYMMDD(dt).substring(0, 8));
					rd.setEMailAddress(getfirstNamePart(key, "@") + "@ibm.com");
					eMailAlias = hs.toArray((new String[hs.size()]));
					for(int i = 0; i < eMailAlias.length; i++){
						eMailAlias[i] = getfirstNamePart(eMailAlias[i], "@") + "@ibm.com";
					}
					rd.setEMailAlias(eMailAlias);
					rd.setFirstName(docEd.getItemValueString("FirstName"));
					rd.setLastName(docEd.getItemValueString("LastName"));
					rd.setMiddleInitial(docEd.getItemValueString("MiddleInitial"));
					nFullName = session.createName(docEd.getItemValueString("FullName"));
					rd.setFullName(getfirstNamePart(nFullName.getAbbreviated(),"/"));
					vFullname = docEd.getItemValue("FullName");
					fullnameAlias = vFullname.toArray(new String[vFullname.size()]);
					for(int i = 0; i<fullnameAlias.length; i++){
						nFullName = session.createName(fullnameAlias[i]);
						fullnameAlias[i] =getfirstNamePart(nFullName.getAbbreviated(), "/") + "/US/IBM";
					}
					rd.setFullNameAlias(fullnameAlias);
					pln(rd.toString());
					rb = nrH.createReservation(rd);
					if (rb.getHasError().booleanValue()){
						pln("Error during reseration");
						pln(rb.getErrDescription());
					}
				}
			}
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		;	}
	private void pln(String s){
		System.out.println(s);
	}

	private DB2ConnectData getdb2con(){

		Reader fReader;
		DB2ConnectData  dbcon  = null;
		String passwd = null;
		String stMod = "T";
		Properties propDb2  = null;
		PasswordHandler ph;

		try {
			fReader = new FileReader(AllConstants.DB2PROPERTIES);

			ph = new PasswordHandler();
			propDb2 = new Properties();
			propDb2.load(fReader);

			dbcon = new DB2ConnectData();
			dbcon.setClass(propDb2.getProperty("Class"));
			dbcon.setDB2Database(propDb2.getProperty("Database"));
			dbcon.setdb2LookupView(propDb2.getProperty("Lookupview"));
			dbcon.setDb2SerialLookupView(propDb2.getProperty("SerialLookupView"));
			dbcon.setURL(propDb2.getProperty("URL"));
			dbcon.setLogLevel(Byte.parseByte(propDb2.getProperty("LogLevel")));
					
			dbcon.setIPAddressBackup(propDb2.getProperty("IPAddressBackupProd"));
			if (stMod.equals("T")){
				dbcon.setIPAddress(propDb2.getProperty("IPAddressTest")); // INT
				dbcon.setUserid(propDb2.getProperty("UserIdTest")); // INT
				passwd = ph.getPw(PasswordHandler.kindOfPwDB2);
				dbcon.setPassword(passwd);
				//dbcon.setPassword(propDb2.getProperty("PasswordTest"));
				dbcon.setPort(Integer.parseInt(propDb2.getProperty("PortTest"))); // INT
			}
			if (stMod.equals("P")){
				dbcon.setIPAddress(propDb2.getProperty("IPAddressProd")); // PROD
				dbcon.setUserid(propDb2.getProperty("UserIdProd")); // PROD
				//dbcon.setPassword(propDb2.getProperty("PasswordProd"));
				passwd = ph.getPw(PasswordHandler.kindOfPwDB2);
				dbcon.setPassword(passwd);
				dbcon.setPort(Integer.parseInt(propDb2.getProperty("PortProd"))); // PROD
				dbcon.setIPAddressBackup(propDb2.getProperty("IPAddressBackupProd"));
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


		return dbcon;
	}

	String getfirstNamePart(String nameAbbr, String sep){
		return nameAbbr.split(sep)[0];
	}

}