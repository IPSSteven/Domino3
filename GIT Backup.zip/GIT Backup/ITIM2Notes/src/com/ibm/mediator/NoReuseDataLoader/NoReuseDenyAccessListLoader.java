package com.ibm.mediator.NoReuseDataLoader;

import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Iterator;

import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.Session;

import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.notesdata.Connect;
import com.ibm.ereg.notesdata.ConnectConfig;
import com.ibm.ereg.rmi.data.denyAccess.DenyAccessData;
import com.ibm.ereg.rmi.data.denyAccess.DenyAccessDataLoader;
import com.ibm.mediator.config.ConfigObjMediatorDB;

public class NoReuseDenyAccessListLoader {
	private HashSet<String> denyListTermination;
	private InputOutputLogger log;
	ConfigObjReConcileITIM cr;
	
	public NoReuseDenyAccessListLoader(InputOutputLogger logIN,ConfigObjReConcileITIM crIN,ConfigObjMediatorDB cfgNotes_Noreuse_SingleVal ){
		
		this.log = logIN;
		this.cr = crIN;
	}
	/*
	public HashSet<String>getDenyAccessList(){
		String stRMIServer;
		String stRMIPort;
		NotesRMIClient nrc;
		ReceiveInterFace nri;
		
		Session session = log.getSess();
		Name nName = null;
		HashSet<String> hsResult = new HashSet<String>();
		
		try {
			stRMIServer = cr.getRMIDomin2SearchCorrectNCOUAR()[0];
			stRMIPort = cr.getRMIPortDenyAccess()[0];
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"RMIServer not provided by configuration");
			log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			e.printStackTrace();
			return null;
	
		}
	
		log.logActionLevel(LogLevel.INFO," Try to conect to RMIServer : " + stRMIServer + "RMIPort :" + stRMIPort);
		
		//System.out.println("RMIServer :" + stRMIServer + "RMIPort :" + stRMIPort);
		try {
			nrc = new NotesRMIClient(stRMIServer,stRMIPort);
			nri = nrc.notesRMIInterface;
			denyListTermination = nri.getDenyListTermination();
			Iterator it = denyListTermination.iterator();
			//int iCount = 0;
			while (it.hasNext()){
				//System.out.println(it.next());
				try {
					nName = session.createName((String)it.next());
					hsResult.add(nName.getAbbreviated());
					nName.recycle();
					//iCount++;
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			denyListTermination = null;
			log.logActionLevel(LogLevel.INFO,"Found " + hsResult.size() + " ids in lockoutgroups");
			System.out.println("Found " + hsResult.size() + " ids in lockoutgroups");
			return hsResult;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while connect to RMI Server");
			log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			e.printStackTrace();
			return null;
		}
		
	}
	*/
	public HashSet<String>getDenyAccessListFromDatabase(){
		HashSet<String> hsResult = new HashSet<String>();
		ConnectConfig connConf = new ConnectConfig();	
		connConf.bOpenNames = true;
		Connect eregCon;
		Name nName = null;
		Session session = log.getSess();
		try {
			eregCon = new Connect(session, this.getClass().getSimpleName(), connConf);
			DenyAccessDataLoader dadl = new DenyAccessDataLoader(eregCon, false);
			dadl.loadCountries();
			DenyAccessData dad = DenyAccessData.getInstance();
			
			denyListTermination = dad.denyListTermination;
			Iterator<String> it = denyListTermination.iterator();
			//int iCount = 0;
			while (it.hasNext()){
				//System.out.println(it.next());
				try {
					nName = session.createName((String)it.next());
					hsResult.add(nName.getAbbreviated());
					nName.recycle();
					//iCount++;
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			denyListTermination = null;
			log.logActionLevel(LogLevel.INFO,"Found " + hsResult.size() + " ids in lockoutgroups");
			System.out.println("Found " + hsResult.size() + " ids in lockoutgroups");
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return hsResult;
	}
	

}
