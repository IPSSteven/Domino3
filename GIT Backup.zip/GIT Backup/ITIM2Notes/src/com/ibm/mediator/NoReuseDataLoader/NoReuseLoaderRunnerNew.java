package com.ibm.mediator.NoReuseDataLoader;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjDocuments;
import com.ibm.ereg.config.ConfigObjMailDomainServer;
import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.NoReuseData.NoReuseLoadThreadData;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Session;


public class NoReuseLoaderRunnerNew {
	//private final int iThreadsMax = 16;
	private final int iThreadsMax = 6;
	private Session session;
	private String passwd;
	private String AgentName;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public NoReuseLoaderRunnerNew(Session s, String pw) {
		this.session = s;
		this.passwd = pw;
	}

	public void runLoader() {

		// 1. Get the Log
		Database dbLog;
		Document docRecyle = null;
		try {


			dbLog = CommonFunctions.getLogDB(session);
			InputOutputLogger log = new InputOutputLogger(session, dbLog, "Main process -> Load ids for no reuse  multithread- " + CommonFunctions.getActDateRecon(),
					LogLevel.INFO);
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKRunning();
			log.refreshLog(lds);

			String sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);


			// 1. get the configuration of the Domain server
			ConfigObjMailDomainServer cfgMailDomainServer = new ConfigObjMailDomainServer(session);

			ConfigObjDocuments cfgDocs = new ConfigObjDocuments(session, AllConstants.MEDIATOR_NOTES_NOREUSE_DOMAINS + sMachineKey);
			DocumentCollection dccDocs = cfgDocs.getAllConfigDocuments();
			Document docConfig = dccDocs.getFirstDocument();

			
			while (docConfig != null) {
				log.logActionLevel(LogLevel.INFO, "Start threads for the config document " + docConfig.getItemValueString("Subject") );
				//2. get the configuration for the machine (domain which should be handle by this machine) 
				int type = docConfig.getItemValueInteger("Type");
				ConfigObjReConcileITIM cr = new ConfigObjReConcileITIM(session,Integer.toString(type) + ">" +
						docConfig.getItemValueString("Subject") , log);
				String handleDenyAccess = cr.gethandleDenyAccessGroup()[0];

				ArrayList<NoReuseLoaderThread> aryNoReuseLoaderThread = new ArrayList<NoReuseLoaderThread>();  

				for(String stDom:cr.getDomainList()){
					NoReuseLoadThreadData nrtd = new NoReuseLoadThreadData();
					nrtd.setDomain(stDom);
					nrtd.setStMachineKey(sMachineKey);
					nrtd.setAgentName(this.AgentName);
					nrtd.setStHandleDenyAccess(handleDenyAccess);
					if (handleDenyAccess.contentEquals("Y")) handleDenyAccess = "N"; // Load Deny Access only with the first thread
					//nrtd.setLog(log);
					nrtd.setPassword(passwd);
					NoReuseLoaderThread nrlt = new NoReuseLoaderThread(nrtd);
					nrlt.setName("Thread for " + stDom);
					aryNoReuseLoaderThread.add(nrlt);
				}

				ExecutorService executorServ = Executors.newFixedThreadPool(iThreadsMax);
				//ExecutorService executorServ = Executors.newFixedThreadPool(1);
				for(NoReuseLoaderThread nrlt : aryNoReuseLoaderThread) {
					executorServ.execute(nrlt);
				}

				executorServ.shutdown(); // means not new tasks are accepted anymore
				
				if(executorServ != null){
					executorServ.awaitTermination(180, TimeUnit.MINUTES); // wait 180 minutes .. this should be sufficient

				}
				System.out.println("main Thread finsihed");
				log.logActionLevel(LogLevel.INFO, "Threads for the config document " + docConfig.getItemValueString("Subject") + " finished" );
				
				//cr.recycle();
				docRecyle = docConfig;
				docConfig = dccDocs.getNextDocument(docConfig);
				docRecyle.recycle();
			}
			lds.setOKDone();
			log.closeLog(lds);


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public String getAgentName() {
		return AgentName;
	}
	public void setAgentName(String agentName) {
		AgentName = agentName;
	}

}
