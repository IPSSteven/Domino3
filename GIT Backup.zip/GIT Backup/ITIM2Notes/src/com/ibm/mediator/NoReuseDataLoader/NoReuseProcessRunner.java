package com.ibm.mediator.NoReuseDataLoader;

import com.ibm.notes.secure.PasswordHandler;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class NoReuseProcessRunner extends NotesThread{
	private String pw;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoReuseProcessRunner nrpr = new NoReuseProcessRunner();
		if (args.length == 1 && !args[0].isEmpty())	{
			nrpr.pw = args[0];
		}else {
			PasswordHandler ph = new PasswordHandler();
			nrpr.pw = ph.getPw("Notes");
		}
		nrpr.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess(pw);
		NoReuseLoaderRunnerNew nrr = new NoReuseLoaderRunnerNew(s, pw);
		nrr.setAgentName("(NoReuseLoaderRunner)|agNoReuseLoaderRunner");
		nrr.runLoader();
	}

	

}
