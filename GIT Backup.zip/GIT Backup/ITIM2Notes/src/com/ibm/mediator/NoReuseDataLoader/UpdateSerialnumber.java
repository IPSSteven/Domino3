package com.ibm.mediator.NoReuseDataLoader;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.FileLoger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.mediator.connector.TheEregConnector;

public class UpdateSerialnumber  extends NotesThread{
	private final String  ST_SQLUPD = "UPDATE NOREUSE.\"NOTES_NOREUSE_SINGLEVAL\" SET SERIALPSC = CASE PERSONUNID";
	public static void main(String[] args){
		UpdateSerialnumber us = new UpdateSerialnumber();
		us.start();
	}



	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		FileReader fr;
		String line;
		StringBuffer sbCase = new StringBuffer();
		StringBuffer sbIn = new StringBuffer();
		String [] stSplit ;
		int iRet = 0;
		Session sess = NotesFactory.createSessionWithFullAccess("mac2jac.");
		FileLoger flog = new FileLoger("c:/temp/log", "txt");
		flog.setCheckLogLevel(LogLevel.FINEST);

		int i =0;
		try {
			ConfigObjMediatorDB cfgMDB = new ConfigObjMediatorDB(sess, AllConstants.MEDIATOR_NOTES_NOREUSE_SINGLEVAL, flog);
			DB2ConnectData dbc = cfgMDB.getDB2ConnectionData();
			TheEregConnector con = new TheEregConnector(flog, dbc);

			fr = new FileReader("Z:/tmp/UnidsSerialPSC.txt");
			BufferedReader br = new BufferedReader(fr);
			String sqlUpdate;
			while ((line = br.readLine()) != null){
				stSplit = line.split(",");
				if(stSplit.length == 2){
					if( stSplit[1].length() < 11 ){
						sbCase.append(" WHEN '" + stSplit[0] + "' THEN '" + stSplit[1] + "'");
						sbIn.append("'" + stSplit[0] + "',");
						if(i%500 == 0){
							sqlUpdate = makeSqlStatement(sbCase, sbIn);
							iRet = con.executeUpdate(sqlUpdate);
							if(iRet <0){
								System.out.println(sqlUpdate);
							}
							sbCase = new StringBuffer();
							sbIn = new StringBuffer();
							System.out.println("Update  successfull  proccesse lines " + iRet + "/" + i);

						}
						flog.logActionLevel(LogLevel.INFO, "Success in line;" + i +";"+  line);
					}else{
						flog.logActionLevel(LogLevel.SEVERE, "Error in line (serial too long):" + i +" "+  line);
					}
				}else{
					flog.logActionLevel(LogLevel.SEVERE, "Error in line:" + i +" "+  line);
				}
				i++;

			}
			
			sqlUpdate = makeSqlStatement(sbCase, sbIn);
			iRet = con.executeUpdate(sqlUpdate);
			if(iRet <0){
				System.out.println(sqlUpdate);
			}
			sbCase = new StringBuffer();
			sbIn = new StringBuffer();
			System.out.println("Update  successfull  proccesse lines " + iRet + "/" + i);
			br.close();
			con.close(true);

			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private String makeSqlStatement(StringBuffer sbCase, StringBuffer sbIn){

		if (sbCase.toString().isEmpty() || sbIn.toString().isEmpty()){
			return null;
		}
		int iEndIn = sbIn.toString().length() -1;
		String sqlStatement = ST_SQLUPD + sbCase.toString() + " END WHERE PERSONUNID IN (" + 
				sbIn.toString().substring(0, iEndIn) + ") AND SERIALPSC IS NULL";
		return sqlStatement;
	}


}
