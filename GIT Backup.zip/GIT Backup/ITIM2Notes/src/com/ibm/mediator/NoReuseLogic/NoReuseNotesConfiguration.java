package com.ibm.mediator.NoReuseLogic;

import lotus.domino.Document;
import lotus.domino.Session;

import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.mediator.config.ConfigObjMediatorDB;

public class NoReuseNotesConfiguration {
	private ConfigObjMediatorDB cfgNotes_Noreuse_SingleVal = null;
	private ConfigObjMediatorDB cfgNotes_Noreuse_Multival = null;
	
	public NoReuseNotesConfiguration(Session session, Document docLog) throws Exception{
		RequestLogger log = new RequestLogger(session, docLog);
		this.cfgNotes_Noreuse_SingleVal = new  ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_SINGLEVAL, log);
		this.cfgNotes_Noreuse_Multival = new  ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_MULTIVAL, log);
	}

	public ConfigObjMediatorDB getCfgNotes_Noreuse_SingleVal() {
		return cfgNotes_Noreuse_SingleVal;
	}

	

	public ConfigObjMediatorDB getCfgNotes_Noreuse_Multival() {
		return cfgNotes_Noreuse_Multival;
	}


}
