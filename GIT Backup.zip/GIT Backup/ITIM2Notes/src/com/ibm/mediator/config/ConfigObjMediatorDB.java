package com.ibm.mediator.config;


import lotus.domino.Session;

import com.ibm.ereg.config.ConfigObj;
import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.connector.DB2ConnectData;


public class ConfigObjMediatorDB extends ConfigObj {

	
	
	public ConfigObjMediatorDB(Session sess, String stType, AbstractLogger logger)
			throws Exception {
		super(sess, stType, logger);
		// TODO Auto-generated constructor stub
	}
	public String [] getIpAddressPort()throws Exception{
		return getValue("V1");
	}
	public String [] getUrl()throws Exception{
		return getValue("V2");
	}
	public String [] getClassName()throws Exception{
		return getValue("V3");
	}
	
	public String [] getDatabase()throws Exception{
		return getValue("V4");
	}
	
	public String [] getTable ()throws Exception{
		return getValue("V5");
	}
	public String[] getUser()throws Exception{
		String stResult [] = new String[1];
		String stDummy =  getValue("V6")[0].split(":")[0];
		stResult[0] = stDummy;
		return stResult;
	}
	public String [] getPassword()throws Exception{
		String stResult [] = getValue("V6")[0].split(":");
		if(stResult.length <2){
			throw new Exception("Password for Mediator Connection not found ");
		}else{
			String  stDummy = stResult[1];
			stResult = new String [1];
			stResult[0] = stDummy;
		}

		return stResult;
	}
	public String [] getLogLevel() throws Exception{
		return getValue("V7");
	}
	public String [] getIsActive()throws Exception{
		return getValue("V8");
	}
	public String getRequestType() throws Exception{
		String subject = this.docConfig.getItemValueString("Subject");
		int idig = subject.indexOf("_") + 1;
		int ilen = subject.length();
		return subject.substring(idig,ilen);
	}
	
	public DB2ConnectData getDB2ConnectionData(){
		DB2ConnectData db2con = new DB2ConnectData();
		
		try {
			String [] ipPort = this.getIpAddressPort()[0].split(":");
			db2con.setClass(this.getClassName()[0]);
			db2con.setDB2Database(this.getDatabase()[0]);
			db2con.setdb2LookupView(this.getTable()[0]);
			db2con.setIPAddress(ipPort[0]);
			db2con.setLogLevel(LogLevel.INFO);
			db2con.setUserid(this.getUser()[0]);
			db2con.setPassword(this.getPassword()[0]);
			db2con.setPort(Integer.parseInt(ipPort[1]));
			db2con.setURL(this.getUrl()[0]);
			return db2con;
		} catch (Exception e) {
			
			e.printStackTrace();
			return null;
		}
	}
	
}
