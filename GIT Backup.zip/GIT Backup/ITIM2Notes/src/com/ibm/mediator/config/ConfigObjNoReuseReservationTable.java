package com.ibm.mediator.config;

public class ConfigObjNoReuseReservationTable {
	final String reservationSingleVal = "NOREUSE.NOTES_RESERVATION_SINGLEVAL";
	final String reservationMultiVal = "NOREUSE.NOTES_RESERVATION_MULTIVAL";
	public String getReservationSingleVal() {
		return reservationSingleVal;
	}
	public String getReservationMultiVal() {
		return reservationMultiVal;
	}
}
