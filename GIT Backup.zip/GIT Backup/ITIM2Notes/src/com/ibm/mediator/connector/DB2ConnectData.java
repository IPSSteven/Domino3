package com.ibm.mediator.connector;

public class DB2ConnectData {
	private String IPAddress;
	private String IPAddressBackup;
	private int port;
	private String URL;
	private String DB2Class;
	private String DB2Database;
	private String db2LookupView;
	private String Userid;
	private String Password;
	private String db2SerialLookupView;
	private byte logLevel;
	
	public byte getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(byte logLevel) {
		this.logLevel = logLevel;
	}

	public DB2ConnectData() {
		// TODO Auto-generated constructor stub
		
	}

	public String getIPAddress() {
		return IPAddress;
	}

	public void setIPAddress(String iPAddress) {
		IPAddress = iPAddress;
	}

	public String getIPAddressBackup() {
		return IPAddressBackup;
	}

	public void setIPAddressBackup(String iPAddressBackup) {
		IPAddressBackup = iPAddressBackup;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getDB2Class() {
		return DB2Class;
	}

	public void setClass(String class1) {
		DB2Class = class1;
	}

	public String getDB2Database() {
		return DB2Database;
	}

	public void setDB2Database(String dB2Database) {
		DB2Database = dB2Database;
	}

	public String getdb2LookupView() {
		return db2LookupView;
	}

	public void setdb2LookupView(String dB2View) {
		db2LookupView = dB2View;
	}

	public String getUserid() {
		return Userid;
	}

	public void setUserid(String userid) {
		Userid = userid;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getURL() {
		return URL;
	}

	public void setURL(String uRL) {
		URL = uRL;
	}

	public String getDb2SerialLookupView() {
		return db2SerialLookupView;
	}

	public void setDb2SerialLookupView(String db2SerialLookupView) {
		this.db2SerialLookupView = db2SerialLookupView;
	}
	
	
	

}
