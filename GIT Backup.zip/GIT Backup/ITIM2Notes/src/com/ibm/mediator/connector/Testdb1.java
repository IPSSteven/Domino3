package com.ibm.mediator.connector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import lotus.domino.AgentBase;
import lotus.domino.Session;

public class Testdb1 extends AgentBase {

	public void NotesMain() {

			Session session = getSession();
			//AgentContext agentContext = session.getAgentContext();

			Connection con = null;
			Statement stmt = null;
			String sql;
			// String stUrl = "jdbc:db2://9.149.202.41:50001/MEDIATOR";
			// String stUser = "db2inst2";
			// String stPasswd = "sum69mer";
			String stUrl = "jdbc:db2://9.154.100.168:50001/MEDIATOR";
			String stUser = "mediator";
			String stPasswd = "spr11ing";
			try {
				Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
				con = DriverManager.getConnection(stUrl, stUser, stPasswd);
				stmt = con.createStatement();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			int i = 0;
			System.out.println((new Date()).toString() + "   Starting...");
			for (i = 0; i < 10000; i++) {
				if (i % 10 == 0) {
					System.out.println("falsch");
					sql = "INSERT INTO MEDIATOR.RAWDATALOTUSNOTES "
						+ "(rundate,domain,shortname,firstname,middleinitial,secondname,"
						+ "qualifiedname,serialnumber,NABSerial,TaskID,IDFILE,status) VALUES "
						+ "('20111109202200','IBMBB','ID"
						+ i
						+ "','Bernhard zu lang 0123456789012345467890123456789','T','Tester',"
						+ "'ahahahaha','0423959724','0423959724','N','Y','active')";
				
				} else {
					System.out.println("richtig");
					sql = "INSERT INTO MEDIATOR.RAWDATALOTUSNOTES "
						+ "(rundate,domain,shortname,firstname,middleinitial,secondname,"
						+ "qualifiedname,serialnumber,NABSerial,TaskID,IDFILE,status) VALUES "
						+ "('20111109202200','IBMBB','ID"
						+ i
						+ "','Bernhard','T','Tester',"
						+ "'ahahahaha','0423959724','0423959724','N','Y','active')";
				}

				//System.out.println(sql);
				try {
					stmt.execute(sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if ((i % 1000) == 0) {
					System.out.println("i=" + i);
				}
			}
			System.out.println((new Date()).toString() + "   Ending...");
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
	}
}
