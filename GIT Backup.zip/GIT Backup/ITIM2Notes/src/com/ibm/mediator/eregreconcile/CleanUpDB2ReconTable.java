package com.ibm.mediator.eregreconcile;

import java.sql.ResultSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObj;
import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnector;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class CleanUpDB2ReconTable extends NotesThread {
	private Session s = null;
	private InputOutputLogger log = null;
	private int numberofDataSetToKeep;
	private HashMap <String,Integer> hmDomNumberofSet = new HashMap<String,Integer>();
	private HashMap <String,HashSet<String>> hmDelete = new HashMap<String,HashSet<String>>();
	private HashSet<String> hsDeletionDates;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CleanUpDB2ReconTable curt = new CleanUpDB2ReconTable();
		curt.start();
	}
	public CleanUpDB2ReconTable() {

	}
	public CleanUpDB2ReconTable(Session s, InputOutputLogger log) {
		this.s = s;
		this.log = log;
	}
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Integer NumberOfDataSet;
		String stDom;
		String stDeleteDate;
		StringBuffer sb = new StringBuffer();

		if (s == null) {
			s = NotesFactory.createSessionWithFullAccess("Used2know.");
		}
		try {

			String sMachineKey = s.getEnvironmentString(AllConstants.MACHINEKEY);
			if (log==null) {
				Database dbLog = CommonFunctions.getLogDB(s);
				log = new InputOutputLogger(s, dbLog, "Cleanup ISIM reconcile db2", LogLevel.FINEST);
			}

			ConfigObjReConcileITIM cr = new ConfigObjReConcileITIM(s,
					AllConstants.EREGTOOLRC_CONFIG + sMachineKey,log);
			numberofDataSetToKeep = cr.getNumberOfDataSetsToKeep();
			if (numberofDataSetToKeep <0 ) {
				log.logActionLevel(LogLevel.SEVERE, "Number (V2) of data set to keep is not configured or negative on ReconcileParameter - no cleanup - break ");
				return;
			}

			ConfigObjMediatorDB confMedDB =  new ConfigObjMediatorDB(s, AllConstants.MEDIATORECONCILEDB, log);
			TheEregConnector eregCon = new TheEregConnector(log, confMedDB);

			//1. get the number fo data sets for each domain which are overdue
			String Sql = "SELECT Count(RUNDATE)AS NumOfDataSet, DOMAIN FROM (SELECT DISTINCT DOMAIN, RUNDATE FROM MEDIATOR.RAWDATALOTUSNOTES ORDER BY DOMAIN) GROUP BY DOMAIN HAVING(Count(RUNDATE) >="+ numberofDataSetToKeep+ ")";
			log.logActionLevel(LogLevel.INFO, "Try to execute: " + Sql );
			ResultSet rs = eregCon.excuteQuery(Sql);
			while (rs.next()) {	
				NumberOfDataSet = Integer.valueOf(rs.getString(1));
				stDom = rs.getString(2);
				sb.append(stDom+ ":" + NumberOfDataSet.intValue());
				sb.append(",");
				hmDomNumberofSet.put(stDom, NumberOfDataSet);
			}
			log.logActionLevel(LogLevel.INFO, "Result : " + sb.toString() );

			//2. get the data sets to remove
			log.logActionLevel(LogLevel.INFO, "Try to get the dataset to remove" );
			Set<String> skeys = hmDomNumberofSet.keySet();

			for (String stKey:skeys) {
				sb = new StringBuffer();
				Integer INumberOfDataSets = hmDomNumberofSet.get(stKey);
				int iNumOfDataSet2Delete =  INumberOfDataSets.intValue() -  numberofDataSetToKeep ;

				if (iNumOfDataSet2Delete >0) {
					hsDeletionDates = new HashSet<String>();
					Sql = "SELECT  DISTINCT RUNDATE, DOMAIN FROM MEDIATOR.RAWDATALOTUSNOTES WHERE DOMAIN = '" + stKey + "' ORDER BY RUNDATE  FETCH FIRST "+ iNumOfDataSet2Delete +" ROWS only";
					rs = eregCon.excuteQuery(Sql);
					sb.append(stKey + "->");
					while (rs.next()) {	
						stDeleteDate = rs.getString(1);
						hsDeletionDates.add(stDeleteDate);
						sb.append(stDeleteDate + ",");

					}
					hmDelete.put(stKey,hsDeletionDates);
					log.logActionLevel(LogLevel.INFO, sb.toString());
				}

			}

			//3. Remove the data sets in rawtable and in Reconfig if there some
			skeys = hmDomNumberofSet.keySet();
			for(String stKey: skeys) {
				System.out.println(stKey + "******");
				hsDeletionDates  = hmDelete.get(stKey);
				String stInClause = makeINStatement(hsDeletionDates);
				if (stInClause != null) { 
					Sql ="DELETE FROM MEDIATOR.RAWDATALOTUSNOTES WHERE DOMAIN ='" + stKey + "' AND RUNDATE IN " + stInClause;
					log.logActionLevel(LogLevel.INFO, Sql );
					//rs = eregCon.excuteQuery(Sql);
					int iRes = eregCon.executeUpdate(Sql);
					/*while (rs.next()) {	
						System.out.println("Raw:" +stKey + "->" + rs.getString(1));
						log.logActionLevel(LogLevel.INFO, "Raw:" +stKey + "->" + rs.getString(1) );
						System.out.println(Sql);
					}*/
					System.out.println("Raw:" +stKey + "->" + iRes);
					log.logActionLevel(LogLevel.INFO, "Raw:" +stKey + "->" + iRes + " rows deleted" );

					Sql ="DELETE FROM MEDIATOR.RECONCILECONF WHERE SYSTEM ='" + stKey + "' AND RUNDATE IN" + stInClause;
					log.logActionLevel(LogLevel.INFO, Sql );
					//rs = eregCon.excuteQuery(Sql);
					iRes = eregCon.executeUpdate(Sql);
					/*while (rs.next()) {	
						System.out.println("Conf:" +stKey + "->" + rs.getString(1));
						log.logActionLevel(LogLevel.INFO,"Conf:" +stKey + "->" + rs.getString(1) );
						System.out.println(Sql + "\n");
					}*/
					System.out.println("Conf:" +stKey + "->" + iRes);
					log.logActionLevel(LogLevel.INFO,"Conf:" +stKey + "->" + iRes + " rows deleted" );
				}
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// get the Notes parameter
	}

	private String makeINStatement(HashSet<String> hsDates) {
		if (hsDates == null) return null;
		StringBuffer sb = new StringBuffer();
		sb.append("(");
		for(String stDate:hsDates){
			sb.append("'");
			sb.append(stDate);
			sb.append("', ");
		}


		return sb.length() > 3 ? sb.substring(0,sb.length()-2) + ")": null;
	}

}
