package com.ibm.mediator.eregreconcile;

import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjCountryTable;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnector;
import com.ibm.mediator.eregreconcile.multithreading.ReconcileDataSingleton;
import com.ibm.mediator.mediatordatabeans.BasicData;
import com.ibm.mediator.mediatordatabeans.NCOUAR_Data;
import com.ibm.mediator.mediatordatabeans.ReconcileConfData;
import com.ibm.mediator.mediatordatabeans.ReconcileRawData;

public class MediatorRawDataExtractor {
	TheEregConnector conReconcile = null;
	TheEregConnector conReconcileConf = null;
	//CommonFunctions cf = null;
	Session session = null;
	private String sReconcileRawDateTable = null;
	private String sReconcileConfTable = null;
	private InputOutputLogger log;
	//private final String DENYACCESS = "DenyAccess";
	private static ConfigObjCountryTable coct = null;

	public MediatorRawDataExtractor(Session session, InputOutputLogger log) throws Exception{
		boolean btryBackup = false;
		this.session = session;
		this.log = log;
		// get the config from the ereg Tool database
		ConfigObjMediatorDB confRecon  = new ConfigObjMediatorDB(session, AllConstants.MEDIATORECONCILEDB, log);
		this.sReconcileRawDateTable = confRecon.getTable()[0];
		ConfigObjMediatorDB confReconConf  = new ConfigObjMediatorDB(session, AllConstants.MEDIATORECONCILECONF, log);
		this.sReconcileConfTable =confReconConf.getTable()[0];

		// init the connector 
		try{
			conReconcile = new TheEregConnector(log, confRecon);
		}catch(Exception e){
			if (e instanceof NotesException) {
				throw e;
			}else{
				log.logActionLevel(LogLevel.WARNING, e.getMessage());
				log.logActionLevel(LogLevel.WARNING, "Connection to Mediator database failed. Try to connect to Backup database");
				btryBackup = true;
			}
		}
		
		// try backup
		if (btryBackup){
			confRecon= new ConfigObjMediatorDB(session, AllConstants.MEDIATORECONCILEDBBCK, log);
			confReconConf  = new ConfigObjMediatorDB(session, AllConstants.MEDIATORECONCILECONFBCK, log);
			this.sReconcileConfTable =confReconConf.getTable()[0];
			this.sReconcileRawDateTable = confRecon.getTable()[0];
			conReconcile = new TheEregConnector(log,confRecon);
		}
		
		
		
		// get the configuration of the Mediator config db
		
		// get the CountryTable
		if (coct == null)coct = new ConfigObjCountryTable(session); 
	}


	public boolean insertReconcileConf(ReconcileConfData rc){
		String stSql = rc.INSERT +  this.sReconcileConfTable +  " "+ rc.FIELDCLAUSE + " " + rc.getValuesClause() ;
		if (conReconcile.executeUpdate(stSql) <0) return false; else return true;
	}
	
	public boolean updateReconcileConf(ReconcileConfData rc){
		String stSql = rc.UPDATE +  this.sReconcileConfTable + " set returncode = '" + rc.getReturncode() +
				"', idnumber= " + rc.getIdnumber() +
				", finishdate=" + rc.getEndDate() +
				", Comment= " + rc.getComment() + 
				" WHERE rundate = " + rc.getRunDate() + " AND system = " + rc.getSystem();
		if (conReconcile.executeUpdate(stSql) <0) return false; else return true;
	}
	
	
	public void close(){
		conReconcile.close(false);
	}
	
	public long getReconcileCount(String runDate, String domain){
		String sql = "select count(*) from " + sReconcileRawDateTable + " where rundate = '" + runDate + "' and domain ='" + domain + "'";
		ResultSet rs = conReconcile.excuteQuery(sql);
		long lRet = 0;
		try {
			if (rs.next()){
				lRet = rs.getLong(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lRet;
	}


	public boolean insertReconcileLineNew( Document docNab, NCOUAR_Data cls_NCOUAR, String stRunDate ){
		ReconcileRawData rid = new ReconcileRawData();
		String serialNumber;
		String state = null;
		String stOwnerCountryCode = null;
		//String stArray [] = null;
		//String stCountry = null;
		String stService = null;
		String stFullName = null;
		String stMailSystem = null;
		String stMailServer = null;
		//StringBuffer sb = new StringBuffer();
		ReconcileDataSingleton rs = ReconcileDataSingleton.getInstance();
		String stMailDomainReplacement = null;

		try {
			String stSql = null;
			rid.setRundate(stRunDate);
			/*stMailDomainReplacement = rs.getMailDomainReplacement().get(docNab.getItemValueString("MailDomain"));
			if(stMailDomainReplacement == null){
				rid.setDomain(docNab.getItemValueString("MailDomain"));
			}else{
				log.logActionLevel(LogLevel.INFO, "MailDomain " + docNab.getItemValueString("MailDomain") + " replaced by " + stMailDomainReplacement);
				rid.setDomain(stMailDomainReplacement);
			}*/
			if((cls_NCOUAR != null) &&
				(cls_NCOUAR.getMailDomain().length() > 0) && 
				(!docNab.getItemValueString("MailDomain").equalsIgnoreCase(cls_NCOUAR.getMailDomain()))) 
			{
				rid.setDomain(cls_NCOUAR.getMailDomain());
			}
			else if(docNab.getItemValueString("MailDomain").equalsIgnoreCase(docNab.getItemValueString("NodeName"))){
				rid.setDomain(docNab.getItemValueString("MailDomain"));
			}else{
				rid.setDomain(docNab.getItemValueString("NodeName"));
			}
			//rid.setDomain(docNab.getItemValueString("MailDomain"));
			serialNumber = docNab.getItemValueString("Empnum");
			rid.setNabserial(serialNumber+ docNab.getItemValueString("Empcc"));

			rid.setFirstname(docNab.getItemValueString("FirstName"));
			rid.setMiddleinitial(docNab.getItemValueString("MiddleInitial"));
			rid.setSecondname(docNab.getItemValueString("LastName"));

			stFullName = (String)CommonFunctions.getFirstItemEntry(docNab, "FullName");
			rid.setQualifiedname(stFullName,session);

			rid.setShortname((String)CommonFunctions.getLastItemEntry(docNab, "ShortName"));

			rid.setShortNameAlias(docNab.getItemValue("ShortName"));
			rid.setUsernameAlias(docNab.getItemValue("Fullname"),session);

			rid.setInternetAdress(docNab.getItemValueString("InternetAddress"));
			
			//docNab.get
			//The service is the service of the of the id not of the owner
			stFullName = CommonFunctions.getNameAbbrivate(session, stFullName);
			
			if(docNab.hasItem("MailSystem")){
				stMailSystem = docNab.getItemValueString("MailSystem");
			}else{
				stMailSystem = "1";
				docNab.computeWithForm(false, false);
				docNab.save();
			}
			
			// get the mail system. Some documents doesn't have the item
			stMailSystem = docNab.getItemValueString("MailSystem");
			if (stMailSystem.equals("1")){
				stMailServer = docNab.getItemValueString("MailSerer");
				if (stMailServer != null && !stMailServer.isEmpty()){
					if (stMailServer.contains("NALLN"))stMailSystem = "5";
				}
			}
			stMailSystem = rs.getMailSystemReconcile().get(stMailSystem);
			//log.logActionLevel(LogLevel.INFO, sb.toString());
			rid.setMailSystem(stMailSystem);
			
			// set TaskID flag and has IdFile flag, and serial number of the owner
			if (cls_NCOUAR == null){
				//rid.setSerialnumber(docNab.getItemValueString("Empnum")+ docNab.getItemValueString("Empcc"));
				rid.setSerialnumber("N/A");
				rid.setStatus("NoUAREntr");
				rid.setIdfile("N");
				rid.setTaskid("-");
				rid.setService("N/A");
				rid.setClassification("-");
			}else{
				//rid.setService(cls_NCOUAR.getService());
				serialNumber = cls_NCOUAR.getOwner();  //change 26.11.2013
				//nobody seems to know right there mapping changed 26.11.2013 to owner
				// I think we need to change it back some day.
				//serialNumber = cls_NCOUAR.getSerialNumber(); // change 26.11.2013
				//if (serialNumber.trim().isEmpty() || cls_NCOUAR.getClassification().equals("F")) serialNumber  = cls_NCOUAR.getOwner(); change 26.11.2013

				// The serial number is the serial number of the owner
				if (serialNumber.length() < 7 || !BasicData.b_serialNpsc){
					stOwnerCountryCode = cls_NCOUAR.getOwnerCountry(); 
					stOwnerCountryCode = coct.getCountryNumber(stOwnerCountryCode);
					rid.setSerialnumber(serialNumber + stOwnerCountryCode);
				}else{
					rid.setSerialnumber(serialNumber);
				}
				//rid.setSerialnumber(serialNumber + docNab.getItemValueString("Empcc"));

				
				rid.setClassification(cls_NCOUAR.getClassification());
				rid.setTaskid(cls_NCOUAR.getTaskId());
				rid.setIdfile(cls_NCOUAR.getIdFile());
				state = cls_NCOUAR.getNABState().trim();

				stService = cls_NCOUAR.getService();
				rid.setService(stService);
				
				rid.setStatus(state);
				/*if (state.equals("")){
					if (hsDenyAccessIds.contains(rid.getQualifiedname())){
						rid.setStatus(DENYACCESS);
					}
				}*/
				
				rid.setLnAdapterCustom(cls_NCOUAR.getLnAdapterCustom());
			}

			stSql = rid.INSERT + sReconcileRawDateTable + " " + rid.FIELDCLAUSE + " "+ rid.getValuesclause();
			if (conReconcile.executeUpdate(stSql) <0) return false; else return true;

		}catch (NullPointerException ne){
			if (docNab == null ){
				System.out.println("doc Nab is null");
				System.out.println(ne.getMessage());

			}else{
				System.out.println(rid.getShortname());
				System.out.println(ne.getMessage());
			}
			ne.printStackTrace();
			return false;
		}catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
}
