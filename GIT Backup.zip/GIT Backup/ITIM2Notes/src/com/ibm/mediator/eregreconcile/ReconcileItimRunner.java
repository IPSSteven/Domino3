package com.ibm.mediator.eregreconcile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Properties;

import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

import com.ereg.isim.process.StartIsimReconAsProcess;
import com.ibm.Ereg2Gateway.WSClient;
import com.ibm.ereg.common.CommonFunctionGeneral;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjAgent;
import com.ibm.ereg.config.ConfigObjCountryTable;
//import com.ibm.ereg.config.ConfigObj;
import com.ibm.ereg.config.ConfigObjISIMRecon;
import com.ibm.ereg.config.ConfigObjMailDomain;
import com.ibm.ereg.config.ConfigObjMailSystem;
import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.config.ConfigObjNCOUARReplic;
import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.config.ConfigObjSlack;
import com.ibm.ereg.constants.AllConstants;
//import com.ibm.ereg.isim.auth.Auth;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.TraceLogger;
import com.ibm.ereg.notesdata.Connect;
import com.ibm.ereg.notesdata.ConnectConfig;
//import com.ibm.ereg.logger.TraceLogger;
import com.ibm.mediator.eregreconcile.multithreading.ExtractNabInputData;
import com.ibm.mediator.eregreconcile.multithreading.ExtractNabThread;
import com.ibm.mediator.eregreconcile.multithreading.NcouarGetDataThread;
import com.ibm.mediator.eregreconcile.multithreading.NcourGetDataInput;
import com.ibm.mediator.eregreconcile.multithreading.ReconcileDataSingleton;
import com.ibm.mediator.mediatordatabeans.NCOUAR_Data;
import com.ibm.mediator.mediatordatabeans.ReconcileConfData;
import com.ibm.mediator.mediatordatabeans.ReconcileRawData;
//import com.ibm.ereg.rmi.NotesRMIClient;
//import com.ibm.ereg.rmi.ReceiveInterFace;
import com.ibm.ereg.rmi.data.denyAccess.DenyAccessData;
import com.ibm.ereg.rmi.data.denyAccess.DenyAccessDataLoader;

public class ReconcileItimRunner  {
	private Session session = null;
	private String sMachineKey = null;
	//private Database dbLog = null;
	private Database dbNab = null;
	private String stDomain = null;
	private ConfigObjReConcileITIM cr = null;
	private ConfigObjMaschineProfile mp = null;
	private InputOutputLogger log;
	private Document docRecycle;
	private View vwNCOUARITIMEXP = null;
	private HashMap<String,NCOUAR_Data> hmNCOUAR;
	private boolean bMailError;
	private boolean bMailWarning;
	private String stRunDate = null;
	private MediatorRawDataExtractor me = null;
	private HashSet<String> denyListTermination;
	private HashSet<String> denyListPasswordLockout;
	private final boolean RUN_IN_MULTITHREADMODE = true;
	private String pw;
	private final String PROCCESSNAME = "RECONCILE";
	private final String COMPONENTNAME = "EREG";


	public ReconcileItimRunner(Session sess) {
		super();
		this.session = sess;


	}

	public void setLog(InputOutputLogger log) {
		this.log = log;
	}

	public void runNotes() {


		//session = getSession();
		int iLen = 0;
		long lCount = 0;
		String[] domains = null;
		TraceLogger tracLog = null;
		ReconcileDataSingleton rs = null;
		ConfigObjNCOUAR cfgUAR;
		ConfigObjMailSystem ms;
		ArrayList <String>arDomains2StartISIMreconinEreg;
		ConfigObjAgent cfgAgn = null;
		DateTime dteStart = null;
		DateTime dteNow = null;
		String startTime;
		int iTimeDiff = 0;
		String interval= null;
		boolean bCleanupDB2 = false;
		
		// get the configuration
		try {
			sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);
			cfgAgn = new ConfigObjAgent(session, "2>(agITIMReconcile)", sMachineKey);
			if (!cfgAgn.getParameter("V1")[0].equals("1")) {
				cfgAgn.recycle();
				pln ("agent is not switched on");	
				return;
			}
			interval = cfgAgn.getParameter("V3")[0];
			startTime = cfgAgn.getParameter("V4")[0];
			bCleanupDB2 = cfgAgn.getParameter("V7")[0].equals("1");
			dteNow = session.createDateTime("Today");
			dteNow.setNow();
			dteStart = session.createDateTime(startTime);
			if (dteNow != null && dteStart != null && !interval.toLowerCase().contentEquals("always")) {
				iTimeDiff = dteNow.timeDifference(dteStart);
				pln (dteNow.getLocalTime() + "-" + dteStart.getLocalTime() + " time diff = " + iTimeDiff);
				if(iTimeDiff < 0) {
					pln ("it is not the turn of the agent ");
					return;
				}
			}

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




		try {
			pln("Start - Reconcile");

			// get the log db, the configDB and the NCOUAR DB, trace log
			try {
				if(log == null){
					Database dbLog  = CommonFunctions.getLogDB(session);
					//create the log document for the reconcile
					log = new InputOutputLogger(session, dbLog, "Reconcile ITIM - " + CommonFunctions.getActDateRecon(),
							LogLevel.FINEST);
					log.getDocLog().replaceItemValue("Agent" , "ITIM_Recon\\Reconcile_Java");
				}
				pln("Got the log document");
				if(dteStart == null || dteNow == null | iTimeDiff == 0){
					log.logActionLevel(LogLevel.SEVERE, "Start date no set in the Agent config document - pls set one");
					log.logActionLevel(LogLevel.SEVERE, "End reconcile");
					LogDocStatus lds = new LogDocStatus(log.getDocLog());
					lds.setErrorCode("No Start Date in the configuration for the Agent");
					lds.setReturnCode("444");
					log.closeLog(lds);
					return;
				}

				//set new date in agent configuration
				cfgAgn.setParameter("V5", dteNow.getLocalTime());
				dteNow.recycle();
				dteStart = CommonFunctions.getNextStart(session, interval, dteStart);
				cfgAgn.setParameter("V4", dteStart.getLocalTime());
				pln("set next start to " + dteStart.getLocalTime());
				log.logActionLevel(LogLevel.INFO, "Set next start to " + dteStart.getLocalTime());
				cfgAgn.recycle();

				// get the domains handled by the machine
				this.mp = new ConfigObjMaschineProfile(session, AllConstants.TYPE_MACHINEPROFILE + ">" + sMachineKey, log);
				cr = new ConfigObjReConcileITIM(session,
						AllConstants.EREGTOOLRC_CONFIG + sMachineKey, log);
				domains = cr.getDomainList();
				arDomains2StartISIMreconinEreg = new ArrayList(Arrays.asList(cr.getDomainsToStartISIMReconInEreg()));
				if(domains != null){
					iLen = domains.length;
				}
				stRunDate = CommonFunctions.getActDateRecon();
				tracLog = new TraceLogger(PROCCESSNAME, COMPONENTNAME, CommonFunctionGeneral.joinStringArray(domains, ","));

				//get the NCOUAR database 
				if (cr.useReplica4NCOUAR()) {
					log.logActionLevel(LogLevel.INFO, " **** Using local replica of NCOUAR ****");
					cfgUAR = new ConfigObjNCOUARReplic(session, log);

				}else {
					log.logActionLevel(LogLevel.INFO, " **** Using NCOUAR on server ****");
					cfgUAR = new ConfigObjNCOUAR(session, log);	
				}

				// the mail System Mapping
				ms = new ConfigObjMailSystem(session, AllConstants.MAIL_SYSTEM, log);

			} catch (Exception e1) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, e1.getMessage());
				e1.printStackTrace();
				throw e1; // leave if the conifguration is not ok
			}


			// we have now all the config ... the recon Singleton holds the common data of all threads
			rs = ReconcileDataSingleton.getInstance();
			if(rs.getMailSystemReconcile() == null)	rs.setMailSystemReconcile(ms.getReconcileMailSystem());
			//if(rs.getMailDomainReplacement() == null) rs.setMailDomainReplacement(ms.getReconcileMailDomainReplacement());

			// get the Termination list from RMI or database .. need by all threads .. is added to the Reconcile singleton
			try{
				//getTerminationLists();
				log.logActionLevel(LogLevel.INFO, "Start to load deny access list");
				getTerminationListFromDatabase();
				log.logActionLevel(LogLevel.INFO, "Loaded termination list pw lockout:" + rs.getDenyListPasswordLockout().size()+ " terminations:" +rs.getDenyListTermination().size());
			}catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
				if (tracLog != null)tracLog.logActionLevel(tracLog.getRcError(), "Error while loading TerminationList");
				StringBuilder sb = new StringBuilder();
				for(String stDom:domains) {
					sb.append(stDom);
					sb.append(",");
				}
				LogDocStatus lds = new LogDocStatus(log.getDocLog());
				lds.setErrorCode("Error while try to get DenyList");
				log.closeLog(lds);

				mailError(cr, "Error while getting terminationlist for domains :" + sb.toString());
				throw e;
			}

			//Mediator Raw Data Extractor handles the db2 output 
			try {
				me = new MediatorRawDataExtractor(session, log);   
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				if (tracLog != null)tracLog.logActionLevel(tracLog.getRcError(), "Error intialise the db2 connection to mediator");
				log.logActionLevel(LogLevel.SEVERE, "Error intialise the db2 connection to mediator");
				log.logActionLevel(LogLevel.SEVERE, e1.getLocalizedMessage());
				e1.printStackTrace();
				throw e1;
			}

			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKRunning();
			pln("got configuration ");

			// Config is ok and  now action now loop through all the domains for this machine
			pln ("Start for reconcile for " + iLen + " domains...");
			log.logActionLevel(LogLevel.INFO, "Start for " + iLen + " domains...");
			for (int i = 0; i < iLen; i++) {
				stDomain = domains[i];
				if (tracLog != null) tracLog.logActionLevel(tracLog.getRcSuccess(), "Reconcile for domain " + stDomain + " started");

				// 1. update the reconcile configuration so that no ISIM recon is started while this runs here
				ReconcileConfData rc = new ReconcileConfData();
				rc.setRunDate(stRunDate);
				rc.setIdnumber(Long.toString(0));
				rc.setReturncode("9999");
				rc.setSystem(stDomain);
				rc.setComment("");
				rc.setEndDate("");
				me.insertReconcileConf(rc);

				if (i >0 ){
					lds.setRunning();
					log.refreshLog(lds);
				}

				// Special for IBMGBLMS
				String stDom ;
				log.logActionLevel(LogLevel.INFO, "Try to get the NCOUAR data for "+ stDomain);
				if(stDomain.equalsIgnoreCase("IBMGBLMS")){
					stDom = "IBMGB";
				}else{
					stDom = stDomain;
				}

				// get the NCOUAR DATA  and put on ReconSingleton .. here we need more than one thread
				long millis = System.currentTimeMillis();
				if (RUN_IN_MULTITHREADMODE){
					if (!bgetNCOUARDataNew(cfgUAR, stDom)){
						//if (!bgetNCOUARDataNew(cfgUAR, stDom)){
						log.logActionLevel(LogLevel.SEVERE, "No  NCOUAR data for "+ stDomain + " domain will not be reconciled");
						mailError(cr, "Error while get NCOUAR data for domain " + stDomain + " therefore no recon");
						tracLog.logActionLevel(tracLog.getRcError(), "No NCOUAR data for "+ stDomain + " domain will not be reconciled");
						
						continue;
					}
					// load additional domain
					boolean bLoadSuccess = false;
					for(String sDom: cr.getRMIDomin2SearchCorrectNCOUAR()) {
						log.logActionLevel(LogLevel.INFO, "Try to get the NCOUAR data for aditional domain : "+ sDom);
						bLoadSuccess = bgetNCOUARDataNew(cfgUAR, sDom);
						if(!bLoadSuccess) {
							mailError(cr, stDom + " - no  NCOUAR data for aditional  domain " + sDom +  " therefore no recon");
							continue;
						}
					}
					if(!bLoadSuccess) continue;

					ReconcileDataSingleton rds = ReconcileDataSingleton.getInstance();
					lCount = rds.getNCOUARSize();
				}else{
					if (!bgetNCOUARData(cfgUAR, stDom)){
						//if (!bgetNCOUARDataNew(cfgUAR, stDom)){
						log.logActionLevel(LogLevel.SEVERE, "No NCOUAR data for "+ stDomain + " domain will not be reconciled");
						tracLog.logActionLevel(tracLog.getRcError(), "No  NCOUAR data for "+ stDomain + " domain will not be reconciled");
						continue;
					}
					lCount = hmNCOUAR.size();
				}
				pln("got NCOUAR Data after " + (System.currentTimeMillis() - millis));
				log.logActionLevel(LogLevel.INFO, "got NCOUAR Data after " + (System.currentTimeMillis() - millis)/1000 + " seconds Number of documents:" + lCount);;

				//ReconcileDataSingleton rds = ReconcileDataSingleton.getInstance();
				pln ("Get NCOUAR data for "+ stDomain + " ready Number of  NCOUARData:" + lCount);
				log.logActionLevel(LogLevel.INFO, "Got NCOUAR data for "+ stDomain + " ready Number of  NCOUARData:" + lCount);

				//-------------------------------------------------------------------------------------------------------------------------------------------

				// 2. extract the NAB now
				String[] dummy = stDomain.split("~");
				stDomain = dummy[0];
				ConfigObjMailDomain cm;
				try {
					try {
						cm = new ConfigObjMailDomain(session, "4>"
								+ stDomain, log);
						// get the NAB for Reconcile
						//dbNab = CommonFunctions.getDatabase(session, cm.getServer()[0],AllConstants.NABDBNAME);
						String stDatabase = cr.getNabFilePathAndView(stDomain)[0];
						dbNab = CommonFunctions.getDatabase(session, cm.getServer()[0],stDatabase);
						bMailError = false;
						bMailWarning = false;
						log.logActionLevel(LogLevel.INFO, "Try extract NAB on server:" + cm.getServer()[0] + " Database:" + stDatabase + " Domain:" + stDomain);


						millis = System.currentTimeMillis();
						if (RUN_IN_MULTITHREADMODE){
							lCount = extractNabNew(stDomain, cr); // here we need more than one Thread
							if(lCount <= 0) {
								mailError(cr, "Recon for domain " + stDomain + "failed because not all threads finished" );
							}

						}else{
							lCount =extractNab(stDomain, cr); 
						}
						pln("got Nab after " + (System.currentTimeMillis() - millis)+ " Number of documents:" + lCount);
						log.logActionLevel(LogLevel.INFO, "got Nab Data after " + (System.currentTimeMillis() - millis) + " Number of documents:" + lCount);;


						// update the reconcile configuration
						//long lContr = me.getReconcileCount(stRunDate, stDomain);
						rc.setIdnumber(Long.toString(lCount));
						rc.setEndDate(CommonFunctions.getActDateRecon());
						if (lCount<=0){   // requested by Bernhard .. 22.02.2016 
							rc.setReturncode("-1");
						}else{ 
							rc.setReturncode("0");
						}
						rc.setEndDate(CommonFunctions.getActDateRecon());
						//if (bMailError)rc.setComment("Not all nab entries reconciled. Some errors, pls look at ereg log");
						if (bMailWarning)rc.setComment("Not all nab entries reconciled. Some errors, pls look at ereg log");
						me.updateReconcileConf(rc);

						// Start Reconcile in ISIM now reconcile is col from external
						ConfigObjCountryTable cfgCt = new ConfigObjCountryTable(session);
						HashSet<String> hsServ = cfgCt.getAllOrgforDoamin(stDom);
						for(String stD:hsServ) {
							if (arDomains2StartISIMreconinEreg.contains(stD)) {
								log.logActionLevel(LogLevel.INFO, "try to start reconcile in ISIM for domain "+ stD);
								bMailError = false;
								startReconInISIM(stD);
								if (bMailError) {
									mailError(cr, "Start of reconcile in ISIM (from ereg) failed for domain " + stD);
								}
							}else {
								log.logActionLevel(LogLevel.INFO, "No start for recon in ISIM, because is in not in config. Domain = "+ stD);
							}
						}
						//log.logActionLevel(LogLevel.INFO, "Done reconcile in ISIM  "+ stDomain);

						log.logActionLevel(LogLevel.INFO, "Extracted "+ stDomain);

						//bMailError = true; // test only
						if(bMailError){
							//mailError(cr, stDomain);
							tracLog.logActionLevel(tracLog.getRcSuccess(),"Reconcile for domain " + stDom + " finished with some errors. Number of ids =  " + lCount);
						}else{
							tracLog.logActionLevel(tracLog.getRcSuccess(), "Reconcile for domain " + stDom + " finished without errors. Number of ids =  " + lCount);
						}

					} catch (Exception e) {
						// TODO Auto-generated catch block
						log.logActionLevel(LogLevel.SEVERE, "Error while extracting domain: " + stDomain);
						log.logActionLevel(LogLevel.SEVERE, e.getMessage());
						e.printStackTrace();
					}
					dbNab.recycle();
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				if(RUN_IN_MULTITHREADMODE){
					ReconcileDataSingleton.getInstance().recycle();
				}
				//extractDenyAccess(stDomain);

			}// end of loop

			if(bCleanupDB2) {
				CleanUpDB2ReconTable cleanDB2 = new CleanUpDB2ReconTable(session, log);
				cleanDB2.runNotes();
			}

			log.logActionLevel(LogLevel.INFO, "Reconcile finished");
			me.close();
			lds.setOKDone();
			log.closeLog(lds);
		} catch (Exception e){
			
			mailError(cr, "*****Error in reconcile Runner :" + e.getLocalizedMessage() + "-"+ e.getMessage());
			e.printStackTrace();
		}
	}

	long extractNab(String stDomain, ConfigObjReConcileITIM cr) {
		String stFullName = null;
		long lcount = 0;
		String stFormula = null;
		boolean bHandleDomSep = cr.handleDomainSeparated(stDomain);
		Vector<String> vFilter = null;
		//NCOUAR_Data nc = null;
		String stKey = null;
		Vector <String> vecShortname;
		View vwReg = null;
		Document docNab = null;

		// reconcile person documents
		try {
			stFormula = cr.getFilterFormula()[0];
			// Changed by krm to read value from reconcile config doc, if available
			String stView = AllConstants.NABVIEWFORRECONCILE ;
			try {
				stView = cr.getNabFilePathAndView(stDomain)[1];
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			vwReg = dbNab.getView(stView);
			docNab = vwReg.getFirstDocument();
		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Problem(NotesException) while get the config NAB view or the first document" );
			log.logActionLevel(LogLevel.SEVERE, e1.getLocalizedMessage() );
			e1.printStackTrace();
			return -1;
		} catch (Exception e) {
			log.logActionLevel(LogLevel.SEVERE, "Problem(Exception) while get the config NAB view or the first document" );
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage() );
			e.printStackTrace();
			return -1;
		}

		// init the Servicecounter
		//rsc = new ReconcileServiceCounter();
		while (docNab != null) {	
			//fe.writeLine(docNab);
			try {
				vFilter = session.evaluate(stFormula,docNab);
			} catch (NotesException e1) {
				log.logActionLevel(LogLevel.SEVERE, "Problem(Exception) while Evaluate" );
				log.logActionLevel(LogLevel.SEVERE, e1.getLocalizedMessage() );
				e1.printStackTrace();
			}
			//System.out.println("type" + vFilter.firstElement().getClass().getName());
			stFullName = (String)CommonFunctions.getFirstItemEntry(docNab, "FullName");
			if(vFilter.firstElement() != null && ((String)vFilter.firstElement()).equals("1")){
				log.logActionLevel(LogLevel.FINER, stDomain + "-" + stFullName + " filtered");
				docRecycle = docNab;
				try {
					docNab = vwReg.getNextDocument(docNab);
					docRecycle.recycle();
				} catch (NotesException e) {
					log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get the next document");
					log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + e.id + ", Text=" + e.text);
				}

				continue;
			}

			try {
				if(bHandleDomSep && !docNab.getItemValueString("MailDomain").equalsIgnoreCase(stDomain)){
					docRecycle = docNab;
					try {
						docNab = vwReg.getNextDocument(docNab);
						docRecycle.recycle();
					} catch (NotesException e) {
						log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get the next document");
						log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + e.id + ", Text=" + e.text);
						return -1;
					}

					continue;
				}
			} catch (NotesException e1) {
				log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get mail domain");
				log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + e1.id + ", Text=" + e1.text);
			}


			try{
				stKey = "";
				vecShortname= docNab.getItemValue("ShortName");
				if(stDomain.equalsIgnoreCase("IBMGBLMS")){
					stKey = "IBMGB" + vecShortname.lastElement();
				}else{
					stKey = stDomain + vecShortname.lastElement();
				}
				//stKey = stDomain + vecShortname.lastElement();
			}catch(Exception e ){
				log.logActionLevel(LogLevel.WARNING, "Problem with shortName for id with fullname "+ stFullName );
			}

			NCOUAR_Data ncd = hmNCOUAR.get(stKey.toUpperCase());

			// Bernhard special
			if(stDomain.equalsIgnoreCase("IBMGBLMS")){
				if (ncd == null || !ncd.getService().equalsIgnoreCase("IBMGBLMS")){
					try {
						docRecycle = docNab;
						docNab = vwReg.getNextDocument(docNab);
						docRecycle.recycle();
					} catch (NotesException e) {
						log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get the next document");
						log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + e.id + ", Text=" + e.text);
					}

					continue;
				}
			}


			checkLockoutStatus(stFullName,ncd);



			//insert line into db2 table
			//chg1
			if (me.insertReconcileLineNew(docNab, ncd, stRunDate)){ 
				lcount++;
			}else{
				bMailError = true;
			}
			//if(docUar != null) docUar.recycle();


			docRecycle = docNab;
			try{
				docNab = vwReg.getNextDocument(docNab); // risk that one doc  is not delete from storage
				docRecycle.recycle();
			}catch(NotesException ne){
				log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get the next document");
				log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + ne.id + ", Text=" + ne.text);
				return -1;
			}

		}
		log.logActionLevel(LogLevel.INFO, stDomain + ":" + lcount + " persons");

		return lcount;
	}
	private void extractDenyAccess(String stDomain){

		//new DenyAccessExtractor(session, stDomain, mp, log);
		try {
			DenyAccessExtractor de = new  DenyAccessExtractor(session, mp, stDomain, log);
			View vwDenyAccess = dbNab.getView(AllConstants.NABVIEWFORDENYACCESS);
			Document docDenyGroup = vwDenyAccess.getFirstDocument();
			String stListName = null;
			long lCounter = 0;
			DateTime dteNow = session.createDateTime("Today");
			while (docDenyGroup != null){
				lCounter ++;
				dteNow.setNow();
				de.writeDenyAcc(dteNow.getDateOnly() + " " + dteNow.getTimeOnly()+ "\r\n");
				stListName = docDenyGroup.getItemValueString("ListName");
				de.writeDenyAcc("*" + stListName + "*" + "\r\n");
				if(stListName.indexOf("Lockout")>=0 ){
					if (stListName.indexOf(stDomain) >= 0){
						de.writeDenyAcc(docDenyGroup);
					}
				}else{
					de.writeDenyAcc(docDenyGroup);
				}
				docRecycle = docDenyGroup;
				docDenyGroup = vwDenyAccess.getNextDocument(docDenyGroup);
				docRecycle.recycle();
			}
			log.logActionLevel(LogLevel.INFO, lCounter +" terminatiion groups in names.nsf");
			de.closeFile();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Error while extracting  "
					+ stDomain);
			log.logActionLevel(LogLevel.SEVERE, e.toString());
			e.printStackTrace();

		}
	}
	private void pln(String stLine){
		System.out.println(stLine);
	}


	private void mailError(ConfigObjReConcileITIM cr, String stDomain){
		String informError = null;
		try {
			informError = cr.getInformErrorSystem();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if (informError != null && informError.toLowerCase().contains("notes")) {
			try {
				String stRecipient []  = cr.getErrorMailRecipient();
				Vector<String>vRecipient = new Vector<String>();
				Database dbCurrent = session.getCurrentDatabase();
				if (dbCurrent == null)dbCurrent = log.getDbLog();
				Document docMail = dbCurrent.createDocument();
				lotus.domino.RichTextItem rtiMail = docMail.createRichTextItem("Body");
				docMail.replaceItemValue("subject", "ITIM Reconcile Error: " + stDomain);
				rtiMail.appendText("Reconcile Error: " + stDomain + ":");
				rtiMail.appendDocLink(log.getDocLog(), "Link to the log");

				for(String strRep:stRecipient){
					vRecipient.addElement(strRep);
				}
				docMail.send(vRecipient);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if (informError != null && informError.toLowerCase().contains("slack")){
			
				
				try {
					ConfigObjSlack cfgSlack = new ConfigObjSlack(session, AllConstants.TYPE_DRAFT + ">Slack");
					String url =  cfgSlack.getProvUrl();
					String stText = cfgSlack.getText();
					
					
					String stLink = log.getDocLog().getNotesURL();
					int idxB = stLink.indexOf("@");
					int idxE = stLink.indexOf("/", idxB);
					String st2rep = stLink.substring(idxB, idxE);
					stLink = stLink.replaceFirst(st2rep,"");
					
					//String jsonStr = "{ \"text\": \"This is a test pls disregard it : "+ stLink + "\"}" ;
					String jsonStr = "{ \"text\": \"" +stText + stLink + "\"}" ;
					WSClient wsClient = new WSClient() ;
					try {
						String reply = wsClient.doPost(url, jsonStr) ;
						System.out.println(reply);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		}
		
	}
	private boolean bgetNCOUARData(ConfigObjNCOUAR cfgUAR, String stDomain){
		String stKey  = null;
		long lcount = 0;
		long lsize = 0;
		hmNCOUAR = new HashMap<String, NCOUAR_Data>();

		try {
			// the view looks:
			// Domain + shortname, LotusName, Shortname, Domain, Firstname~MiddleInitial~LastName, AsoDom, Owner, EmpNo,
			// ASoEmpNum,Clasification, Classification, hasAttachment, ITIOwner, SecondaryId, State
			vwNCOUARITIMEXP = cfgUAR.getVwITIMEXPORT(stDomain); // this is hidden view in NCOUAR '(ITIMEXPORT)'
		
			cfgUAR.getDbNCOUAR(stDomain).getView(AllConstants.NCOUARVIEWITIMEXPORT);
			ViewEntryCollection vec = vwNCOUARITIMEXP.getAllEntriesByKey(stDomain,true);


			ViewEntry ve = vec.getFirstEntry();
			ViewEntry veRec = null;
			NCOUAR_Data nd = null;
			Vector vecLine = null;
			lsize = vec.getCount();

			while(ve != null){
				vecLine = ve.getColumnValues();

				stKey = vecLine.elementAt(3).toString() + vecLine.elementAt(2).toString();
				stKey = stKey.toUpperCase();

				nd = new NCOUAR_Data();
				nd.setClassification(vecLine.elementAt(9).toString());
				// test
				//if (stKey.equalsIgnoreCase("IBMZAPURITY")){
				//	String dummy = nd.getClassification();
				//}
				// test
				if (vecLine.elementAt(10).toString().equals("1.0")){
					nd.setIdFile("Y");
				}else{
					nd.setIdFile("N");
				}
				nd.setOwner(vecLine.elementAt(6).toString());
				nd.setOwnerCountry(vecLine.elementAt(5).toString());
				nd.setSerialNumber(vecLine.elementAt(8).toString());
				nd.setService(vecLine.elementAt(5).toString());
				nd.setState(vecLine.elementAt(13).toString());
				if(nd.getClassification().equals("F")){
					nd.setTaskId("Y");
				}else{
					nd.setTaskId("N");
				}
				//hmNCOUAR.put(stKey, nd);
				hmNCOUAR.put(stKey.toUpperCase(), nd);
				veRec = ve;
				ve = vec.getNextEntry(ve);
				veRec.recycle();
				lcount ++;
				//if (lcount % 100 ==0)pln("Reading " + lcount +"/" + lsize + "entry");
			}
			vec.recycle();
			if (hmNCOUAR.size() == 0){
				log.logActionLevel(LogLevel.SEVERE, "NO NCOUAR data found for the Domain" + stDomain );
				return false;
			}else {
				log.logActionLevel(LogLevel.INFO, "Found " + lcount + " ids for domain " +  stDomain );
			}

			return true;

		}catch (NotesException e) {
			// TODO Auto-generated catch block
			System.out.println(" Notes error while get NCOUAR data for the Domain: " + stDomain );
			log.logActionLevel(LogLevel.SEVERE, "Notes error while get NCOUAR data for the Domain: " + stDomain );
			log.logActionLevel(LogLevel.SEVERE, e.getMessage() );
			e.printStackTrace();
			return false;
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error while get NCOUAR data for the Domain: " + stDomain );
			log.logActionLevel(LogLevel.SEVERE, "Error while get NCOUAR data for the Domain" + stDomain );
			log.logActionLevel(LogLevel.SEVERE, e.getMessage() );
			e.printStackTrace();
			return false;
		}

	}

	/*private void getDeniedIsNotInUse(){
		hsDeniedIds= new HashSet<String>();
		View vwDenyAccess;
		Vector<String> vecMembers = null;
		Iterator<String> itMember =  null;
		String strMember = null;
		Name nmMember = null;
		Document docDestroy;

		Document docGroup;
		if (dbNab == null){
			log.logActionLevel(LogLevel.SEVERE, "Nab is null - not able to get denied ids!");
			return;
		}

		try {
			vwDenyAccess = dbNab.getView(DENYVIEW);
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Nab is null - not able to get denied ids ");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			return ;
		}

		try {
			docGroup = vwDenyAccess.getFirstDocument();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		while(docGroup != null){
			try {
				vecMembers = docGroup.getItemValue("Members");
				itMember = vecMembers.iterator();
				while (itMember.hasNext()){
					strMember = (String)itMember.next();
					nmMember = session.createName(strMember);
					if (nmMember.isHierarchical()){
						hsDeniedIds.add(nmMember.getCanonical());
					}
					nmMember.recycle();
				}

			} catch (NotesException e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.WARNING, "Member not found in the deny access group document");
				e.printStackTrace();
			}



			try {
				docDestroy = docGroup;
				docGroup = vwDenyAccess.getNextDocument(docGroup);
				docDestroy.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.logActionLevel(LogLevel.SEVERE, "Error while read the deny access document ");
				docGroup = null;
				break;
			}	
		}
	}*/

	/*
	private void getTerminationLists() throws Exception{
		NotesRMIClient nrc = null;
		ReceiveInterFace nri = null;
		String stRMIServer = null;
		String stRMIPort = null;
		int iTrail = 0;
		boolean bFound = false;


		while(!bFound){
			try {
				//nrc = new NotesRMIClient(session);
				//nrc = new NotesRMIClient("9.149.143.80","9999");
				if (iTrail == 0) {
					stRMIServer = cr.getRMIDomin2SearchCorrectNCOUAR()[0];
					stRMIPort = cr.getRMIPortDenyAccess()[0];
				}else {
					stRMIServer = cr.get2ndRMIServerDenyAccess()[0];
					stRMIPort = cr.get2ndRMIPortDenyAccess()[0];
				}
				log.logActionLevel(LogLevel.INFO,"\"Try connect to RMIServer: " + stRMIServer + " RMIPort: " + stRMIPort);
				System.out.println("Try connect to RMIServer:" + stRMIServer + " RMIPort : " + stRMIPort);
				nrc = new NotesRMIClient(stRMIServer,stRMIPort);
				nri = nrc.notesRMIInterface;
				if(RUN_IN_MULTITHREADMODE){
					ReconcileDataSingleton rds = ReconcileDataSingleton.getInstance();
					rds.setDenyListPasswordLockout(nri.getDenyListPasswordLockout());
					rds.setDenyListTermination(nri.getDenyListTermination());
				}else{
					denyListPasswordLockout =nri.getDenyListPasswordLockout();
					denyListTermination = nri.getDenyListTermination();
				}
				bFound = true;
				log.logActionLevel(LogLevel.INFO,"Connection to RMIServer: " + stRMIServer + " RMIPort: " + stRMIPort + " successful");
				System.out.println("Connection to RMIServer:" + stRMIServer + " RMIPort :" + stRMIPort  + " successful");

			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE,"Can not connect to RMI server:" + stRMIServer + " RMIPort :" + stRMIPort);
				log.logActionLevel(LogLevel.SEVERE,"Error is : " + e.getMessage() );
				for(StackTraceElement ste: e.getStackTrace()) {
					log.logActionLevel(LogLevel.SEVERE,"class name = " + ste.getClassName()+" File Name =" + ste.getFileName() + " method name = " +
							ste.getMethodName() + " Line number = " + ste.getLineNumber());

				}
				e.printStackTrace();
				iTrail++;
				if(iTrail > 1) throw e;
			}
		}

	}
	 */
	private void getTerminationListFromDatabase() throws NotesException, FileNotFoundException {
		ConnectConfig connConf = new ConnectConfig();	
		connConf.bOpenNames = true;
		connConf.bopenLogDb = true;
		pln("get Termination");

		Connect eregCon = new Connect(this.session, this.getClass().getSimpleName(), connConf);
		if(eregCon.dbNamesDE != null)log.logActionLevel(LogLevel.INFO, "Use database for loading termination list " + eregCon.dbNamesDE.getServer() +":" + eregCon.dbNamesDE.getFilePath() +"/" + eregCon.dbNamesDE.getFileName() );

		DenyAccessDataLoader dadl = new DenyAccessDataLoader(eregCon, false);
		dadl.loadCountries();
		DenyAccessData dad = DenyAccessData.getInstance();
		if(RUN_IN_MULTITHREADMODE){
			ReconcileDataSingleton rds = ReconcileDataSingleton.getInstance();
			//rds.setDenyListPasswordLockout(nri.getDenyListPasswordLockout());
			rds.setDenyListPasswordLockout(dad.denyListPasswordLockout);
			//rds.setDenyListTermination(nri.getDenyListTermination());
			rds.setDenyListTermination(dad.denyListTermination);
		}else{
			denyListPasswordLockout =dad.denyListPasswordLockout;
			denyListTermination =dad.denyListTermination;
		}

		eregCon.closeLog();
	}


	private void checkLockoutStatus(String fullName, NCOUAR_Data ncouar){
		Name nmfullname;
		String stFullname;
		String stState;

		if(ncouar == null) return;

		if(denyListPasswordLockout == null || denyListPasswordLockout == null){
			try {
				getTerminationListFromDatabase();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}


		try {
			stState = ncouar.getNABState();
			if (!stState.toUpperCase().equals(ReconcileRawData.STATUS_FREEZE)){
				nmfullname = session.createName(fullName);
				stFullname = nmfullname.getCanonical();
				nmfullname.recycle();

				if(denyListPasswordLockout.contains(stFullname) ){
					ncouar.setState(ReconcileRawData.STATUS_PW_EXPIRED);
					return;
				}

				if(denyListTermination.contains(stFullname)){
					ncouar.setState(ReconcileRawData.STATUS_TERMINATED);
					return;
				}

			}
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException np){
			log.logActionLevel(LogLevel.SEVERE, "Termination list not found -- > exit");
			throw np;
		}
	}

	private boolean bgetNCOUARDataNew(ConfigObjNCOUAR cfgUAR, String stDomain){
		Database dbUar;
		long lcount = 0;
		int istartAt = 0;
		int isize = 1024; // 2048 needs to be able to customize (read from config in future 1024)
		int iThreads = 0; // needs to be able to customize (read from config in future 
		int iThreadsMax = 12;  // (24)eeds to be able to customize (read from config in future 32
		NcourGetDataInput UARInputData;
		//hmNCOUAR = new HashMap<String, NCOUAR_Data>();

		try {
			// the view looks:
			// Domain + shortname, LotusName, Shortname, Domain, Firstname~MiddleInitial~LastName, AsoDom, Owner, EmpNo,
			// ASoEmpNum,Clasification, Classification, hasAttachment, ITIOwner, SecondaryId, State

			//cfgUAR = new ConfigObjNCOUAR(session, log);
			// get the ereg Password from NCOUAR (pro
			vwNCOUARITIMEXP = cfgUAR.getVwITIMEXPORT(AllConstants.EREG_NOTESID_DOMAIN);
			Document docNCOUAR =vwNCOUARITIMEXP.getDocumentByKey(AllConstants.EREG_NOTESID_DOMAIN.toUpperCase()+AllConstants.EREG_NOTESID_SHORTNAME.toUpperCase());
			pw = docNCOUAR.getItemValueString("Password");
			docNCOUAR.recycle();
			//vwNCOUARITIMEXP.recycle();
			
			//vwNCOUARITIMEXP = cfgUAR.getVwITIMEXPORT(stDomain); // this is hidden view in NCOUAR '(ITIMEXPORT)'
			vwNCOUARITIMEXP  = cfgUAR.getVwITIMEXPORT(stDomain, log.getDocLog());
			log.logActionLevel(LogLevel.INFO, "Using view " +  vwNCOUARITIMEXP.getName() + " for creating threads");
			// get view for the right NCOUAR DB
			vwNCOUARITIMEXP.setAutoUpdate(false);
			dbUar = vwNCOUARITIMEXP.getParent();


			pln(vwNCOUARITIMEXP.getParent().getFileName() + "- " + vwNCOUARITIMEXP.getName());

			ViewEntryCollection vec = vwNCOUARITIMEXP.getAllEntriesByKey(stDomain,true);
			//ViewEntryCollection vec = vwNCOUARITIMEXP.getAllEntriesByKey(stDomain);
			lcount = vec.getCount();

			if(dbUar.getServer().isEmpty()) isize = (int)lcount; // only 1 thread if we are on local
			vec.recycle();

			pln("Found " + lcount + " entries");
			iThreads = (int)Math.ceil(lcount/((double)isize)); // size of the heaps

			ExecutorService executorServ = Executors.newFixedThreadPool(iThreadsMax);
			NcouarGetDataThread[] aryUARThread = new NcouarGetDataThread[iThreads];

			ReconcileDataSingleton rds = ReconcileDataSingleton.getInstance();
			rds.clearSuccessTread();

			pln("Found "+ lcount + " entries, heapSize=" + isize + " number of threads=" + iThreads);
			for(int i = 0; i<iThreads; i++){
				// set input data for thread(s)
				UARInputData = new NcourGetDataInput();
				UARInputData.setDatabaseServer(cfgUAR.getDbNCOUAR(stDomain).getServer());
				UARInputData.setDatabasefilepath(cfgUAR.getDbNCOUAR(stDomain).getFilePath());
				istartAt = i*isize +1;
				UARInputData.setiStartAt(istartAt);
				UARInputData.setiStackSize(isize);

				UARInputData.setPassWord(pw);
				UARInputData.setStDomain(stDomain);
				Integer iThread = new Integer(i);
				UARInputData.setThreadNumber(iThread);
				UARInputData.setLog(log);
				UARInputData.setUarViewName(vwNCOUARITIMEXP.getName());

				rds.setSuccessThread(iThread, new Boolean(false));

				// create new Thread and add it to the arrays
				aryUARThread[i] = new NcouarGetDataThread(UARInputData);
				aryUARThread[i].setName("Ncouar from : " + istartAt + " - " + (istartAt + isize));


			}

			for(int i = 0; i<iThreads;i++){
				executorServ.execute(aryUARThread[i]);
			}


			executorServ.shutdown(); // means not new tasks are accepted anymore
			if(executorServ != null){
				executorServ.awaitTermination(90, TimeUnit.MINUTES); // wait 90 minutes .. this should be sufficient

			}

			// check whether all threads finished successful
			for(int i=0; i< iThreads; i++){
				Boolean b = rds.getSuccessThread(new Integer(i));
				if (!b.booleanValue()){
					return false;
				}
			}



		}catch (NotesException e) {
			// TODO Auto-generated catch block
			System.out.println(" Notes error (NotesException) while get NCOUAR data for the Domain: " + stDomain );
			log.logActionLevel(LogLevel.SEVERE, "Notes error while get NCOUAR data for the Domain:" + stDomain );
			log.logActionLevel(LogLevel.SEVERE, e.getMessage() );
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setErrorCode("97");
			lds.setOKDone();
			log.closeLog(lds);
			mailError(cr, " Error during open NCOUAR database");
			try {
				log.getDocLog().save();
			} catch (NotesException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return false;
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error (Exception) while get NCOUAR data for the Domain: " + stDomain );
			log.logActionLevel(LogLevel.SEVERE, "Error while get NCOUAR data for the Domain" + stDomain );
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage() );
			try {
				log.getDocLog().save();
			} catch (NotesException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			return false;
		}
		return true;
	}

	private long extractNabNew(String stDomain, ConfigObjReConcileITIM cr) {
		int iCount = 0;
		int iThreads = 0;
		int iStartAt = 0;
		int iThreadsMax = 24;
		int iSize = 2048;
		long lNumberofReconciledIds = 0;
		View vwReg = null;
		ExtractNabThread [] aryNabThread;

		ExtractNabThread NabThread;
		ExtractNabInputData NabThreadInput;


		// reconcile person documents
		try {
			String stView = AllConstants.NABVIEWFORRECONCILE ;
			try {
				stView = cr.getNabFilePathAndView(stDomain)[1];
			}
			catch(Exception e) {
				e.printStackTrace();
			}

			vwReg = dbNab.getView(stView);

			iCount = vwReg.getAllEntries().getCount();
			iThreads = (int)Math.ceil(iCount/((double)iSize)); // size of the heaps
			aryNabThread = new ExtractNabThread[iThreads];
			ReconcileDataSingleton rds = ReconcileDataSingleton.getInstance();
			rds.clearSuccessTread();
			rds.setbMailError(false);
			rds.setbMailWarning(false);
			pln("Found " + iCount + " entries in NAB for " + stDomain +" HeapSize=" + iSize + " Number of Threads=" + iThreads );

			for(int i = 0;i<iThreads; i++){
				NabThreadInput = new ExtractNabInputData();
				NabThreadInput.setConfObjReconcile(cr);
				NabThreadInput.setDatabaseServer(dbNab.getServer());
				NabThreadInput.setDatabasefilepath(dbNab.getFilePath());
				NabThreadInput.setiStackSize(iSize);
				iStartAt = i*iSize +1;
				NabThreadInput.setiStartAt(iStartAt);
				NabThreadInput.setLog(log);
				//NabThreadInput.setMe(me);
				NabThreadInput.setPassWord(pw);
				NabThreadInput.setStDomain(stDomain);
				NabThreadInput.setStRunDate(stRunDate);
				NabThreadInput.setThreadNumber(new Integer(i));
				NabThread = new ExtractNabThread(NabThreadInput);
				aryNabThread[i] = NabThread;
				rds.setSuccessThread(new Integer(i), new Boolean(false));
			}

			ExecutorService executorServ = Executors.newFixedThreadPool(iThreadsMax);

			for(int i = 0; i< iThreads; i++){
				executorServ.execute(aryNabThread[i]);
			}


			executorServ.shutdown(); // means not new tasks are accepted anymore
			if(executorServ != null){
				executorServ.awaitTermination(180, TimeUnit.MINUTES); // wait 180 minutes .. this should be sufficient

			}

			pln("##############################After ExcutorServer #######################################");

			bMailError = rds.getbMailError();
			bMailWarning = rds.isbMailWarning();

			for(int i = 0; i < iThreads ; i++){
				Boolean b = rds.getSuccessThread(new Integer(i));
				if (!b.booleanValue()){
					return -1;
				}
				lNumberofReconciledIds = lNumberofReconciledIds + rds.getNumberofReconciledIds(new Integer(i)).intValue();
			}
			return lNumberofReconciledIds;



		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Problem(NotesException) while get the config NAB view or the first document" );
			log.logActionLevel(LogLevel.SEVERE, e1.getLocalizedMessage() );
			e1.printStackTrace();
			return -1;

		} catch (Exception e) {
			log.logActionLevel(LogLevel.SEVERE, "Problem(Exception) while get the config NAB view or the first document" );
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage() );
			e.printStackTrace();
			return -1;

		}


	}

	private void startReconInISIM(String dom) {

		String propFile;
		String prefix = "";
		try {
			ConfigObjISIMRecon isimRecon = new ConfigObjISIMRecon(session, "12>ISIMRecon");
			String stReconUser =isimRecon.getISIMUser();
			String stPw = isimRecon.getPw();
			String formula = isimRecon.getFormulaServicePrefix();
			Document docLog = log.getDocLog();
			docLog.replaceItemValue("RecDomain", dom);
			docLog.save();
			Vector vRes =session.evaluate(formula, docLog);
			if(vRes != null && !vRes.isEmpty()) {
				dom = vRes.firstElement().toString();
			}



			propFile = isimRecon.getPropertyFile();
			//pln(stReconUser + "/" + stPw + "/" + propFile);
			FileInputStream fis = new FileInputStream(new File(propFile)) ;
			Properties props = new Properties();
			props.load(fis);
			fis.close();

			System.out.println("Running recon for  dom .... " + dom ) ;
			StartIsimReconAsProcess sISIMRecon = new StartIsimReconAsProcess();
			sISIMRecon.startReconinIsim(stReconUser, stPw, propFile, dom);
			ArrayList<String> aLog = sISIMRecon.getLog();
			for(String sLog : aLog ) {
				if (sLog.contains("Exception")) {
					bMailError = true;
				}
				log.logActionLevel(LogLevel.INFO, sLog);
			}
			System.out.println("Running recon....") ;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Error during recon of " + dom);
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
		}


	}

	public void startISIMReconOnly() {
		if(log == null){
			Database dbLog;
			try {
				dbLog = CommonFunctions.getLogDB(session);
				//create the log document for the reconcile
				log = new InputOutputLogger(session, dbLog, "Reconcile ITIM - " + CommonFunctions.getActDateRecon(),
						LogLevel.FINEST);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// get the machine key an the domains handled by the machine
		try {
			sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);
			this.mp = new ConfigObjMaschineProfile(session, AllConstants.TYPE_MACHINEPROFILE + ">" + sMachineKey, log);
			//pln("Machine key:" + sMachineKey);

			cr = new ConfigObjReConcileITIM(session,
					AllConstants.EREGTOOLRC_CONFIG + sMachineKey, log);
			String [] domains = cr.getDomainList();

			for (String stDom: domains) {
				startReconInISIM(stDom);
			}

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}




	}


}
