package com.ibm.mediator.eregreconcile;

import java.util.HashMap;
import java.util.Set;

public class ReconcileServiceCounter {
	private HashMap<String, Count> hmServiceCount;
	//private long lcount;
	
	private class Count{
		// we don't want to use Integer because it is immutable
		long count;

		public long getCount() {
			return count;
		}

		public void setCount(long count) {
			this.count = count;
		}
		
	}
	
	public  ReconcileServiceCounter(){
		hmServiceCount = new HashMap<String, Count>();
	}
	
	public void addService(String Service){
		Count cCount = hmServiceCount.get(Service);
		if(cCount == null){
			Count c = new Count();
			c.setCount(1);
			hmServiceCount.put(Service,c);
		}else{
			cCount.setCount(cCount.getCount() + 1);
		}
	}
	
	public long getServiceCount(String Service){
		Count cCount = hmServiceCount.get(Service);
		if(cCount == null){
			return 0;
		}else{
			return cCount.getCount();
		}	
	}
	
	public String[] getAllServices(){
		
		Set<String> s = hmServiceCount.keySet();
		return s.toArray(new String[s.size()]);
		
		
		
	}

}
