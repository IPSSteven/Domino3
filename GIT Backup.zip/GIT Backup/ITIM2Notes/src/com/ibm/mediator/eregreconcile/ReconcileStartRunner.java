package com.ibm.mediator.eregreconcile;




import com.ibm.notes.secure.PasswordHandler;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class ReconcileStartRunner extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		ReconcileStartRunner rsr = new ReconcileStartRunner();
		rsr.start();
	}
	
	
	
	

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		PasswordHandler ph = new PasswordHandler();
		String pw =  ph.getPw("Notes");
		
		//System.out.println("PW---" +pw);
	
		Session sess = NotesFactory.createSessionWithFullAccess(pw );
		ReconcileItimRunner rr = new ReconcileItimRunner(sess);
		/*System.out.println("\n\n Begin" +this.getClass().getName());
		CommonFunctions.showenv();
		System.out.println("End" +this.getClass().getName() + "\n\n"); */
		rr.runNotes();
	}
	
	

}
