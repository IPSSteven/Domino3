package com.ibm.mediator.eregreconcile.multithreading;

import java.util.HashMap;
import java.util.HashSet;
import java.util.TreeMap;

import com.ibm.mediator.mediatordatabeans.NCOUAR_Data;

public class ReconcileDataSingleton {
	private static ReconcileDataSingleton reconDataSing = null;
	
	private TreeMap<String, NCOUAR_Data> tmNCOUAR = new TreeMap<String, NCOUAR_Data>();
	
	private HashSet<String> denyListTermination = null;
	private HashSet<String> denyListPasswordLockout = null;
	private HashMap<String,String> mailSystemReconcile = null;
	//private HashMap<String,String> mailDomainReplacement = null;
	private TreeMap<Integer, Boolean> ThreadSuccessful = new TreeMap<Integer, Boolean>();
	private TreeMap<Integer, Integer> NumberOfReconiledIDs = new TreeMap<Integer, Integer>();
	
	private boolean bMailError = false;
	private boolean bMailWarning = false;
	
	private ReconcileDataSingleton(){
		
	}
	
	public static ReconcileDataSingleton getInstance(){
		if(reconDataSing == null){
			synchronized (ReconcileDataSingleton.class) {
				if (reconDataSing == null){
					reconDataSing = new ReconcileDataSingleton();
				}
			}
			
		}
		return reconDataSing;
	}
	
	public synchronized void addNCOUARData (String key, NCOUAR_Data value){
		tmNCOUAR.put(key, value);
	}
	public int getNCOUARSize(){
		return tmNCOUAR.size();
	}
	
	public void setSuccessThread (Integer iThread, Boolean bSuccess){
		ThreadSuccessful.put(iThread, bSuccess);
	}
	public Boolean getSuccessThread(Integer iThread){
		return ThreadSuccessful.get(iThread);
	}
	public void clearSuccessTread(){
		ThreadSuccessful = new TreeMap<Integer, Boolean>();
		NumberOfReconiledIDs = new TreeMap<Integer, Integer>();
	}

	public HashSet<String> getDenyListTermination() {
		return denyListTermination;
	}

	public void setDenyListTermination(HashSet<String> denyListTermination) {
		this.denyListTermination = denyListTermination;
	}

	public HashSet<String> getDenyListPasswordLockout() {
		return denyListPasswordLockout;
	}

	public void setDenyListPasswordLockout(HashSet<String> denyListPasswordLockout) {
		this.denyListPasswordLockout = denyListPasswordLockout;
	}
	
	public NCOUAR_Data getNCOUAR_Data(String stKey){
		return tmNCOUAR.get(stKey);
	}
	
	public void recycle(){
		//reconDataSing = null;
		//denyListTermination = null;
		//denyListPasswordLockout = null;
		ThreadSuccessful = new TreeMap<Integer, Boolean>();
		NumberOfReconiledIDs = new TreeMap<Integer, Integer>();
	}

	public boolean getbMailError() {
		return bMailError;
	}

	public void setbMailError(boolean bMailError) {
		this.bMailError = bMailError;
	}
	
	public synchronized void addNumberofReconciledIs(Integer ThreadNumber, Integer NumberOfIds){
		NumberOfReconiledIDs.put(ThreadNumber, NumberOfIds);
	}
	
	public Integer getNumberofReconciledIds(Integer ThreadNumber){
		return NumberOfReconiledIDs.get(ThreadNumber);
	}

	public  synchronized HashMap<String, String> getMailSystemReconcile() {
		return mailSystemReconcile;
	}

	public void setMailSystemReconcile(HashMap<String, String> mailSystemReconcile) {
		this.mailSystemReconcile = mailSystemReconcile;
	}

	public boolean isbMailWarning() {
		return bMailWarning;
	}

	public void setbMailWarning(boolean bMailWarning) {
		this.bMailWarning = bMailWarning;
	}

	

}
