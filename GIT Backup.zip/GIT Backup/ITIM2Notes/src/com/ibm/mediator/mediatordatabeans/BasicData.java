/**
 * The databeans represent the data of an EREG request. The name of the methods must be the same as the name
 * of fields in the view, where the data is read (get and set at the begining) Ex. (getEndDate- SqlViewField EndData)
 * The ordering of the methods needs to be the same as in the view
 */
package com.ibm.mediator.mediatordatabeans;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import lotus.domino.Session;

import com.ibm.ereg.config.ConfigObjCountryTable;

/**
 * @author Kurt Raiser
 * 
 */
public abstract class BasicData {
	public static final boolean b_serialNpsc = true; // change serial + PSC
	private String rTyp;
	private String endTime;
	private String startTime;
	private String eregMailDomain;
	private String eregShortName;
	public String eregOrg;
	private String status;
	private String ReturnCode;
	private String ReturnCodeDescription;
	private String LNUnId;
	private String ItimRequestID;
	protected ConfigObjCountryTable cfgCT;
	
	public String getRTyp() {
		return rTyp;
	}

	public void setRTyp(String rTyp) {
		this.rTyp = rTyp;
	}

	public String getItimRequestID() {
		return ItimRequestID;
	}

	public void setItimRequestID(String itimRequestID) {
		ItimRequestID = itimRequestID;
	}

	public  Method[] Setmethods = null;
	public  Method[] Getmethods = null;

	@SuppressWarnings("unchecked")
	private void initMethods() {
		try {
			// StackTraceElement[] sTrace =
			// Thread.currentThread().getStackTrace();
			// System.out.println(sTrace[2].getClassName());
			// Class c = Class.forName(sTrace[2].getClassName());
			Class c = Class.forName(this.getClass().getName());
			Class cst[] = new Class[1];
			Object[] obj;
			cst[0] = String.class;
			Method[] ms = c.getMethods();
			Method mset;
			String stSetName;
			String stGetName;
			ArrayList<Method> arymdsget = new ArrayList<Method>(5);
			ArrayList<Method> arymdsset = new ArrayList<Method>(5);
			for (Method m : ms) {
				// Get all the getter and setter pairs which do no inherit from the clas Object
				if (m.getDeclaringClass().getName().indexOf("java.lang.Object") < 0) {
					stGetName = (m.getName());
					if (stGetName.indexOf("get") >= 0) {
						stSetName = "set" + stGetName.substring(3, stGetName.length());
						try {
							mset = c.getMethod(stSetName, cst);
							arymdsget.add((Method) m);
							arymdsset.add(mset);
						} catch (SecurityException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (NoSuchMethodException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
		
				}
			}
			
			// do the setter and getter to the arrays
			obj = arymdsget.toArray();
			Getmethods = new Method[obj.length];
			for (int i = 0; i < obj.length; i++) {
				Getmethods[i] = (Method) obj[i];
			}
			obj = arymdsset.toArray();
			Setmethods = new Method[obj.length];
			for (int i = 0; i < obj.length; i++) {
				Setmethods[i] = (Method) obj[i];
			}

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Method[] receiveGetterMethods() {
		if (Getmethods == null || Setmethods == null) {
			initMethods();
		}
		return Getmethods;
	}

	public Method[] receiveSetterMethods() {
		if (Getmethods == null || Setmethods == null) {
			initMethods();
		}
		return Setmethods;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTimeStamp) {
		this.endTime = endTimeStamp;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTimeStamp) {
		this.startTime = startTimeStamp;
	}

	public String getEregMailDomain() {
		return eregMailDomain;
	}

	public void setEregMailDomain(String domain) {
		this.eregOrg = domain; // ITIM delivers the org not the domain
		this.eregMailDomain = cfgCT.getMailDomain(domain); // find the domain for the org
	}

	public String getEregShortName() {
		return eregShortName;
	}

	public void setEregShortName(String shortName) {
		this.eregShortName = shortName;
	}

	public String getStatus() {

		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReturnCode() {
		return ReturnCode;
	}

	public void setReturnCode(String statusCode) {
		this.ReturnCode = statusCode;
	}

	public String getReturnCodeDescription() {
		return ReturnCodeDescription;
	}

	public void setReturnCodeDescription(String statusDescription) {
		ReturnCodeDescription = statusDescription;
	}

	public String getLNUnId() {
		return LNUnId;
	}

	public void setLNUnId(String lNRequestId) {
		LNUnId = lNRequestId;
	}

	public BasicData(){
		
	}
	
	public BasicData(ResultSet rs, Session sess) {
		Method[] mds = receiveSetterMethods();
		Object[] data = new String[1];
		String stData;
		try {
			
			cfgCT = new ConfigObjCountryTable(sess);
			
			// TODO Auto-generated constructor stub
			// move the data from the Resultset to the members .. the view needs to match to the data bean
			// this means, all the getter or setter methods needs an column in the view (without the beginning get and set)
			// the select statement for reading is build in the of the methods
			for (int i = 0; i < mds.length; i++) {
				stData =  rs.getString(i + 1);
				if (stData != null) stData = stData.trim();
				data[0] = stData;
				//System.out.println(mds[i].getName() + "--" + data[0]);
				mds[i].invoke(this, data);
			}
		
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public String receiveRawData(){
		StringBuffer res = new StringBuffer("ItimData:");
		for(Method m : Getmethods){
			try {
				res.append(m.getName() + "=" + m.invoke(this, new Object[0])+ ";") ;
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return res.toString();
	}

}
