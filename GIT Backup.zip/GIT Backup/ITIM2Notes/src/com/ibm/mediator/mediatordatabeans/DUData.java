package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

public class DUData extends BasicData {
	
	public DUData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DUData(ResultSet rs, Session sess) {
		super(rs, sess);
		// TODO Auto-generated constructor stub
	}

}
