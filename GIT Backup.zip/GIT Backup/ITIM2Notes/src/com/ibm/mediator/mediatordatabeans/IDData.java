/**
 * 
 */
package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

/**
 * @author Kurt Raiser
 *
 */
public class IDData extends BasicData {
private String eregHasIdFile;
private String eregMgrMail;
private String eregNewOwner;
private String eregClassification;

	public String getEregClassification() {
	return eregClassification;
}

public void setEregClassification(String eregClassification) {
	this.eregClassification = eregClassification;
}

	public String getEregHasIdFile() {
	return eregHasIdFile;
}

public void setEregHasIdFile(String eregIdFile) {
	this.eregHasIdFile = eregIdFile;
}

public String getEregMgrMail() {
	return eregMgrMail;
}

public void setEregMgrMail(String eregManagerEmail) {
	this.eregMgrMail = eregManagerEmail;
}

public String getEregNewOwner() {
	int iLen =eregNewOwner.length();
	if (iLen >3){
		return eregNewOwner.substring(0, iLen-3);
	}else{
		return eregNewOwner;
	}
}

public void setEregNewOwner(String eregNewOwner) {
	this.eregNewOwner = eregNewOwner;
}

	/**
	 * 
	 */
	public IDData() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param rs
	 * @param sess
	 */
	public IDData(ResultSet rs, Session sess) {
		super(rs, sess);
		// TODO Auto-generated constructor stub
	}

}
