package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

public class KUData extends BasicData {

	

	public KUData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KUData(ResultSet rs,Session sess) {
		super(rs, sess);
		// TODO Auto-generated constructor stub
	}

}
