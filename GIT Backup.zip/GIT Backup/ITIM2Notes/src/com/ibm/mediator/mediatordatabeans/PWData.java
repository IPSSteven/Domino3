package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

public class PWData extends BasicData {
	public PWData() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PWData(ResultSet rs,Session sess) {
		super(rs, sess);
		// TODO Auto-generated constructor stub
	}
	private String eregSpecialFlag;  // if 9 then id is removed from Deny Access
	private String eregMgrId;
	private String eregMgrDomain;
	public String getEregSpecialFlag() {
		return eregSpecialFlag;
	}
	public void setEregSpecialFlag(String eregSpecialFlag) {
		this.eregSpecialFlag = eregSpecialFlag;
	}
	public String getEregMgrId() {
		return eregMgrId;
	}
	public void setEregMgrId(String eregMgrId) {
		this.eregMgrId = eregMgrId;
	}
	public String getEregMgrDomain() {
		return eregMgrDomain;
	}
	public void setEregMgrDomain(String eregMgrDomain) {
		this.eregMgrDomain = eregMgrDomain;
	}
	
}
