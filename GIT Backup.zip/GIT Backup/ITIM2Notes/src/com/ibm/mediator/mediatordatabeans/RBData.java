package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

public class RBData extends BasicData {
	
	public RBData() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RBData(ResultSet rs, Session sess) {
		super(rs, sess);
		// TODO Auto-generated constructor stub
	}
	private String eregLastName;
	private String eregMgrId;
	public String getEregLastName() {
		return eregLastName;
	}
	public void setEregLastName(String eregLastName) {
		this.eregLastName = eregLastName;
	}
	public String getEregMgrId() {
		return eregMgrId;
	}
	public void setEregMgrId(String eregMgrId) {
		this.eregMgrId = eregMgrId;
	}
	public String getEregMgrDomain() {
		return eregMgrDomain;
	}
	public void setEregMgrDomain(String eregMgrDomain) {
		this.eregMgrDomain = eregMgrDomain;
	}
	private String eregMgrDomain;
}
