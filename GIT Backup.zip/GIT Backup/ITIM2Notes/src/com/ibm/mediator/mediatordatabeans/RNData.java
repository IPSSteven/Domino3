package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

public class RNData extends BasicData {
	private String eregSpecialFlag ;
	private String eregLastName;
	private String eregFirstName;
	private String eregMiddleInitial;
	private String eregHasIdFile;
	private String eregNewFullName;
	private String eregNewShortName;


	public RNData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getEregHasIdFile() {
		return eregHasIdFile;
	}

	public void setEregHasIdFile(String eregIsIDInNCOUAR) {
		this.eregHasIdFile = eregIsIDInNCOUAR;
	}

	public String getEregSpecialFlag() {
		return eregSpecialFlag;
	}

	public void setEregSpecialFlag(String eregSpecialFlag) {
		this.eregSpecialFlag = eregSpecialFlag;
	}

	public String getEregLastName() {
		return eregLastName;
	}

	public void setEregLastName(String eregLastName) {
		this.eregLastName = eregLastName;
	}

	public String getEregFirstName() {
		return eregFirstName;
	}

	public void setEregFirstName(String eregFirstName) {
		this.eregFirstName = eregFirstName;
	}

	public String getEregMiddleInitial() {
		return eregMiddleInitial;
	}

	public String getEregNewFullName() {
		return eregNewFullName;
	}

	public void setEregNewFullName(String eregFullName) {
		this.eregNewFullName = eregFullName;
	}

	public String getEregNewShortName() {
		return eregNewShortName;
	}

	public void setEregNewShortName(String eregNewShortName) {
		this.eregNewShortName = eregNewShortName;
	}

	public void setEregMiddleInitial(String eregMiddleInitial) {
		this.eregMiddleInitial = eregMiddleInitial;
	}
	

	public RNData(ResultSet rs, Session sess) {
		super(rs, sess);
		// TODO Auto-generated constructor stub
	}

}
