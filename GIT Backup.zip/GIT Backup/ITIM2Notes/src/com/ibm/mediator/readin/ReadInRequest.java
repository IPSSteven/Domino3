package com.ibm.mediator.readin;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.util.ArrayList;

import lotus.domino.AgentBase;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Session;
import lotus.domino.View;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObj;
import com.ibm.ereg.config.ConfigObjBase;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnector;
import com.ibm.mediator.constants.MediatorRequestStatusConstants;
import com.ibm.mediator.mediatordatabeans.BasicData;

public class ReadInRequest extends AgentBase {
	private Session session;
	private Database dbLog;
	private InputOutputLogger logger;
	private RequestBasic ri;
	private TheEregConnector con;
	// private Class cData;
	private String[] stRequests;

	public static void main(String[] argv) {
		/*
		 * String stClassName = "com.ibm.ereg.mediatordatabeans." + "AU" +
		 * "Data"; try { // only test the function main is never used in a notes
		 * Environment Class c = Class.forName(stClassName); Object objData =
		 * c.newInstance(); System.out.println(objData.getClass().getName()); }
		 * catch (ClassNotFoundException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } catch (InstantiationException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } catch
		 * (IllegalAccessException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

	}

	private void getTheLogger() throws Exception {
		try {
			dbLog = CommonFunctions.getLogDB(session);
			logger = new InputOutputLogger(session, dbLog,
					"ITIM-Requst Read in", LogLevel.FINEST);

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			throw e1;
		}
	}

	@SuppressWarnings("unchecked")
	private void handleRequest(Class cData, ResultSet rs) throws Exception {
		String stQuery;
		int iRow;
		Class[] c1 = new Class[2];
		c1[0] = ResultSet.class;
		c1[1] = Session.class;
		BasicData bd = null;
		try {
			// 1. make a instance of data bean and leave if the status not correct
			Constructor ct = cData.getDeclaredConstructor(c1);
			bd = (BasicData) ct.newInstance(rs, session);
			if (bd.getStatus() != null
					&& !bd.getStatus().equals(MediatorRequestStatusConstants.INITIAL)) {
				logger.logActionLevel(LogLevel.FINEST, bd.getRTyp() + " "
						+ bd.getEregMailDomain() + " " + bd.getEregShortName()
						+ " not started because Status != "
						+ MediatorRequestStatusConstants.INITIAL);
				return;
			}

			// create the log document and write the unid of the document to the data bean
			RequestLogger rl = new RequestLogger(session, dbLog, "ITIM-Typ:"
					+ bd.getRTyp()+"-Dom:" + bd.getEregMailDomain()+ "-Short:" + bd.getEregShortName() 
					+"-ItimID:" + bd.getItimRequestID(), bd);
			logger.logActionLevel(LogLevel.FINEST, "Try to start "
					+ bd.getRTyp() + " " + bd.getEregMailDomain() + " "
					+ bd.getEregShortName());

			// move all the data from DB2 to new request and set the request status ready to start
			if (rl.startRequest()) {
				// start successfull
				logger.logActionLevel(LogLevel.FINEST, "Started "
						+ bd.getRTyp() + " " + bd.getEregMailDomain() + " "
						+ bd.getEregShortName() + "sucessfull");
				logger.logActionLevel(LogLevel.FINEST,
						"Try to update the request database");
				// set the status and the unid of the log document
				bd.setLNUnId(rl.getDocLog().getUniversalID());
				bd.setStatus(MediatorRequestStatusConstants.INWORK);
			} else {
				// start goes wrong
				logger.logActionLevel(LogLevel.SEVERE, "Error :" + bd.getRTyp()
						+ " " + bd.getEregMailDomain() + " "
						+ bd.getEregShortName() + "was not successfull");
				logger.logActionLevel(LogLevel.SEVERE, "Error reason: "
						+ rl.getErrorMsg());
				bd.setStatus(MediatorRequestStatusConstants.ERROR);
				bd.setReturnCode("999");
				bd.setReturnCodeDescription(rl.getErrorMsg());
			}

			// build the query to update the SQL database
			logger.logActionLevel(LogLevel.FINEST,
					"Try to build the update statement");
			stQuery = ri.buildUpdate(bd);
			logger.logActionLevel(LogLevel.FINEST, "Update statement: "
					+ stQuery);
			iRow = con.executeUpdate(stQuery);
			if (iRow < 0) {
				logger.logActionLevel(LogLevel.SEVERE,
						"Error:Update of mediator database does not work. Request will be deleted");
				if (rl.deleteRequest()){
					logger.logActionLevel(LogLevel.SEVERE,"Request deleted successful");
				}{
					logger.logActionLevel(LogLevel.SEVERE,"Request can not be deleted");
				}

			} else {
				logger.logActionLevel(LogLevel.FINEST, "Update sucessful: "
						+ iRow + " records updated");
			}

		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			logger.logActionLevel(LogLevel.SEVERE,
					"Argument exception while handle request: " + e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			logger.logActionLevel(LogLevel.SEVERE,
					"Security exception while handle request: " + e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (InstantiationException e) {
			logger.logActionLevel(LogLevel.SEVERE,
					"InstantiationException exception while handle request: " + e.getMessage());
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			logger.logActionLevel(LogLevel.SEVERE,
					"IIllegalAccessException exception while handle request: " + e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			logger.logActionLevel(LogLevel.SEVERE,
					"Invocation Target exception while handle request: " + e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			logger.logActionLevel(LogLevel.SEVERE,
					"No such method exception while handle request Class: "
							+ bd.getClass().getName() + " " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			logger.logActionLevel(LogLevel.SEVERE,
					"Exception exception while handle request: " + e.getMessage());
			throw e;
		}


	}

	private void getRequests() {
		try {
			ConfigObjMediatorDB confMDb;
			String stSubject;
			// get the configuration object (settings in EREG Tool)
			// each request has one config document, where the sql/table,
			// ip-address etc is stored
			ConfigObjBase obj = new ConfigObj(session);
			View vwConf = obj.getVwConfig();
			ArrayList<String> arl = new ArrayList<String>();
			vwConf.refresh();
			DocumentCollection dcc_requests = vwConf
					.getAllDocumentsByKey(AllConstants.MEDIATOREQUESTDB);

			// we got the config doc .. so loop through all request types
			// and put all the subjects to a arrylist
			Document doc_req = dcc_requests.getFirstDocument();
			while (doc_req != null) {
				stSubject = doc_req.getItemValueString("Subject");
				confMDb = new ConfigObjMediatorDB(session, "45>" + stSubject,
						logger);
				if (confMDb.getIsActive()[0].equals("1")) {
					arl.add(confMDb.getRequestType());
				}
				doc_req = dcc_requests.getNextDocument(doc_req);
			}

			// fill the request of this class
			int ilen = arl.size();
			stRequests = new String[ilen];
			for (int i = 0; i < ilen; i++) {
				stRequests[i] = arl.get(i);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	@Override
	public void NotesMain() {

		Session sess = getSession();
		try {

			ReadInRequestRunner  rr = new ReadInRequestRunner(sess);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	} 
}
/**
 * @param args
 */

