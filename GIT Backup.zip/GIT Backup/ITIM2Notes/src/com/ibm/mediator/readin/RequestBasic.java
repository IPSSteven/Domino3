package com.ibm.mediator.readin;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.ibm.ereg.constants.AllConstants;
import com.ibm.mediator.mediatordatabeans.BasicData;

/**
 * @author Kurt Raiser
 * 
 */
public class RequestBasic {
	/**
	 * Methode to read the new request
	 * 
	 */

	public String buildSelect(BasicData bData) {
		StringBuilder stSelect = new StringBuilder("select ");

		Method[] methods = bData.receiveGetterMethods();
		int iLen;
		for (Method m : methods) {
			stSelect.append("\""
					+ m.getName().substring(3, m.getName().length()) + "\" , ");
		}
		iLen = stSelect.length();
		stSelect.delete(iLen - 2, iLen);

		stSelect.append(" from " + AllConstants.SELECTVIEW + bData.getRTyp() + "\" where \"Status\" = 'Initial'");
		return stSelect.toString();
	}

	public String buildUpdate(BasicData bd) {
		Method[] mds = bd.receiveGetterMethods();
		StringBuilder stUpdate = new StringBuilder("update " + AllConstants.SELECTVIEW
				+ bd.getRTyp() + "\"" + " set ");
		int iLen;
		String stValue;
		//update only status and LUNID
		for (Method m : mds) {
			try {
				if (m.getName().indexOf("Status") >= 0
						|| m.getName().indexOf("LNUnId") >= 0) {
					stValue = (String) m.invoke(bd, new Object[0]);
					if (stValue != null) {
						stUpdate.append("\""
								+ m.getName()
										.substring(3, m.getName().length())
								+ "\"" + "='" + stValue + "' , ");
					}
				}
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		iLen = stUpdate.length();
		stUpdate.delete(iLen - 2, iLen);
		//String stStartTimePhrase = bd.getStartTime() != null ? " = '" + bd.getStartTime() + "' ":" is null ";
	/*	if (bd.getStartTime()== null){
			stStartTimePhrase = " = '" + bd.getStartTime() + "' ";
		}else{
			stStartTimePhrase = " is null ";
		}
	*/	
		stUpdate.append(" where \"StartTime\"");
		stUpdate.append(bd.getStartTime() != null ? " = '" + bd.getStartTime() + "' ":" is null "); 
		stUpdate.append("and " + "\"EregMailDomain\"" );
		stUpdate.append("= '");
		//stUpdate.append(bd.getEregMailDomain() + "' and " + "\"EregShortName\""
		stUpdate.append(bd.eregOrg+ "' and " + "\"EregShortName\""
				+ " = '" + bd.getEregShortName() + "'");
		return stUpdate.toString();
	}

}
