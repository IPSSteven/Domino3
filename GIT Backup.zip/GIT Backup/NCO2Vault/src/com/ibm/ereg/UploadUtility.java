package com.ibm.ereg;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ibm.ereg.notes.NotesConnection;
import com.ibm.ereg.utils.CmdOpts;
import com.ibm.ereg.utils.MailGtwyInputObj;
import com.ibm.ereg.utils.UploadConstants;
import com.ibm.ereg.utils.UploadDoc;
import com.ibm.ereg.utils.UploadOverride;
import com.ibm.ereg.utils.UploadStatus;
import com.ibm.ereg.utils.Utils;
import com.ibm.ereg.utils.WSClient;
import com.ibm.ereg.vault.NotesIDVault;
import com.ibm.ereg.vault.domino.GDVault;
import com.ibm.ereg.vault.ibmmail.MailGateway;
import com.ibm.itim.ereg.auth.CryptUtil;

import lotus.domino.NotesThread;

public class UploadUtility extends NotesThread {
	Logger logger = null ;
	static CmdOpts cmdOpts = new CmdOpts() ;
	static Properties props = null ;
	char scenario ;
	String propFile = "config/uploadutility.properties" ;
	static NotesConnection con = null ;
	Boolean updateHistory = false ;
	//Boolean forceCloud = false ;
	UploadOverride uploadOverride = UploadOverride.NONE;
	static CryptUtil cryptUtil = null ;
	Boolean initOnly = false ;
	Boolean alertFlag = false ;
	
	
	public void runNotes() {
		try {
			String user = props.getProperty(UploadConstants.KEY_NOTES_USER) ;
			String pass = cryptUtil.decrypt(props.getProperty(UploadConstants.KEY_NOTES_PW)) ;
			String server = props.getProperty(UploadConstants.KEY_NOTES_REMOTE_SERVER) ;
			alertFlag = Boolean.valueOf(props.getProperty(UploadConstants.KEY_FAILURE_ALERT_FLAG, "false")) ;
			updateHistory = Boolean.valueOf(props.getProperty(UploadConstants.KEY_NOTES_UPDATE_HISTORY, "false")) ;
			Boolean forceCloud = Boolean.valueOf(props.getProperty(UploadConstants.KEY_FORCE_CLOUD, "false")) ;
			if (forceCloud) {
				uploadOverride = UploadOverride.FORCECLOUD;
			}
			if(cmdOpts.containsOpt("N")) {
				initOnly = true ;
			}
			
			switch(scenario) {
				case 'G':
					con = new NotesConnection(user, pass, server, props.getProperty(UploadConstants.KEY_NOTES_UPLOAD_GWTAG)) ;
					con.init(initOnly);
					if(!initOnly) {
						uploadToMailGatewayVault() ;
					}
					break ;
				case 'S':
					con = new NotesConnection(user, pass, server, props.getProperty(UploadConstants.KEY_NOTES_UPLOAD_SCNTAG)) ;
					con.init(initOnly);
					if(!initOnly) {
						uploadToVault() ;
					}
					break ;
				case 'D':
					// note change last arg
					con = new NotesConnection(user, pass, server, props.getProperty(UploadConstants.KEY_NOTES_UPLOAD_SCNTAG)) ;
					con.initSession();
					globalDominoTest() ;
					break;
			}
		}
		catch(Exception e) {
			if(logger != null) {
				logger.info("Error: " + e.getMessage());
				logger.debug(e);
			}
			else {
				e.printStackTrace();
			}
			if(alertFlag) {
				boolean alertSent = sendAlert(e.getMessage()) ;
				if(alertSent) {
					logger.info("Alert sent successfully");
				}
				else {
					logger.info("Alert NOT sent successfully");
				}
			}
		}
		finally {
			if(con != null) {
				con.close();
			}
		}
	}
	
	private void globalDominoTest() throws Exception {
		GDVault vault = new GDVault() ;
		vault.init(props);
		String user = cmdOpts.getOptVal("u");
		String pass = cmdOpts.getOptVal("p");
		String userFile = cmdOpts.getOptVal("f");
		try {
			String rtnStr = vault.isInVault(user) ;
			if(rtnStr.equals("NO")) {
				logger.info("User: " + user + " ID file not in vault.  Uploading...");
				rtnStr = vault.upload(user, userFile, pass) ;
				logger.info("rtnStr = " + rtnStr);
			}
			else {
				logger.info("User: " + user + " ID file was in vault.  Nothing to do.");
			}
		}
		catch(Exception e) {
			logger.info("Error uploading: " + e.getMessage());
		}
		
	}

	private void uploadToVault() throws Exception {
		ArrayList<UploadDoc> uploadDocs = null ;
		if(cmdOpts.containsOpt("O")) {
			uploadOverride = UploadOverride.FORCEMAILGATEWAY;
			logger.info("Setting Force Mail Gateway Flag");
		}
		if(cmdOpts.containsOpt("I")) {
			con.setIgnoreHistory(true);
		}
		con.openDatabaseByTag();
		if(cmdOpts.containsOpt("s")) {
			String shortName = cmdOpts.getOptVal("s");
			uploadDocs = con.checkViewForSingleUpload(props.getProperty("notes.ncoshortname.view"), shortName) ;
		}
		else if(cmdOpts.containsOpt("f")) {
			String fileName = cmdOpts.getOptVal("f"); //FileNamePath is passed in at command line.
			ArrayList<String> shortNameList = loadShortNamesFromFile(fileName) ;
 			uploadDocs = con.checkViewForShortNameList(props.getProperty("notes.ncoshortname.view"), shortNameList) ;
		}
		else {
			uploadDocs = con.checkViewForUpload(props.getProperty("notes.ncodboutstanding.view"));
		}
		if(uploadDocs.size() > 0) {
			checkVaultAndUpload(uploadDocs) ;
		}
	}

	private ArrayList<String> loadShortNamesFromFile(String fileName) throws IOException {
		ArrayList<String> shortNames = new ArrayList<>();
        FileReader fileReader = new FileReader(fileName);     
        BufferedReader bufferedreader = new BufferedReader(fileReader);           
        int numRow = 1;
        
        try{
        	String strLine;
        	String shortName;
        	while ((strLine = bufferedreader.readLine()) != null) {
        		 shortName = strLine.trim();
        		 if (shortName.length() > 0 && shortName != null) {
         			shortNames.add(shortName);
                     numRow = numRow + 1;
         		}
            } 
        } catch (IOException ex) {
    		    ex.printStackTrace();
    	}        
        fileReader.close();
        return shortNames;
	}

	private void uploadToMailGatewayVault() throws Exception {
		boolean byFullname = false ;
		Boolean reportOnly = false ;
		MailGateway mailGWVault = null ;
		int sleepTime = Integer.parseInt(props.getProperty(UploadConstants.KEY_GW_SLEEPTIME)) ;
		int retryCount = Integer.parseInt(props.getProperty(UploadConstants.KEY_GW_RETRY_COUNT)) ;
		int retrySleepTime = Integer.parseInt(props.getProperty(UploadConstants.KEY_GW_RETRY_SLEEPTIME)) ;
		con.openDatabaseByTag();
		
		try {
			mailGWVault = new MailGateway() ;
			mailGWVault.init(props);
		}
		catch(Exception e) {
			logger.info("Error initializing mail gateway vault: " + e.getMessage());
			logger.debug(e); 
			throw e ;
		}
		
		if(cmdOpts.containsOpt("F")) {
			byFullname = true ;
		}
		if(cmdOpts.containsOpt("R")) {
			reportOnly = true ;
		}
		ArrayList<MailGtwyInputObj> inputObjs = getInputObjs(byFullname) ;
		int records = 0 ;
		if(!byFullname) {
			records = con.checkViewForGatewayUpload(props.getProperty("notes.ncoshortname.view"), inputObjs) ;
		}
		else {
			records = con.checkViewByFullnameForGatewayUpload(props.getProperty("notes.ncofullname.view"), inputObjs) ;
		}
		int uploadedCount = 0 ;
		int uploadFailedCount = 0 ;
		int badRecordCount = 0 ;
		int foundInVaultCount = 0 ;
		logger.info("Found " + records + " documents matching input file");
		logger.info("Uploading ID files...");
		for(int i = 0;i < inputObjs.size();i++) {
			MailGtwyInputObj inputObj = inputObjs.get(i) ;
			try {		
				if((inputObj.getUploadStatus() != UploadStatus.BAD_DATA) &&
				   (inputObj.getUploadStatus() != UploadStatus.NO_ID_FILE) &&
				   (inputObj.getUploadStatus() != UploadStatus.NO_MATCH_FOUND))
				{
					logger.info("Checking mail gateway vault for: " + inputObj.getEmpNum());
					String inVaultStr = mailGWVault.isInVault(inputObj.getEmpNum()) ;
					if(inVaultStr.equals("YES")) {
						logger.info("ID file FOUND in gateway vault for: " + inputObj.getEmpNum());
						foundInVaultCount++ ;
						inputObj.setUploadStatus(UploadStatus.FOUND_IN_VAULT);
					}
					else if(inVaultStr.equals("NO")) {	
						logger.info("ID file NOT found in gateway vault for: " + inputObj.getEmpNum());
						if(!reportOnly) {
							if(byFullname) {
								logger.info("Working on ID file for fullname: " + inputObj.getFullName() + ", UID: " + inputObj.getEmpNum()) ;
							}
							else {
								logger.info("Working on ID file for shortname: " + inputObj.getShortName() + ", UID: " + inputObj.getEmpNum()) ;
							}
							
							int attemptCount = 0 ;
							boolean uploadSucceeded = false ;
							
							do {
								String uploadStr = mailGWVault.upload(inputObj.getEmpNum(), inputObj.getDetachedFile(), inputObj.getPassword()) ;
								if(uploadStr.equals("SUCCESS")) {
									logger.info("File uploaded successfully");
									inputObj.setUploadStatus(UploadStatus.UPLOAD_SUCCEEDED);
									uploadedCount++ ;
									uploadSucceeded = true ;
								}
								else {
									inputObj.setUploadStatus(UploadStatus.UPLOAD_FAILED);
									logger.info("File NOT uploaded successfully.  Response code: " + mailGWVault.getResponseCode());
									logger.info("Sleeping " + retrySleepTime + " seconds before retrying up to " + (retryCount - attemptCount) + " times...");
									if((retryCount - attemptCount) > 0) {
										Thread.sleep(retrySleepTime * 1000) ;
									}
									if(attemptCount >= retryCount) {
										uploadFailedCount++ ;
									}
								}
							} while((!uploadSucceeded) && (++attemptCount <= retryCount)) ;
						}
						else {
							logger.info("Report-only mode: " + inputObj.getShortName() + " is uploadable.");
							inputObj.setUploadStatus(UploadStatus.REPORT_ONLY_UPLOADABLE);
						}
					}
				}
				else {
					logger.info("Error: record for " + inputObj.getShortName() + " not uploadable");
					badRecordCount++ ;
				}
				if(sleepTime > 0) {
					logger.info("Sleeping for " + sleepTime + " seconds...");
					Thread.sleep((sleepTime * 1000)) ;
				}
			}
			catch(Exception e) {
				logger.info("Error: " + e.getMessage());
				logger.debug(e);
			}
			inputObjs.set(i, inputObj) ;
		}
		printMailGatewayResults(inputObjs) ;
		logger.info("Total successful uploads: " + uploadedCount);
		logger.info("Total failed uploads: " + uploadFailedCount);
		logger.info("Rejected records: " + badRecordCount);
		logger.info("Total records already in vault: " + foundInVaultCount);
	}
	
	private void printMailGatewayResults(ArrayList<MailGtwyInputObj> inputObjs) {
		for(MailGtwyInputObj inputObj : inputObjs) {
			logger.info("Serial: " + inputObj.getEmpNum() + ", shortname: " + 
		                inputObj.getShortName() + ", fullname: " + inputObj.getFullName() + 
		                ", status: " + inputObj.getUploaStatusString()) ;;
		}
	}

	private ArrayList<MailGtwyInputObj> getInputObjs(boolean byFullname) throws Exception {
		ArrayList<MailGtwyInputObj> inputObjs = new ArrayList<MailGtwyInputObj>() ;
		if(!cmdOpts.containsOpt("f")) {
			throw new Exception("Missing input file option -f <INPUT_FILE>") ;
		}
		String fileName = cmdOpts.getOptVal("f") ;
		BufferedReader reader = new BufferedReader(new FileReader(fileName)) ;
		String inputLine = reader.readLine() ;
		Integer maxCount = Integer.valueOf(props.getProperty("upload.gw.testMaxCount")) ;
		if(maxCount == -1) maxCount = Integer.MAX_VALUE ;
		int count = 0 ;
		while((inputLine != null) && (count++ < maxCount)) {
			if(inputLine.length() > 0) {
				logger.debug(inputLine) ;
				MailGtwyInputObj inputObj = getInputObjFromStr(inputLine, byFullname) ;
				if(inputObj != null) {
					inputObjs.add(inputObj) ;
				}
			}
			inputLine = reader.readLine() ;
		}
		reader.close();
		
		return inputObjs ;
	}
	
	private MailGtwyInputObj getInputObjFromStr(String inputLine, boolean byFullname) {
		MailGtwyInputObj inputObj = null ;
		
		try {
			String[] fields = inputLine.split(props.getProperty("upload.gw.inputDelim")) ;
			logger.debug("fields.length is " + fields.length);
			int requiredFieldCount = Integer.parseInt(props.getProperty("upload.gw.fields.count")) ;
			if(fields.length < requiredFieldCount) {
				logger.info("Rejecting input line: " + inputLine + " due to missing fields.");
			}
			else {
				inputObj = new MailGtwyInputObj() ;
				inputObj.setInternetAddress(fields[Integer.parseInt(props.getProperty("upload.gw.fields.internetAddress"))].trim());
				inputObj.setFullName(fields[Integer.parseInt(props.getProperty("upload.gw.fields.fullName"))].trim());
				if(!byFullname) {
					inputObj.setShortName(fields[Integer.parseInt(props.getProperty("upload.gw.fields.shortName"))].trim());
				}
				inputObj.setSerial(fields[Integer.parseInt(props.getProperty("upload.gw.fields.serial"))].trim());
				if(inputObj.getEmpNum().length() == 0) {
					inputObj.setUploadStatus(UploadStatus.BAD_DATA);
				}
			}
		}
		catch(Exception e) {
			logger.info("Error with input param(s): " + e.getMessage());
			logger.debug(e) ;
			return null ;
		}
		return inputObj ;
	}

	private void checkVaultAndUpload(ArrayList<UploadDoc> uploadDocs) throws Exception {
		NotesIDVault cloudVault = null ;
		NotesIDVault mailGWVault = null ;
		String cloudVaultClass = props.getProperty(UploadConstants.KEY_CLOUD_CLASSNAME) ;
		String mgVaultClass = props.getProperty(UploadConstants.KEY_GW_CLASSNAME) ;
		HashMap<String,NotesIDVault> vaults = new HashMap<String,NotesIDVault>() ;
		int yesCount = 0 ;
		int checkErrorCount = 0 ;
		int uploadFailedCount = 0 ;
		int extractFailedCount = 0 ;
		int noCount = 0 ;
		int uploadedCount = 0 ;
		int totalDocs = uploadDocs.size() ;
		int count = 0 ;
		logger.info("Upload docs count = " + totalDocs);
		logger.info("Checking ID vault...");
		try {
			cloudVault = (NotesIDVault)Class.forName(cloudVaultClass).newInstance() ;
			cloudVault.init(props);
			vaults.put(UploadConstants.CLOUD_TAG, cloudVault) ;
			
			mailGWVault = (NotesIDVault)Class.forName(mgVaultClass).newInstance() ;
			mailGWVault.init(props);
			vaults.put(UploadConstants.MAIL_GATEWAY_TAG, mailGWVault) ;	
		}
		catch(Exception e) {
			logger.info("Error initializing IDFileCheck: " + e.getMessage());
			logger.debug(e);
			throw e ;
		}
		for(UploadDoc uploadDoc : uploadDocs) {
			NotesIDVault vault = null ;
			
			if((uploadDoc.getMailSystem().equals(UploadConstants.MAIL_SYSTEM_OTHER) &&
					(uploadOverride != UploadOverride.FORCECLOUD )) || 
					(uploadOverride == UploadOverride.FORCEMAILGATEWAY))
			{
				vault = vaults.get(UploadConstants.MAIL_GATEWAY_TAG) ;
				logger.info("Checking mail gateway vault...");
			}
			else {
				vault = vaults.get(UploadConstants.CLOUD_TAG) ;
				logger.info("Checking Cloud vault...");
			}
			try {
				if(vault instanceof com.ibm.ereg.vault.domino.GDVault) {
					logger.info("Using GD Vault Instance");
				} else {
					logger.info("Using Mail Gateway Vault Instance");
				}
				logger.info("Checking " + ++count + " doc out of " + totalDocs);
				logger.info("Checking shortname: " + uploadDoc.getShortName() + ", internet address: " + uploadDoc.getInternetAddress());
				String rtnStr = vault.isInVault(uploadDoc.getUserForMailSystem(uploadOverride)) ;
				logger.info("Return val is " + rtnStr);
				if(rtnStr.equals("NO")) {
					noCount++ ;
					logger.info("File not in vault.  Need to upload.");
					String extractedFile = con.detachFile(uploadDoc, props.getProperty("notes.extractDir")) ;
					if(extractedFile.length() > 0) {
						try {
							logger.info("Uploading file: " + extractedFile + ", shortname: " + uploadDoc.getShortName() + ", address: " + uploadDoc.getInternetAddress() + 
									               " fullname: " + uploadDoc.getFullName() + " to vault...");
							String msg = vault.upload(uploadDoc.getUserForMailSystem(uploadOverride), extractedFile, uploadDoc.getPassword()) ;
							if(msg.equals("SUCCESS")) {
								uploadedCount++ ;
								logger.info("Uploaded shortname: " + uploadDoc.getShortName() + ", address: " + uploadDoc.getInternetAddress() + " successfully");
								logger.info("Updating Notes doc...");
								boolean updated = con.updateNCOUARDoc(uploadDoc.getDocID(), uploadDoc.getShortName(), "idFileInVault", "1") ;
								if(updated) {
									logger.info("Doc updated successfully");
								}
							}
							else {
								uploadFailedCount++ ;
								logger.info("Upload failed: " + msg);
							}
							if(vault.getSleepTime() > 0) {
								logger.info("Sleeping for " + vault.getSleepTime() + " seconds before continuing...");
								Thread.sleep(vault.getSleepTime() * 1000);
							}
						}
						catch(Exception e) {
							logger.info("Upload failed: " + e.getMessage());
							logger.debug(e);
						}
					}
					else {
						logger.info("Unable to extract ID file for " + uploadDoc.getShortName());
						extractFailedCount++ ;
					}
				}
				else if(rtnStr.equals("YES")) {
					yesCount++ ;
					logger.info("ID file already in vault for: " + uploadDoc.getShortName() + ". Updating idFileInVault field to 1...");
					boolean updated = con.updateNCOUARDoc(uploadDoc.getDocID(), uploadDoc.getShortName(), "idFileInVault", "1") ;
					if(updated) {
						logger.info("Document updated successfully");
					}
				}
				else if(rtnStr.equals("ERROR")) {
					checkErrorCount++ ;
					if(updateHistory) {
						logger.info("Updating doc with Cloud Error...");
						boolean updated = con.appendValueToNCOUAR(uploadDoc.getDocID(), uploadDoc.getShortName(), "History", formatHistoryEntry()) ;
						if(updated) {
							logger.info("Document updated successfully");
						}
					}
				}
			}	// end try
			catch(Exception e) {
				logger.info("Error with checkIDFile: " + e.getMessage());
				logger.debug(e);
			}
		}	// end for
		logger.info("NO (not in vault) count = " + noCount + ", YES (found in vault) count = " + yesCount + 
				    ", ID File Check ERROR count = " + checkErrorCount + ", UPLOADED count = " + uploadedCount +
				    ", Failed Upload count: " + uploadFailedCount +
				    ", ID Extraction failure count: " + extractFailedCount);
		logger.info("Total gateway vault successful uploads: " + mailGWVault.getUploadedCount() + ", total Cloud successful uploads: " + cloudVault.getUploadedCount());
	}
	
	private boolean sendAlert(String errMsg) {
		boolean alertSent = false ;
		String alertMsg = "{ \"text\" : \"" + 
		                     props.getProperty(UploadConstants.KEY_FAILURE_ALERT_BASE_MSG) + ": " + errMsg +
		                     "\" }" ;
		logger.debug("alertMsg is: " + alertMsg) ;
		WSClient wsClient = new WSClient() ;
		try {
			String response = wsClient.doPost(props.getProperty(UploadConstants.KEY_FAILURE_ALERT_URL), alertMsg) ;
			if(response.equals("ok")) {
				alertSent = true ;
			}
			else {
				logger.debug("Response is:" + response);
			}
		}
		catch(Exception e) {
			logger.info("Error: " + e.getMessage());
		}
		
		return alertSent ;
	}
	
	private String formatHistoryEntry() {
		String rtnStr = "" ;
		rtnStr = Utils.formatDate(props.getProperty("notes.ncodb.history.dateformat")) + ":  " +
		         "Cloud ID file upload | CloudUploadError detected by " + con.whoAmI() ;
		return rtnStr ;
	}
	
	public void init(String[] args) throws Exception {
		initOpts(args) ;
		initProps() ;
		initLogger() ;
		logger.info("Program starting...") ;
	}
	
	private void initOpts(String[] args) throws Exception {
		cmdOpts.init(args);
		if(!cmdOpts.containsOpt("S")) {
			throw new Exception("Missing command option 'S'") ;
		}
		else {
			scenario = cmdOpts.getOptVal("S").charAt(0) ;
		}
	}

	private void initLogger() {
		logger = Logger.getLogger(getClass()) ;
		PropertyConfigurator.configure(props) ;
	}

	private void initProps() throws Exception {
		FileInputStream fis = new FileInputStream(propFile) ;
		props = new Properties() ;
		props.load(fis) ;
		fis.close() ;
		cryptUtil = new CryptUtil(props) ;
	}
	
	public static Properties getProperties() {
		return props ;
	}
	
	public static CmdOpts getCmdOpts() {
		return cmdOpts ;
	}
	
	public static CryptUtil getCryptUtil() {
		return cryptUtil ;
	}

	public static void main(String[] args) {
		try {
			UploadUtility uploadUtility = new UploadUtility() ;
			uploadUtility.init(args);
			uploadUtility.start();
			while(uploadUtility.isAlive()) {
				// wait
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}
	
	public static NotesConnection getNotesConnection() {
		return con ;
	}

}
