package com.ibm.ereg.notes;

import lotus.domino.Database;
import lotus.domino.DbDirectory;

public class DatabaseConnection {	
	String remoteName ;
	String localName ;
	String dbType ;
	Boolean preReplicate ;
	Boolean postReplicate ;
	Database db = null ;
	DbDirectory dbDir = null ;
	
	public DatabaseConnection(String remoteName,
			                  String localName,
			                  String dbType,
			                  Boolean preReplicate,
			                  Boolean postReplicate)
	{
		this.remoteName = remoteName ;
		this.localName = localName ;
		this.dbType = dbType ;
		this.preReplicate = preReplicate ;
		this.postReplicate = postReplicate ;
	}
	
	public String getRemoteName() {
		return remoteName;
	}
	
	public void setRemoteName(String remoteName) {
		this.remoteName = remoteName;
	}
	
	public String getLocalName() {
		return localName;
	}
	
	public void setLocalName(String localName) {
		this.localName = localName;
	}
	
	public String getDbType() {
		return dbType;
	}
	
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}
	
	public Boolean isPreReplicate() {
		return preReplicate;
	}
	
	public void setPreReplicate(Boolean preReplicate) {
		this.preReplicate = preReplicate;
	}
	
	public Boolean isPostReplicate() {
		return postReplicate;
	}
	
	public void setPostReplicate(Boolean postReplicate) {
		this.postReplicate = postReplicate;
	}

	public Database getDb() {
		return db;
	}

	public void setDb(Database db) {
		this.db = db;
	}

	public DbDirectory getDbDir() {
		return dbDir;
	}

	public void setDbDir(DbDirectory dbDir) {
		this.dbDir = dbDir;
	}
	
}
