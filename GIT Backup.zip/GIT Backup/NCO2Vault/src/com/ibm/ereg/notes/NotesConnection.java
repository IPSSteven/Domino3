package com.ibm.ereg.notes;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.ibm.ereg.UploadUtility;
import com.ibm.ereg.utils.MailGtwyInputObj;
import com.ibm.ereg.utils.UploadConstants;
import com.ibm.ereg.utils.UploadDoc;
import com.ibm.ereg.utils.UploadStatus;

import lotus.domino.Database;
import lotus.domino.DbDirectory;
import lotus.domino.Document;
import lotus.domino.EmbeddedObject;
import lotus.domino.Item;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.Registration;
import lotus.domino.Session;
import lotus.domino.View;

public class NotesConnection {
	private Session session = null ;
	private DbDirectory dbDir = null ;
	private DbDirectory mailDbDir = null ;
	private Registration registration = null ;
	private String user ;
	private String passwd ;
	private String server ;
	private Database db = null ;
	private String dbTag ;
	private String extractDir ;
	private boolean ignoreHistory = false ;
	private boolean isLocal = false ;
	Logger logger = Logger.getLogger(this.getClass()) ;
	Properties props = null ;
	int testMaxCount = -1 ;
	private ArrayList<DatabaseConnection> dbConnections = null ;
	
	public NotesConnection(Session session) {
		this.session= session ;
	}
	
	public NotesConnection() { }
	
	public NotesConnection(String user, String passwd, String server, String dbTag) {
		this.user = user ;
		this.passwd = passwd ;
		this.server = server ;
		this.dbTag = dbTag ;
	}
	
	public NotesConnection(String user, String passwd, String server) {
		this.user = user ;
		this.passwd = passwd ;
		this.server = server ;
	}
	
	public void initForSecurity() throws Exception {
		logger.info("NotesConnection init() called...") ;
		props = UploadUtility.getProperties() ;
		extractDir = props.getProperty(UploadConstants.KEY_NOTES_EXTRACTDIR) ;
		
		if(session == null) {
			session = NotesFactory.createSession() ;
			registration = session.createRegistration() ;
			
			logger.info("Authenticating into Notes using ID file " + user + "...") ;
			String adminName = registration.switchToID(user, passwd) ;
			logger.info("Successfully authenticated as " + adminName) ;
		}
	}
	
	public void initSession() throws Exception {
		logger.info("NotesConnection init() called...") ;
		props = UploadUtility.getProperties() ;
		extractDir = props.getProperty(UploadConstants.KEY_NOTES_EXTRACTDIR) ;
		
		if(session == null) {
			session = NotesFactory.createSession() ;
			registration = session.createRegistration() ;
			
			logger.info("Authenticating into Notes using ID file " + user + "...") ;
			String adminName = registration.switchToID(user, passwd) ;
			logger.info("Successfully authenticated as " + adminName) ;
		}
	}
	
	public void init(boolean initOnly) throws Exception {
		logger.info("NotesConnection init() called...") ;
		props = UploadUtility.getProperties() ;
		extractDir = props.getProperty(UploadConstants.KEY_NOTES_EXTRACTDIR) ;
		if(props.containsKey(UploadConstants.KEY_NOTES_TESTCOUNT)) {
			testMaxCount = Integer.valueOf(props.getProperty(UploadConstants.KEY_NOTES_TESTCOUNT)) ;
		}
		
		if(session == null) {
			session = NotesFactory.createSession() ;
			registration = session.createRegistration() ;
			
			logger.info("Authenticating into Notes using ID file " + user + "...") ;
			String adminName = registration.switchToID(user, passwd) ;
			logger.info("Successfully authenticated as " + adminName) ;
		}
		
		if(initOnly) {
			logger.info("Called in init-only mode.  Creating new database replica...");
			initOnly() ;
		}
		else {
			logger.info("Getting database directory for server " + server + "...") ;
			if(props.getProperty("notes." + dbTag + ".dbType").equals(UploadConstants.DB_TYPE_LOCAL)) {
				dbDir = session.getDbDirectory("") ;
			}
			else {
				dbDir = session.getDbDirectory(server) ;
			}
			if(dbDir == null) {
				logger.info("Couldn't set dbDir") ;
			}
		}
	}
	
	public String clearDigestField(String mailServer, String shortName) throws Exception {
		String rtnFullName = "" ;
		DbDirectory mailDBDir = session.getDbDirectory(mailServer) ;
		logger.info("Opening NAB on " + mailServer);
		Database serverNAB = mailDBDir.openDatabase("names.nsf") ;
		if(!serverNAB.isOpen()) {
			serverNAB.open() ;
		}
		logger.info("Opening view...");
		View view = serverNAB.getView("People\\People by Shortname") ;
		logger.info("Searching for person document...");
		Document doc = view.getDocumentByKey(shortName, true);
		if(doc != null) {
			logger.info("Found person doc");
			logger.info("shortname field = " + doc.getItemValueString("Shortname")) ;
			String FQLongName = doc.getItemValueString("Fullname");
			Name fullName = session.createName(doc.getItemValueString("Fullname")) ;
			logger.info("Abbrev fullname is " + fullName.getAbbreviated());
			logger.info("Clearing password digest field...");
			doc.replaceItemValue("PasswordDigest", "") ;
			logger.info("Saving person doc...");
			if(doc.save()) {
				logger.info("Document saved successfully");
				rtnFullName = fullName.getAbbreviated() ;
			}
		}
		return rtnFullName ;
	}
	
	public void init() throws Exception {
		logger.info("NotesConnection init() called...") ;
		
		if(session == null) {
			session = NotesFactory.createSession() ;
			registration = session.createRegistration() ;
			
			logger.info("Authenticating into Notes using ID file " + user + "...") ;
			String adminName = registration.switchToID(user, passwd) ;
			logger.info("Successfully authenticated as " + adminName) ;
		}
		
		logger.info("Getting database directory for server " + server + "...") ;
		
		dbDir = session.getDbDirectory(server) ;
		if(dbDir == null) {
			logger.info("Couldn't set dbDir") ;
		}

	}
	
	private void initOnly() throws Exception  {
		logger.info("Creating local replica...");
		logger.debug("Remote path is " + props.getProperty("notes." + dbTag + ".remote.name"));
		Database remoteDB = session.getDatabase(server, props.getProperty("notes." + dbTag + ".remote.name")) ;
		Database localDB = remoteDB.createReplica(null, props.getProperty("notes." + dbTag + ".local.name")) ;
		logger.info("Done");
	}

	public String whoAmI() {
		String whoami = "" ;
		try {
			if(session != null) {
				whoami = session.getUserName() ;
			}
		}
		catch(Exception e) {
			logger.debug(e);
		}
		return whoami ;
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList<UploadDoc> checkViewForUpload(String viewName) throws Exception {
		ArrayList<UploadDoc> uploadDocs = new ArrayList<UploadDoc>() ;
		if(db != null) {
			logger.info("Opening view " + viewName);
			View view = db.getView(viewName) ;
			if(view != null) {
				logger.info("View opened successfully");
				int docCount = view.getEntryCount() ;
				logger.info("Number of docs found in view is " + docCount) ;
				int count = 0 ;
				int maxCount = testMaxCount ;
				if(maxCount == -1) maxCount = Integer.MAX_VALUE ;
				Document doc = view.getFirstDocument() ;
				
				while((doc != null) && (count < maxCount)) {
					logger.info("Checking " + count + " out of " + docCount + " documents...");
					Vector vector = doc.getItemValue("History") ;
					String shortName = doc.getItemValueString("LNShortname") ;
					String mailAddress = doc.getItemValueString("InternetAddress") ;
					String mailAddress2 = doc.getItemValueString("InternetAdddress") ;
					String mailSystem = doc.getItemValueString("MailSystem") ;
					String ownerSerial = doc.getItemValueString("EmpNo").trim() + doc.getItemValueString("Empcc").trim() ;
					String fullName = getFullName(doc.getItemValueString("LotusName").trim());
					logger.debug("Adding fullname: " + fullName);
					logger.info(shortName + " has not been uploaded to vault");
					if(((mailAddress.length() > 0) || (mailAddress2.length() > 0)) && (noPriorError(vector))) 
					{
						UploadDoc uploadDoc = new UploadDoc() ;
						uploadDoc.setDocID(doc.getUniversalID());
						if(mailAddress.length() == 0) {
							uploadDoc.setInternetAddress(mailAddress2);
						}
						else {
							uploadDoc.setInternetAddress(mailAddress);
						}
						uploadDoc.setShortName(doc.getItemValueString("LNShortname"));
						uploadDoc.setPassword(doc.getItemValueString("Password"));
						uploadDoc.setOwnerSerial(ownerSerial);
						uploadDoc.setMailSystem(mailSystem);
						uploadDoc.setFullName(fullName);
						uploadDocs.add(uploadDoc) ;
						count++ ;
					}
					doc = view.getNextDocument(doc) ;
				}
			}
			else {
				logger.info("Unable to open view");
				throw new Exception("Unable to open database view " + viewName) ;
			}
		}
		return uploadDocs ;
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList<UploadDoc> checkViewForShortNameList(String viewName, ArrayList<String> shortNameList) throws Exception {
		ArrayList<UploadDoc> uploadDocs = new ArrayList<UploadDoc>() ;
		
		if(db != null) {
			logger.info("Opening view " + viewName);
			View view = db.getView(viewName) ;
			if(view != null) {
				logger.info("View opened successfully");
				for (String searchVal : shortNameList) {
					Document doc = view.getDocumentByKey(searchVal);
					if(doc != null) {
						Vector vector = doc.getItemValue("History") ;
						String shortName = doc.getItemValueString("LNShortname") ;
						String mailAddress = doc.getItemValueString("InternetAddress") ;
						String mailAddress2 = doc.getItemValueString("InternetAdddress") ;
						String mailSystem = doc.getItemValueString("MailSystem") ;
						String ownerSerial = doc.getItemValueString("EmpNo").trim() + doc.getItemValueString("Empcc").trim() ;
						String fullName = getFullName(doc.getItemValueString("LotusName").trim());
						logger.debug("Adding fullname: " + fullName);
						logger.info(shortName + " has not been uploaded to vault");
						if(((mailAddress.length() > 0) || (mailAddress2.length() > 0)) && (noPriorError(vector)))  
						{
							UploadDoc uploadDoc = new UploadDoc() ;
							uploadDoc.setDocID(doc.getUniversalID());
							if(mailAddress.length() == 0) {
								uploadDoc.setInternetAddress(mailAddress2);
							}
							else {
								uploadDoc.setInternetAddress(mailAddress);
							}
							uploadDoc.setShortName(doc.getItemValueString("LNShortname"));
							uploadDoc.setPassword(doc.getItemValueString("Password"));
							uploadDoc.setOwnerSerial(ownerSerial);
							uploadDoc.setMailSystem(mailSystem);
							uploadDoc.setFullName(fullName);
							uploadDocs.add(uploadDoc) ;
						}
					}
				}
			} else {
				logger.info("Unable to open view");
				throw new Exception("Unable to open database view " + viewName) ;
			}
		}
		
		
		return uploadDocs;
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList<UploadDoc> checkViewForSingleUpload(String viewName, String searchVal) throws Exception {
		ArrayList<UploadDoc> uploadDocs = new ArrayList<UploadDoc>() ;
		
		if(db != null) {
			logger.info("Opening view " + viewName);
			View view = db.getView(viewName) ;
			if(view != null) {
				logger.info("View opened successfully");
				Document doc = view.getDocumentByKey(searchVal);
				if(doc != null) {
					Vector vector = doc.getItemValue("History") ;
					String shortName = doc.getItemValueString("LNShortname") ;
					String mailAddress = doc.getItemValueString("InternetAddress") ;
					String mailAddress2 = doc.getItemValueString("InternetAdddress") ;
					String mailSystem = doc.getItemValueString("MailSystem") ;
					String ownerSerial = doc.getItemValueString("EmpNo").trim() + doc.getItemValueString("Empcc").trim() ;
					String fullName = getFullName(doc.getItemValueString("LotusName").trim());
					logger.debug("Adding fullname: " + fullName);
					logger.info(shortName + " has not been uploaded to vault");
					if(((mailAddress.length() > 0) || (mailAddress2.length() > 0)) && (noPriorError(vector)))  
					{
						UploadDoc uploadDoc = new UploadDoc() ;
						uploadDoc.setDocID(doc.getUniversalID());
						if(mailAddress.length() == 0) {
							uploadDoc.setInternetAddress(mailAddress2);
						}
						else {
							uploadDoc.setInternetAddress(mailAddress);
						}
						uploadDoc.setShortName(doc.getItemValueString("LNShortname"));
						uploadDoc.setPassword(doc.getItemValueString("Password"));
						uploadDoc.setOwnerSerial(ownerSerial);
						uploadDoc.setMailSystem(mailSystem);
						uploadDoc.setFullName(fullName);
						uploadDocs.add(uploadDoc) ;
					}
				}
			}	
			else {
				logger.info("Unable to open view");
				throw new Exception("Unable to open database view " + viewName) ;
			}
		}
		return uploadDocs ;
	}
	
	public int checkViewForGatewayUpload(String viewName, ArrayList<MailGtwyInputObj> inputObjs) throws Exception {
		int records = 0 ;
		if(db != null) {
			logger.info("Opening view " + viewName);
			View view = db.getView(viewName) ;
			if(view != null) {
				logger.info("View opened successfully");
				for(MailGtwyInputObj inputObj : inputObjs) {
					if(inputObj.getShortName().length() == 0) {
						logger.info("Missing shortname.  Not searching for document");
						inputObj.setUploadStatus(UploadStatus.BAD_DATA);
						continue ;
					}
					logger.debug("Attempting to open document for shortname " + inputObj.getShortName()) ;
					Document doc = view.getDocumentByKey(inputObj.getShortName(), true) ;
					if(doc != null) {
						logger.info("Found matching document");
						String shortName = doc.getItemValueString("LNShortname") ;
						if(shortName.equals(inputObj.getShortName())) {
							logger.info("Document shortname matches that from input file");
							inputObj.setPassword(doc.getItemValueString("Password"));
							String detachedFile = detachFile(doc, UploadUtility.getProperties().getProperty("notes.extractDir")) ;
							if(detachedFile.length() > 0) {
								inputObj.setDetachedFile(detachedFile);
								inputObj.setNotesDocID(doc.getUniversalID());
								records++ ;
							}
							else {
								inputObj.setUploadStatus(UploadStatus.NO_ID_FILE);
							}
						}
						else {
							inputObj.setUploadStatus(UploadStatus.NO_MATCH_FOUND);
						}
					}
					else {
						inputObj.setUploadStatus(UploadStatus.NO_MATCH_FOUND);
					}
				}
			}
		}
		return records ;
	}
	
	public int checkViewByFullnameForGatewayUpload(String viewName, ArrayList<MailGtwyInputObj> inputObjs) throws Exception {
		int records = 0 ;
		if(db != null) {
			logger.info("Opening view " + viewName);
			View view = db.getView(viewName) ;
			if(view != null) {
				logger.info("View opened successfully");
				for(MailGtwyInputObj inputObj : inputObjs) {
					if(inputObj.getFullName().length() == 0) {
						logger.info("Fullname is blank, not searching for document.");
						inputObj.setUploadStatus(UploadStatus.BAD_DATA);
						continue ;
					}
					logger.debug("Attempting to open document for fullname " + inputObj.getFullName()) ;
					Document doc = view.getDocumentByKey(inputObj.getFullName(), true) ;
					if(doc != null) {
						logger.info("Found matching document");
						String ownerSerial = doc.getItemValueString("Dept_Id") ;
						logger.debug("Verifying owner serial from document: " + ownerSerial);
						if(ownerSerial.equals(inputObj.getEmpNum())) {
							logger.info("Document owner serial matches that from input file");
							inputObj.setPassword(doc.getItemValueString("Password"));
							String detachedFile = detachFile(doc, UploadUtility.getProperties().getProperty("notes.extractDir")) ;
							if(detachedFile.length() > 0) {
								inputObj.setDetachedFile(detachedFile);
								inputObj.setNotesDocID(doc.getUniversalID());
								records++ ;
							}
							else {
								inputObj.setUploadStatus(UploadStatus.NO_ID_FILE);
							}
						}
						else {
							inputObj.setUploadStatus(UploadStatus.NO_MATCH_FOUND);
						}
					}
					else {
						inputObj.setUploadStatus(UploadStatus.NO_MATCH_FOUND);
					}
				}
			}
		}
		return records ;
	}
	
	private boolean noPriorError(Vector vector) {
		boolean rtnVal = true ;
		if(!ignoreHistory) {
			for(int i = 0;i < vector.size();i++) {
				String val = (String)vector.get(i) ;
				if(val.length() > 0) {
					if(val.contains("SCNUploadError detected")) {
						logger.debug("Document with prior error detected.  Not using.");
						rtnVal = false ;
						break ;
					}
				}
			}
		}
		return rtnVal;
	}
	
	private String getFullName(String dn) {
		String[] parts = dn.split("/");
		String newnotesemail = "";
		for (int i = 0; i < parts.length; i++) {
			String tmpst = parts[i].replaceAll(".*=", "");
			if (i == 0) {
				newnotesemail = tmpst;
			}
			else {
				newnotesemail = newnotesemail + "/" + tmpst;
			}		
		}
		return newnotesemail;
	}


	@SuppressWarnings("unchecked")
	public boolean updateNCOUARDoc(String docID, String shortName, String field, String value) {
		boolean updated = false ;
		@SuppressWarnings("rawtypes")
		Vector encryptionKey = new Vector() ;
		encryptionKey.addElement(UploadConstants.NCOUAR_ENCRYPTION_KEY) ;
		try {
			Document doc = getDocumentById(docID) ;
			if(doc != null) {
				if(doc.getItemValueString("LNShortname").equals(shortName)) {
					logger.info("Encrypting and saving document for " + shortName + "...");
					doc.replaceItemValue(field, value) ;
					if(!doc.isEncrypted()) {
						doc.setEncryptionKeys(encryptionKey);
						doc.encrypt();
					}
					doc.save() ;
					updated = true ;
				}
			}
		}
		catch(Exception e) {
			logger.info("Update failed: " + e.getMessage());
			logger.debug(e);
		}
		return updated ;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public boolean appendValueToNCOUAR(String docID, String shortName, String field, String appendValue) {
		boolean updated = false ;
		Vector encryptionKey = new Vector() ;
		encryptionKey.addElement(UploadConstants.NCOUAR_ENCRYPTION_KEY) ;
		try {
			Document doc = getDocumentById(docID) ;
			if(doc != null) {
				Vector vector = doc.getItemValue(field) ;			
				if(vector != null) {
					logger.debug("Appending entry: " + appendValue);
				}
				vector.add(appendValue) ;
				doc.replaceItemValue(field, vector) ;
				if(!doc.isEncrypted()) {
					doc.setEncryptionKeys(encryptionKey);
					doc.encrypt();
				}
				doc.save() ;
				updated = true ;
			}
		}
		catch(Exception e) {
			logger.info("Update failed: " + e.getMessage());
			logger.debug(e);
		}
		return updated;
	}
	
	public Document getDocumentById(String docId) throws Exception {
		Document doc = null ;
		if(db != null) {
			doc = db.getDocumentByUNID(docId) ;
		}
		return doc ;
	}
	
	public String detachFile(Document doc, String tmpDir) throws Exception {
		String rtnVal = "" ;
		boolean foundfile = false;
		Vector encryptionKey = new Vector() ;
		encryptionKey.addElement(UploadConstants.NCOUAR_ENCRYPTION_KEY) ;
		logger.info("Detaching id file...");
		Vector v = doc.getItems();
		for (int i = 0; i < v.size(); i++) {
			Item item = (Item) v.elementAt(i);
			String name = item.getName();
			if (name.equals("$FILE")) {
				foundfile = true;
				logger.info("Found attachment");
				String attach = item.getValueString();
				EmbeddedObject eo = doc.getAttachment(attach);
				if ((eo != null) && (eo.getType() == EmbeddedObject.EMBED_ATTACHMENT)) {
					logger.info("Detaching...");
					attach = eo.getSource();
                    if (attach != null) {
                        int j = attach.indexOf(" ");
                        if (j == -1) {
                        	// String extractFile = tmpDir + "/" + attach ;
                        	String extractFile = verifyFilename(tmpDir, attach) ;
                        	eo.extractFile(extractFile);
                        	rtnVal = extractFile ;
                        }
                    }
				}
				break ;
			}
		}
		if (!foundfile) {
			// Update idFileInVault to 1
			if(doc != null) {
				logger.info("Attachment not found; setting idFileInVault value to 1.");	
				String field = "idFileInVault";
				String value = "1";
				doc.replaceItemValue(field, value);
				if(!doc.isEncrypted()) {
					doc.setEncryptionKeys(encryptionKey);
					doc.encrypt();
				}
				doc.save();
			}
		}
		return rtnVal;
	}
	
	public String detachFile(UploadDoc uploadDoc, String tmpDir) throws Exception {
		String rtnVal = "" ;
		Vector encryptionKey = new Vector() ;
		encryptionKey.addElement(UploadConstants.NCOUAR_ENCRYPTION_KEY) ;
		boolean foundfile = false;
		logger.info("Detaching id file...");
		Document doc = getDocumentById(uploadDoc.getDocID()) ;
		Vector v = doc.getItems();
		for (int i = 0; i < v.size(); i++) {
			Item item = (Item) v.elementAt(i);
			String name = item.getName();
			if (name.equals("$FILE")) {
				foundfile = true ;
				logger.info("Found attachment");
				String attach = item.getValueString();
				EmbeddedObject eo = doc.getAttachment(attach);
				if ((eo != null) && (eo.getType() == EmbeddedObject.EMBED_ATTACHMENT)) {
					logger.info("Detaching...");
					attach = eo.getSource();
                    if (attach != null) {
                        int j = attach.indexOf(" ");
                        if (j == -1) {
                        	//String extractFile = tmpDir + "/" + attach ;
                        	String extractFile = verifyFilename(tmpDir, attach) ;
                        	eo.extractFile(extractFile);
                        	rtnVal = extractFile ;
                        }
                    }
				}
				break ;
			}
		}
		if (!foundfile) {
			// Update idFileInVault to 1
			if(doc != null) {
				logger.info("Attachment not found; setting idFileInVault value to 1.");	
				String field = "idFileInVault";
				String value = "1";
				doc.replaceItemValue(field, value);
				if(!doc.isEncrypted()) {
					doc.setEncryptionKeys(encryptionKey);
					doc.encrypt();
				}
				doc.save();
			}
		}
		return rtnVal;
	}
	
	private String verifyFilename(String dirName, String fileName) {
		String rtnFileName = dirName + "/" + fileName ;
		try {
			File file = new File(dirName + "/" + fileName) ;
			if(file.exists()) {
				logger.info("Found existing file name match for " + fileName + ".  Attempting to generate a unique file name...");
				File dir = new File(dirName) ;
				File newFile = File.createTempFile("idfile", ".id", dir) ;
				rtnFileName = dirName + "/" + newFile.getName() ;
			}
		}
		catch(Exception e) {
			logger.debug(e);
		}
		logger.debug("File will be detached as " + rtnFileName);
		return rtnFileName ;
	}

	
	private Date getModDate(String exportDxl) throws Exception {
		Date rtnDate = null ;
		logger.debug("getModDate() called...") ;
		String path = "/document/item[@name='$FILE']/object/file/modified/datetime" ;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
		DocumentBuilder builder = factory.newDocumentBuilder();

		org.w3c.dom.Document document = builder.parse(new InputSource(new ByteArrayInputStream(exportDxl.getBytes("utf-8")))) ;
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		XPathExpression expr = (XPathExpression) xpath.compile(path);
		NodeList nl = (NodeList) expr.evaluate(document, XPathConstants.NODESET);
		for(int i = 0;i < nl.getLength();i++) {
			Element elem = (Element)nl.item(i) ;
			String elemStr = elem.getTextContent().trim().substring(0, 8) ;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd") ;
			rtnDate = sdf.parse(elemStr) ;
		}
		return rtnDate ;
	}

	private Item findItem(Vector vec, String key) throws Exception {
		Item item = null;
		Vector v = vec;
		for (int i = 0; i < v.size(); i++) {
			Item tmpItem = (Item) v.elementAt(i);
			if ((tmpItem != null) && (tmpItem.getName().equals(key))) {
				item = tmpItem;
				break;
			}
		}
		return item;
    }

	public void close() {
		logger.info("Closing connections...") ;
		try {
			if(db != null) {
				if(dbTag.length() > 0) {
					boolean postReplicate = Boolean.parseBoolean(props.getProperty("notes." + dbTag + ".post-replicate")) ;
					if(postReplicate) {
						logger.info("Replicating before closing DB...");
						if(replicateDatabase(db, props.getProperty(UploadConstants.KEY_NOTES_REMOTE_SERVER))) {
							logger.info("Replication was successful");
						}
					}
				}
				db.recycle() ;
			}
			if(dbDir != null) dbDir.recycle() ;
			if(session != null) session.recycle() ;
		}
		catch(Exception e) {
			logger.debug(e) ;
		}
	}
	
	public void openDatabase(String dbName) throws Exception {
		logger.debug("Opening database: " + dbName);
		if(dbDir == null) {
			logger.info("dbDir is null") ;
			throw new Exception("DB dir is null") ;
		}
		if((dbName == null) || (dbName.length() == 0)) {
			logger.info("Invalid database name passed to openDatabase()") ;
			throw new Exception("Invalid database name passed to openDatabase()") ;
		}
		db = dbDir.openDatabase(dbName) ;
	}
	
	public void openDatabaseByTag() throws Exception {
		logger.debug("dbTag = " + dbTag);	
		if(dbTag.length() > 0) {
			boolean preReplicate = Boolean.parseBoolean(props.getProperty("notes." + dbTag + ".pre-replicate")) ;
			String dbName = "" ;
			if(props.getProperty("notes." + dbTag + ".dbType").equals(UploadConstants.DB_TYPE_LOCAL)) {
				logger.debug("Setting dbName to: " + props.getProperty("notes." + dbTag + ".local.name"));
				dbName = props.getProperty("notes." + dbTag + ".local.name") ;
			}
			else {
				logger.debug("Setting dbName to: " + props.getProperty("notes." + dbTag + ".remote.name"));
				dbName = props.getProperty("notes." + dbTag + ".remote.name") ;
			}
			logger.debug("Opening database: " + dbName);
			if(dbDir == null) {
				logger.info("dbDir is null") ;
				throw new Exception("DB dir is null") ;
			}
			db = dbDir.openDatabase(dbName) ;
			if(preReplicate) {
				logger.info("Replicating before using...");
				if(db.replicate(props.getProperty(UploadConstants.KEY_NOTES_REMOTE_SERVER))) {
					logger.info("Replication was successful");
				}
			}
		}
	}
	
	public void openDatabaseByTag(DatabaseConnection dbConnection) throws Exception {
		Database database = null ;
		
		if(dbConnection.getDbType().equals(UploadConstants.DB_TYPE_LOCAL)) {
			dbConnection.setDbDir(session.getDbDirectory(""));
			dbConnection.setDb(dbConnection.getDbDir().openDatabase(dbConnection.getLocalName()));
			if(dbConnection.isPreReplicate()) {
				dbConnection.getDb().replicate(server) ;
			}
		}
		else {
			dbConnection.setDbDir(session.getDbDirectory(server));
			dbConnection.setDb(dbConnection.getDbDir().openDatabase(dbConnection.getRemoteName()));
		}
		
	}
	
	private boolean replicateDatabase(Database db, String server) {
		boolean replicated = false ;
		int count = 0 ;
		int attemptCount = Integer.parseInt(props.getProperty("notes." + dbTag + ".replicateRetryCount", "0")) ;
		
		do {
			logger.info("Replicating database...");
			try {
				replicated = db.replicate(server) ;
			}
			catch(NotesException ne) {
				logger.info("Error: " + ne.getMessage());
				String msg = ne.getMessage() ;
				if(!msg.contains("Network operation did not complete in a reasonable amount of time")) {
					break ;
				}
				else {
					logger.info("Retrying replication up to " + attemptCount + " times...");
				}
			}
			catch(Exception e) {
				logger.info("Error: " + e.getMessage());
				break ;
			}
		} while((++count < attemptCount) && (!replicated)) ;
		if(!replicated) {
			logger.info("Replication retry count exceeded or other error detected; replication was not successful") ;
		}
		return replicated ;
	}
	
	public void closeDatabase() throws Exception {
		if(db != null) {
			db.recycle();
			db = null ;
		}
	}
	
	public Database createReplica(Database database, String newServer, String replica) throws Exception {
		Database localDb = database.createReplica(newServer, replica) ;
		
		return localDb ;
	}
	
	public Session getSession() {
		return session;
	}
	public void setSession(Session session) {
		this.session = session;
	}
	public DbDirectory getDbDir() {
		return dbDir;
	}
	public void setDbDir(DbDirectory dbDir) {
		this.dbDir = dbDir;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public Database getDb() {
		return db;
	}

	public String getExtractDir() {
		return extractDir;
	}

	public void setExtractDir(String extractDir) {
		this.extractDir = extractDir;
	}

	public boolean isIgnoreHistory() {
		return ignoreHistory;
	}

	public void setIgnoreHistory(boolean ignoreHistory) {
		this.ignoreHistory = ignoreHistory;
	}

	public boolean isLocal() {
		return isLocal;
	}

	public void setLocal(boolean isLocal) {
		this.isLocal = isLocal;
	}


}
