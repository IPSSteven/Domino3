package com.ibm.ereg.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class TestListUploadUtility {

	public static void main(String[] args) throws Exception {
		String fileNamePath = "C:\\Users\\StevenCannon\\Documents\\IDUploadUtility\\Test2.txt";
		
		try {
			ArrayList<String> shortNameList = loadShortNamesFromFile(fileNamePath) ;
			System.out.println("Short Name List - " + shortNameList);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	private static ArrayList<String> loadShortNamesFromFile(String filePathName) throws IOException {
		ArrayList<String> shortNames = new ArrayList<>();
        FileReader fileReader = new FileReader(filePathName);     
        BufferedReader bufferedreader = new BufferedReader(fileReader);           
        int numRow = 1;
		
        try{
        	String strLine;
        	String shortName;
        	while ((strLine = bufferedreader.readLine()) != null) {
        		shortName = strLine.trim();
        		if (shortName.length() > 0 && shortName != null) {
        			shortNames.add(shortName);
                    numRow = numRow + 1;
        		}
            } 
        } catch (IOException ex) {
    		    ex.printStackTrace();
    	}        
        fileReader.close();
        return shortNames;
	}
}