/*
 * Created on Jan 10, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ibm.ereg.utils;

import java.util.HashMap;
import java.util.StringTokenizer;

public class CmdOpts {
	private HashMap optList = null ;
	private String[] argsPassed ;
	private TextParser textParser = null ;

	
	public CmdOpts() {
		
	}
	/**
	 * 
	 */
	public CmdOpts(String[] args) {
		init(args) ;
	}
	
	public void init(String[] args) {
		textParser = new TextParser() ;
		textParser.addMapElement("%2F", "-") ;
		argsPassed = args ;
		optList = new HashMap() ;
		String cmdLineString = getArgsAsString(args) ;
		initOptList(cmdLineString) ;
	}
	
	public String getOptVal(String key) {
		return (String)optList.get(key) ;
	}
	
	public boolean containsOpt(String key) {
		return optList.containsKey(key) ;
	}

	/**
	 * @param cmdLineString
	 */
	private void initOptList(String cmdLineString) {
		StringTokenizer strTok = new StringTokenizer(cmdLineString, "-") ;
		while(strTok.hasMoreTokens()) {
			String tok = strTok.nextToken() ;
			String opt = tok.substring(0, 1) ;
			String optval = tok.substring(1).trim() ;
			textParser.setText(optval) ;
			optval = textParser.sub() ;
			if((opt != null) && (opt.length() > 0)) {
				optList.put(opt, optval) ;
			}
		}
	}

	/**
	 * @param args
	 * @return
	 */
	private String getArgsAsString(String[] args) {
		StringBuffer strBuf = new StringBuffer() ;
		for(int i = 0;i < args.length;i++) {
			strBuf.append(args[i] + " ") ;
		}
		return strBuf.toString().trim() ;
	}
	public String[] getArgsPassed() {
		return argsPassed;
	}

}
