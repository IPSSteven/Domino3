package com.ibm.ereg.utils;

public class MailGtwyInputObj {
	String internetAddress ;
	String fullName ;
	String shortName ;
	String serial ;
	String psc ;
	String country ;
	String empType ;
	String detachedFile ;
	String password ;
	String notesDocID ;
	UploadStatus uploadStatus = UploadStatus.NO_STATUS;
	
	public String getInternetAddress() {
		return internetAddress;
	}
	public void setInternetAddress(String internetAddress) {
		this.internetAddress = internetAddress;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getSerial() {
		return serial;
	}
	public void setSerial(String serial) {
		this.serial = serial;
	}
	public String getPsc() {
		return psc;
	}
	public void setPsc(String psc) {
		this.psc = psc;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmpType() {
		return empType;
	}
	public void setEmpType(String empType) {
		this.empType = empType;
	}
	
	public String getEmpNum() {
		String empNum = "" ;
		if((serial != null) &&
		   (serial.length() > 0) && 
		   (psc != null) &&
		   (psc.length() > 0)) 
		{
			empNum = serial + psc ;
		}
		else if((serial != null) && (serial.length() > 0)) {
			empNum = serial ;
		}
		return empNum ;
	}
	
	public String toString() {
		return internetAddress + "," + fullName + "," + shortName + "," +
	           serial + "," + psc + "," + country + "," + empType ;
	}
	
	public String getUploaStatusString() {
		String rtnStr = "" ;
		if(uploadStatus == UploadStatus.BAD_DATA) {
			rtnStr = "Bad input data" ;
		}
		else if(uploadStatus == UploadStatus.NO_ID_FILE) {
			rtnStr = "Missing ID file" ;
		}
		else if(uploadStatus == UploadStatus.NO_MATCH_FOUND) {
			rtnStr = "Record not found" ;
		}
		else if(uploadStatus == UploadStatus.NO_STATUS) {
			rtnStr = "Status unknown" ;
		}
		else if(uploadStatus == UploadStatus.UPLOAD_FAILED) {
			rtnStr = "Upload failed" ;
		}
		else if(uploadStatus == UploadStatus.UPLOAD_SUCCEEDED) {
			rtnStr = "Upload succeeded" ;
		}
		else if(uploadStatus == UploadStatus.REPORT_ONLY_UPLOADABLE) {
			rtnStr = "Report-only uploadable" ;
		}
		else if(uploadStatus == UploadStatus.FOUND_IN_VAULT) {
			rtnStr = "Already in vault" ;
		}
		else if(uploadStatus == UploadStatus.UNABLE_TO_VERIFY_VAULT_STATUS) {
			rtnStr = "Error checking vault" ;
		}
		return rtnStr ;
	}
	
	public String getDetachedFile() {
		return detachedFile;
	}
	public void setDetachedFile(String detachedFile) {
		this.detachedFile = detachedFile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UploadStatus getUploadStatus() {
		return uploadStatus;
	}
	public void setUploadStatus(UploadStatus uploadStatus) {
		this.uploadStatus = uploadStatus;
	}
	public String getNotesDocID() {
		return notesDocID;
	}
	public void setNotesDocID(String notesDocID) {
		this.notesDocID = notesDocID;
	}
	
}
