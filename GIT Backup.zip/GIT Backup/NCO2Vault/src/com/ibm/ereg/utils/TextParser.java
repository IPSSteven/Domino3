/*
 * Created on Mar 21, 2006
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.ibm.ereg.utils;

import java.util.Enumeration;
import java.util.Hashtable;

public class TextParser {
	Hashtable subMap = null ;
	String text ;
	
	public TextParser(Hashtable map, String txt) {
		subMap = map ;
		text   = txt ;
	}
	
	public TextParser() {
		subMap = new Hashtable() ;
		text = "" ;
	}
	
	public String sub() {
		Enumeration e = subMap.keys() ;
		String rtnStr = text ;
		while(e.hasMoreElements()) {
			String key = (String)e.nextElement() ;
			String val = (String)subMap.get(key) ;
			rtnStr = subVal(rtnStr, key, val) ;
		}
		
		return rtnStr ;
	}
	
	private String subVal(String inString, String oldChars, String newChars) {
		String rtnStr = "" ;
		int i = -1 ;
		if(inString == null) {
			return rtnStr ;
		}
		if((i = inString.indexOf(oldChars)) != -1) {
			String sub1 = "" ;
			String sub2 = "" ;
			if(i == 0) {
				sub1 = inString.substring(i + oldChars.length()) ;
				rtnStr = newChars + subVal(sub1, oldChars, newChars) ;
			}
			else if((i + oldChars.length()) == inString.length()) {
				sub1 = inString.substring(0, i) ;
				rtnStr = sub1 + newChars ;
			}
			else {
				sub1 = inString.substring(0, i) ;
				sub2 = inString.substring(i + oldChars.length(), inString.length()) ;
				rtnStr = sub1 + newChars + subVal(sub2, oldChars, newChars) ;
			}
			return rtnStr ;
		}
		else {
			rtnStr = inString;
			return rtnStr ;
		}
	}

	public void addMapElement(String key, String val) {
		subMap.put(key, val) ;
	}

	public Hashtable getSubMap() {
		return subMap;
	}

	public void setSubMap(Hashtable subMap) {
		this.subMap = subMap;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
