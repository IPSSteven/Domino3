package com.ibm.ereg.utils;

public interface UploadConstants {
	
	public final static String KEY_NOTES_USER = "notes.user" ;
	public final static String KEY_NOTES_PW = "notes.passwd" ;
	public final static String KEY_NOTES_EXTRACTDIR = "notes.extractDir" ;
	public final static String KEY_NOTES_TESTCOUNT = "notes.testMaxCount" ;
	public final static String KEY_NOTES_UPLOAD_SCNTAG = "notes.upload.scndb" ;
	public final static String KEY_NOTES_UPLOAD_GWTAG = "notes.upload.gatewaydb" ;
	public final static String KEY_NOTES_REMOTE_SERVER = "notes.remote.server" ;
	public final static String KEY_NOTES_UPDATE_HISTORY = "notes.updateHistory" ;
	public final static String KEY_GW_SLEEPTIME = "upload.gw.sleepTime" ;
	public final static String KEY_GW_RETRY_COUNT = "upload.gw.retryCount" ;
	public final static String KEY_GW_RETRY_SLEEPTIME = "upload.gw.retrySleepTime" ;
	public final static String KEY_FAILURE_ALERT_FLAG = "upload.failure.sendAlert" ;
	public final static String KEY_FAILURE_ALERT_URL = "upload.failure.alert.url" ;
	public final static String KEY_FAILURE_ALERT_BASE_MSG = "upload.failure.alert.baseMsg" ;
	public final static String KEY_GW_UPLOAD_URL = "upload.gw.upload.url" ;
	public final static String KEY_GW_CHECK_URL = "upload.gw.check.url" ;
	public final static String KEY_MAIL_SERVER = "notes.mail.server" ;
	public final static String KEY_MAIL_DB = "notes.mail.db" ;
	public final static String KEY_SECURITY_DBTAGS = "notes.security.dbs" ;
	public final static String KEY_GD_VAULT_SERVER = "upload.gd.server" ;
	public final static String KEY_GW_CLASSNAME = "upload.gw.className" ;
	public final static String KEY_CLOUD_CLASSNAME = "upload.cloud.className" ;
	public final static String KEY_FORCE_CLOUD = "upload.forceCloud";
	
	public final static String DB_TYPE_LOCAL = "local" ;
	public final static String DB_TYPE_REMOTE = "remote" ;
	
	public final static String MAIL_GATEWAY_TAG = "MG" ;
	public final static String CLOUD_TAG = "CLOUD" ;
	
	public final static String MAIL_SYSTEM_OTHER = "3" ;
	
	public final static String NCOUAR_ENCRYPTION_KEY = "NCOUAR_ITIM";
}
