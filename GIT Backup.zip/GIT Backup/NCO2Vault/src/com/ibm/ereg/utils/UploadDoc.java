package com.ibm.ereg.utils;

public class UploadDoc {
	String docID ;
	String internetAddress ;
	String ownerSerial ;
	String password ;
	String shortName ;
	String detachedFile ;
	String mailSystem ;
	UploadStatus uploadStatus ;
	String fullName;
	
	public String getDocID() {
		return docID;
	}
	public void setDocID(String docID) {
		this.docID = docID;
	}
	public String getInternetAddress() {
		return internetAddress;
	}
	public void setInternetAddress(String internetAddress) {
		this.internetAddress = internetAddress;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getDetachedFile() {
		return detachedFile;
	}
	public void setDetachedFile(String detachedFile) {
		this.detachedFile = detachedFile;
	}
	public UploadStatus getUploadStatus() {
		return uploadStatus;
	}
	public void setUploadStatus(UploadStatus uploadStatus) {
		this.uploadStatus = uploadStatus;
	}
	public String getOwnerSerial() {
		return ownerSerial;
	}
	public void setOwnerSerial(String ownerSerial) {
		this.ownerSerial = ownerSerial;
	}
	public String getMailSystem() {
		return mailSystem;
	}
	public void setMailSystem(String mailSystem) {
		this.mailSystem = mailSystem;
	}
	
	public String getUserForMailSystem(UploadOverride uploadOverride) {
		String rtnUser = "" ;
		if(mailSystem.equals(UploadConstants.MAIL_SYSTEM_OTHER) && (uploadOverride != UploadOverride.FORCECLOUD)) {
			rtnUser = ownerSerial ;
		} else if(uploadOverride == UploadOverride.FORCEMAILGATEWAY){
			rtnUser = ownerSerial;
		}
		else {
			rtnUser = fullName ;
		}
		return rtnUser ;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
}
