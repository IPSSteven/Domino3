package com.ibm.ereg.utils;

public enum UploadOverride {
	NONE, 
	FORCECLOUD,
	FORCEMAILGATEWAY
}
