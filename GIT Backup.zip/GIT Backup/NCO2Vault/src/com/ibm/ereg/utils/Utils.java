package com.ibm.ereg.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class Utils {
	public static String formatDate(String dateFormat) {
		String timeStamp = "" ;
		DateFormat gmtFormat = new SimpleDateFormat(dateFormat, Locale.ENGLISH);
		TimeZone gmtTime = TimeZone.getTimeZone("GMT");
		gmtFormat.setTimeZone(gmtTime);
		timeStamp = gmtFormat.format(new Date());
		
		return timeStamp ;
	}
}
