package com.ibm.ereg.utils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;

import org.apache.log4j.Logger;

public class WSClient {
	private final String DEFAULT_USER_AGENT = "Mozilla/5.0";
	private final String DEFAULT_PROTOCOL = "TLSv1.2" ;
	private final String DEFAULT_ACCEPT_LANG = "en-US,en;q=0.5" ;
	private final String DEFAULT_CONTENT_TYPE = "application/json" ;
	
	private String userAgent = DEFAULT_USER_AGENT ;
	private String protocol = DEFAULT_PROTOCOL ;
	private String acceptLang = DEFAULT_ACCEPT_LANG ;
	private String contentType = DEFAULT_CONTENT_TYPE ;
	private int responseCode = -1 ;
	private boolean useSSL = true ;
	private HashMap<String, String> requestProperties = null ;
	Logger logger = null ;
	
	public WSClient(boolean useSSL) {
		this.useSSL = useSSL ;
		logger = Logger.getLogger(getClass()) ;
	}
	
	public WSClient() { 
		logger = Logger.getLogger(getClass()) ;
	}
	
	public String doGet(String url) throws Exception {
		HttpURLConnection con = null ;
		URL obj = new URL(url);
		if(useSSL) {
			SSLContext sc = SSLContext.getInstance(protocol); 
			sc.init(null, null, new java.security.SecureRandom());
			con = (HttpsURLConnection) obj.openConnection();
			((HttpsURLConnection)con).setSSLSocketFactory(sc.getSocketFactory());
		}
		else {
			con = (HttpURLConnection)obj.openConnection();
		}
		con.setRequestMethod("GET");
		return(postData(con, null)) ;
	}
	
	public int doGetForHttpRC(String url) throws Exception {
		HttpURLConnection con = null ;
		URL obj = new URL(url);
		if(useSSL) {
			SSLContext sc = SSLContext.getInstance(protocol); 
			sc.init(null, null, new java.security.SecureRandom());
			con = (HttpsURLConnection) obj.openConnection();
			((HttpsURLConnection)con).setSSLSocketFactory(sc.getSocketFactory());
		}
		else {
			con = (HttpURLConnection)obj.openConnection();
		}
		con.setRequestMethod("GET");
		return(postDataForHttpRC(con, null)) ;
	}
	
	public String doPost(String url, String jsonStr) throws Exception {
		HttpURLConnection con = null ;
		URL obj = new URL(url);
		if(useSSL) {
			SSLContext sc = SSLContext.getInstance(protocol); 
			sc.init(null, null, new java.security.SecureRandom());
			con = (HttpsURLConnection) obj.openConnection();
			
			((HttpsURLConnection)con).setSSLSocketFactory(sc.getSocketFactory());
		}
		else {
			con = (HttpURLConnection) obj.openConnection();
		}
		con.setRequestMethod("POST");
		con.setRequestProperty("User-Agent", userAgent);
		con.setRequestProperty("Accept-Language", acceptLang);
		con.setRequestProperty("Content-Type", contentType);
		
		con.setDoOutput(true);
		return(postData(con, jsonStr)) ;
	}
	
	public int doPost(String url, File file) throws Exception {
		HttpURLConnection con = null ;
		URL obj = new URL(url);
		if(useSSL) {
			SSLContext sc = SSLContext.getInstance(protocol); 
			sc.init(null, null, new java.security.SecureRandom());
			con = (HttpsURLConnection) obj.openConnection();
			
			((HttpsURLConnection)con).setSSLSocketFactory(sc.getSocketFactory());
		}
		else {
			con = (HttpURLConnection) obj.openConnection();
		}
		con.setRequestMethod("POST");
		con.setRequestProperty("User-Agent", userAgent);
		con.setRequestProperty("Accept-Language", acceptLang);
		con.setRequestProperty("Content-Type", contentType);
		
		if(requestProperties != null) {
			Iterator<String> iter = requestProperties.keySet().iterator() ;
			while(iter.hasNext()) {
				String key = iter.next() ;
				con.setRequestProperty(key, requestProperties.get(key));
			}
		}
		
		con.setDoOutput(true);
		return(postDataFile(con, file)) ;
	}
	
	private String postData(HttpURLConnection con, String jsonStr) throws Exception {
		String rtnStr = "" ;
		if(jsonStr != null) {
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(jsonStr);
			wr.flush();
			wr.close();
		}
	 
		responseCode = con.getResponseCode();
		
		// Note:  this print statement is just a test for the vault ID upload solution 
		// System.out.println(con.getHeaderField("responseMsg")) ;
		
		if(responseCode == 200) {
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String output;
			StringBuffer response = new StringBuffer();
		 
			while((output = in.readLine()) != null) {
				response.append(output);
			}
			in.close();
			rtnStr = response.toString();
			
		}
		else {
			StringBuffer strBuf = new StringBuffer() ;
			strBuf.append("{ ").append("{ \"msg:\"")
			                   .append("\"HTTPS Error\"")
			                   .append("\"returncode:\"")
			                   .append("\"" + Integer.valueOf(responseCode) + "\"}") ;
			rtnStr = strBuf.toString() ;
		}
		return rtnStr ;	
	}
	
	private int postDataForHttpRC(HttpURLConnection con, String jsonStr) throws Exception {
		if(jsonStr != null) {
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(jsonStr);
			wr.flush();
			wr.close();
		}
	 
		return(con.getResponseCode());
	}
	
	private int postDataFile(HttpURLConnection con, File file) throws Exception {
		if(file.exists()) {
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			FileInputStream fis = new FileInputStream(file.getAbsolutePath()) ;
			byte b[] = new byte[(int)file.length()] ;
			fis.read(b) ;
			fis.close();
			wr.write(b);
			wr.flush();
			wr.close();
		}
		else {
			throw new Exception("File " + file.getAbsolutePath() + " not found") ;
		}
	 
		responseCode = con.getResponseCode();
		try {
			logger.debug("Response message: " + con.getHeaderField("responseMsg"));
			logger.info("Response code: " + responseCode);
		}
		catch(Exception e) {
			logger.debug(e);
		}
		// System.out.println(con.getHeaderField("responseMsg")) ;
		return responseCode ;	
	}


	public String getUserAgent() {
		return userAgent;
	}

	/**Sets the User-Agent request property for client
	 * 
	 * @param userAgent
	 */
	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public String getProtocol() {
		return protocol;
	}

	/**
	 * Sets the protocol for SSL context used for client
	 * @param protocol - SSL protocol
	 * 
	 */
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getAcceptLang() {
		return acceptLang;
	}

	/**Sets the Accept-Language request property for client
	 * @param acceptLang
	 */
	public void setAcceptLang(String acceptLang) {
		this.acceptLang = acceptLang;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public HashMap<String, String> getRequestProperties() {
		return requestProperties;
	}

	public void setRequestProperties(HashMap<String, String> requestProperties) {
		this.requestProperties = requestProperties;
	}
	
	public void addRequestProperty(String key, String val) {
		if(requestProperties == null) {
			requestProperties = new HashMap<String, String>() ;
		}
		requestProperties.put(key, val) ;
	}
}
