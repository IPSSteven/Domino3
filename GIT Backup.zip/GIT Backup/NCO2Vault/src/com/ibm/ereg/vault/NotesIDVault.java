package com.ibm.ereg.vault;

import java.util.Properties;

public interface NotesIDVault {
	public void init(Properties props) throws Exception ;
	public String isInVault(Object obj) throws Exception ;
	public String upload(String user, String userIdFilePath, String userPassword) throws Exception ;
	public int getSleepTime() ;
	public int getUploadedCount() ;
}
