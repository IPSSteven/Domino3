package com.ibm.ereg.vault.domino;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.ibm.ereg.UploadUtility;
import com.ibm.ereg.utils.UploadConstants;
import com.ibm.ereg.vault.NotesIDVault;

import lotus.domino.IDVault;
import lotus.domino.Session;

public class GDVault implements NotesIDVault {
	private Properties props = null ;
	private int sleepTime = 0 ;
	private int uploadedCount = 0 ;
	String vaultServer ;
	Logger logger = null ;
	Session session = null ;
	IDVault vault = null ;

	@Override
	public void init(Properties props) throws Exception {
		this.props = props ;
		vaultServer = props.getProperty(UploadConstants.KEY_GD_VAULT_SERVER) ;
		logger = Logger.getLogger(getClass()) ;
		session = UploadUtility.getNotesConnection().getSession() ;
		vault = session.getIDVault() ;
	}

	@Override
	public String isInVault(Object user) throws Exception {
		String rtnStr = "YES" ;
		try {
			boolean isInVault = vault.isIDInVault((String)user, vaultServer) ;
			if(!isInVault) {
				rtnStr = "NO" ;
			}
		}
		catch(Exception e) {
			logger.info("Error: " + e.getMessage());
			logger.debug(e);
			rtnStr = "ERROR" ;
		}
		return rtnStr;
	}

	@Override
	public String upload(String user, String userIdFilePath, String userPassword) throws Exception {
		String rtnStr = "" ;
		logger.info("Uploading ID file for " + user);
		/*
		 * public void putUserIDFile(String idFilePath, String username, String passwd, String servername)
		 */
		try {
			if(vault != null) {
				vault.putUserIDFile(userIdFilePath, user, userPassword, vaultServer);
				rtnStr = "SUCCESS" ;
			}
		}
		catch(Exception e) {
			logger.info("Error: " + e.getMessage());
			logger.debug(e);
			rtnStr = "ERROR" ;
		}
		return rtnStr;
	}

	@Override
	public int getSleepTime() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getUploadedCount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
