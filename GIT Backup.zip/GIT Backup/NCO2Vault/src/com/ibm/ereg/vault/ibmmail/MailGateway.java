package com.ibm.ereg.vault.ibmmail;

import java.io.File;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.ibm.ereg.utils.UploadConstants;
import com.ibm.ereg.utils.WSClient;
import com.ibm.ereg.vault.NotesIDVault;

public class MailGateway implements NotesIDVault {
	private Properties props = null ;
	private int sleepTime = 0 ;
	Logger logger = null ;
	private int uploadedCount = 0 ;
	WSClient wsClient ;
	

	@Override
	public void init(Properties props) throws Exception {
		this.props = props ;
		logger = Logger.getLogger(getClass()) ;
		sleepTime = Integer.parseInt(props.getProperty(UploadConstants.KEY_GW_SLEEPTIME)) ;
	}

	@Override
	public int getSleepTime() {
		return sleepTime;
	}
	
	@Override
	public String isInVault(Object obj) throws Exception {
		String rtnStr = "" ;
		String url = props.getProperty(UploadConstants.KEY_GW_CHECK_URL) + "?uid=" + (String)obj ;
		logger.debug("Checking mail gateway vault with url = " + url);
		wsClient = new WSClient() ;
		try {
			String reply = wsClient.doGet(url) ;			
			logger.debug("reply = " + reply);
			int rc = wsClient.getResponseCode() ;
			if(rc == 200) {
				rtnStr = "YES" ;
			}
			else if(rc == 404) {
				rtnStr = "NO" ;
			}
			else {
				rtnStr = "ERROR" ;
			}
		}
		catch(Exception e) {
			logger.info("Error: " + e.getMessage());
			logger.debug(e); 
			rtnStr = "ERROR" ;
		}
		return rtnStr;
	}

	@Override
	public String upload(String user, String userIdFilePath, String userPassword) throws Exception {
		String rtnStr = "" ;
		File file = new File(userIdFilePath) ;
		wsClient = new WSClient() ;
		wsClient.setContentType("application/octet-string");
		wsClient.addRequestProperty("uid", user);		// Note:  need UID instead of email addr!!  Set before this method is called
		wsClient.addRequestProperty("password", userPassword);
		wsClient.addRequestProperty("Content-Length", new Long(file.length()).toString());	
		int rtnCode = wsClient.doPost(props.getProperty(UploadConstants.KEY_GW_UPLOAD_URL), file) ;
		if(rtnCode == 201) {
			rtnStr = "SUCCESS" ;
			uploadedCount++ ;
		}
		else {
			rtnStr = "ERROR" ;
		}
		
		return rtnStr;
	}

	@Override
	public int getUploadedCount() {
		return uploadedCount;
	}

	public int getResponseCode() {
		int responseCode = 0 ;
		if(wsClient != null) {
			responseCode = wsClient.getResponseCode() ;
		}
		
		return responseCode ;
	}

}
