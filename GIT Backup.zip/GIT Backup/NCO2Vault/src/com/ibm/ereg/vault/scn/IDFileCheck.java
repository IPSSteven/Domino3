package com.ibm.ereg.vault.scn;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.ibm.commons.util.io.json.JsonJavaFactory;
import com.ibm.commons.util.io.json.JsonJavaObject;
import com.ibm.commons.util.io.json.JsonParser;
import com.ibm.ereg.UploadUtility;
import com.ibm.ereg.vault.NotesIDVault;

public class IDFileCheck implements NotesIDVault {
	String propFile = "config/idfilecheck.properties" ;
	SamlRestClient client = null ;
	Properties props = null ;
	Logger logger = null ;
	String adminUser ;
	String adminPw ;
	String apiServer ;
	String restApiAddr ;
	String restUri ;
	String iSamlPath ;
	private int uploadedCount = 0;
	
	public IDFileCheck() { }
	
	public IDFileCheck(Properties p) {
		props = p ;
	}
	
	@Override
	public void init(Properties props) throws Exception {
		this.props = props ;
		init(false) ;
	}

	@Override
	public int getSleepTime() {
		// No sleep time required for SCN vault
		return 0;
	}

	
	@Override
	public String isInVault(Object obj) throws Exception {
		String userId = (String)obj ;
		return checkIDFile(userId);
	}

	@Override
	public String upload(String user, String userIdFilePath, String userPassword) throws Exception {
		return(uploadIDFile(user, userIdFilePath, userPassword)) ;
	}
	
	public void init(boolean fullLoggerInit) throws Exception {
		initProps() ;
		initLogger(fullLoggerInit) ;
		apiServer = props.getProperty("idcheck.server").trim() ;
		adminUser = props.getProperty("idcheck.adminEmail").trim() ;
		adminPw = UploadUtility.getCryptUtil().decrypt(props.getProperty("idcheck.adminPw").trim()) ;
		restApiAddr = props.getProperty("idcheck.restApiAddr").trim() ;
		restUri = props.getProperty("idcheck.restUri").trim() ;
		iSamlPath = props.getProperty("idcheck.samlPath").trim() ;
		logger.debug("iSamlPath = " + iSamlPath);
		client = new SamlRestClient(apiServer, restApiAddr, adminUser, adminPw, iSamlPath);
	}
	
	private void initProps() throws Exception {
		if(props == null) {
			FileInputStream fis = new FileInputStream(propFile) ;
			props = new Properties() ;
			props.load(fis);
			fis.close(); 
		}
	}
	
	private void initLogger(boolean fullLoggerInit) throws Exception {
		logger = Logger.getLogger(getClass()) ;
		if(fullLoggerInit) {
			PropertyConfigurator.configure(props) ;
		}
	}
	
	private String checkIDFile(String user) throws Exception {
		logger.info("Checking ID file for user " + user) ;
		String rtnStr = "" ;
		
		logger.info(restUri);
		RestResult result = client.get(restUri, null, user);
		if (result.getResponseCode() == 200) {
			JsonJavaObject getContent = (JsonJavaObject)JsonParser.fromJson(JsonJavaFactory.instanceEx, 
					                                                        new InputStreamReader(result.asInputStream()));
			boolean idFileExists = getContent.getBoolean("idFileExists");
			if(idFileExists) {
				rtnStr = "YES" ;
			}
			else {
				rtnStr = "NO" ;
			}
		}
		else {
			logger.info("Response code was " + result.getResponseCode() );
			rtnStr = "ERROR" ;
		}
		return rtnStr ;
	}
	
	private String uploadIDFile(String user, String userIdFilePath, String userPassword) throws Exception {
		String rtnStr = "" ;
		RestResult result = null ;
		/* PAYLOAD
		 * 
		 * ["passw0rd",IDFileData]
		 * 
		 * passwordlength=24
		 * */
			
		Map<String, Object> objMap = buildPayload(userIdFilePath, userPassword);
		@SuppressWarnings("unchecked")
		HashMap<String, String> queryParam = (HashMap<String, String>) objMap.get("queryParam");
		byte[] payloadByteArray = (byte[]) objMap.get("payload");
		
		logger.info(restUri + " " + queryParam.toString());
			
		/* Commence the upload*/

		result = client.post(restUri, user, userPassword, payloadByteArray, queryParam);
		logger.debug("Just finished call to post().  response code is " + result.getResponseCode()) ;

		
		/* Parse the response from the server to a JAVA JSON for further processing */

		JsonJavaObject postContent = (JsonJavaObject) JsonParser.fromJson(JsonJavaFactory.instanceEx, 
				new InputStreamReader(result.asInputStream()));
		
		if(result.getResponseCode() == 200)
		{
			logger.info("Return message = " + postContent.getString("message")) ;

			/*
			 * Sample response  
			 * { 
			 * 	"message":"ID File Uploaded Successfully" 	// String
			 * }
			 */
				
			if(postContent.getString("message").equals("ID File Uploaded Successfully")) {
				logger.info(user + "'s ID File has been succcessfully uploaded");
			}
			rtnStr = "SUCCESS" ;
			uploadedCount++ ;
		}
		else
		{
			logger.info("Operation failed");
			logger.info("Response code:" + result.getResponseCode());
			logger.debug("Result payload:" + postContent.toString());
			rtnStr = "ERROR" ;
		}


		return rtnStr ;
	}
	
	/** 
	 * This method will create a payload that will be consumed by /idfile POST request  
	 * to upload Id file to the Vault. Generated payload will be a byte array as follows
	 * ["passw0rd", [ID File bytes]] and a HashMap<String, String> of 
	 * required query parameters.
	 * 
	 * @param filePath	 		user's valid ID File location.
	 * @param userPassword 		user's valid ID File password.
	 * @throws IOException
	 */
	private Map<String, Object> buildPayload(String filePath, String userPassword) throws IOException
	{
		String passwordLength = userPassword.getBytes().length + "";
		
		HashMap<String, String> queryParam = new HashMap<String, String>();
		queryParam = new HashMap<String, String>();
		queryParam.put("passwordLength", passwordLength);
		
		/* Reading the file and converting into byte array */
		byte[] fileBytes = null;
		File file = new File(filePath);
		FileInputStream fis = new FileInputStream(file);
		BufferedInputStream bis = new BufferedInputStream(fis);
		fileBytes = new byte[(int) file.length()];
		bis.read(fileBytes);
		bis.close();	
		
		byte[] payloadByteArray = new byte[fileBytes.length] ;
		System.arraycopy(fileBytes, 0, payloadByteArray, 0, fileBytes.length) ;

		Map<String, Object> objMap = new HashMap<String, Object>();
		objMap.put("payload", payloadByteArray);
		objMap.put("queryParam", queryParam);
		
		return objMap;
	}

	
	public static void main(String[] args) {
		IDFileCheck idFileCheck = new IDFileCheck() ;
		try {
			idFileCheck.init(true); 
			String rtnStr = idFileCheck.checkIDFile(args[0]) ;
			System.out.println(rtnStr) ;
		}
		catch(Exception e) {
			StringBuffer strBuf = new StringBuffer() ;
			StackTraceElement[] stElems = e.getStackTrace() ;
			for(StackTraceElement ste : stElems) {
				strBuf.append(ste.getLineNumber() + ", " + ste.getFileName() + ", " + ste.getMethodName() + "\n") ;
			}
			System.err.println(strBuf.toString());
			System.err.println(e.getMessage());
			System.out.println("ERROR") ;
		}

	}

	@Override
	public int getUploadedCount() {
		return uploadedCount;
	}


}
