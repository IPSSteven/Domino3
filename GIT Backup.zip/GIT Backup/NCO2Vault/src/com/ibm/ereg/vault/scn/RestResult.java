package com.ibm.ereg.vault.scn;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;

public class RestResult {
	
	private HttpURLConnection conn;
	
	RestResult(HttpURLConnection conn) {
		this.conn = conn;
	}
	
	/**
	 * The HTTP response code from the service. 
	 * @return
	 * @throws IOException 
	 */
	public int getResponseCode() throws SamlRestClientException{
		try {
			return conn.getResponseCode();
		} catch (IOException e) {
			throw new SamlRestClientException(e);
		}
	}
	/**
	 * The content type of the response
	 * @return
	 */
	public String getContentType(){
		return conn.getContentType();
	}
	
	public InputStream getErrorStream()
	{
		return conn.getErrorStream();
	}
	
	/**
	 * Return the response contents as a String
	 * @return
	 * @throws IOException 
	 */
	public String asString() throws SamlRestClientException {
		String retval = null;
		InputStream is;
		try {
			/* when an error is returned by the server
			 * all the information regarding that error
			 * is part of the ErrorStream
			 * While on a successful attempt all information
			 * will be part  of InputStream
			 * */
			if(conn.getErrorStream() != null)
				is = conn.getErrorStream();
			else
				is = conn.getInputStream();
			
			InputStreamReader isr = new InputStreamReader(is);
			StringBuilder sb = new StringBuilder();
			final int bufSize = 10280;
			char buf[] = new char[bufSize];
			 
			while(true){
				int count = isr.read(buf, 0, bufSize);			
				if(count == -1)
					break;
				sb.append(buf, 0, count);
				
			}
			retval = sb.toString();
		} catch (IOException e) {
			throw new SamlRestClientException(e);
		}
		return retval;
	}
	/**
	 * 
	 */
	public InputStream asInputStream() throws SamlRestClientException {
		InputStream is;
		try {
			/* when an error is returned by the server
			 * all the information regarding that error
			 * is part of the ErrorStream
			 * While on a successful attempt all information
			 * will be part  of InputStream
			 * */
			if(conn.getErrorStream() != null)
				is = conn.getErrorStream();
			else
				is = conn.getInputStream();
			return is;
		} catch (IOException e) {
			throw new SamlRestClientException(e);
		}
	}
}
