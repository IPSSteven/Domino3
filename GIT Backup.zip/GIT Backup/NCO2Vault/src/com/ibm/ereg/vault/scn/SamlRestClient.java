package com.ibm.ereg.vault.scn;


import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;

/**
 * This is sample code that demonstrates how to process the SAML authentication
 * flow and invoke the SmartCloud Notes Administration ReST API. Cookie management 
 * is unsophisticated in this example but functional for demonstration. 
 * 
 * 
 * @author ghegfield
 *
 */
public class SamlRestClient {
	Logger logger = Logger.getLogger(getClass()) ;
	private String host;
	private String serviceURI;
	private String iSamlPath ;
	
	private final String PROTOCOL = "https";
	private final String SET_COOKIE_HEADER = "Set-Cookie";
	private final String COOKIE_HEADER = "Cookie";
	private HashMap<String, String> cookies = new HashMap<String, String>();
	private boolean authenticated = false;
	/**
	 * 
	 * @param host - Host name for the SmartCloud Notes API
	 * @param serviceURI - Root URI for the API, /api/admin, etc.
	 * @param userName - user with Administrator role
	 * @param password 
	 * @throws SamlRestClientException 
	 */
	public SamlRestClient(String host, String serviceURI, String userName, String password, String samlPath) throws SamlRestClientException {
		this.host = host;
		if(serviceURI.charAt(serviceURI.length() - 1) == '/'){
			serviceURI = serviceURI.substring(0, serviceURI.length() - 1);
		}
		this.iSamlPath = samlPath ;
		this.serviceURI = serviceURI;
		logger.debug("SamlRestClient about to authenticate...");
		authenticate(userName, password);
	}
	
	/**
	 * 
	 * @param api URI component relative to the service URI. 
	 * 
	 * @return result of API call. 
	 */
	public RestResult get(String api, Map<String, String> queryParameters, String userId){
		if(!authenticated)
			throw new IllegalStateException("Service not authenticated");
		
		StringBuilder targetURI = new StringBuilder(serviceURI);
		
		if(api != null && !api.isEmpty()){
			if(!api.startsWith("/"))
				targetURI.append('/');
			targetURI.append(api);
		}
		HashMap<String,String> headers = new HashMap<String,String>();
		/*
		 * Make the default content type application/json. 		
		 */
		headers.put("Content-Type", "application/json");
		headers.put("X-HTTP-Query-Email", userId) ;
			
		HttpURLConnection conn = doGet(host, targetURI.toString(), headers, queryParameters);
		
		return new RestResult(conn);
	}
	/**
	 * Posts data to API with application/octet-stream content type
	 * @param api
	 * @param data
	 * @return
	 */
	public RestResult post(String api, String userId, String passwd, byte[] data, HashMap<String,String> queryParameters){
		
		if(api == null || api.isEmpty())
			throw new IllegalArgumentException("api argument required");
		
		StringBuilder targetURI = new StringBuilder(serviceURI);
	
		if(!api.startsWith("/"))
			targetURI.append('/');
		targetURI.append(api);
		
		String queryParams = "?";
		int keySetSize = queryParameters.keySet().size() ;
		int count = 0 ;
		for( String key: queryParameters.keySet())
		{
			queryParams = queryParams + key + "="+ queryParameters.get(key) + ((++count == keySetSize) ? "" : "&");
		}

		String uri = targetURI.toString() +  queryParams;
			
		return new RestResult(doPost(host, uri, userId, passwd, data));
	}
		
	/**
	 * Initiates the SAML authentication flow and retrieves authentication cookie
	 * from the service provider.  
	 * @return
	 * @throws MalformedURLException 
	 * @throws Exception 
	 */
	private boolean authenticate(String userName, String password) throws SamlRestClientException{
		if(authenticated)
			return authenticated;
		
		try {
			initSSL();
			/*
			 * Access the root service URI to initiate the SAML flow. Note that
			 * each root URI authenticated via SAML has a different authentication context.
			 */
			HttpURLConnection conn = doGet(host, serviceURI, null, null);
			
			/* 
			 * Follow redirect to IBM Connections Cloud to get correct server to post credentials
			 * This may be IBM Connections Cloud or your on-premise identity provider. 
			 */
			
			int redirCount = 0;
			URL url = null;
			final int MAX_REDIR = 10;
			while(conn.getResponseCode() == 302 && redirCount < MAX_REDIR){
				url = new URL(conn.getHeaderField("Location"));
				conn = doGet(url.getHost(), url.getFile(), null, null);
				redirCount++;
			}
			if(redirCount == MAX_REDIR){
				throw new SamlRestClientException("Redirection loop encountered when locating IDP host");
			}
			
			/* Found the IDP server, post credentials to the form */
			if(conn.getResponseCode() == 200){
				/*
				 * Post credentials to IDP
				 */
				String samlResponse = postToIDP(url, userName, password);
				/*
				 * Post SAML assertion to service provider. 
				 * Successful authentication will return cookie passed on subsequent calls
				 */
				postSAML(samlResponse);
				authenticated = true;
			} 
			else {
					/* 
					 * Anything but a 302 in response means that we aren't being sent back to 
					 * the original endpoint with a SAML assertion. So authentication has failed at this point. 
					 * 
					 */
					logger.debug(getReturnValueAsString(conn));
			}
		} 
		catch (KeyManagementException e) {
			logger.debug(e) ;
			throw new SamlRestClientException(e);
		} 
		catch (NoSuchAlgorithmException e) {
			logger.debug(e) ;
			throw new SamlRestClientException(e);
		} 
		catch (IOException e) {
			logger.debug(e) ;
			throw new SamlRestClientException(e);
		}
		return authenticated;
	}
	/**
	 * Posts credentials to SAML Identity provider. Returns response
	 * containing SAML assertion. This method is specific to IBM WebSEAL.
	 * If your organization uses a different Identity Provider, you will 
	 * need to change this code authenticate with your provider implementation. 
	 * @param userName
	 * @param password
	 * @return
	 * @throws IOException 
	 * @throws UnsupportedEncodingException 
	 * @throws MalformedURLException 
	 * @throws SamlRestClientException 
	 * @throws Exception 
	 */
	private String postToIDP(URL url, String userName, String password) throws MalformedURLException, UnsupportedEncodingException, IOException, SamlRestClientException{
		HttpURLConnection conn = null;
		String samlResponse = null;
		HashMap<String,String> headers = new HashMap<String,String>();
		
		headers.put("Referer", url.toString());
		ArrayList<NameValue> formFields = new ArrayList<NameValue>();
		formFields.add(new NameValue("login-form-type", "pwd"));
		formFields.add(new NameValue("error-code", ""));
		formFields.add(new NameValue("username", userName));
		formFields.add(new NameValue("password", password));
		formFields.add(new NameValue("show_login", "showLoginAgain"));
		
		conn = doPostForm(url.getHost(), "/pkmslogin.form", headers, formFields);
		logger.debug("Coming back from doPostForm().  responseCode = " + conn.getResponseCode()) ;
		/*
		 * Redirect means that authentication succeeded and we are being 
		 * sent back to the service end point. But we don't have the SAML
		 * assertion yet, just the path to get it from the IDP. 
		 */
		if(conn.getResponseCode() == 302){		
			url = new URL(conn.getHeaderField("Location"));
			/* The URL to retrieve the SAML assertion is actually a query parameter of 
			 * the redirect location. So we parse out of the location, URL decode 
			 * and get the SAML assertion. 
			 */
			String query = url.getQuery();
			int idx = query.indexOf("url=");
			String samlPath = null;
			URL samlURL = null;
			if(idx >= 0){
				int pathStart = idx + "url=".length();
				int delim = query.indexOf('&', pathStart);
				int pathEnd = delim == -1 ? query.length() : delim;
				samlPath = query.substring(pathStart, pathEnd);
				samlPath = URLDecoder.decode(samlPath, "UTF-8");
				logger.debug("About to invoke new instance for samlURL.  samlPath = " + samlPath);
				//samlURL = new URL(iSamlPath);
				samlURL = new URL(samlPath);
				/*
				 * Note:  above call is inconsistent (when samlPath = "/pkmslogin.form").  The following is the
				 * observed value of samlPath when it does work
				 * http://apps.na.collabserv.com/sps/idp/saml11/login?SP_PROVIDER_ID=https://api.notes.na.collabserv.com&TARGET=https%3a%2f%2fapi.notes.na.collabserv.com%2fapi%2fadmin
				 */
			}
			if(samlPath != null) {
				/*
				 * Force the protocol to be HTTPS. 
				 */
				logger.debug("About to instantiate url object (samlPath != null");
				url = new URL(PROTOCOL, samlURL.getHost(), samlURL.getFile());
				conn = doGet(url, null);
				samlResponse = getReturnValueAsString(conn);
				logger.debug(samlResponse);
			}
			else 
			{
				/*
				 * At other times, the actual returned location is where the SAML assertion is. 
				 */
				logger.debug("Calling doGet().  samlPath == null") ;
				conn = doGet(url, null);
				samlResponse = getReturnValueAsString(conn);
			} 
		} 
		else {
			 throw new SamlRestClientException("Authentication with identity provider failed: " + conn.getResponseCode());
		}
		return samlResponse;
	}
	/**
	 * Parses the SAML response received from the IDP and posts it
	 * to the service host. If successful, cookie will be returned 
	 * allowing access to the service.
	 * @param samlResponse
	 * @throws MalformedURLException
	 */
	private void postSAML(String samlResponse) throws MalformedURLException{
		ArrayList<NameValue> formValues = new ArrayList<NameValue>(); 
		String formAction = null;
		Pattern p = Pattern.compile("<form(.*)>.*</form>", Pattern.DOTALL);
		Matcher m = p.matcher(samlResponse);
		if(m.find()){
			HashMap<String,String> formAttrs = parseAttributes(m.group(1));
			formAction = formAttrs.get("action");
			String formInnards = null;
			formInnards = m.group(0);
			p = Pattern.compile("(<input)(\\s+[s+(\\w+=\"\\w+\")s+]*.*?)/>", Pattern.DOTALL);
			m = p.matcher(formInnards);
			while(m.find()){
				int groups = m.groupCount();
				if(groups != 2)
					continue;
				String attribList = m.group(2);
				HashMap<String,String> nvPairs = parseAttributes(attribList);
				formValues.add(new NameValue(nvPairs.get("name"), nvPairs.get("value")));
			}
			doPostForm(new URL(formAction).getHost(), "", null, formValues);
		}
	}
	/**
	 * Transform a string of <attr>=<values> into a HashMap
	 * @param attrs
	 * @return
	 */
	private HashMap<String,String> parseAttributes(String attrs){
		Pattern attribPattern = Pattern.compile("\\s*(\\S+)=\"([^>]*?)\"");
		HashMap<String,String> nvPairs = new HashMap<String,String>();
		Matcher attrMatcher = attribPattern.matcher(attrs);
		while(attrMatcher.find()){
			if(attrMatcher.groupCount() != 2)
				break;
			String attrName = attrMatcher.group(1);
			String attrValue = attrMatcher.group(2);
			nvPairs.put(attrName,attrValue);
		}
		return nvPairs;
	}	
	/*
	 * This code should be implemented properly in a production scenario. 	
	 */
	private void initSSL() throws NoSuchAlgorithmException, KeyManagementException{
		SSLContext ctx;
		// Create a trust manager that does not validate certificate chains
	      final TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager()
	      {
//	         @Override
			public java.security.cert.X509Certificate[] getAcceptedIssuers()
	         {
	            return null;
	         }

//	         @Override
			public void checkClientTrusted(final java.security.cert.X509Certificate[] certs, final String authType)
	         {
	            // nothing to check
	         }

//	         @Override
			public void checkServerTrusted(final java.security.cert.X509Certificate[] certs, final String authType)
	         {
	            // nothing to check
	         }
	      } };
		ctx = SSLContext.getInstance("TLS");
		ctx.init(null, trustAllCerts, null);
		SSLContext.setDefault(ctx);	
	}

	private String getReturnValueAsString(HttpURLConnection conn){
		String retval = null;
		try {
			InputStream is = conn.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			StringBuilder sb = new StringBuilder();
			final int bufSize = 10280;
			char buf[] = new char[bufSize];
			
			while(true){
				int count = isr.read(buf, 0, bufSize);			
				if(count == -1)
					break;
				sb.append(buf, 0, count);
				
			}
			retval = sb.toString();
			
		} 
		catch (IOException e) {
			logger.info("IOException caught in getReturnValueAsString()") ;
			logger.debug(e);
		}
		return retval;
	}
	
	/**
	 * Utility method to perform get
	 * @param url
	 * @param headers
	 * @return
	 */
	private HttpsURLConnection doGet(URL url, HashMap<String,String> headers){
		HttpsURLConnection conn = null;
		try {
			conn = (HttpsURLConnection) url.openConnection();
		    conn.setRequestMethod("GET");
		    addCookies(conn);
		    conn.setUseCaches(false);
		    conn.setRequestProperty("Accept-Language", "en");
		    conn.setRequestProperty("User-Agent", "");
		    conn.connect();
		    storeCookies(conn);
		} catch (MalformedURLException e) {
			logger.debug(e);
		} catch (IOException e) {
			logger.debug(e);
		}
		return conn;
	}
	
	/**
	 * Utility method to perform get
	 * @param uri
	 * @param headers
	 * @param queryParams
	 * @return
	 */
	private HttpsURLConnection doGet(String host, String uri, Map<String,String> headers, Map<String, String> queryParams){
		HttpsURLConnection conn = null;
		try {
			URL url = new URL(PROTOCOL, host, uri);
			conn = (HttpsURLConnection) url.openConnection();
		    conn.setRequestMethod("GET");
		    addCookies(conn);
		    conn.setUseCaches(false);
		    conn.setRequestProperty("Accept-Language", "en");
		    conn.setRequestProperty("User-Agent", "");
		    addHeadersToConnection(conn, headers);
		    conn.connect();
		    storeCookies(conn);
		} catch (MalformedURLException e) {
			logger.debug(e);
		} catch (IOException e) {
			logger.debug(e);
		}
		return conn;
	}
	
	/**
	 * Utility method to perform post of application/octet-stream data
	 * @param uri
	 * @param headers
	 * @param queryParams
	 * @return
	 */
	private HttpsURLConnection doPost(String host, String uri, String userId, String passwd, byte[] data){
		HttpsURLConnection conn = null;
		try {
			URL url = new URL(PROTOCOL, host, uri);
			conn = (HttpsURLConnection) url.openConnection();
		    conn.setRequestMethod("POST");
		    addCookies(conn);
		    conn.setUseCaches(false);
		    conn.setRequestProperty("Accept", "application/json");
		    conn.setRequestProperty("Accept-Language", "en");
		    conn.setRequestProperty("User-Agent", "");
		    conn.setRequestProperty("Content-Type", "application/octet-stream");
		    conn.setRequestProperty("Host", host);
		    conn.setRequestProperty("X-HTTP-Query-Email", userId) ;		
		    conn.setRequestProperty("X-HTTP-Query-Password", passwd) ;
		    conn.setRequestProperty("Content-Length", String.valueOf(data.length));
		    conn.setDoOutput(true);
		    conn.getOutputStream().write(data);

		} catch (MalformedURLException e) {
			logger.debug(e);
		} catch (IOException e) {
			logger.info("Caught IOException in doPost()...") ;
			logger.debug(e);
		}
		return conn;
	}
	
	/**
	 * Utility method to perform post
	 * @param uri
	 * @param headers
	 * @param queryParams
	 * @return
	 */
	private HttpsURLConnection doPostForm(String host, String uri, HashMap<String,String> headers, List<NameValue> formData){
		HttpsURLConnection conn = null;
		try {
			URL url = new URL(PROTOCOL, host, uri);
			logger.debug("Aabout to open connection with protocol " + PROTOCOL + ", host " + host + ", uri " + uri );
			conn = (HttpsURLConnection) url.openConnection();
			logger.debug("Connection opened");
		    conn.setRequestMethod("POST");
		    addCookies(conn);
		    conn.setUseCaches(false);
		    conn.setRequestProperty("Accept", "text/html");
		    conn.setRequestProperty("Accept-Language", "en");
		    conn.setRequestProperty("User-Agent", "");
		    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		    conn.setRequestProperty("Host", host);
		    addHeadersToConnection(conn, headers);
		    StringBuilder postContent = new StringBuilder();
		    for(NameValue nv : formData){
		    	if(postContent.length() != 0)
		    		postContent.append('&');
		    	postContent.append(URLEncoder.encode(nv.getName(), "UTF-8"));
		    	postContent.append('=');
		    	postContent.append(URLEncoder.encode(nv.getValue(), "UTF-8"));
		    }
		    byte[] postBytes = postContent.toString().getBytes("UTF-8");
		    
		    conn.setRequestProperty("Content-Length", String.valueOf(postBytes.length));
		    conn.setDoOutput(true);
		    conn.getOutputStream().write(postBytes);
		    storeCookies(conn);
		    
		} catch (MalformedURLException e) {
			logger.debug(e);
		} catch (IOException e) {
			logger.debug(e);
		}
		return conn;
	}
	/**
	 * Utility method to add headers before sending request.
	 * @param conn 
	 * @param headers name value pairs representing HTTP headers
	 */
	private void addHeadersToConnection(HttpURLConnection conn, Map<String, String> headers){
		if(headers == null)
			return;
		for(Map.Entry<String, String> header : headers.entrySet() ){
			conn.setRequestProperty(header.getKey(), header.getValue());
		}
	}
	/**
	 * Pull the Set-Cookie headers out and save the values. 
	 * @param conn URL connection 
	 */
	private void storeCookies(HttpURLConnection conn){
		int idx = 1;
		String key = conn.getHeaderFieldKey(idx);
		Pattern p = Pattern.compile("\\s*(\\S+?)\\s*=[\"]?([^;\"]+)[\"]?\\s*;");
		while(key != null){
			if(SET_COOKIE_HEADER.equalsIgnoreCase(key)){
				String cookie = conn.getHeaderField(idx);
				Matcher m = p.matcher(cookie);
				String name = null;
				String value= null;
				if(m.find()){
					name = m.group(1);
					value = m.group(2);
					cookies.put(name, value);
				} else {
					logger.info("Unable to process Set-Cookie header value: " + cookie);
				}
			}
			idx++;
			key = conn.getHeaderFieldKey(idx);
		}
	}
	/**
	 * Add stored cookies to connection. 
	 * @param conn
	 */
	private void addCookies(HttpURLConnection conn){
		Set<String> keys = cookies.keySet();
		StringBuilder builder = new StringBuilder();
		for(String key:keys){
			String value = cookies.get(key);
			builder.append(key);
			builder.append('=');
			builder.append(value);
			builder.append("; ");
		}
		
		if(builder.length() > 0){
			conn.setRequestProperty(COOKIE_HEADER, builder.toString().trim());
			logger.debug(COOKIE_HEADER + ":" + builder.toString().trim());
		}
		
		
	}
	
	
	
	public class NameValue {
		public String getName() {
			return name;
		}

		public String getValue() {
			return value;
		}

		NameValue(String name, String value) {
			this.name = name;
			this.value = value;
		}
		
		private String name;
		private String value;
	}
	
	static {
		HttpURLConnection.setFollowRedirects(false);
	}
}
