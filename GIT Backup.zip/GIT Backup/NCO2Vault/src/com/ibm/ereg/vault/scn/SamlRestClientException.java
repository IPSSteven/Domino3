package com.ibm.ereg.vault.scn;
/**
 * Thrown when SAML authentication fails 
 *
 * @author ghegfield
 *
 */
public class SamlRestClientException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7963707760660262507L;

	public SamlRestClientException() {
		super();
		
	}

	public SamlRestClientException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		//super(arg0, arg1, arg2, arg3);
	}

	public SamlRestClientException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public SamlRestClientException(String arg0) {
		super(arg0);
	}

	public SamlRestClientException(Throwable arg0) {
		super(arg0);
	}

}
