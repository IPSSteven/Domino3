package com.ibm.ereg.sync;

public class Constants {
	public static final String LOOKUP_VIEW = "People\\IGAIBM";
	public static final String UAR_VIEW = "LN Shortname";
	
}