package com.ibm.ereg.sync;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjDatabase;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import com.ibm.notes.secure.PasswordHandler;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

public class SyncGateway extends NotesThread {
	
	// TODO How to Add a Properties file to my project Explorer
	
	public static void main(String[] args) {
		SyncGateway sg = new SyncGateway();
		sg.start();
	}

	@Override
	public void runNotes() throws NotesException {
		super.runNotes();
		
		Database dbLog ;
		Database dbNab;
		Database dbUAR;
		InputOutputLogger log;
		View vwLookup;
		ViewEntryCollection vecLookup;
		ViewEntry veLookup;
		View vwSearch, vwSearch2;
		PasswordHandler ph;
		
		System.out.println("Test");
		
		//01. Setup Session.
		
		// TODO Figure out how to pull PWD encrypted from Properties file
		String pw = "#############";
		Session s = NotesFactory.createSessionWithFullAccess(pw);
		
		try {
			//02. Get & Setup Log DB
			dbLog = CommonFunctions.getLogDB(s);
			log = new InputOutputLogger(s, dbLog, "Sync Gateway", LogLevel.INFO);
			log.setAgent("that is the title of the log document");
			
			//03. Get NAB DB & Lookup View & EntryCollection
			ConfigObjDatabase cfgNABDB = new ConfigObjDatabase(s, "4>IBM");
			String nabServer = cfgNABDB.getFilePath();
			String nabFilename = cfgNABDB.getFilePath1Rep();
			dbNab =  CommonFunctions.getDatabase(s, nabServer, nabFilename);		
			vwLookup = dbNab.getView(Constants.LOOKUP_VIEW);
			vecLookup = vwLookup.getAllEntries();
			System.out.println("Number of entries = " + vecLookup.getCount());
			
			//04. Get UAR Database & Search View
			ConfigObjDatabase cfgUARDB = new ConfigObjDatabase(s, "9>UAR2");
			String uarServer = cfgUARDB.getServer();
			String uarFilename = cfgUARDB.getFilePath();
			dbUAR = CommonFunctions.getDatabase(s, uarServer, uarFilename);
			// TODO What does the cfgUAR do/for?
			ConfigObjNCOUAR cfgUAR = new ConfigObjNCOUAR(s, log);
			dbUAR = cfgUAR.getDbNCOUAR("IBM");
			vwSearch = cfgUAR.getVwByFullName("IBM");
			vwSearch2 = dbUAR.getView(Constants.UAR_VIEW);
			
			
			//05. Loop through LOOKUP_VIEW, Search UAR_VIEW for Match and process
			veLookup = vecLookup.getFirstEntry();
			Document docLookup = null;
			Document docUARMatch = null;
			ViewEntry veLookup2;
			String lookupKey;
			while (veLookup != null) {
				docLookup = veLookup.getDocument();
				System.out.println("Entry is at position " + veLookup.getPosition('.'));
				lookupKey = docLookup.getItemValueString("Shortname");
				docUARMatch = vwSearch2.getDocumentByKey(lookupKey, true);
				if (docUARMatch == null) {
					// TODO Log UAR Document Not Found Error/Log Entry.
				} else {
					// TODO Process Lookup Document versus UAR - Check Domain & MailSystem - Update UAR Doc
					// TODO Check $File and Password fields in UAR Document
					// TODO If both $File and Password are present update �idFileInValut� in UAR Document to �0�
					// TODO Save/Close the UAR Document using NCOUAR_ITIM encryption key.  See Kevin's Code!!
				}
				veLookup2 = vecLookup.getNextEntry(veLookup);
				veLookup.recycle();
				veLookup = veLookup2;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}