package com.ibm.Ereg2SCN.Loader;

import java.util.Vector;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class GetNabDataThread extends NotesThread {
	private String passWord = null;
	private int iStartAt = -1;
	private int iStackSize = -1;
	private VaultLoaderDataSingleton vlds = null;
	private String DatabaseServer;
	private String Databasefilepath;
	private InputOutputLogger log;
	private Integer ThreadNumber;
	
	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	public int getiStartAt() {
		return iStartAt;
	}

	public void setiStartAt(int iStartAt) {
		this.iStartAt = iStartAt;
	}

	public int getiStackSize() {
		return iStackSize;
	}

	public void setiStackSize(int iStackSize) {
		this.iStackSize = iStackSize;
	}

	public String getDatabaseServer() {
		return DatabaseServer;
	}

	public void setDatabaseServer(String databaseServer) {
		DatabaseServer = databaseServer;
	}

	public String getDatabasefilepath() {
		return Databasefilepath;
	}

	public void setDatabasefilepath(String databasefilepath) {
		Databasefilepath = databasefilepath;
	}

	public InputOutputLogger getLog() {
		return log;
	}

	public void setLog(InputOutputLogger log) {
		this.log = log;
	}

	public Integer getThreadNumber() {
		return ThreadNumber;
	}

	public void setThreadNumber(Integer threadNumber) {
		ThreadNumber = threadNumber;
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		long lstart = System.currentTimeMillis();
		vlds = VaultLoaderDataSingleton.getInstance();
		Session s = NotesFactory.createSessionWithFullAccess(passWord);
		Database dbNab = CommonFunctions.getDatabase(s, DatabaseServer, Databasefilepath);
		View vwByShortname =dbNab.getView("People\\People by ShortName");
		Document docRecycle = null;
		Vector<String> vShortName = null;
		NabDataForVault ndfv;
		int iCount = 0;
		Document docNab = vwByShortname.getNthDocument(iStartAt);
		while (docNab != null && iCount < iStackSize) {
			vShortName = docNab.getItemValue("ShortName");	
			if (vShortName != null && vShortName.size() >0){
				ndfv = new NabDataForVault();
				ndfv.setInternetAddress(docNab.getItemValueString("ShortName"));
				ndfv.setMailSystem(docNab.getItemValueString("MailSystem"));
				ndfv.setOfficePhoneNumber(docNab.getItemValueString("OfficePhoneNumber"));
				vlds.getDomainNabData().put(vShortName.lastElement().toString(), ndfv);
			}
			docRecycle = docNab;
			docNab = vwByShortname.getNextDocument(docNab);
			docRecycle.recycle();
			iCount++;
		}
		
		if (vwByShortname !=null)vwByShortname.recycle();
		if (dbNab != null) {
			dbNab.recycle();
		}
		if (s != null) s.recycle();
		vlds.getThreadSuccessful().put(ThreadNumber, new Boolean(true));
		pln ("****Thread: " + ThreadNumber.toString() + " ended after " + ((System.currentTimeMillis() - lstart)/1000) +
				" sec - " + ((System.currentTimeMillis() - lstart)/60000) + " min****"  );
		log.logActionLevel(LogLevel.INFO,"****Thread: " + ThreadNumber.toString() + " ended after " + ((System.currentTimeMillis() - lstart)/1000) +
				" sec - " + ((System.currentTimeMillis() - lstart)/60000) + " min****");
		
	}
	
	private void pln(String s) {
		System.out.println(s);
	}
	
}
