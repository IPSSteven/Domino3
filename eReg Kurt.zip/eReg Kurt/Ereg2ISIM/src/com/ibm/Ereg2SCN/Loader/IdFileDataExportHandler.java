package com.ibm.Ereg2SCN.Loader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class IdFileDataExportHandler {
	
	public boolean save2MediatorFolder(String Domain, String Shortname, String uid,String pw,File f, String docUnid  ) {
		try {
			String filepath;
			// read the id file in binary array
			FileInputStream fis = new FileInputStream(f);
			byte bs[] = new byte[(int)f.length()] ;
			fis.read(bs);
			fis.close();
			
			// cerate a new class and fill the content
			IdFileData ifd = new IdFileData();
			ifd.setDomain(Domain);
			ifd.setShortname(Shortname);
			ifd.setPassword(pw);
			ifd.setIdFileBinary(bs);
			ifd.setUid(uid);
			
			//serialize file name is combination of docunind of the uar document and the uid
			filepath = VaultLoaderDataSingleton.OUTPUTDIR +uid+"_" + docUnid+ ".txt";
			FileOutputStream fos = new FileOutputStream(new File(filepath));
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(ifd);
			oos.close();
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
