package com.ibm.Ereg2SCN.Loader;

import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjMailDomainServer;
import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.config.ConfigObjSCNAPI;
import com.ibm.ereg.config.ConfigObjUploadSCN;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class LoadFromNCOUAR2SCN_New extends NotesThread {
	private final boolean DEBUG = false;
	private  String[] domains;
	private String stpw;
	private String tmpDir = "C:\\ereg\\temp\\";
	private String pw;
	private Database dbLog;
	private InputOutputLogger log;
	private ConfigObjNCOUAR cfgNcouar;
	private Session session;
	private HashMap<String, String> MailDomainServer;
	private boolean bFullUpload;
	private boolean bUploadMailSystem;


	public LoadFromNCOUAR2SCN_New() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] argv){
		LoadFromNCOUAR2SCN_New ln = new LoadFromNCOUAR2SCN_New();
		ln.stpw = argv[0];
		ln.start();
	}

	public LoadFromNCOUAR2SCN_New(Runnable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		session = NotesFactory.createSessionWithFullAccess(stpw);
		
		processNew(session);

	}

	public void processNew(Session s) {
		if (this.session == null) session = s; 
		// get the logger
		try {
			dbLog = CommonFunctions.getLogDB(session);
			log = new InputOutputLogger(session, dbLog, "Load ids from NCOUAR to vault", LogLevel.FINEST);
			log.logActionLevel(LogLevel.INFO, "Start Loader try to gather config ");
			if (getConfig()) {
				log.logActionLevel(LogLevel.INFO, "Configuration found ok ");
			}else{
				log.logActionLevel(LogLevel.SEVERE, "Error while try to get configuration - exit");
				LogDocStatus lds = new LogDocStatus(log.getDocLog());
				log.closeLog(lds);
				return;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}

		if(DEBUG) {
			domains = new String[1];
			domains[0] = "IBMLT";
		}
		for(String stDom:domains){
			// only load the Nab Data for full upload. partial upload only take data from NCOUAR
			if (bFullUpload && !getNabDataMultiThread(stDom)){
				log.logActionLevel(LogLevel.SEVERE, "Error while get the NAB data for " + stDom);
				continue;
			}

			processUARMultiThread(stDom);

		}	

		log.logActionLevel(LogLevel.INFO, "******************************************All done***********************");
		LogDocStatus lds = new LogDocStatus(log.getDocLog());
		lds.setOKDone();
		log.closeLog(lds);

	}

	private boolean getNabDataMultiThread (String stDom) {

		// get the nab of the domain
		String Server = MailDomainServer.get(stDom);
		Database dbEDC = CommonFunctions.getDatabase(session, Server, "names.nsf");
		int iEntryNum = 0;
		int iThreads;
		VaultLoaderDataSingleton vlds = null;
		int iStartAt;
		Integer ThreadNumber = null;

		try {
			View vwByShortname =dbEDC.getView("People\\People by ShortName");
			if (vwByShortname != null)iEntryNum = vwByShortname.getAllEntries().getCount();
			if (vwByShortname != null) vwByShortname.recycle();

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// get Number of threads
		if(iEntryNum == 0) {
			log.logActionLevel(LogLevel.INFO, " Found " + iEntryNum + " ids in NAB -> nothing to do return");
			return(false);
		}else {
			vlds = VaultLoaderDataSingleton.getInstance();
			vlds.clearSuccessTread();
			iThreads = (int)Math.ceil((double)iEntryNum/VaultLoaderDataSingleton.HEAPSIZE_NAB);		
			log.logActionLevel(LogLevel.INFO, " Found " + iEntryNum + " ids in NAB separated in "+  iThreads + " threads");
		}



		try {
			// create and start the Threads
			GetNabDataThread[] ndts = new GetNabDataThread[iThreads];
			for(int i = 0;i<iThreads; i++){
				ndts[i] = new GetNabDataThread();
				ndts[i].setDatabaseServer(dbEDC.getServer());
				ndts[i].setDatabasefilepath(dbEDC.getFilePath());
				ndts[i].setiStackSize(VaultLoaderDataSingleton.HEAPSIZE_NAB);
				iStartAt = i*VaultLoaderDataSingleton.HEAPSIZE_NAB +1;
				ndts[i].setiStartAt(iStartAt);
				ndts[i].setLog(log);
				ndts[i].setPassWord(pw);
				ThreadNumber = new Integer(i);
				ndts[i].setThreadNumber(ThreadNumber);
				vlds.getThreadSuccessful().put(ThreadNumber, new Boolean(false));
			}

			if (dbEDC != null) dbEDC.recycle();
			
			ExecutorService executorServ = Executors.newFixedThreadPool(VaultLoaderDataSingleton.THREADMAX);

			for(int i = 0; i< iThreads; i++){
				executorServ.execute(ndts[i]);
			}


			executorServ.shutdown(); // means not new tasks are accepted anymore
			if(executorServ != null){
				executorServ.awaitTermination(180, TimeUnit.MINUTES); // wait 180 minutes .. this should be sufficient

			}
			return (true);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return (false);
		}	
	}


	private boolean getConfig()	{

		try {
			String sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);
			ConfigObjMaschineProfile mp = new ConfigObjMaschineProfile(session, AllConstants.TYPE_MACHINEPROFILE + ">" + sMachineKey, log);
			tmpDir = mp.getTempDir()[0];

			cfgNcouar = new ConfigObjNCOUAR(session, log);
			View vwNCOUARITIMEXP = cfgNcouar.getVwITIMEXPORT(AllConstants.EREG_NOTESID_DOMAIN);
			Document docNCOUAR =vwNCOUARITIMEXP.getDocumentByKey(AllConstants.EREG_NOTESID_DOMAIN.toUpperCase()+AllConstants.EREG_NOTESID_SHORTNAME.toUpperCase());
			pw = docNCOUAR.getItemValueString("Password");
			if(DEBUG)pw = "go2bechtle.";
			docNCOUAR.recycle();

			ConfigObjMailDomainServer cfgMailMailDomainServer = new ConfigObjMailDomainServer(session);
			this.MailDomainServer = cfgMailMailDomainServer.getNabServers_domain();
			ConfigObjUploadSCN UlScn = new ConfigObjUploadSCN(session,"12>UpLoadSCN");
			domains = UlScn.getDomains()[0].split(",");
			bFullUpload = UlScn.getFullUpload();
			
			bUploadMailSystem = UlScn.getUploadMailSystem2UAR();
			VaultLoaderDataSingleton.OUTPUTDIR = UlScn.getTemporyDir4Uload()[0];
			VaultLoaderDataSingleton.HEAPSIZE_NAB = UlScn.getHeapSizeNAB();
			VaultLoaderDataSingleton.HEAPSIZE_UAR = UlScn.getHeapSizeUAR();
			VaultLoaderDataSingleton.THREADMAX =UlScn.getMaxThreads();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage());
			return false;
		}

	}


	private boolean processUARMultiThread(String Domain){
		//View vwSNView;
		String stSCNAcount = null;
		String stSCNPw = null;
		String stNCOUARServer = null;
		String stNCOUARFilePath = null;
		String stNCOUARView = null;
		Integer ThreadNumber;
		//View vwUAR = cfgNcouar.getVwByFullName(Domain);
		View vwUAR = null;
		int iEntryNum = 0;
		int iThreads = 0;
		int iStartAt = 0;
		VaultLoaderDataSingleton vlds = null;

		if(bFullUpload) {
			vwUAR = cfgNcouar.getVwByShortName(Domain);
		}else {
			vwUAR = cfgNcouar.getVwNoIdfileInVault(Domain);
		}
		

		try {
			iEntryNum = vwUAR.getEntryCount();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// get Number of threads
		if(iEntryNum == 0) {
			log.logActionLevel(LogLevel.INFO, " Found " + iEntryNum + " ids in UAR -> nothing to do return");
			return(false);
		}else {
			vlds = VaultLoaderDataSingleton.getInstance();
			vlds.clearSuccessTread();
			iThreads = (int)Math.ceil((double)iEntryNum/VaultLoaderDataSingleton.HEAPSIZE_UAR);		
			log.logActionLevel(LogLevel.INFO, " Found " + iEntryNum + " ids in UAR separated in "+  iThreads + " threads HeapSize = " + VaultLoaderDataSingleton.HEAPSIZE_UAR);
		} 

		try {
			ConfigObjSCNAPI confSCN = new ConfigObjSCNAPI(session, "12>SCNAPI", log);
			stSCNAcount = confSCN.getSCNAccount();
			stSCNPw = confSCN.getSCNAccountPassword();
			//ConfigObjNCOUAR cfgNcouar = new ConfigObjNCOUAR(log.getSess(), log);
			//if(bFullUpload) {
			//	vwSNView = cfgNcouar.getVwByShortName(Domain);
			//}else {
			//	vwSNView = cfgNcouar.getVwNoIdfileInVault(Domain);
			//}
			//vwUAR = cfgNcouar.getVwByShortName(Domain);
			Database dbNcouar = vwUAR.getParent();
			stNCOUARServer = dbNcouar.getServer();
			stNCOUARFilePath = dbNcouar.getFilePath();
			stNCOUARView = vwUAR.getName();
			vwUAR.recycle();
			dbNcouar.recycle();

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Error during reading the configuration");		 
			e1.printStackTrace();
			return(false);
		}
		if (DEBUG) iThreads = 1;
		ProcessUarThread[] puart = new ProcessUarThread[iThreads];
 
		
		for (int i = 0; i< iThreads; i++) {
			puart[i] = new ProcessUarThread();

			puart[i].setScnApiAccount(stSCNAcount);
			puart[i].setScnAPipassword(stSCNPw);
			puart[i].setDatabaseServer(stNCOUARServer);
			puart[i].setDatabaseFilePath(stNCOUARFilePath);
			puart[i].setTheView(stNCOUARView );

			puart[i].setPassWord4Session(pw);
			iStartAt = i*VaultLoaderDataSingleton.HEAPSIZE_UAR + 1;
			puart[i].setiStartAt(iStartAt);
			puart[i].setiStackSize(VaultLoaderDataSingleton.HEAPSIZE_UAR);
			//Document docLog = log.getDocLog();
			puart[i].setDomain(Domain);
			/*try {
				puart[i].setLogUnid(docLog.getUniversalID());
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
			puart[i].setLog(log);
			puart[i].setbFullUpload(bFullUpload);
			puart[i].setTmpDir(tmpDir);
			puart[i].setbUploadMailSystem(bUploadMailSystem);
			ThreadNumber = new Integer(i);

			puart[i].setThreadNumber(ThreadNumber);
			vlds.getThreadSuccessful().put(ThreadNumber, new Boolean(false));
		}

		ExecutorService executorServ = Executors.newFixedThreadPool(VaultLoaderDataSingleton.THREADMAX);

		iThreads = 1;
		for(int i = 0; i< iThreads; i++){
			executorServ.execute(puart[i]);
		}


		executorServ.shutdown(); // means not new tasks are accepted anymore
		if(executorServ != null){
			try {
				executorServ.awaitTermination(180, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			} // wait 180 minutes .. this should be sufficient

		}


		return true;

	}
	
	

}
