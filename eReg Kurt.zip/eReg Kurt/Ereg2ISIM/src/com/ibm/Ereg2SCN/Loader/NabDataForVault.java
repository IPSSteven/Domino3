package com.ibm.Ereg2SCN.Loader;

public class NabDataForVault {

	String internetAddress;
	String MailSystem;
	String OfficePhoneNumber;
	
	
	public NabDataForVault() {
		// TODO Auto-generated constructor stub
	}


	public String getInternetAddress() {
		return internetAddress;
	}


	public void setInternetAddress(String internetAddress) {
		this.internetAddress = internetAddress;
	}


	public String getMailSystem() {
		return MailSystem;
	}


	public void setMailSystem(String mailSystem) {
		MailSystem = mailSystem;
	}

	public boolean isValid() {
		return (!internetAddress.isEmpty() && !MailSystem.isEmpty());
	}


	public String getOfficePhoneNumber() {
		return OfficePhoneNumber;
	}


	public void setOfficePhoneNumber(String officePhoneNumber) {
		OfficePhoneNumber = officePhoneNumber;
	}

	
}
