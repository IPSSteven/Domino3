package com.ibm.Ereg2SCN.Loader;

import java.util.HashMap;
import java.util.TreeMap;

public class VaultLoaderDataSingleton {
	
	public static  int HEAPSIZE_NAB = 1000;
	//public static int HEAPSIZE_UAR = 1000;
	public static  int HEAPSIZE_UAR = 200000;
	public static int THREADMAX = 24;
	//public static final String OUTPUTDIR = "E:\\pending\\uploadGateway\\";
	public static  String OUTPUTDIR;
	
	private static VaultLoaderDataSingleton vlds = null;
	
	private String eregPW;
	
	private HashMap<String,NabDataForVault> DomainNabData = new HashMap<String, NabDataForVault>();
	private TreeMap<Integer, Boolean> ThreadSuccessful = new TreeMap<Integer, Boolean>();
	
	private int iUpload2VaultSuccessFul= 0;
	private int iUpload2VaultNotSuccessFul = 0;
	private int iUpload2VaultGWSuccessFul = 0;
	private int iUpload2VaultGWNotSuccessFul = 0;
	
	
	private VaultLoaderDataSingleton() {
		// TODO Auto-generated constructor stub
	}

	public static VaultLoaderDataSingleton getInstance() {

		if (vlds == null) {
			synchronized (VaultLoaderDataSingleton.class) {
				if (vlds == null) {

					vlds = new VaultLoaderDataSingleton();
				}

			}
		}
		return vlds;
	}

	public HashMap<String, NabDataForVault> getDomainNabData() {
		return DomainNabData;
	}

	public void setDomainNabData(HashMap<String, NabDataForVault> domainNabData) {
		DomainNabData = domainNabData;
	}

	public String getEregPW() {
		return eregPW;
	}

	public void setEregPW(String eregPW) {
		this.eregPW = eregPW;
	}

	public TreeMap<Integer, Boolean> getThreadSuccessful() {
		return ThreadSuccessful;
	}

	public void setThreadSuccessful(TreeMap<Integer, Boolean> threadSuccessful) {
		ThreadSuccessful = threadSuccessful;
	}

	public void clearSuccessTread(){
		ThreadSuccessful = new TreeMap<Integer, Boolean>();
	}

	public void  addUpload2VaultSuccessFul(int icount2Add) {
		synchronized (VaultLoaderDataSingleton.class) {
			iUpload2VaultSuccessFul =+ icount2Add;
			
		}
		
	}
	public void  addUpload2VaultNotSuccessFul(int icount2Add) {
		synchronized (VaultLoaderDataSingleton.class) {
			iUpload2VaultNotSuccessFul =+ icount2Add;
			
			
		}
		
	}
	
	public void  addUpload2VaultGWSuccessFul(int icount2Add) {
		synchronized (VaultLoaderDataSingleton.class) {
			iUpload2VaultGWSuccessFul =+ icount2Add;
			
		}
		
	}
	public void  addUpload2VaultGWNotSuccessFul(int icount2Add) {
		synchronized (VaultLoaderDataSingleton.class) {
			iUpload2VaultGWNotSuccessFul =+ icount2Add;
			
			
		}
		
	}

	public int getiUpload2VaultSuccessFul() {
		return iUpload2VaultSuccessFul;
	}

	public int getiUpload2VaultNotSuccessFul() {
		return iUpload2VaultNotSuccessFul;
	}

	public int getiUpload2VaultGWSuccessFul() {
		return iUpload2VaultGWSuccessFul;
	}

	public int getiUpload2VaultGWNotSuccessFul() {
		return iUpload2VaultGWNotSuccessFul;
	}
	
	
	
	
}
