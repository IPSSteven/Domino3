package com.ibm.ereg.common;

import java.util.Calendar;
import java.util.GregorianCalendar;

import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
//import lotus.domino.NotesException;
import lotus.domino.Session;

import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;

import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.constants.AllConstants;
/**
 * 
 * @author Kurt Raiser
 *
 */
public class CommonFunctions  extends CommonFunctionGeneral{
	private static boolean OPEN_LOC_REPLICA = false;
	public static Session getNewSession(String pw){
		Session s = null;
		try {
			s = NotesFactory.createSessionWithFullAccess(pw);

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return s;
	}

	public static String arrayToString(String [] stIn){
		StringBuilder res = new StringBuilder();
		for (String s : stIn){
			res.append(s);
		}
		return res.toString();
	}


	private static GregorianCalendar  calNow = null;


	public static Database getDatabase(Session sess, String stServer, String stFilePath) {
		Database dbReturn = null;
		Database dbRetLocal = null;
		String stReplicID;
		try {
			dbReturn = sess.getDatabase(stServer, stFilePath);

			if (!dbReturn.isOpen()) {
				if (!dbReturn.open()) {
					return null;
				}
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Error  while try to open database server = " + stServer + " filepath=" + stFilePath);
			e.printStackTrace();
		}
		if (OPEN_LOC_REPLICA) {
			try {
				stReplicID = dbReturn.getReplicaID();
				dbRetLocal = sess.getDatabase(null, null);
				dbRetLocal.openByReplicaID("", stReplicID);
				if(dbRetLocal.isOpen()) {
					dbRetLocal.replicate(dbReturn.getServer());
					dbReturn.recycle();
					return dbRetLocal;
				}
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return dbReturn;
	}

	@SuppressWarnings("unchecked")
	public static Object getLastItemEntry(Document doc, String stEntryName) {
		Vector<String> vecEntry;
		//String FullName = "";
		int iLen = 0;
		try {
			vecEntry= doc.getItemValue(stEntryName);
			iLen = vecEntry.size();
			if (iLen == 0)
				return "";
			else
				return vecEntry.elementAt(iLen - 1);
			//FullName = doc.getItemValueString("FullName");

		} catch (ArrayIndexOutOfBoundsException ae) {
			//System.out.print("Fullname " + FullName);
			//System.out.println ("Length " + iLen);
			ae.printStackTrace();
			return null;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}


	@SuppressWarnings("unchecked")
	public static Object getFirstItemEntry(Document doc, String stEntryName) {
		Vector<String> vecEntry;
		try {
			//System.out.println(stEntryName);
			if (doc.hasItem(stEntryName)){
				vecEntry = doc.getItemValue(stEntryName);
				return vecEntry.elementAt(0);
			}else{
				return "";
			}
		}catch(ArrayIndexOutOfBoundsException aie){
			return "";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(stEntryName);
			e.printStackTrace();
			return null;
		}
	}
	public static String addLeadingZeros (String stToAdd, int ilen){
		StringBuffer stbZeros = new StringBuffer("");
		if (ilen <= stToAdd.length()){
			return stToAdd;
		}else{
			int iDiff = ilen - stToAdd.length();
			for ( int i = 0; i< iDiff; i++){
				stbZeros.append('0');
			}
			return stbZeros + stToAdd;
		}
	}

	static public Database getLogDB(Session session) throws Exception {

		String stServer;
		String stFileP;
		String sMachineKey;
		Database dbLog;
		try {
			sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);
			//showenv();
			ConfigObjMaschineProfile mp = new ConfigObjMaschineProfile(session, "1>" + sMachineKey);
			String[] logDb = mp.getLogDB();
			if (logDb.length == 2) {
				stServer = logDb[0];
				stFileP = logDb[1];
			} else if (logDb.length == 1) {
				stServer = "";
				stFileP = logDb[0];
			} else {
				throw new Exception("Configuration for Log DB not found");
			}
			//CommonFunctions cf = new CommonFunctions(session);
			dbLog = CommonFunctions.getDatabase(session, stServer, stFileP);
			return dbLog;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	public static String getYYYYMMDD(DateTime dt){
		if(dt == null){
			return "";
		}else{
			if (calNow == null) calNow = new GregorianCalendar();
			try {
				calNow.setTime(dt.toJavaDate());
				String stRunDateString = Integer.toString(calNow.get(Calendar.YEAR))+
						CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.MONTH)+1),2) + 
						CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.DATE)),2) +
						CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.HOUR_OF_DAY)),2) +
						CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.MINUTE)),2)+
						CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.SECOND)),2);
				return stRunDateString;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "";
			}
		}

	}
	public static String getNameAbbrivate(Session s, String stName){
		String strResult = "";
		Name nName;
		try {
			nName = s.createName(stName);
			strResult= nName.getAbbreviated();
			nName.recycle();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			strResult = stName;
			e.printStackTrace();
		}

		return strResult;
	}

	public static boolean isNumeric(String s){
		if(s == null || s.length() == 0)return false;
		for (int i = 0; i < s.length(); i++){
			if(! Character.isDigit(s.charAt(i))){
				return false;
			}
		}
		return true;
	}

	public static String getActDateRecon(){
		if (calNow == null) calNow = new GregorianCalendar();
		calNow.setTimeInMillis(System.currentTimeMillis());
		String stRunDateString = Integer.toString(calNow.get(Calendar.YEAR))+
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.MONTH)+1),2) + 
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.DATE)),2) +
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.HOUR_OF_DAY)),2) +
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.MINUTE)),2)+
				CommonFunctions.addLeadingZeros(Integer.toString(calNow.get(Calendar.SECOND)),2);
		return stRunDateString;

	}

	public static DateTime getNextStart(Session s, String Time2Delay, DateTime dtelastStart) {
		String [] dateTags = {"ye", "mo", "mi", "da", "ho"}; 
		int idx = 0;
		int iNumber = 0;
		DateTime dteNow = null;
		String TagFound = null;
		boolean bloop;
		int iDiff = 0;


		try {
			dteNow = s.createDateTime("Today");
			dteNow.setNow();
			if(Time2Delay== null || Time2Delay.length() < 3) {
				return null;
			}

			// try to find the tag
			for (String sTag : dateTags) {
				idx = Time2Delay.toLowerCase().indexOf(sTag);
				if(idx>0) {
					iNumber = Integer.parseInt(Time2Delay.substring(0, idx).trim());
					TagFound = sTag;
					break;
				}	
			}

			// if nothing is found set default to 15 min
			if (TagFound == null)  TagFound = "mi";
			if (iNumber == 0) iNumber = 15;

			bloop = true;
			do {
				if (TagFound.equals("ye"))dtelastStart.adjustYear(iNumber);
				if (TagFound.equals("mo"))dtelastStart.adjustMonth(iNumber);
				if (TagFound.equals("da"))dtelastStart.adjustDay(iNumber);
				if (TagFound.equals("mi"))dtelastStart.adjustMinute(iNumber);
				iDiff = dtelastStart.timeDifference(dteNow);
				System.out.println(dtelastStart.getLocalTime() + "-" + dteNow.getLocalTime() + "-" + iDiff);
				if(iDiff > 0) bloop =false;

			}while (bloop);




		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			dtelastStart = null;
		}

		if (dteNow != null) {
			try {
				dteNow.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return dtelastStart;







	}



}
