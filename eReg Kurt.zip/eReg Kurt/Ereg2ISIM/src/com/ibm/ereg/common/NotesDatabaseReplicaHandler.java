package com.ibm.ereg.common;

import java.io.FileNotFoundException;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.Session;

public class NotesDatabaseReplicaHandler {
	private final String DB_NOT_FOUND = "Notes Database con not be  found/opened";
	private final String SESSION_NULL = "Session is null";
	private Session s;
	private Database dbSource = null;
	private Database dbReplica = null;
	

	public NotesDatabaseReplicaHandler(Session sess, String SourceServer, String SourcefilePath) throws Exception {
		dbSource = CommonFunctions.getDatabase(sess, SourceServer,  SourcefilePath);
		if(dbSource == null) throw new FileNotFoundException( DB_NOT_FOUND);
		if(sess == null) throw new Exception(SESSION_NULL);
		s = sess;

	}
	public NotesDatabaseReplicaHandler(Session sess, Database dbS) throws Exception {
		if (dbS == null)throw new FileNotFoundException( DB_NOT_FOUND);
		if(sess == null) throw new Exception(SESSION_NULL);
		s = sess;
		dbSource = dbS;
	}
	
	private Database getReplica (String serverReplica, String stFilepathReplica, boolean createIfNotExists) {
		boolean bSuccess;
		String sServer = serverReplica == null ? "": serverReplica;
		try {
			String stReplicaID = dbSource.getReplicaID();
			dbReplica = s.getDatabase(null, null);
			bSuccess = dbReplica.openByReplicaID(sServer, stReplicaID);
			if(bSuccess)pln("opened replic with id " + stReplicaID + " sucessful");
			else pln(" Not opened replic with id " + stReplicaID + " sucessful");
			
			
			if(bSuccess) {
				if (sServer.isEmpty() && stFilepathReplica != null) {
					pln("Return local replica");
					return dbReplica; /// local replica	
				}
				if(!sServer.isEmpty() && stFilepathReplica != null && dbReplica.getServer().equals(sServer) && dbReplica.getFilePath().equals(stFilepathReplica)) {
					pln("Return  replica on server");
					return dbReplica; // get the replica on an other server
				}
			}
			
			if (createIfNotExists) {
				pln("Try to create a new replica");
				dbReplica = dbSource.createReplica(sServer, stFilepathReplica);
			}
			
			return dbReplica;
			
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		
	}
	
	public Database getLocalReplica(boolean createIfNotExists) {
		return getReplica(null,null,createIfNotExists);
	}
	
	public Database getLocalReDatabase() {
		return getReplica(null, null, false);
	}
	
	public Database getLocalReplicaAndReplicate(boolean createIfNotExists, String LocalFilePath) {
		Database dbReturn = getReplica(null,LocalFilePath,createIfNotExists);
		String Server;
		try {
			Server = dbSource.getServer();
			pln("replicate ..... ");
			dbReturn.replicate(Server);
			return dbReturn;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public Database getLocalReplicaAndReplicate(boolean createIfNotExists) {
		 return getLocalReplicaAndReplicate(createIfNotExists,null);
	}
	
	public Database getLocalReplicaAndReplicate() {
		return getLocalReplicaAndReplicate(false);
	}
	
	private void pln(String s) {
		System.out.println(s);
	}

}
