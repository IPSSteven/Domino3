package com.ibm.ereg.common;

public class UserNameCheck {
	private final String reMask = "[\\x41-\\x5A\\x61-\\x7A\\x30-\\x39\\x27\\x20]*$" ;

	public boolean isValidName(String name) {
		boolean rtnVal = false ;
		
		rtnVal = name.matches(reMask) ;
		return rtnVal ;
	}
	
	public String getReMask() {
		return reMask;
	}
	
	
}
