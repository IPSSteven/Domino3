package com.ibm.ereg.config;

import java.util.Iterator;
import java.util.Vector;
import lotus.domino.Session;
import com.ibm.ereg.constants.AllConstants;


public class ConfigNoReuseMasterDatabase extends ConfigObj {

	private String stServer;
	private String stFilePath;
	private String stReplicServer;
	private String stReplicFilePath;

	
	public String getStServer() {
		return stServer;
	}



	public void setStServer(String stServer) {
		this.stServer = stServer;
	}



	public String getStFilePath() {
		return stFilePath;
	}



	public void setStFilePath(String stFilePath) {
		this.stFilePath = stFilePath;
	}



	public String getStReplicServer() {
		return stReplicServer;
	}



	public void setStReplicServer(String stReplicServer) {
		this.stReplicServer = stReplicServer;
	}



	public String getStReplicFilePath() {
		return stReplicFilePath;
	}



	public void setStReplicFilePath(String stPepFilePath) {
		this.stReplicFilePath = stPepFilePath;
	}



	public ConfigNoReuseMasterDatabase(Session sess) throws Exception {
		super(sess);
		// TODO Auto-generated constructor stub
		super.st_type = AllConstants.NOTES_NOREUSE_MASTERDATABASE;
		if (!getConfigDocument()) {
			throw new Exception("Config Document not found->" +super.st_type);
		}
		Vector<String> vecV1 = super.docConfig.getItemValue("V1");
		Vector<String> vecV2 = super.docConfig.getItemValue("V2");
		int i = 0;
		
		Iterator<String> it = vecV1.iterator();
		while(it.hasNext()){
			if (i == 0){
				stServer = it.next();
			}else{
				stFilePath = it.next();
			}	
			i++;
		}
		
		i = 0;
		it = vecV2.iterator();
		while(it.hasNext()){
			if (i == 0){
				stReplicServer = it.next();
			}else{
				stReplicFilePath = it.next();
			}	
			i++;
		}
		
	}

	

}
