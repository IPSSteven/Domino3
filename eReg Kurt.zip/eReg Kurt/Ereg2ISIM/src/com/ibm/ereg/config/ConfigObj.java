package com.ibm.ereg.config;


import lotus.domino.NotesException;
import lotus.domino.Session;

import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.LogLevel;

//import com.ibm.ereg.common.*;

public class ConfigObj extends ConfigObjBase {
	//Session session = null;
	protected AbstractLogger Log = null;

	public ConfigObj(Session sess, String stType, AbstractLogger logger)throws Exception {
		super(sess, stType);
		Log = logger;
		if (!getConfigDocument()) {
			logger.logActionLevel(LogLevel.SEVERE, "Configuration not found -> " + stType );
			throw new Exception("Config Document not found ->"+ stType);
		}

	}
	public ConfigObj(Session sess)throws Exception{
		super(sess);
	}

	public ConfigObj(Session sess, String stType)throws Exception {
		super(sess, stType);

		if (!getConfigDocument()) {
			throw new Exception("Config Document not found->" + stType +" on db = "+ vwConfig.getParent().getFilePath()+ "/" +
					vwConfig.getParent().getFileName() + " Server=" + vwConfig.getParent().getServer()  );
		}

	}

	protected boolean getConfigDocument() {

		try {
			docConfig = vwConfig.getDocumentByKey(st_type);
			if (docConfig == null)
				return false;
			else
				return true;

		} catch (NotesException e) {
			if (Log != null){
				Log.logActionLevel(LogLevel.SEVERE,
						"Error +++ Configuration document not found for " + st_type);
			}
			e.printStackTrace();
			return false;
		}
	}
	
	

}
