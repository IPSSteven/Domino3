package com.ibm.ereg.config;

import lotus.domino.Document;
import lotus.domino.Session;

public class ConfigObjCommon extends ConfigObj {

	public ConfigObjCommon(Session sess, String stType) throws Exception {
		super(sess, stType);
		// TODO Auto-generated constructor stub
	}
	public Document getConfigurationDoc() {
		return this.docConfig;
	}

}
