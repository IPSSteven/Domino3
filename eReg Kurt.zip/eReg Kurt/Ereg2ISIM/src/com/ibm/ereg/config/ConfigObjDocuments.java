package com.ibm.ereg.config;

import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.Session;

public class ConfigObjDocuments extends ConfigObjBase {
	protected AbstractLogger Log = null;

	public ConfigObjDocuments(Session sess, String stType) throws Exception {
		super(sess, stType);
		// TODO Auto-generated constructor stub
		if (!getConfigDocument()) {
			throw new Exception("Error while init of class ConfigDocuments");
		}
	}

	private DocumentCollection allConfigDocuments;
	
	@Override
	

	protected boolean getConfigDocument() {

		try {
			allConfigDocuments= vwConfig.getAllDocumentsByKey(st_type,false);
			if (allConfigDocuments.getCount() >0) {
				return true;
			}else {
				if (Log != null) {
					Log.logActionLevel(LogLevel.SEVERE,
							"Error +++ Configuration documents not found");
				}
				return false;
			}

		} catch (NotesException e) {
			if (Log != null){
				Log.logActionLevel(LogLevel.SEVERE,
						"Error +++ Configuration document not found");
			}
			e.printStackTrace();
			return false;
		}
	}

	public DocumentCollection getAllConfigDocuments() {
		return allConfigDocuments;
	}
	
	
	
	
}
