package com.ibm.ereg.config;

import lotus.domino.Session;

import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.InputOutputLogger;

public class ConfigObjMailDomain extends ConfigObj {
	public ConfigObjMailDomain(Session sess, String stType, InputOutputLogger logger)
			throws Exception {
		super(sess, stType, logger);
		// TODO Auto-generated constructor stub
	}
	public ConfigObjMailDomain(Session sess, String stType, AbstractLogger logger)
			throws Exception {
		super(sess, stType, logger);
		// TODO Auto-generated constructor stub
	}

	public String[] getServer() throws Exception {
		return (getValue("V1"));
	}

	public String[] getReplic() throws Exception {
		return (getValue("V2"));
	}

	public String[] getInternetDomain() throws Exception{
		return (getValue("V3"));
	}

	public String[] getNumberOfTaskid()throws Exception {
		return (getValue("V4"));
	}

	public String[] getNumerofPositionId() throws Exception{
		return (getValue("V5"));
	}

	public String[] getNumberOfOrgUnit() throws Exception{
		return (getValue("V6"));
	}

	public String[] getMailSizeQuota() throws Exception{
		return (getValue("V7"));
	}

	public String[] getACLofMailFile()throws Exception {
		return (getValue("V8"));
	}

}
