package com.ibm.ereg.config;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import com.ibm.ereg.logger.AbstractLogger;

import lotus.domino.Session;

public class ConfigObjMailSystem extends ConfigObj {
	private HashMap<String,String> NotesMailSystem = null;
	private HashMap<String,String> ReconcileMailSystem = null;
	//private HashMap<String,String> ReconcileMailDomainReplacement = null;


	public ConfigObjMailSystem(Session sess, String stType, AbstractLogger logger) throws Exception {
		super(sess, stType, logger);
		// TODO Auto-generated constructor stub

	}

	public HashMap<String, String> getReconcileMailSystem() throws Exception {
		if (ReconcileMailSystem == null) loadReconcileMailSystem();
		return ReconcileMailSystem;
	}


	public HashMap<String, String> getNotesMailSystem() throws Exception {
		if (NotesMailSystem == null)  loadNotesMailSystem();
		return NotesMailSystem;
	}

	
	

/*	public HashMap<String, String> getReconcileMailDomainReplacement() throws Exception {
		if (ReconcileMailDomainReplacement == null)  loadReconcileMailReplacement();
		return ReconcileMailDomainReplacement;
	}
*/
	private void loadNotesMailSystem() throws Exception{
		this.NotesMailSystem = new HashMap<String, String>();
		String[] dummy = null;
		String MailSys = this.getValue("V1")[0];
		Vector vMailS= this.session.evaluate(MailSys);
		Iterator<String> it = vMailS.iterator();
		while(it.hasNext()){
			MailSys = it.next();
			dummy = MailSys.split("\\|");
			if (dummy.length == 2){
				this.NotesMailSystem.put(dummy[0], dummy[1]);
				this.NotesMailSystem.put(dummy[1], dummy[0]);
			}
		}
	}

	private void loadReconcileMailSystem() throws Exception{
		this.ReconcileMailSystem = new HashMap<String, String>();
		String[] dummy = null;
		String MailSys = this.getValue("V2")[0];
		Vector vMailS= this.session.evaluate(MailSys);
		Iterator<String> it = vMailS.iterator();
		while(it.hasNext()){
			MailSys = it.next();
			dummy = MailSys.split("\\|");
			if (dummy.length == 2){
				this.ReconcileMailSystem.put(dummy[0], dummy[1]);
				this.ReconcileMailSystem.put(dummy[1], dummy[0]);
			}
		}
		
	}
	/*
	private void loadReconcileMailReplacement() throws Exception{
		this.ReconcileMailDomainReplacement = new HashMap<String, String>();
		String[] dummy = null;
		String MailRep = this.getValue("V3")[0];
		Vector vMailS= this.session.evaluate(MailRep);
		Iterator<String> it = vMailS.iterator();
		while(it.hasNext()){
			MailRep = it.next();
			dummy = MailRep.split("\\|");
			if (dummy.length == 2){
				this.ReconcileMailDomainReplacement.put(dummy[0], dummy[1]);
				//this.ReconcileMailDomainReplacement.put(dummy[1], dummy[0]);
			}
		}
	}
*/
}
