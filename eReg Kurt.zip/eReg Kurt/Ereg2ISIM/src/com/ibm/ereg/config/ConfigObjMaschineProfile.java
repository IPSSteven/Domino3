package com.ibm.ereg.config;

import lotus.domino.Session;

import com.ibm.ereg.logger.BasicLogger;

public class ConfigObjMaschineProfile extends ConfigObj{
	
	public ConfigObjMaschineProfile(Session sess, String stType) throws Exception {
		super(sess, stType);
		// TODO Auto-generated constructor stub
	}
	public ConfigObjMaschineProfile(Session sess, String stType, BasicLogger log) throws Exception {
		super(sess, stType, log);
		// TODO Auto-generated constructor stub
	}
	public String[] getLogDB()throws Exception{
		return(getValue("V1"));
	}
	public String[] getUploadDir()throws Exception{
		return(getValue("V2"));
	}
	public String[] getPendingDir()throws Exception{
		return(getValue("V3"));
	}
	public String[] getUpDoneDir()throws Exception{
		return(getValue("V4"));
	}
	public String[] getExportDir()throws Exception{
		return(getValue("V5"));
	}
	public String[] getTempDir()throws Exception{
		return(getValue("V6"));
	}
	public String[] getRegistrationDir()throws Exception{
		return(getValue("V7"));
	}
	public String[] getAliveDir()throws Exception{
		return(getValue("V8"));
	}
	

}
