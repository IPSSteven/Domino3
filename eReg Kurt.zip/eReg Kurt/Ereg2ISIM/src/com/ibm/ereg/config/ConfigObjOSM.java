package com.ibm.ereg.config;

import java.util.HashMap;
import java.util.HashSet;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.BasicLogger;
import com.ibm.ereg.logger.LogLevel;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;

public class ConfigObjOSM extends ConfigObj {
	
	private Database OSMDatabase;
	private View vwDomain  = null;
	private final String VWDOMAIN = "Single Types\\Type 4";
	private final String VWMAILSERVER = "Single Types\\Type 5";
	private ConfigObj osmP;

	public ConfigObjOSM(Session sess, String stType, BasicLogger logger)
			throws Exception {
	
		super(sess, stType, logger);
		if(sess == null)System.out.println("sess  = null");
		if(this.session == null)System.out.println("session=null");
		osmP = new ConfigObj(sess,AllConstants.TYPE_OSM_PARAM +">OSM Parameter");
		
		// TODO Auto-generated constructor stub
	}

	public String[] getOSMServer(){
		try {
			String formula = this.docConfig.getItemValueString("V4");
			//Document doctmp = this.Log.getDbLog().createDocument();
			String [] ret = new String [6];
			ret[0] = "D06OSM01";
			ret[1] = "D06OSM02";
			ret[2] = "D06OSM03";
			ret[3] = "D06OSM04";
			ret[4] = "D06OSM05";
			ret[5] = "D06OSM06";
			return ret;
			
			//Vector <String> vRes = session.evaluate(formula);
			//doctmp.recycle();
			//return vRes.toArray(new String[vRes.size()]);
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			this.Log.logActionLevel(LogLevel.SEVERE, "Error while get the OSM server");
			this.Log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
			e.printStackTrace();
			return null;
		}
		
	}
	
	public Database getOSMDatabase(String stServer){
		try {
			OSMDatabase = CommonFunctions.getDatabase(session, stServer, this.docConfig.getItemValueString("V2"));
			return OSMDatabase;
		} catch (NotesException e) {
			this.Log.logActionLevel(LogLevel.SEVERE, "Error while get the OSM database");
			this.Log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	
	public View getUCBView(String stServer){
		getOSMDatabase(stServer);
		if (OSMDatabase != null){
			try {
				View vwOsm = OSMDatabase.getView(this.docConfig.getItemValueString("V3"));
				if (vwOsm != null){
					return vwOsm;
				}else{
					this.Log.logActionLevel(LogLevel.SEVERE, "Error while get the OSM UBC view");
					return null;
					
				}
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				this.Log.logActionLevel(LogLevel.SEVERE, "Error while get the OSM UBC view");
				e.printStackTrace();
				return null;
			}
			
		}else{
			return null;
		}
	}
	public String [] getEmailForErrorReport() throws Exception{
		return getValue("V7");
	}
	public HashMap<String, HashSet<String>> getNabServer(){
		HashMap<String, HashSet<String>> hmMailServer = new HashMap<String, HashSet<String>>(); // IBMDE, MailServers
		HashSet<String> hsMailServer;
		String subject;
		String server;
		try {
			if (vwDomain == null)vwDomain = this.confDB.getView(VWDOMAIN); // ConvfigDB = EregouleSingle type 4 mail domain
			View vwServer = this.confDB.getView(VWMAILSERVER); // single type 5 Mailserver
			Document doc = vwServer.getFirstDocument();
			Document docRec = null;
			boolean bAdd;
			
			// get the mail server in hmMailserver IBMXX -> D06MLX1, D06MLX3, ....
			while(doc != null){
				docRec = doc;
				subject =  doc.getItemValueString("V1");
				hsMailServer = hmMailServer.get(subject);
				bAdd = false;
				if(hsMailServer == null){
					hsMailServer = new HashSet<String>();
					bAdd = true;
				}
				hsMailServer.add(doc.getItemValueString("Subject"));
				if(bAdd){
					hmMailServer.put(subject, hsMailServer);
				}
				doc = vwServer.getNextDocument(doc);
				docRec.recycle();
			}
			vwServer.recycle();
			
			// loop through all domains and build list of Domain mail server, hub mail server
			// D06HBxxx -> D06MLxx
			doc = vwDomain.getFirstDocument();
			HashMap<String, HashSet<String>> hmRetun = new HashMap<String, HashSet<String>>();
			while(doc != null){
				subject = doc.getItemValueString("Subject"); //IBM..
				server = doc.getItemValueString("V1"); //D06...
				hsMailServer = hmMailServer.get(subject);
				//if (hsMailServer == null) {
				//	this.Log.logActionLevel(LogLevel.SEVERE, "No mail server found for " + subject);
				//}
				if(!server.equals("ITIMTEST")){
					hmRetun.put(server, hsMailServer); //D06HB ..
				}
				
				//System.out.println(server+ ":" + hsMailServer);
				docRec = doc;
				doc = vwDomain.getNextDocument(doc);
				docRec.recycle();
			}
			
			
			//vwDomain.recycle();
			return hmRetun;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			this.Log.logActionLevel(LogLevel.SEVERE, "Error while get the mail domain/server");
			this.Log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			return null;
		}
		
		
	}
	
	public HashMap<String, String> getDomain(){
		Document docRec;
		String subject;
		String server;
		HashMap<String, String> hmRetun = new HashMap<String, String>();
		Document doc;
		try {
			if (vwDomain == null)vwDomain = this.confDB.getView(VWDOMAIN);
			doc = vwDomain.getFirstDocument();
			while(doc != null){
				subject = doc.getItemValueString("Subject");
				server = doc.getItemValueString("V1");
				hmRetun.put(server, subject);
				
				hmRetun.put(server, subject);
				docRec = doc;
				doc = vwDomain.getNextDocument(doc);
				docRec.recycle();
			}
			return hmRetun;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			this.Log.logActionLevel(LogLevel.SEVERE, "Error while get the mail domain/server");
			this.Log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			return null;
		}
		
	}
	public String getFTPCallScript(){
		try {
			return osmP.docConfig.getItemValueString("V4");
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public String getFTPTransferScript(){
		try {
			return osmP.docConfig.getItemValueString("V5");
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public String [] getFilter() throws Exception{
		return getValue("V8");
	}
}