package com.ibm.ereg.config;


import java.util.ArrayList;
import java.util.TreeMap;
import com.ibm.ereg.recertify.CertificationData;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;


public class ConfigObjRecertify extends ConfigObj {
	private final String CONF_VIEW = "Type6";
	private CertificationData certData;
	private ConfigObj confCMDRC;
	private ConfigObj confObjAgent;
	private ArrayList<String> aryRecertAll = null;
	private ArrayList<String> aryDoNotRecert = null;
	
	public ConfigObjRecertify(Session sess, String stMachineKey) throws Exception {
		super(sess);
		confObjAgent = new ConfigObjAgent(sess, "2>RecertificationExpiredIds", stMachineKey);
		confCMDRC = new ConfigObj(sess, "10>CMDRC");
		loadCertificationdata();
		// TODO Auto-generated constructor stub
	}

	

	public ArrayList<String> getAryRecertAll() {
		return aryRecertAll;
	}



	public ArrayList<String> getAryDoNotRecert() {
		return aryDoNotRecert;
	}



	private void loadCertificationdata(){
		try {
			View vwCert = confDB.getView(CONF_VIEW);
			certData = new CertificationData();
			TreeMap<String , CertificationData.CertificateConf> tmCertConf = certData.getCertListConf();
			Document docRec = null;
			Document docCert = vwCert.getFirstDocument();

			while(docCert != null){
				CertificationData.CertificateConf cerConf = certData.new CertificateConf();

				cerConf.setCertifierName(docCert.getItemValueString("Subject").toLowerCase());
				cerConf.setCertIdFile(docCert.getItemValueString("V1"));
				cerConf.setCertPW(docCert.getItemValueString("V2"));
				cerConf.setCertifierExpirationDate(docCert.getItemValueString("V3"));
				if(docCert.getItemValueString("V4").equals("1")){
					if(aryRecertAll == null ) aryRecertAll = new ArrayList<String>();
					aryRecertAll.add(cerConf.getCertifierName());
					cerConf.setRecertifiyAll(true);
				}else{
					cerConf.setRecertifiyAll(false);
				}
				if(docCert.getItemValueString("V5").equals("1")){
					if(aryDoNotRecert == null ) aryDoNotRecert = new ArrayList<String>();
					aryDoNotRecert.add(cerConf.getCertifierName());
					cerConf.setDoNoRecertThis(true);
				}else{
					cerConf.setDoNoRecertThis(false);
				}
				
				
				tmCertConf.put(cerConf.getCertifierName(), cerConf);

				docRec = docCert;
				docCert = vwCert.getNextDocument(docCert);
				docRec.recycle();
			}

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public CertificationData.CertificateConf getCertificationConfig(String stCert){
		TreeMap<String , CertificationData.CertificateConf> tmCertConf = certData.getCertListConf();
		if(tmCertConf == null || tmCertConf.size() == 0 ){
			loadCertificationdata();
		}
		return tmCertConf.get(stCert.toLowerCase());
	}
	
	public String getExpirationIdDay(){
		if(confCMDRC == null) return null;
		try {
			String sRes =confCMDRC.getValue("V2")[0];
			Integer.parseInt(sRes); // throws Numberformat exception is String is no numeric..
			return sRes;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return null;
		}
	}
	
	public String [] getDomainFilter(){
		try {
			return confObjAgent.getValue("V6");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public String [] getLogLevel(){
		try {
			return confCMDRC.getValue("V3");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

}
