package com.ibm.ereg.config;

import lotus.domino.NotesException;
import lotus.domino.Session;

import com.ibm.ereg.logger.BasicLogger;

public class ConfigObjSCNAPI extends ConfigObj {

	public ConfigObjSCNAPI(Session sess, String stType, BasicLogger logger)
			throws Exception {
		super(sess, stType, logger);
		// TODO Auto-generated constructor stub
	}

	public String getSCNAccount(){
		try {
			return docConfig.getItemValueString("V1");
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public String getSCNAccountPassword(){
		try {
			return docConfig.getItemValueString("V2");
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

}
