package com.ibm.ereg.config;

import lotus.domino.Session;

public class ConfigObjSlack extends ConfigObj {

	public ConfigObjSlack(Session sess, String stType) throws Exception {
		super(sess, stType);
		// TODO Auto-generated constructor stub
	}

	public String getProvUrl() throws Exception {
		return getValue("V1")[0];
	}
	public String getText() throws Exception {
		return getValue("V2")[0];
	}
}


