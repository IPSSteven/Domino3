package com.ibm.ereg.config;



import com.ibm.ereg.logger.AbstractLogger;
import lotus.domino.Session;

public class ConfigObjTerminate extends ConfigObj {
	
	
	
	public String getSubject() throws Exception{
		return this.getValue("Subject")[0];
	}
	
	public ConfigObjTerminate(Session sess, String stType, AbstractLogger logger) throws Exception {
		super(sess, stType, logger);
		// TODO Auto-generated constructor stub
	}

	public String getSearchFormula() throws Exception{
		return this.getValue("V1")[0];
	}
	
	public String getReturnFormula() throws Exception{
		return this.getValue("V2")[0];
	}

	


}
