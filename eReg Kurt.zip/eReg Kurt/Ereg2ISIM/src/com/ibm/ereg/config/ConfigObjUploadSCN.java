package com.ibm.ereg.config;

import lotus.domino.Session;

public class ConfigObjUploadSCN extends ConfigObj {

	

	public ConfigObjUploadSCN(Session sess, String stType) throws Exception {
		super(sess, stType);
		// TODO Auto-generated constructor stub
	}
	
	
	
	public String [] getDomains(){
		try {
			return getValue("V1");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public boolean getFullUpload(){
		String stFullUpload;
		try {
			stFullUpload = getValue("V2")[0];
			if(stFullUpload == null) return true;
			if(stFullUpload.endsWith("1"))return true;
			return false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return true;
		}
	
	}
	
	public boolean getUploadMailSystem2UAR(){
		String stUploadMailSystem;
		try {
			 stUploadMailSystem = getValue("V3")[0];
			if( stUploadMailSystem == null) return true;
			if (stUploadMailSystem.endsWith("1"))return true;
			return false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return true;
		}
	}
	
	public String [] getTemporyDir4Uload(){
		try {
			return getValue("V4");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public int getHeapSizeNAB() {
		int iRetDefault = 1000;
		int iRet;
		try {
			String sHeapSize = getValue("V5")[0];
			iRet = Integer.parseInt(sHeapSize);
			return iRet;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return iRetDefault;
		}
		
	}
	
	public int getHeapSizeUAR() {
		int iRetDefault = 1000;
		int iRet;
		try {
			String sHeapSize = getValue("V6")[0];
			iRet = Integer.parseInt(sHeapSize);
			return iRet;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return iRetDefault;
		}
		
	}
	public int getMaxThreads() {
		int iRetDefault = 1000;
		int iRet;
		try {
			String sMaxThreads = getValue("V7")[0];
			iRet = Integer.parseInt(sMaxThreads);
			return iRet;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return iRetDefault;
		}
		
	}
	
	public String getPath2java() {
		String sRet = null;
		try {
			sRet  = getValue("V8")[0];
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sRet;
	}
	
	
}
