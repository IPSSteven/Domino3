package com.ibm.ereg.logger;


//import java.io.FileWriter;
import java.lang.reflect.Field;
import java.util.Map;

import lotus.domino.Agent;
import lotus.domino.Database;
//import lotus.domino.Document;
import lotus.domino.NotesException;
//import lotus.domino.RichTextItem;
import lotus.domino.Session;

//import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.constants.AllConstants;

public class InputOutputLogger extends BasicLogger {
	//private final String ITM_NAME_LOG2FILE = "Log2File";
	//private final String ITM_NAME_LOGFILENAME = "LogFileName";
	//private Session sess;
	private String sMachineKey;
	//private int iLineCount = 0;
	//private final int LINE_COUNTLIMIT = 512;
	//private static boolean bWrite2File = false;
	//private static BufferedWriter bw = null;
	private String stAgentname = null;

	//private Document docLog;

	// private Item iLog = null;


	public InputOutputLogger  (Session session, Database dbLog, String stSubject, byte logLevel)
			throws Exception {
		super(session, dbLog);
		// TODO Auto-generated constructor stub

		sess = session;
		try {
			// check the log level
			boolean bCheck = false;
			checkLogLevel = logLevel;
			if (dteNow == null) dteNow = session.createDateTime("Today");

			this.dbLog = dbLog;

			// set up the log document
			sMachineKey = sess.getEnvironmentString(AllConstants.MACHINEKEY);
			//docLog = dbLog.createDocument();
			docLog.replaceItemValue("Body","");
			docLog.replaceItemValue("MKey",  sMachineKey);		
			docLog.replaceItemValue("Subject", stSubject);

			// set the agent name
			if (session.getAgentContext() == null){
				//docLog.replaceItemValue("TestAgentContext", "no");
				//if(!docLog.hasItem("Agent") || docLog.getItemValueString("Agent").isEmpty()){
				stAgentname = docLog.getItemValueString("Agent");
				if (stAgentname == null || stAgentname.isEmpty()){
					Map<String, String> env = System.getenv();
					stAgentname = env.get(AllConstants.ENVIRONMENT_AGENTNAME);
					if (stAgentname == null || stAgentname.isEmpty()) stAgentname = "TestAgent pls delete log or disregard";
				}

			}else{
				//docLog.replaceItemValue("TestAgentContext", "yes");
				Agent ag = session.getAgentContext().getCurrentAgent();
				stAgentname = ag.getName();
			}

			docLog.replaceItemValue("Agent", stAgentname);
			dteNow = session.createDateTime("Today");
			dteNow.setNow();
			docLog.replaceItemValue("StartTime", dteNow);

			logAction(" >>> started agent "+ stAgentname);
			docLog.replaceItemValue("Starter", session.getUserName());
			docLog.replaceItemValue("RunStatus", "Running");
			docLog.replaceItemValue("Status", "New");
			docLog.save(true,true);

			Class c = Class.forName(new LogLevel().getClass().getName());
			Field[] fs = c.getFields();
			for (int i = 0; i < fs.length; i++) {
				if (logLevel == fs[i].getByte(fs[i])) {
					bCheck = true;
					break;
				}
			}
			if (!bCheck)
				throw new Exception("LogLevel is wrong");

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			logAction(e.toString());
			e.printStackTrace();
			throw e;
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			logAction(e.toString());
			e.printStackTrace();
			throw e;
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			logAction(e.toString());
			e.printStackTrace();
			throw e;
		}
		// System.out.println("End the logger");
	}

	/*public InputOutputLogger(Session session, Document docLog) {
		super(session, docLog);
		synchronized (this.getClass()) {

			try {
				if(docLog.hasItem(ITM_NAME_LOG2FILE)) {
					if(docLog.getItemValueString(ITM_NAME_LOG2FILE).equals("1")){
						String fn = docLog.getItemValueString(ITM_NAME_LOGFILENAME);

						try {
							bw = new BufferedWriter(new FileWriter(fn));
							bWrite2File = true;
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}*/

	@Override
	public void logActionLevel(byte bLevel, String stLog) {
		// TODO Auto-generated method stub
		synchronized (this.getClass()) {


			/*	if (bWrite2File & bw != null){
				if (bLevel >= checkLogLevel) {
					try {
						//try{
							dteNow.setNow(); // sometimes the date lose it object,
						}catch(NotesException e) {
							System.out.println(e.getLocalizedMessage());

							dteNow.setNow();
						}

						bw.write(dteNow.getDateOnly() + " " + dteNow.getTimeOnly() + " >>>> " + stLog);
						//bw.write(CommonFunctionGeneral.getActDate()+" >>>> " + stLog);
						bw.newLine();

				} catch (NotesException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						super.logActionLevel(LogLevel.SEVERE, "Error while write to the file");
						super.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage()); 
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}else{ */
			super.logActionLevel(bLevel, stLog);
			//iLineCount ++;
			//if(iLineCount > LINE_COUNTLIMIT){
				//bWrite2File = true;
				// get the MachineProfile
				/*ConfigObjMaschineProfile mp;
				String fn; 
				try {
					mp = new ConfigObjMaschineProfile(sess,AllConstants.TYPE_MACHINEPROFILE + ">" + this.sMachineKey, this);
					String fp =  mp.getPendingDir()[0];
					if(!fp.endsWith("\\\\")) fp = fp + "\\";

					if (stAgentname != null){
						//stAgentname.replaceAll("\\", "").split("\\|")[0] 
						fn = fp  + stAgentname.replaceAll("\\\\", "").split("\\|")[0] + this.docLog.getUniversalID() +".txt";
					}else{
						fn = fp  +this.docLog.getUniversalID() +".txt";
					}

					bw = new BufferedWriter(new FileWriter(fn));
					body = (RichTextItem)docLog.getFirstItem("Body");
					if (body != null){
						bw.write(body.getUnformattedText());
						//bw.flush();
						body.remove();
						docLog.replaceItemValue(ITM_NAME_LOG2FILE, "1");
						docLog.replaceItemValue(ITM_NAME_LOGFILENAME, "fn");
						docLog.save();
						super.logActionLevel(LogLevel.SEVERE, "log moved to file -> " + fn );
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					super.logActionLevel(LogLevel.SEVERE, "Error while open the file");
					super.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage());
					e.printStackTrace();

				}	*/	
				//}
			//}
		}
	}

	@Override
	public void closeLog(LogDocStatus lds) {
		// TODO Auto-generated method stub
		super.closeLog(lds);
/*		if (bw != null){
			try {
				//bw.flush();
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} */
	}

	public void setAgent(String stAgent){

		try {
			docLog.replaceItemValue("Agent", stAgent);
			docLog.save();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
