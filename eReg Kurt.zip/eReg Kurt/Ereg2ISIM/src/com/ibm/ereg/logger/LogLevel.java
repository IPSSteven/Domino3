package com.ibm.ereg.logger;

public class LogLevel {
	public final static byte FINEST = 10;
	public final static byte FINER = 20;
	public final static byte FINE = 30;
	public final static byte CONFIG = 40;
	public final static byte INFO = 50;
	public final static byte WARNING = 60;
	public final static byte SEVERE  = 70;
	
}
