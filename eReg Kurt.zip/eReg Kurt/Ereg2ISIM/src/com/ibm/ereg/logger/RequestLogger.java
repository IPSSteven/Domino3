package com.ibm.ereg.logger;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashSet;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;

import com.ibm.ereg.config.ConfigObjRequest;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.mediator.mediatordatabeans.BasicData;

public class RequestLogger extends BasicLogger {
	@Override
	public void closeLog(LogDocStatus lds) {
		// TODO Auto-generated method stub
		super.closeLog(lds);

		/*try {
			super.docLog.replaceItemValue("ITIMResponseError", lds.getErrorCode());
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}
	private BasicData bd;
	private Session session;
	private static String  stActiveMachines = null;
	private String ErrorMsg;

	public String getErrorMsg() {
		return ErrorMsg;
	}

	public RequestLogger(Session session, Database dbLog, String stSubject, BasicData DataObj)
			throws Exception {
		super(session, dbLog);
		this.session = session;
		this.bd = DataObj;
		this.docLog.replaceItemValue("Type",DataObj.getRTyp());
		this.docLog.replaceItemValue("Status","New");
		this.docLog.replaceItemValue("Subject", stSubject);
		this.docLog.replaceItemValue("ASOContent", DataObj.receiveRawData());
		if (DataObj.getItimRequestID()== null){
			this.docLog.replaceItemValue("ItimRequestID", "EMPTY");
		}else{
			this.docLog.replaceItemValue("ItimRequestID", DataObj.getItimRequestID());
		}


		// TODO Auto-generated constructor stub
	}

	public RequestLogger(Session session, Document docLog) {
		super(session, docLog);
		// TODO Auto-generated constructor stub
	}

	public boolean startRequest(){
		ErrorMsg = "";
		moveData();
		//this.session.e
		scheduleRequest();
		try {
			this.docLog.save();
			return true;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			ErrorMsg = e.toString();
			e.printStackTrace();
			return false;

		}
	}
	public boolean deleteRequest(){
		ErrorMsg = "";
		try {
			docLog.remove(true);
			return true;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			ErrorMsg = e.getMessage();
			e.printStackTrace();
			return false;
		}
	}

	private void scheduleRequest(){
		boolean bFoundSpeficDoc =true;
		String stKey1 = AllConstants.TYPE_REQUEST + ">New" + bd.getEregMailDomain() +"_" +bd.getRTyp() ; //send request to machine via domain .. not immplemented yet
		String stKey2 = AllConstants.TYPE_REQUEST + ">New_" + bd.getRTyp();
		//String stKey1 = AllConstants.TYPE_REQUEST + ">New_" + bd.getRTyp();

		ConfigObjRequest conf = null;
		int ilen = 0;
		try {
			conf = new ConfigObjRequest(session, stKey1, this);
		} catch (Exception e) {
			// we have no to found the config ob for Domain now search for default obj
			bFoundSpeficDoc = false;
			this.logActionLevel(LogLevel.INFO, "No specific config  document for new request "+ stKey1);
			//this.logActionLevel(LogLevel.SEVERE, e.toString());
			//return;
			//conf = null;
		}
		
		if (!bFoundSpeficDoc) {
			try {
				conf = new ConfigObjRequest(session, stKey2, this);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				this.logActionLevel(LogLevel.SEVERE, "Absolut no  config  document for new request " + stKey2);
				this.logActionLevel(LogLevel.SEVERE, e.toString());
				e.printStackTrace();
				return;
				//conf = null;
				
			}
		}

		// next start
		try {
			String stNextStart = conf.getNextStartTime()[0];
			DateTime dteStart = session.createDateTime("Today");
			dteStart.setNow();
			if ( !stNextStart.trim().equals("")){
				ilen = stNextStart.toLowerCase().indexOf("day");
				if (ilen >= 0){
					String sDummy = stNextStart.substring(0,ilen);
					int iDay = Integer.parseInt(sDummy);
					dteStart.adjustDay(iDay);
				}else {
					ilen = stNextStart.toLowerCase().indexOf("hour");
					if (ilen >= 0){
						String sDummy = stNextStart.substring(0,ilen);
						int iHour = Integer.parseInt(sDummy);
						dteStart.adjustHour(iHour);
					}
				}
			}
			this.docLog.replaceItemValue("NextStart", dteStart);
			this.docLog.replaceItemValue("RunStatus", "0");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			this.logActionLevel(LogLevel.SEVERE, "Error while try to get the next start of the request");
			e.printStackTrace();
		}

		//PRIO
		String sPrio;
		try {
			sPrio = conf.getPrio()[0];
			this.docLog.replaceItemValue("Priority", sPrio);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			this.logActionLevel(LogLevel.SEVERE, "Error while try to get the prio of the request");
			this.logActionLevel(LogLevel.SEVERE, e.toString());
			e.printStackTrace();
		}

		//Machine Key
		if (stActiveMachines == null) stActiveMachines = getActiveMaschine(conf.getVwConfig());
		String stHistory = null;
		//String stMachine4Request = null;
		String [] aryMachine4Request = null;
		String stMachineSelected = null;
		try {
			stHistory = session.getEnvironmentString("machineHistoryItim");
		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			stHistory = "";
			e1.printStackTrace();
		}
		try {
			stHistory = session.getEnvironmentString("machineHistoryItim");
			//stMachine4Request = CommonFunctions.arrayToString(conf.getMachineKeys())
			aryMachine4Request = conf.getMachineKeys();
			//char [] cMachine4Request = stMachine4Request.toCharArray();

			// Filter the machines which are not active
			//for (char c : cMachine4Request){
			/*for (String c : aryMachine4Request){
				if (getOccurrence(stActiveMachines, c) < 0){
					stMachine4Request.replaceAll(String.valueOf(c), "");
				}
			}*/
			
			aryMachine4Request = filterOccurrence(stActiveMachines.split(","), aryMachine4Request);
			
			// find the machine with the lowest occurrence in the history
			//cMachine4Request = stMachine4Request.toCharArray();
			//char cSelect = cMachine4Request[0];
			int iOcc = stHistory.length();
			int i;
			for (String c : aryMachine4Request){
				if ((i = getOccurrence(stHistory.split(";"), c)) < iOcc){
					iOcc = i;
					stMachineSelected = c;
				}
			}
			//stMachineSelected = String.valueOf(cSelect);
			this.logActionLevel(LogLevel.INFO, "Found Machine Key:" + stMachineSelected );
			this.docLog.replaceItemValue("AssignedMKey", stMachineSelected);
			//this.docLog.replaceItemValue("AssignedMKey", "F");
			//this.logActionLevel(LogLevel.INFO, "found Machine Key replaced because of test :" +  "F");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			this.logActionLevel(LogLevel.SEVERE, "Error while try to get the machine key of the request");
			this.logActionLevel(LogLevel.SEVERE, e.toString());

			e.printStackTrace();
		}



		// limit history to 256 and write it back
		if (stMachineSelected == null ||stMachineSelected.trim().equals("")) stMachineSelected = conf.getSMachineKey();
		if (stHistory.length() > 250){
			stHistory = stHistory.substring(0,250);
			int idx = stHistory.lastIndexOf(";");
			if (idx >0) stHistory = stHistory.substring(0,idx);
			stHistory =  stMachineSelected + ";" + stHistory;
		}else{
			stHistory = stHistory + stMachineSelected + ";";
		}
		try {
			session.setEnvironmentVar("machineHistoryItim", stHistory);
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private String  getActiveMaschine( View Configview){
		try {
			DocumentCollection dccMatch = Configview.getAllDocumentsByKey(AllConstants.TYPE_AGENT +">Request Manager");
			Document docConf = dccMatch.getFirstDocument();
			Document docR;
			StringBuffer stResult = new StringBuffer("");
			while(docConf != null){
				if (docConf.getItemValueString("V1").equals("1")){
					stResult.append(docConf.getItemValueString("V2") + ","); // machine key

				}
				docR = docConf;
				docConf = dccMatch.getNextDocument(docConf);
				docR.recycle();
			}
			dccMatch.recycle();
			return stResult.toString();
		} catch (NotesException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}
	private int getOccurrence(String [] stSource, String cFind){
		int found = -1;
		//char []cSource = stSource.toCharArray();
		for(String c : stSource){
			if (cFind.equals(c)){
				found ++;
			}
		}
		if (found > -1){
			found ++;
		}
		return found;
	}

	private String[] filterOccurrence(String[] stSourceAll, String [] cFind){
		HashSet<String> Machines = new HashSet<String>();
		for(String stM:stSourceAll) {
			for(String sFind: cFind)
			if (stM.equals(sFind)) Machines.add(stM);

		}
		return Machines.toArray(new String [Machines.size()]);

	}
	private void moveData(){
		String stItemName;
		String stMethodName;
		Document docLog; // is filled with the class document for debbugging reasons
		String stValue;
		// move all the data form the methods of the getEreg methods
		for (Method m: this.bd.Getmethods){
			stMethodName = m.getName();
			if (stMethodName.indexOf("getEreg") >= 0){
				stItemName = stMethodName.substring(7,stMethodName.length());
				docLog = this.getDocLog();
				try {
					stValue = (String)m.invoke(bd, new Object[0]);
					docLog.replaceItemValue(stItemName, stValue);
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	}

}
