/**
 * 
 */
package com.ibm.ereg.mediatorresponse;

import java.sql.SQLWarning;

import lotus.domino.Agent;
import lotus.domino.AgentContext;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;
//import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.constants.SuccessMessages;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnectorNotes;
import com.ibm.mediator.constants.MediatorRequestStatusConstants;

/**
 * @author Kurt Raiser
 *
 */
public class ResponseRequestRunner {
	private Session session;
	private boolean bHasError;
	private String stReturnCode;
	private String stReturnCodeDescription;
	private RequestLogger rl;


	public ResponseRequestRunner(Session sess) {
		super();
		this.session = sess;
		// TODO Auto-generated constructor stub
	}
	public void runNotes(){
		Database dbLog;
		AgentContext agCon;
		Agent ag;
		String stUnid;
		String stReturn;
		Document docLog = null;
		String stType;
		String stSql;
		LogDocStatus lds= null;

		bHasError = false;

		TheEregConnectorNotes con  = null;
		ConfigObjMediatorDB confMed = null;
		int iLen;
		
		// try to get the log database
		try {
			pln("Start ITIM response agent");
			agCon = session.getAgentContext();
			ag = agCon.getCurrentAgent();
			stUnid = ag.getParameterDocID();
			//	stUnid = "476E1E";
			//pln("Unid: " + stUnid);
			dbLog = CommonFunctions.getLogDB(session);
		}catch(Exception e){
			pln("log data base not found");
			return;
		}
		
		// logdatabase  found 
		
		// try to get the log document
		try {
			docLog = dbLog.getDocumentByID(stUnid);
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			pln("NotesException while trying to get the log document:" + e.getMessage());
			//e.printStackTrace();
			return;
		}
		//log document found .. no we can write to the log

		// create the log Status class, which collect the status
		lds = new LogDocStatus(docLog);
		lds.setOKRunning();
		
		// try to get the values from the log document
		try {
			stType = docLog.getItemValueString("Type");
			stReturn = docLog.getItemValueString("Returncode");
			//pln(stReturn);
			iLen = stReturn.length();
			if  (iLen > 3){
				stReturnCode = stReturn.substring(0,3);
				stReturnCodeDescription = stReturn.substring(4, iLen);
			}else{
				stReturnCode = "0";
				stReturnCodeDescription = SuccessMessages.getMsg(stType);
			}
		} catch (NotesException e) {
			pln("NotesException while trying to get values the log document:" + e.getMessage());
			e.printStackTrace();

			return;
		}
		//pln("got the values from the log doc");

		// get the logger
		rl = new RequestLogger(session, docLog);	
		// now we got the logger ..
		
		// get the configuration for the Mediator database
		try {
			confMed = new ConfigObjMediatorDB(session, AllConstants.MEDIATOREQUESTDB + stType, rl);
		} catch (Exception e) {
			//pln("Exception while trying to get configuation of the database " + e.getMessage());
			rl.logActionLevel(LogLevel.SEVERE, "Exception while trying to get configuation of the database " + e.getMessage());
			lds.setITIMResponseError("Exception while trying to get configuation of the database " + e.getMessage());
			lds.setRunStatus(LogDocStatus.RunStatusStopped);
			lds.setStatus(LogDocStatus.StatusPending);
			rl.closeLog(lds);
			return;
		}
		//pln("got the config for the mediator");
		// try to set the loglevel
		try {
			pln("got the config for the mediator loglevel:" + confMed.getLogLevel()[0]);
			rl.setCheckLogLevel(Byte.parseByte(confMed.getLogLevel()[0]));
		} catch (NumberFormatException e1) {
			rl.logActionLevel(LogLevel.SEVERE, "Exception while settin the log level " + e1.getMessage());
			lds.setITIMResponseError("Exception while setting the log level \n " + e1.getMessage());
			lds.setRunStatus(LogDocStatus.RunStatusStopped);
			lds.setStatus(LogDocStatus.StatusPending);
			rl.closeLog(lds);
		} catch (Exception e1) {
			rl.logActionLevel(LogLevel.SEVERE, "Exception while settin the log level " + e1.getMessage());
			lds.setITIMResponseError("Exception while setting the log level \n " + e1.getMessage());
			lds.setRunStatus(LogDocStatus.RunStatusStopped);
			lds.setStatus(LogDocStatus.StatusPending);
			rl.closeLog(lds);
		}

		rl.logActionLevel(LogLevel.FINEST, "Got the config obj for request " + stType);
		
	
		
		// try to get the connection to the mediator database
		rl.logActionLevel(LogLevel.FINEST, "try to get the Connector ");
		try {
			con = new TheEregConnectorNotes(rl, confMed);
		} catch (Exception e0) {
			// try to find the backup
			try {
				// if the first connection goes wrong try to get the backup
				rl.logActionLevel(LogLevel.WARNING, "Connection to Meditor was not successfull. Try to connect to backup database");
				confMed = new ConfigObjMediatorDB(session, AllConstants.MEDIATOREQUESTDBBCK + stType, rl);
				
			} catch (Exception e1) {
				//pln("Exception while trying to get configuation of the database " + e.getMessage());
				rl.logActionLevel(LogLevel.SEVERE, "Exception while trying to get configuation of the backup database" );
				lds.setITIMResponseError("Exception while trying to get configuation of the backup database " + e1.getMessage());
				lds.setRunStatus(LogDocStatus.RunStatusStopped);
				lds.setStatus(LogDocStatus.StatusPending);
				
				rl.closeLog(lds);
				return;
			}
			try{
				//try to connect to the backup database
				con = new TheEregConnectorNotes(rl, confMed);
				rl.logActionLevel(LogLevel.INFO, "Connection backup database was successful.");
			}catch(Exception e2){
				bHasError = true;
				if (rl != null){
					rl.logActionLevel(LogLevel.SEVERE, "Exception error while try to connect to the backup database" + e2.getMessage());
					
					
				}
				//pln("Exception:" + e2.getMessage());
				//e.printStackTrace();
			}
		}

		if (bHasError){
			rl.logActionLevel(LogLevel.SEVERE,"Connection to mediator db2 database can not be established");
			try {	
				rl.logActionLevel(LogLevel.SEVERE, "Error while try to connect to ITIM Mediator DB2" );
				lds.setITIMResponseError("Error while try to connect to ITIM Mediator DB2: Set Status to pending");
				lds.setRunStatus(LogDocStatus.RunStatusStopped); // was commented added again 27 Aug 2019
				lds.setStatus(LogDocStatus.StatusPending); // was commented out added again 27 Aug 2019
				lds.setFTPok(LogDocStatus.FTP_NOT_OK);
				rl.closeLog(lds);
				session.recycle();
				return;
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				pln ("Error while recycle of Notessesion");
				return;
			}	
		}else{
			rl.logActionLevel(LogLevel.FINEST, "Connection to database established");
		}

		// try to update
		rl.logActionLevel(LogLevel.FINEST, "Try to build the update statment");
		stSql = buildUpdateStatement(docLog); 
		if (stSql != null ){	
			rl.logActionLevel(LogLevel.FINEST, "try to excute the Sql statment: \n");
			rl.logActionLevel(LogLevel.FINEST,stSql);
			int iRet = con.executeUpdate(stSql);
			if (iRet == 1){
				rl.logActionLevel(LogLevel.INFO,"updated one row");
				lds.setFTPok(LogDocStatus.FTP_OK);
			}else{
				SQLWarning sqlW = con.getSqlWarning();
				while(sqlW != null){
					rl.logActionLevel(LogLevel.SEVERE, sqlW.getMessage()+ "-" + sqlW.toString());
					sqlW = sqlW.getNextWarning();
				}
				rl.logActionLevel(LogLevel.SEVERE, "SQL Statemant:" + stSql);
				rl.logActionLevel(LogLevel.SEVERE, "the update was not successfull, try to update 1 row " + iRet + " rows updated" );
				rl.logActionLevel(LogLevel.SEVERE, "Error while try to update to ITIM Mediator DB2" );
				lds.setITIMResponseError("Error while try to update to ITIM Mediator DB2 \n");
				lds.setFTPok(LogDocStatus.FTP_NOT_OK);
				lds.setRunStatus(LogDocStatus.RunStatusStopped); // was commented added again 27 Aug 2019
				lds.setStatus(LogDocStatus.StatusPending);  // was commented added again 27 Aug 2019
			}
		}else{
			rl.logActionLevel(LogLevel.SEVERE, "Error while building update statement");
			lds.setITIMResponseError("Error while try to build the update statment for ITIM Mediator DB2 \n");
			lds.setRunStatus(LogDocStatus.RunStatusStopped);
			lds.setStatus(LogDocStatus.StatusPending);
		}

		con.close(true);
		rl.closeLog(lds);

		// try to recycle the session
		try {
			session.recycle();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	String buildUpdateStatement(Document docLog){

		String stType;
		StringBuilder stSql;
		String stHasIdFile;
		try {
			// Prefix
			stType = docLog.getItemValueString("Type");
			stSql = new StringBuilder( "update " + AllConstants.SELECTVIEW + stType + "\" set "  );
			// Middle
			if (stType.toUpperCase().equals("AU")){
				if(docLog.hasItem("IDFILE") && !docLog.getItemValueString("IDFILE").trim().equals("") ){
					stHasIdFile = "Y";
				}else{
					stHasIdFile = "N";
				}
				if(docLog.hasItem("FNIndex")&& docLog.getItemValueString("FNIndex")!= null){
					stReturnCodeDescription = stReturnCodeDescription + "- but-" + docLog.getItemValueString("FNIndex");
				}
				stSql.append("\"EregEmpNum\" = '" + docLog.getItemValueString("EmpNum") + docLog.getItemValueString("EmpCC") +
						"', \"EregFullname\" = '" + getVal4SQL(docLog.getItemValueString("FullName")) +
						"', \"hasIDFile\" ='" + stHasIdFile + 
						"', \"NotesStatus\" ='" + getVal4SQL(docLog.getItemValueString("OfficePhoneNumber")) + "' , ");

				pln (stReturnCodeDescription);

			}else if(stType.toUpperCase().equals("DU") || stType.toUpperCase().equals("RV")|| stType.toUpperCase().equals("TR")) {
				stSql.append("\"NotesStatus\" ='" + docLog.getItemValueString("OfficePhoneNumber") + "' , ");
			}else if(stType.toUpperCase().equals("RN")){

				stSql.append("\"EregHasIdFile\" ='" + docLog.getItemValueString("hasIdFile") + "' , ");
				stSql.append("\"EregNewFullName\" ='" + docLog.getItemValueString("NewFullName") + "' , ");
				stSql.append("\"EregSerial\" ='" + docLog.getItemValueString("serialNumber") + "' , ");
			}else if(stType.toUpperCase().equals("ID")){
				stSql.append("\"EregClassification\" ='" + docLog.getItemValueString("Classification") + "' , ");
			}

			//suffix
			stSql.append("\"Status\" = '" + MediatorRequestStatusConstants.EXECUTED + 
					"', \"ReturnCode\" ='" + stReturnCode + 
					"', \"ReturnCodeDescription\" ='" + stReturnCodeDescription+ "'" +
					" where \"LNUnId\" = '" + docLog.getUniversalID()+ "'");
			return stSql.toString();
		} catch (NotesException e) {
			rl.logActionLevel(LogLevel.SEVERE, "NotesExeption: " + e.getMessage());
			e.printStackTrace();
			return null;
		}
	}

	void pln(String stData){
		System.out.println(stData);
	}
	private String getVal4SQL(String stValue){
		return stValue.replaceAll("'", "''");
	}
}
