package com.ibm.ereg.osmSCOExport;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import lotus.domino.Session;

import com.ibm.ereg.config.ConfigObjFTP_SSH;
import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.BasicLogger;
import com.ibm.ereg.logger.LogLevel;

public class GetOwnerFile {
	private String tmpDir;
	private String stBatchFile;
	private String stTransFile;
	private String stTransFilePath = null;
	private BasicLogger log;

	public GetOwnerFile(Session s, BasicLogger log, ConfigObjMaschineProfile cfgM) throws Exception {
		
		this.log = log;
		tmpDir =cfgM.getTempDir()[0];
		ConfigObjFTP_SSH confSSH = new ConfigObjFTP_SSH(s, AllConstants.TYPE_FTP + ">GetOwnerForSCO", log);
		stTransFile = confSSH.getTimeOut();
		String Script = confSSH.getDestination();
		Script = Script.replace("TMPDIR", tmpDir).replace("TRANSFERFILE", stTransFile);
		stBatchFile = tmpDir + "\\transfer.bat";
		BufferedWriter bw = new BufferedWriter(new FileWriter(stBatchFile));
		bw.write(Script);
		bw.close();
	}

	public String getTransferFile(){
		// ProcessBuilder pb = new ProcessBuilder("cmd", "/c", "dir" );

		try {
			ProcessBuilder pb = new ProcessBuilder(stBatchFile);
			pb.redirectErrorStream(true);
			Process p;
			p = pb.start();
			InputStreamConsumer isc = new InputStreamConsumer(p.getInputStream());
			isc.start();
			int exitCode = p.waitFor();
			isc.join();
			//String stERR = isc.getErrorLevel();
			//System.out.print(stERR);
			if (isc.getErrorLevel().equals("0 \r\n")){
				stTransFilePath = (tmpDir.endsWith("/") |tmpDir.endsWith("\\"))? tmpDir + stTransFile:tmpDir+"/"+stTransFile;
				return  stTransFilePath;
			}else{
				return null; 
			}    
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, "IO exception while try to execute CMD");
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage());
			return null;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Interrupt exception while try to execute CMD");
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage());
			e.printStackTrace();
			return null;
		}


	}
	public boolean deleteownerFile(){
		if (stTransFilePath != null){
			File f = new File(stTransFilePath);
			return f.delete();
		}
		return false;
	}

	public class InputStreamConsumer extends Thread {

		private InputStream is;
		private StringBuilder sbResult;

		public String getErrorLevel() {
			String sDummy = sbResult.toString();
			int idx = sbResult.indexOf("Errorlevel=") + "Errorlevel=".length();
			if (idx > 0)sDummy = sDummy.substring(idx);
			else sDummy = "N/A";
			return sDummy;

		}

		public InputStreamConsumer(InputStream is) {
			this.is = is;
			sbResult = new StringBuilder();
		}

		@Override
		public void run() {
			char cvalue;
			try {
				int value = -1;
				while ((value = is.read()) != -1) {
					cvalue = (char)value;
					System.out.print(cvalue);
					sbResult.append(cvalue);
				}
			} catch (IOException exp) {
				exp.printStackTrace();
			}

		}

	}

}
