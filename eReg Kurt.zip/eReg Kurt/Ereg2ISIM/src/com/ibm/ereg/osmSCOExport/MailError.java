package com.ibm.ereg.osmSCOExport;

import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.RichTextItem;
import lotus.domino.Session;
import lotus.domino.DbDirectory;

public class MailError {
	private Database dbMail;
	public MailError(Session s) {
		// TODO Auto-generated constructor stub
		DbDirectory dir;
		try {
			dir = s.getDbDirectory(null);
			dbMail = dir.openMailDatabase();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void sendMail (String subject, String stBody, String[] sendTo){
		try {
			Document docMail = dbMail.createDocument();
			docMail.replaceItemValue("Subject", subject);
			RichTextItem rti = docMail.createRichTextItem("Body");
			rti.appendText(stBody);
			Vector<String> vSendTo = new Vector<String>();
			for(String stSend: sendTo){
				vSendTo.add(stSend);
			}
			docMail.replaceItemValue("SendTo", vSendTo);
			docMail.send(vSendTo);
			docMail.recycle();
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void close(){
		if(dbMail != null){
			try {
				dbMail.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
