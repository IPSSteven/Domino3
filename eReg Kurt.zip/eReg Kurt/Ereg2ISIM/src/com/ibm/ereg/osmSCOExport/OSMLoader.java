package com.ibm.ereg.osmSCOExport;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjCountryTable;
import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.config.ConfigObjOSM;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.mediatordatabeans.NCOUAR_Data;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;



public class OSMLoader extends NotesThread {
	private final String TASKID = "Task Id";
	private final String IMBEMPLOYEE = "IBM employee";
	private final String CONTRACTOR = "Contractor";
	private final String DELSTAT = "In deletion";
	private final String ACTSTAT = "Active";
	private Session session;
	private Database dbLog;
	private InputOutputLogger log;
	private ConfigObjMaschineProfile confMachine;
	private ConfigObjOSM confOsm; 
	//private ConfigObjFTP_SSH confSSH;
	private String stDomain;
	TreeMap<String,String>hmUserIDOwner;
	//HashMap<String,String> hmOsmMailServer;
	HashMap<String, HashSet<String>> hmServers;
	HashMap<String,String>hmDomains;
	HashMap<String, NCOUAR_Data>hmNCOUAR;
	HashMap<String,UBC_Data>hmUbc;
	private MailError mailError = null;
	private BufferedWriter bf;
	private String pw;
	private ConfigObjCountryTable cfgObjCountryTable;
	private long lines;
	private boolean bUploadUBC = true;
	private HashSet <String> handledServer;
	private HashSet <String> failedServer;
	private ConfigObjNCOUAR cfgUAR;
	private HashMap <String,String> hmFilter = null;

	public static void main (String[] argv){
		OSMLoader osml = new OSMLoader();
		osml.pw = argv[0];
		osml.start();;
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		//String stOrg;
		//String stMailServer;
		super.runNotes();
		session = NotesFactory.createSessionWithFullAccess(pw);
		String tmpDir = null;
		
		// get the config
		if ( !getConfiguration()){
			log.logActionLevel(LogLevel.SEVERE, "Error during get configuration");
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setStatus("Error");
			log.closeLog(lds);
		}

		// get the machine profile
		try {
			tmpDir = confMachine.getTempDir()[0];
			bf = new BufferedWriter(new FileWriter( tmpDir + "/UBCExport.txt"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Can not open output file");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			return;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Can read Machine Profile");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			e.printStackTrace();
		}

		// write the header
		try {
			bf.write(getHeader());
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String server;
		handledServer = new HashSet<String>();
		failedServer = new HashSet<String>();
		bUploadUBC = true;
		Set<String> keys = hmServers.keySet(); // hmServers is filled in getConfiguration
		Iterator<String> it = keys.iterator();
		while (it.hasNext()){
			server = it.next();
			if (!handleServer(server)) bUploadUBC = false;
	
		}
		
		// try the failed Server again
		if (!bUploadUBC){
			log.logActionLevel(LogLevel.WARNING, "Not all server can be extracted export finshed not succesful");
			handledServer = new HashSet<String>();
			HashSet<String> failedServer2Handle = (HashSet<String>) failedServer.clone();
			failedServer = new HashSet<String>();
			it = failedServer2Handle.iterator();
			bUploadUBC = true;
			while (it.hasNext()){
				server = it.next();
				log.logActionLevel(LogLevel.WARNING, "Try to extract server again");
				bUploadUBC = handleServer(server);
			}
		}


		if (!bUploadUBC){
			log.logActionLevel(LogLevel.SEVERE, "Not all server can be extracted export finshed not succesful");
		}

		// write the footer line
		try {
			bf.write(getFooter(lines));
			bf.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Can not close output file");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
		}
		
		

		// upload the file
		//SendSCOFile sendSCO = new SendSCOFile(s, log, cfgM);
		try {
			SendSCOFile sendSCO = new SendSCOFile(session, log, confMachine,confOsm);
			String desDir = "E:/backup/SCO/";
			sendSCO.copyOSMFile( tmpDir + "/UBCExport.txt", desDir + "/UBCExport.txt");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Document dNote = log.getDbLog().createDocument();
		dNote.replaceItemValue("Subject", "OSMReport is ready");
		dNote.replaceItemValue("SendTo","Kurt Raiser1/Bechtle/Germany/IDE" );
		dNote.send("Kurt Raiser1/Bechtle/Germany/IDE");
		
		
		
		LogDocStatus lds = new LogDocStatus(log.getDocLog());
		lds.setOKDone();
		log.closeLog(lds);



		dNote.recycle();
		session.recycle();

	}

	// get the OSM server
	/*	String stOsmServer = hmOsmMailServer.get(server);
		if(stOsmServer == null){
			HashSet<String> hsEregMailServer = hmServers.get(server);
			if(hsEregMailServer == null){
				log.logActionLevel(LogLevel.SEVERE, "OSM Server not found for "+ server);
			}else{
				Iterator<String> itOsm = hsEregMailServer.iterator();
				while(itOsm.hasNext()){
					stMailServer = itOsm.next();
					stOsmServer = hmOsmMailServer.get(stMailServer);
					//if(stOsmServer != null) break; 
					if(stOsmServer != null)log.logActionLevel(LogLevel.SEVERE, "OSM Server not found for "+ server);
				}
			}


		} */

	// load OSM Data
	//loadOSMData(stOsmServer);

	private boolean getConfiguration(){
		try {
			dbLog  = CommonFunctions.getLogDB(session);
			log = new InputOutputLogger(session, dbLog, "OSM Export - " + CommonFunctions.getActDateRecon(),
					LogLevel.FINEST);

			confMachine = new ConfigObjMaschineProfile(session, AllConstants.TYPE_MACHINEPROFILE + ">" , log);
			confOsm = new ConfigObjOSM(session, "17>OSM Parameter", log);

			//String[] osmServers = confOsm.getOSMServer();
			//OSMconfig osmConf = new OSMconfig(session,osmServers,log);

			//hmOsmMailServer = osmConf.getMailServerOSM();


			hmServers = confOsm.getNabServer(); // hub server in ereg tool (view, mail server; D06HBxx ->  D06MLxx
			hmDomains = confOsm.getDomain(); // server domain D06HBM01 -> IBMDE


			//Get the user owner mapping
			//GetOwnerFile gof = new GetOwnerFile(session, log, confMachine);
			//String stf = gof.getTransferFile();
			//String stf = "C:\\EREG\\Temp\\UBC.csv";
			//if(stf == null){
			//	log.logActionLevel(LogLevel.SEVERE, "Error while transfering ownerFile");
			//	return false;
			//}
			//UserIDOwnerMap uidown = new UserIDOwnerMap(stf);
			//pln("User manager map init start");
			UserIDOwnerMap uidown = new UserIDOwnerMap();  // replacement
			pln("User manager map init done");

			hmUserIDOwner = uidown.getHmUserIDOwner(); // replacement
			//gof.deleteownerFile();
			//gof = null;
			
			
			cfgObjCountryTable = new ConfigObjCountryTable(session);
			
			
			cfgUAR = new ConfigObjNCOUAR(session, log);
			
			
			return true;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	private void loadNCOUARData(String Domain){
		//get the NCOUAR database 
		//ConfigObjNCOUAR cfgUAR = null;
		ViewEntry veRec = null;
		NCOUAR_Data nd = null;
		Vector<Object> vecLine = null;
		String stKey = null;
		long lcount = 0;
		try {
			
			View vwNCOUARITIMEXP = cfgUAR.getVwITIMEXPORT(Domain); // this is hidden view in NCOUAR '(ITIMEXPORT)'
			hmNCOUAR = new HashMap<String, NCOUAR_Data>();
			ViewEntryCollection vec = vwNCOUARITIMEXP.getAllEntriesByKey(stDomain,true);
			long lsize = vec.getCount();
			ViewEntry ve = vec.getFirstEntry();

			while(ve != null){
				vecLine = ve.getColumnValues();
				stKey = vecLine.elementAt(3).toString() + vecLine.elementAt(2).toString();
				stKey = stKey.toUpperCase();

				nd = new NCOUAR_Data();
				nd.setClassification(vecLine.elementAt(9).toString());
				// test
				//if (stKey.equalsIgnoreCase("IBMZAPURITY")){
				//	String dummy = nd.getClassification();
				//}
				// test
				
				if (vecLine.elementAt(10).toString().equals("1.0")){
					nd.setIdFile("Y");
				}else{
					nd.setIdFile("N");
				}
				nd.setOwner(vecLine.elementAt(6).toString());
				nd.setOwnerCountry(vecLine.elementAt(5).toString());
				nd.setSerialNumber(vecLine.elementAt(8).toString());
				nd.setService(vecLine.elementAt(5).toString());
				nd.setState(vecLine.elementAt(13).toString());
				if(nd.getClassification().equals("F")){
					nd.setTaskId("Y");
				}else{
					nd.setTaskId("N");
				}
				//hmNCOUAR.put(stKey, nd);
				hmNCOUAR.put(stKey.toUpperCase(), nd);
				veRec = ve;
				ve = vec.getNextEntry(ve);
				veRec.recycle();
				vecLine = null;
				lcount ++;
				if (lcount % 500 ==0)pln("Reading " + lcount +"/" + lsize + "entry from NCOAUR for " + stDomain);
			}
			vec.recycle();
			System.gc();





		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void loadOSMData(String stOSMServer){
		View vwUBC = confOsm.getUCBView(stOSMServer);
		hmUbc = new HashMap<String, UBC_Data>();
		String stKey;
		UBC_Data ubc;
		Name na;
		try {


			Document doc = vwUBC.getFirstDocument();
			Document docRec = null;
			while(doc != null){
				ubc = new UBC_Data();
				ubc.setEmpcc(doc.getItemValueString("Empcc"));
				ubc.setEmpNum(doc.getItemValueString("EmpNum"));
				na = session.createName(doc.getItemValueString("FullName"));
				ubc.setFullName(na.getAbbreviated());
				na = session.createName(doc.getItemValueString("MailServer"));
				ubc.setMailServer(na.getAbbreviated());
				ubc.setMailFile(doc.getItemValueString("MailFile"));
				ubc.setMailFileSize(doc.getItemValueString("MailFileSize"));
				ubc.setThresHold_3(doc.getItemValueString("Threshold_3"));
				stKey = ubc.getEmpNum()+ubc.getEmpcc();
				hmUbc.put(stKey, ubc);
				docRec = doc;
				doc = vwUBC.getNextDocument(doc);
				docRec.recycle();
			}
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	private boolean extractNab(String stServer){


		Database dbNab =CommonFunctions.getDatabase(session, stServer, AllConstants.NABDBNAME);
		try {
			HashSet<String> hs = new HashSet<String>();
			View vwP = dbNab.getView("People");
			vwP.refresh();
			Document doc = vwP.getFirstDocument();
			Document docR;
			OsmOutPut oOut;
			//UBC_Data ubcDat;
			Vector vDummy;
			String stKey;
			String stResult;
			Name na;
			NCOUAR_Data ncDat;

			long lcount = 0;
			long lFilter = 0;
			long lsize = vwP.getEntryCount();
			int ipos;
			log.logActionLevel(LogLevel.INFO, "found " + lsize + " documents on server" + stServer );

			// sometimes the people view seems be corrupted
			if (lsize == 0) {
				log.logActionLevel(LogLevel.SEVERE, " found nothing on this server " );

				try{
					log.logActionLevel(LogLevel.SEVERE, "Name:" + vwP.getName() + "- rowlines:"+ vwP.getRowLines());
					vwP.recycle();
				}catch(Exception e){
					log.logActionLevel(LogLevel.SEVERE, "Exception:" + e.getLocalizedMessage());
				}
				try{
					log.logActionLevel(LogLevel.SEVERE, "try to open view by shortname");
					vwP = dbNab.getView("People\\People by Shortname");
					log.logActionLevel(LogLevel.SEVERE, " as wie found nothing try to open view peopley by shortname "  );
					lsize = vwP.getEntryCount();
					log.logActionLevel(LogLevel.INFO, "found " + lsize + " documents on server" + stServer );
				}catch (Exception e){
					log.logActionLevel(LogLevel.SEVERE, "Exception:" + e.getLocalizedMessage());
				}

				
			}

// ---------------------------------------------			
			doc = vwP.getFirstDocument();
			while (doc != null){
				if(bFilterID(doc)){
					docR = doc;
					doc = vwP.getNextDocument(doc);
					docR.recycle();
					lFilter ++;
					continue;
				}

				oOut = new OsmOutPut();
				oOut.setCountryCode(doc.getItemValueString("Empcc")); //w1 Nab
				oOut.setEmpNumCharge(doc.getItemValueString("EmpNum")); //w2 NAB
				vDummy = doc.getItemValue("ShortName"); 
				ipos = vDummy.size()-1;
				if (ipos >=0)oOut.setShortName((String)vDummy.elementAt(ipos));
				else oOut.setShortName("N/A");//w4
				vDummy = doc.getItemValue("FullName"); //NAB
				na = session.createName((String)vDummy.elementAt(0)); 
				oOut.setNotesId(na.getAbbreviated());//w5 NA
				na.recycle();
				na = session.createName(doc.getItemValueString("MailServer")); //NAB
				//pln(na.getAbbreviated());
				oOut.setServerName(na.getAbbreviated());//w6
				na.recycle();
				oOut.setProfile("In"); // w10
				oOut.setAllocTier(""); // w11
				if(!doc.getItemValueString("OfficePhoneNumber").trim().equals("")){
					oOut.setUserStatus(this.DELSTAT);// w12
				}else{
					oOut.setUserStatus(this.ACTSTAT);// w12
				}

				// company w3
				String[] nameparts = oOut.getNotesId().split("/");
				ipos = nameparts.length -1;
				try{
					if (nameparts[ipos].equals("IBM")){
						oOut.setCompany("IBM"); //w3
					}else{
						oOut.setCompany(nameparts[ipos-1]); //w3
					}
				}catch(ArrayIndexOutOfBoundsException e){
					pln("Problem " + oOut.getNotesId());
				}

				// owner information
				oOut.setOrginOfEmpNum("N/A"); // w13 Kostenstelle

				stKey = oOut.getEmpNumCharge() + oOut.getCountryCode();
				stResult = hmUserIDOwner.get(stKey); // needed for replacement of 
				if (stResult == null){
					stKey = stDomain + "$$$"+ oOut.getShortName();
					stResult = hmUserIDOwner.get(stKey); 
					if(stResult == null){
						oOut.setOwnerEmpNum("N/A"); // w14
					}else{
						oOut.setOwnerEmpNum(stResult);
					}

				}else{
					oOut.setOwnerEmpNum(stResult);
				}

				// the ncouar data
				stKey = doc.getItemValueString("MailDomain") + oOut.getShortName().toUpperCase();
				ncDat = hmNCOUAR.get(stKey);
				if(ncDat == null){
					oOut.setASOserial("");//w7
					oOut.setRegType("N/A"); //w9
				}else{
					if(ncDat.getOwner().isEmpty()){
						oOut.setEmpNumCharge(doc.getItemValueString("Empnum"));
					}else{
						oOut.setEmpNumCharge(ncDat.getOwner());
					}
					//oOut.setEmpNumCharge((ncDat.getOwner().isEmpty())?doc.getItemValueString("Empnum"):(ncDat.getOwner())); //w2
					oOut.setASOserial(ncDat.getSerialNumber());//w7
					if(ncDat.getClassification().equals("F")){
						oOut.setRegType(this.TASKID); //w9
					}else if(ncDat.getClassification().equals("E")){
						oOut.setRegType(this.CONTRACTOR); //w9)
					}else{
						oOut.setRegType(this.IMBEMPLOYEE);
					}
				}


				
				oOut.setSize("");

				// remove dead rats
				specialReplace(oOut);


				//bf.write(oOut.getOutLine() + "\r\n");
				hs.add(oOut.getOutLine() + "\r\n");
				lcount++;

				docR = doc;
				doc = vwP.getNextDocument(doc);
				docR.recycle();

				if (lcount % 500 ==0){
					pln("Reading " + lcount +"/" + lsize + "entry from NAB for " + stDomain + "-" + stServer);
					//log.logActionLevel(LogLevel.INFO,"Reading " + lcount +"/" + lsize + "entry from NAB for " + stDomain + "-" + stServer );
				}
				
			}

		
	
	//	----------------------------------------------------------------------	
			double p = (lsize != 0)? ((lFilter + lcount)/lsize ): 1.0;
			log.logActionLevel(LogLevel.INFO,"Deviation " + p );
			
			if ((lFilter + lcount) < lsize){
				p = (lsize != 0)? (double)(lFilter + lcount)/lsize : 1.0;
				log.logActionLevel(LogLevel.INFO,"Deviation " + p );
				log.logActionLevel(LogLevel.SEVERE, "lcount = " + lcount + " lfilter=" + lFilter + " lsize=" +lsize);
				if (mailError == null){
					mailError = new MailError(session);
					try {
						mailError.sendMail("Error while create OSM Export on Server " + stServer, "", confOsm.getEmailForErrorReport());
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					lines = lines + lcount;
					return false;
				}else{
					log.logActionLevel(LogLevel.INFO, "lcount = " + lcount + " lfilter=" + lFilter + " lsize=" +lsize); 
				}
			}

			// write all
			Iterator<String> it = hs.iterator();
			while (it.hasNext()){
				bf.write(it.next());
			}
			
			
			lines = lines + lcount;
			log.logActionLevel(LogLevel.INFO, " finished NAB extract on server " + stServer + " added " + lcount + " lines (" + lFilter + " filtered)   summe = " + lines );
			vwP.recycle();
			dbNab.recycle();
			hs =null;
			System.gc();
			if (lcount != 0) return true; else return false;

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "NotesException while handle NAB");
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage());
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "IO Exeption while handle NAB");
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage());
			e.printStackTrace();
			return false;
		}

	}

	private void specialReplace(OsmOutPut osmOut){
		// remove tabs from PSC
		String stPsc = osmOut.getCountryCode();
		String stCountry = null;
		if(stPsc.trim().isEmpty()){
			String [] stArray = osmOut.getNotesId().split("/");
			if (stArray.length >=2 ){
				stCountry = stArray[1];
				if (stCountry.contains("=")){
					stArray = stCountry.split("=");
					stCountry = stArray[1];
				}
				stPsc = cfgObjCountryTable.getCountryNumberByCountry(stCountry);
				osmOut.setCountryCode(stPsc);
			}
		}else{
			if(!(osmOut.getCountryCode().indexOf("\t") < 0)){
				osmOut.setCountryCode(osmOut.getCountryCode().replaceAll("\t", ""));
			}

		}		
	}

	private String getHeader(){
		StringBuilder sb   = new StringBuilder();
		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		sb.append("HEADER SCO ");
		sb.append(sdf.format(dt));
		sb.append(" ");
		sdf = new SimpleDateFormat("yyyy-MM-dd");
		sb.append(sdf.format(dt));
		sb.append("\r\n");
		return sb.toString();

	}

	private String getFooter(long lCount){
		return "TRAILER SCO " + lCount + "\r\n";
	}

	private boolean bFilterID(Document doc){
		String stName =null;
		String stValue = null;
		Vector<String> vValue = null;
		
		// read filter configuration only once
		if (this.hmFilter == null){
			this.hmFilter = new HashMap<String, String>();
			try {
				String [] filterArr = confOsm.getFilter();
				for(String s: filterArr){
					String [] nameVal = s.split("=");
					if (nameVal.length == 2){
						hmFilter.put(nameVal[0], nameVal[1]);
					}
				}
			} catch (Exception e) {
				log.logActionLevel(LogLevel.SEVERE, "Error while reading filter " + e.getMessage());
				this.hmFilter = null;
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		try {
			if(doc.getItemValueString("ShortName").isEmpty()){
				return true;
			}
			if(!doc.getItemValueString("MailDomain").equals(stDomain)){
				return true;
			}
			if(doc.hasItem("$Conflict")){
				return true;
			}
			
			if(hmFilter != null){
				Iterator<String> it = hmFilter.keySet().iterator();
				if(it.hasNext()){
					stName = it.next();
					stValue = hmFilter.get(stName);
					vValue = doc.getItemValue(stName);
					if(vValue != null){
						if(vValue.lastElement().equalsIgnoreCase(stValue)) return true;
					}
				}
			}
	
			
			
			return false;

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return true;
		}
	}

	private void pln(String s){
		System.out.println(s);
	}

	private boolean handleServer(String server){
		String stOrg;
		//		String stMailServer;

		// look whether server is already handle. if yes it can not be adder
		if(!handledServer.add(server)){
			return true;
		}

		log.logActionLevel(LogLevel.INFO, "Start for server " + server);

		// get the Domain
		stOrg = hmDomains.get(server);
		stDomain = cfgObjCountryTable.getMailDomain(stOrg);
		pln(server + "-" + stOrg + "-" + stDomain);
		//if(bDo)continue;
		if(stDomain == null){
			// there is no org so the Domain, so we take the domain ...
			stDomain = stOrg;
			log.logActionLevel(LogLevel.SEVERE, "No Domain found for server" + server);
			//continue;
		}
		log.logActionLevel(LogLevel.INFO, "start load NCOUAR  for domain " + stDomain);
		
		// load NCOUAR data in hmNcouar
		loadNCOUARData(stDomain);
		log.logActionLevel(LogLevel.INFO, " finished load NCOUAR  for domain " + stDomain + " found " +  + hmNCOUAR.size()  + " entries now start Nab Extract");

		if(extractNab(server)){
			log.logActionLevel(LogLevel.INFO, " Upload for  " + stDomain + " successful");
		}else{
			log.logActionLevel(LogLevel.INFO, " Upload for  " + stDomain + " NOT successful");
			failedServer.add(server);
			return false;
		}

		hmNCOUAR = null;
		System.gc();
		// flush after each domain
		try {
			bf.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block

			e.printStackTrace();
			return false;
		}

		return true;

	}

}
