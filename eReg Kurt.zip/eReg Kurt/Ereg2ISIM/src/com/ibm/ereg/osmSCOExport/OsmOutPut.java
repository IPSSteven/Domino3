package com.ibm.ereg.osmSCOExport;

public class OsmOutPut {
	private String CountryCode; // w1
	private String EmpNumCharge; // w2
	private String Company;// w3
	private String ShortName; // w4
	private String NotesId; // w5
	private String ServerName; // w6
	private String ASOserial; // w7
	private String Size; // w8
	private String RegType; // w9
	private String Profile; // w10
	private String AllocTier; // w11
	private String UserStatus; // w12
	private String OrginOfEmpNum; // w13
	private String OwnerEmpNum; // w14
	private String Comment; // w15
	
	public String getCountryCode() {
		return CountryCode;
	}
	public void setCountryCode(String countryCode) {
		CountryCode = countryCode;
	}
	public String getEmpNumCharge() {
		if(EmpNumCharge == null) return null;
		if(EmpNumCharge.length()>6){
			return EmpNumCharge.substring(0,6);
		}else{
			return EmpNumCharge;
		}
		
	}
	public void setEmpNumCharge(String empNumCharge) {
		EmpNumCharge = empNumCharge;
	}
	public String getCompany() {
		return Company;
	}
	public void setCompany(String company) {
		Company = company;
	}
	public String getShortName() {
		if(ShortName == null) return null;
		return ShortName.toUpperCase();
	}
	public void setShortName(String shortName) {
		ShortName = shortName;
	}
	public String getNotesId() {
		if(NotesId.length() > 120){
			int iReduce = NotesId.length() - 120; // chars to kill
			int idx = NotesId.indexOf("/"); // find the 
			String stEnd =  NotesId.substring(idx);
			String stBeg =  NotesId.substring(0,idx-iReduce-1)+ "~";
			return  stBeg+ stEnd;
		}else{
			return NotesId;
		}
		
	}
	public void setNotesId(String notesId) {
		NotesId = notesId;
	}
	public String getServerName() {
		int pos = ServerName.indexOf("/");
		if(pos>0){
			return ServerName.substring(0,pos);
		}else{
			return ServerName;
		}
		
	}
	public void setServerName(String serverName) {
		ServerName = serverName;
	}
	public String getASOserial() {
		return ASOserial;
	}
	public void setASOserial(String aSOserial) {
		ASOserial = aSOserial;
	}
	public String getSize() {
		return Size;
	}
	public void setSize(String size) {
		Size = size;
	}
	public String getRegType() {
		return RegType;
	}
	public void setRegType(String regType) {
		RegType = regType;
	}
	public String getProfile() {
		return Profile;
	}
	public void setProfile(String profile) {
		Profile = profile;
	}
	public String getAllocTier() {
		if (ServerName == null) return null;
		if(ServerName.startsWith("NALL")) return "SCN";
		else return AllocTier;
	}
	public void setAllocTier(String allocTier) {
		AllocTier = allocTier;
	}
	public String getUserStatus() {
		return UserStatus;
	}
	public void setUserStatus(String userStatus) {
		UserStatus = userStatus;
	}
	public String getOrginOfEmpNum() {
		return OrginOfEmpNum;
	}
	public void setOrginOfEmpNum(String orginOfEmpNum) {
		OrginOfEmpNum = orginOfEmpNum;
	}
	public String getOwnerEmpNum() {
		if (OwnerEmpNum.length() >6){
			return OwnerEmpNum.substring(0,6);
		}else{
			return OwnerEmpNum;
		}
		
	}
	public void setOwnerEmpNum(String ownerEmpNum) {
		OwnerEmpNum = ownerEmpNum;
	}
	public String getComment() {
		return Comment;
	}
	public void setComment(String comment) {
		Comment = comment;
	}
	
	public String getOutLine(){
		StringBuilder sb = new StringBuilder();
		sb.append(getCountryCode()); //A
		sb.append(";");
		sb.append(getEmpNumCharge()); //B
		sb.append(";");
		sb.append(getCompany()); //C
		sb.append(";");
		sb.append(getShortName()); //D
		sb.append(";");
		sb.append(getNotesId()); //E
		sb.append(";");
		sb.append(getServerName()); //F
		sb.append(";");
		sb.append(getASOserial()); //G
		sb.append(";");
		sb.append(getSize());//H
		sb.append(";");
		sb.append(getRegType()); //I
		sb.append(";");
		sb.append(getProfile()); //J
		sb.append(";");
		sb.append(getAllocTier()); //K
		sb.append(";");
		sb.append(getUserStatus()); //L
		sb.append(";");
		sb.append(getOrginOfEmpNum()); //M
		sb.append(";");
		sb.append(getOwnerEmpNum()); //N
		sb.append(";");
		sb.append(getComment()); //O
		
		if (sb.length() > 200){
			String stResult = sb.toString();
			int iReduce = stResult.length() - 200; // chars to kill
			int idx = stResult.indexOf("/"); // find the 
			String stEnd = stResult.substring(idx);
			String stBeg = stResult.substring(0,idx-iReduce-1)+ "~";
			stResult = stBeg+ stEnd;
			return stResult;
		}else{
			return sb.toString();
		}
		
		
	}

}
