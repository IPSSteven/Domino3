package com.ibm.ereg.osmSCOExport;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;




import java.io.OutputStream;

import lotus.domino.Session;
import com.ibm.ereg.config.ConfigObjFTP_SSH;
import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.config.ConfigObjOSM;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.BasicLogger;
import com.ibm.ereg.logger.LogLevel;

public class SendSCOFile {
	private String tmpDir;
	private String stBatchFile;
	private String stTransFile;
	private String stTransFilePath = null;

	private String stUser;
	private String stPassword;
	private BasicLogger log;

	public SendSCOFile(Session s, BasicLogger log, ConfigObjMaschineProfile cfgM, ConfigObjOSM cfgOSM) throws Exception {

		this.log = log;
		tmpDir =cfgM.getTempDir()[0];
		ConfigObjFTP_SSH confOSMFTP_SSH = new ConfigObjFTP_SSH(s, AllConstants.TYPE_FTP + ">OSM", log);

		stUser = confOSMFTP_SSH .getAccount();
		stPassword = confOSMFTP_SSH .getPW();
		stTransFile = confOSMFTP_SSH .getTimeOut();
		//String destination = confOSMFTP_SSH .getDestination();
		stBatchFile = tmpDir + "\\ftpexe.bat";
		stTransFile = tmpDir + "ftptans.txt";


		String ftpScript = cfgOSM.getFTPCallScript();
		ftpScript = ftpScript.replace("TMP_FILESCRIPT", stTransFile);
		String ftpTransScript = cfgOSM.getFTPTransferScript();
		ftpTransScript.replace("TMP_FTPUSER", stUser);
		ftpTransScript.replace("TMPPASSWORD", stPassword);

		BufferedWriter bw = new BufferedWriter(new FileWriter(stBatchFile));
		bw.write(ftpScript);
		bw.close();
		bw = new BufferedWriter(new FileWriter(stTransFile));
		bw.write(ftpTransScript);
		bw.close();
	}

	public String getTransferFile(){
		// ProcessBuilder pb = new ProcessBuilder("cmd", "/c", "dir" );

		try {
			ProcessBuilder pb = new ProcessBuilder(stBatchFile);
			pb.redirectErrorStream(true);
			Process p;
			p = pb.start();
			InputStreamConsumer isc = new InputStreamConsumer(p.getInputStream());
			isc.start();
			int exitCode = p.waitFor();
			isc.join();
			//String stERR = isc.getErrorLevel();
			//System.out.print(stERR);
			if (isc.getErrorLevel().equals("0 \r\n")){
				stTransFilePath = (tmpDir.endsWith("/") |tmpDir.endsWith("\\"))? tmpDir + stTransFile:tmpDir+"/"+stTransFile;
				return  stTransFilePath;
			}else{
				return null; 
			}    
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, "IO exception while try to execute CMD");
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage());
			return null;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Interrupt exception while try to execute CMD");
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage());
			e.printStackTrace();
			return null;
		}


	}
	public boolean deleteownerFile(){
		if (stTransFilePath != null){
			File f = new File(stTransFilePath);
			return f.delete();
		}
		return false;
	}

	public class InputStreamConsumer extends Thread {

		private InputStream is;
		private StringBuilder sbResult;

		public String getErrorLevel() {
			String sDummy = sbResult.toString();
			int idx = sbResult.indexOf("Errorlevel=") + "Errorlevel=".length();
			if (idx > 0)sDummy = sDummy.substring(idx);
			else sDummy = "N/A";
			return sDummy;

		}

		public InputStreamConsumer(InputStream is) {
			this.is = is;
			sbResult = new StringBuilder();
		}

		@Override
		public void run() {
			char cvalue;
			try {
				int value = -1;
				while ((value = is.read()) != -1) {
					cvalue = (char)value;
					System.out.print(cvalue);
					sbResult.append(cvalue);
				}
			} catch (IOException exp) {
				exp.printStackTrace();
			}

		}

	}

	public boolean copyOSMFile (String osmFilePath, String destionationFilePath){
		File s = new File(osmFilePath);
		File d = new File(destionationFilePath);
		boolean bRet = false;
		try {
			InputStream is = new FileInputStream(s);
			OutputStream os = new FileOutputStream(d);
			
			byte [] buffer = new byte[1024];
			int length = 0;
			while ((length = is.read(buffer)) > 0) {
	            os.write(buffer, 0, length);
	        }
			is.close();
			os.close();
			bRet = true;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return bRet;
	}

}


