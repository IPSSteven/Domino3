package com.ibm.ereg.osmSCOExport;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeMap;


import com.ibm.getIsimInfo.DataSingleton;
import com.ibm.getIsimInfo.ExportOwnerInfoNew;

public class UserIDOwnerMap {

	//private final String INPUTFILE = "C:/EREG/SCO/UBC.csv";
	private String inputFile;
	private final String ORPHANOWNER = "042395724";
	private TreeMap <String,String> hmUserIDOwner = null;


	public  UserIDOwnerMap(String inputFile){
		this.inputFile = inputFile;
		initMap();
		//initMapNew();
	}
	public  UserIDOwnerMap(){
		
		initMapNew();
	}

	private void initMapNew(){
		
			System.out.println("init new before runexport");
			ExportOwnerInfoNew.runTheExport();
			System.out.println("init new after runexport");
	
		DataSingleton ds = DataSingleton.getInstance();
	
		this.hmUserIDOwner = ds.getSerialIDMgr();
		
	}

	private void initMap() {
		String []lineFields;
		if (hmUserIDOwner == null){
			hmUserIDOwner = new TreeMap<String, String>();
		}
		BufferedReader bf;
		int iLen;
		try {
			bf = new BufferedReader(new FileReader(inputFile));
			String stLine;
			while((stLine = bf.readLine()) != null){
				lineFields = stLine.split(";");
				iLen = lineFields.length;
				if (iLen == 11){
					if (lineFields[6].equals(ORPHANOWNER)){
						hmUserIDOwner.put(lineFields[3] , "ORPHAN");
						hmUserIDOwner.put(lineFields[0] + "$$$" + lineFields[1] , "ORPHAN");
					}else{
						hmUserIDOwner.put(lineFields[3] , lineFields[6]); // serialnumber User, serialnumber owner
						
						hmUserIDOwner.put(lineFields[0] + "$$$" + lineFields[1] , lineFields[6]); // service ++ $$$ + shortname
					}

				}
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public TreeMap<String, String> getHmUserIDOwner() {
		if (hmUserIDOwner == null){
			initMapNew();
		}
		return hmUserIDOwner;
	}



}
