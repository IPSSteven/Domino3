package com.ibm.ereg.recertify;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

public class AdminpParam implements Serializable {
	ArrayList< AdminpParam.AdminpP> alApinp = new ArrayList<AdminpParam.AdminpP>();

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public class AdminpP implements  Serializable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String Server;
		private String certIdFile;
		private String pw;
		private String user;
		private Date expireDate;
		public String getServer() {
			return Server;
		}
		public void setServer(String server) {
			Server = server;
		}
		public String getCertIdFile() {
			return certIdFile;
		}
		public void setCertIdFile(String certIdFile) {
			this.certIdFile = certIdFile;
		}
		public String getPw() {
			return pw;
		}
		public void setPw(String pw) {
			this.pw = pw;
		}
		public String getUser() {
			return user;
		}
		public void setUser(String user) {
			this.user = user;
		}
		public Date getExpireDate() {
			return expireDate;
		}
		public void setExpireDate(Date expireDate) {
			this.expireDate = expireDate;
		}
		
	}
	public ArrayList<AdminpParam.AdminpP> getAlApinp() {
		return alApinp;
	}
	public void setAlApinp(ArrayList<AdminpParam.AdminpP> alApinp) {
		this.alApinp = alApinp;
	}
	
	

}
