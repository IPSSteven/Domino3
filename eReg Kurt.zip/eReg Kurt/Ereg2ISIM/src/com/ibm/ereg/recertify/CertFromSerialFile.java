package com.ibm.ereg.recertify;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.recertify.AdminpParam.AdminpP;

import lotus.domino.AdministrationProcess;
import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class CertFromSerialFile extends NotesThread {
	InputOutputLogger log;


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String s = "D51HUB01\\51\\H\\IBM.ser";
		//s= s.replace("\\", "");\
		CertFromSerialFile cfid = new CertFromSerialFile();
		cfid.start();
	}
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		//Session s = NotesFactory.createSessionWithFullAccess("1Bestfriend!");
		Session s = NotesFactory.createSessionWithFullAccess("Sharpdr3ssedman!");
		Database dbLog;
		int icount = 0;
		long lstart = System.currentTimeMillis();
		try {
			dbLog = CommonFunctions.getLogDB(s);
			log = new InputOutputLogger(s, dbLog, "Recert from serial", LogLevel.FINEST);	
			File [] fs = getFiles();
			for(File f: fs) {

				log.logActionLevel(LogLevel.INFO, "working on file " + f.getName());
				AdminpParam ap = aParam(f);
				ArrayList<AdminpP> al = ap.alApinp;
				for(AdminpP aAp : al) {
					//String aUser = aAp.getUser().toLowerCase();
					//int idx = aUser.indexOf("york");
					//if(idx <0) {
					makeAdminp(s, aAp);
					//}
					icount++;
					if (icount % 200 == 0) {
						System.out.println("Working on " + icount + " request after " + (System.currentTimeMillis() - lstart)+ " millis");
					}
				}
				log.logActionLevel(LogLevel.INFO, "delete file " + f.getName());
				f.delete();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private void makeAdminp(Session sess, AdminpP apD){
		String sRegistrationDir = null; 
		AdministrationProcess ap =null;
		try {

			sRegistrationDir = apD.getCertIdFile();
			ap = sess.createAdministrationProcess(apD.getServer());
			ap.setCertifierFile(apD.getCertIdFile());
			ap.setCertifierPassword(apD.getPw());
			DateTime reCertDate = sess.createDateTime(apD.getExpireDate());
			ap.setCertificateExpiration(reCertDate);
			//Date t = reCertDate.toJavaDate();
			ap.recertifyUser(apD.getUser());

			ap.recycle();
			log.logActionLevel(LogLevel.INFO, "requested recertification of " + apD.getUser()+ " recert date " + reCertDate.getDateOnly() + " successful ");
			reCertDate.recycle();


		} catch (NotesException e) {
			log.logActionLevel(LogLevel.SEVERE, "Error while starting Adminp process (NotesError) for " +  apD.getUser()+ " error msg= "  + e.text  );
			log.logActionLevel(LogLevel.SEVERE, "Certification details: " +  sRegistrationDir + "\\" +
					apD.getCertIdFile() + "-----" + apD.getPw() );			// TODO Auto-generated catch block
			if(ap != null) {

				try {
					ap.recycle();
					log.logActionLevel(LogLevel.SEVERE, "AdministrationProcess recycled "   );
				} catch (NotesException e1) {
					// TODO Auto-generated catch block
					log.logActionLevel(LogLevel.SEVERE, " Error while recycling AdministrationProcess : " + e1.text   );
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
		} catch (Exception e) {
			log.logActionLevel(LogLevel.SEVERE, "Error while starting Adminp process (Common Error) for " +  apD.getUser()  );
			log.logActionLevel(LogLevel.SEVERE, "Cerfication details:" +  sRegistrationDir + "\\" +
					apD.getCertIdFile() + "-----" +apD.getPw() );	
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			if(ap != null) {

				try {
					ap.recycle();
					log.logActionLevel(LogLevel.SEVERE, "AdministrationProcess recycled "   );
				} catch (NotesException e1) {
					// TODO Auto-generated catch block
					log.logActionLevel(LogLevel.SEVERE, " Error while recycling AdministrationProcess : " + e1.text   );
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
		}
	}


	private File[] getFiles() {
		File f = new File(System.getProperty("user.dir"));
		FilenameFilter ff = new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				// TODO Auto-generated method stub
				return name.toLowerCase().endsWith(".ser");
			}
		};

		File [] fs = f.listFiles(ff);
		return fs;
	}



	private AdminpParam aParam (File f) {
		try {
			FileInputStream finp = new FileInputStream(f);
			ObjectInputStream obin = new ObjectInputStream(finp);
			AdminpParam ap = (AdminpParam)obin.readObject();
			obin.close();
			return ap;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}


}
