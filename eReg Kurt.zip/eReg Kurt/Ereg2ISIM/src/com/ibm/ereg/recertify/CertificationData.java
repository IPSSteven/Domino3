package com.ibm.ereg.recertify;


import java.util.TreeMap;

public class CertificationData {
	private TreeMap <String,CertificateConf> CertListConf = new TreeMap< String, CertificateConf>();
	
	public class  CertificateConf{
		private String Server;
		private String CertifierName;
		private String CertIdFile;
		private String CertPW;
		private String CertifierExpirationDate;
		private boolean recertifiyAll;
		private boolean doNoRecertThis;
		
		
		
		public String getServer() {
			return Server;
		}
		public void setServer(String server) {
			Server = server;
		}
		public String getCertifierName() {
			return CertifierName;
		}
		public void setCertifierName(String certifierName) {
			CertifierName = certifierName;
		}
		public String getCertifierExpirationDate() {
			return CertifierExpirationDate;
		}
		public void setCertifierExpirationDate(String certifierExpirationDate) {
			CertifierExpirationDate = certifierExpirationDate;
		}
		public boolean isRecertifiyAll() {
			return recertifiyAll;
		}
		public void setRecertifiyAll(boolean recertifiyAll) {
			this.recertifiyAll = recertifiyAll;
		}
		public String getCertIdFile() {
			return CertIdFile;
		}
		public void setCertIdFile(String certIdFile) {
			CertIdFile = certIdFile;
		}
		public String getCertPW() {
			return CertPW;
		}
		public void setCertPW(String certPW) {
			CertPW = certPW;
		}
		public boolean isDoNoRecertThis() {
			return doNoRecertThis;
		}
		public void setDoNoRecertThis(boolean doNoRecertThis) {
			this.doNoRecertThis = doNoRecertThis;
		}
		
		
	}

	public TreeMap<String, CertificateConf> getCertListConf() {
		return CertListConf;
	}

	public void setCertListConf(TreeMap<String,CertificateConf> certListConf) {
		CertListConf = certListConf;
	}
	
	
}
