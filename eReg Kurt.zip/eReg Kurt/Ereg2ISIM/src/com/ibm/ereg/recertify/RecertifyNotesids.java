package com.ibm.ereg.recertify;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjMailDomainServer;
import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.config.ConfigObjRecertify;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import lotus.domino.AdministrationProcess;
import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.DocumentCollection;
import lotus.domino.Name;

public class RecertifyNotesids extends NotesThread {
	private ConfigObjMaschineProfile confMachPro;
	private ConfigObjRecertify confRecert;
	private Set<Entry<String,String>> DomainServers;
	private final String DEFAULT_EXTENSION = "180";
	private AdminpParam aParam = new AdminpParam();

	//private final String SELECT_FORMULA = "Type = \"Person\" & Certificate != \"\" & @Certificate([Issuer];Certificate)  != \"\" &(@If(@Certificate([IntlExpiration];Certificate)=\"\";@Certificate([Expiration];Certificate);@Certificate([IntlExpiration];Certificate))< @Adjust(@Now; 0;6;0;0;0;0))";
	private final String SELECT_FORMULA = "Type = \"Person\" & Certificate != \"\" & @Certificate([Issuer];Certificate)  != \"\" &(@If(@Certificate([IntlExpiration];Certificate)=\"\";@Certificate([Expiration];Certificate);@Certificate([IntlExpiration];Certificate))< @Adjust(@Now; 0;0;DAYSEXP;0;0;0))";
	private InputOutputLogger log = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RecertifyNotesids rnids = new RecertifyNotesids();
		rnids.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("Sharpdr3ssedman!");
		//Session s = NotesFactory.createSessionWithFullAccess("1Bestfriend!");
		Database dbLog;
		try {
			dbLog = CommonFunctions.getLogDB(s);
			log = new InputOutputLogger(s, dbLog, "Recertify Ids", LogLevel.INFO);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return;
		}


		try {
			getCertData(s);
			processRecert(s);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "error while get configuration");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
		}finally {
			if (log != null){
				LogDocStatus lds = new LogDocStatus(log.getDocLog());
				lds.setOKDone();
				log.closeLog(lds);
			}
		}
	}


	public void getCertData(Session sess) throws Exception{


		String sMachineKey = sess.getEnvironmentString(AllConstants.MACHINEKEY);
		confMachPro = new ConfigObjMaschineProfile(sess, "1>" + sMachineKey);
		confRecert = new ConfigObjRecertify(sess, sMachineKey); // RecertificationExpiredIds(agent) and cmdRC tool document


		try{
			byte bLogLevel = Byte.parseByte(confRecert.getLogLevel()[0]);
			log.setCheckLogLevel(bLogLevel);
		}catch(NumberFormatException ne){
			log.logActionLevel(LogLevel.SEVERE, "Number format exception in log level CMDRC");
		}
		//log.setCheckLogLevel(checkLogLevel);F

		ConfigObjMailDomainServer confMailDomainServ = new ConfigObjMailDomainServer(sess);
		HashMap<String, String> hmServers = confMailDomainServ.getNabServers_domain();


		// find the server in scope for this current machine
		if(confRecert.getDomainFilter() == null || confRecert.getDomainFilter()[0].isEmpty()){
			log.logActionLevel(LogLevel.INFO, "No filter for this machine, all servers are in scope");
			DomainServers = hmServers.entrySet(); // no filter .. all servers are regarded
		}else{
			HashMap<String, String> tmpHm = new HashMap<String, String>();
			String stFormula = confRecert.getDomainFilter()[0];
			log.logActionLevel(LogLevel.INFO, "only regard these server acordding the filter : " + stFormula
					);
			Vector<String> vRes = sess.evaluate(stFormula, log.getDocLog());
			if (vRes == null || vRes.isEmpty() || (vRes.size() >0 && vRes.elementAt(0).isEmpty())){
				DomainServers = hmServers.entrySet();
			}else{
				// filter only the server for this machine according the config
				HashSet<String> tmpDomains = new HashSet<String>(vRes);
				Iterator <String>it = hmServers.keySet().iterator();
				String key;
				while(it.hasNext()){
					key = it.next();
					if (tmpDomains.contains(key)){
						tmpHm.put(key, hmServers.get(key));
					}
				}
				DomainServers = tmpHm.entrySet();
			}			
		}


		log.logActionLevel(LogLevel.INFO, "Get configuration finished successful, server to be handle: " + DomainServers.toString());
	}

	public void processRecert(Session sess){
		Database dbNab = null;
		DocumentCollection dcc2recert = null;
		Entry<String, String> entrServer = null;
		String selectFormula = null;
		String recertall;
		String DoNotRecert;
		HashSet<String> hsServerDone = new HashSet<String>();
		Iterator <String>itServerDone;
		StringBuilder sbServerDone = new StringBuilder();

		String sExpDays = confRecert.getExpirationIdDay();
		if (DomainServers == null) return;
		Iterator<Entry<String,String>> itServer = DomainServers.iterator();
		int iNum = 0;
		while (itServer.hasNext()){
			entrServer = itServer.next();
			//if(!entrServer.getValue().equals("D06ML400")) continue;
			if (!hsServerDone.add(entrServer.getValue())){
				continue;
			}
			dbNab = CommonFunctions.getDatabase(sess,entrServer.getValue(), "names.nsf");
			if (dbNab == null){
				log.logActionLevel(LogLevel.SEVERE, "Nab for " + entrServer.getValue() + "not found");
			}else{
				try {
					selectFormula = SELECT_FORMULA.replaceAll("DAYSEXP", sExpDays==null ?  DEFAULT_EXTENSION: sExpDays);
					recertall = getRecertAllClause();
					if (!recertall.isEmpty()) selectFormula = "(" + selectFormula + ") | (" + recertall + ")";
					DoNotRecert = getDoNotRecertClause();
					if(!DoNotRecert.isEmpty()) selectFormula = "(" + selectFormula + ") & (" + DoNotRecert + ")";
					log.logActionLevel(LogLevel.INFO, "Search with  " + selectFormula);
					pln(selectFormula);

					dcc2recert = dbNab.search(selectFormula);
					pln("Found " + dcc2recert.getCount() + " ids to recertify for domain " + entrServer.getKey() + " on server " + entrServer.getValue());
					log.logActionLevel(LogLevel.INFO, "Found " + dcc2recert.getCount() + " ids to recertify for domain " + entrServer.getKey() + " on server " + entrServer.getValue());

					recertificateIds(sess, entrServer.getValue(), dcc2recert);

					serOut(entrServer.getKey() + iNum +".ser"); // to be changed;
					aParam = new AdminpParam();
					dcc2recert.recycle();
					iNum++;

				} catch (NotesException e) {
					// TODO Auto-generated catch block
					log.logActionLevel(LogLevel.SEVERE, "Error while searching in NAB");
					log.logActionLevel(LogLevel.SEVERE, e.getMessage());
					e.printStackTrace();
				}
			}
		}

		itServerDone = hsServerDone.iterator();
		if(itServerDone != null){
			while(itServerDone.hasNext()){
				sbServerDone.append(itServerDone.next());
				sbServerDone.append(";");
			}
			log.logActionLevel(LogLevel.INFO, " Recertification finished for : " + sbServerDone.substring(0, sbServerDone.length()-1));

		}



	}

	private void recertificateIds (Session sess, String server, DocumentCollection dcc2Recert){
		Document docRecycle;
		String stFullName;
		Vector<String> vFullName;
		int idx;
		int icount =0;
		long lstart = System.currentTimeMillis();
		String stCert;
		Name nmFullName;
		Document doc2Recert = null;
		try {
			doc2Recert = dcc2Recert.getFirstDocument();
		} catch (NotesException e) {
			log.logActionLevel(LogLevel.SEVERE, "Error while reading document in NAB");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
		}

		while (doc2Recert != null && icount < 10000){
			try {
				vFullName = doc2Recert.getItemValue("Fullname");
				if(!vFullName.isEmpty()) {
					stFullName = (String)doc2Recert.getItemValue("Fullname").elementAt(0);
					nmFullName = sess.createName(stFullName); // firstname lastname/Germany/IBM
					stFullName = nmFullName.getAbbreviated();
					nmFullName.recycle();
					idx = stFullName.indexOf("/");
					stCert = stFullName.substring(idx+1).toLowerCase(); // /Germany/IBM
					CertificationData.CertificateConf certConf = confRecert.getCertificationConfig(stCert);

					if(certConf == null){
						log.logActionLevel(LogLevel.SEVERE, "No Cert configuration found for " + stFullName);
					}else{
						certConf.setServer(server);
						DateTime recertDate = getRecertTime(sess,  certConf);
						//pln(stFullName);

						makeAdminp(sess, stFullName, certConf,recertDate );
						//makeAdminpSer(sess, stFullName, certConf,recertDate );
						log.logActionLevel(LogLevel.FINE,"Create Adminp for : " + stFullName);
						recertDate.recycle();
					}
				}


			} catch (NotesException e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, "Error during recertification");
				log.logActionLevel(LogLevel.SEVERE, e.getMessage());

				e.printStackTrace();
			}



			try {
				docRecycle = doc2Recert;
				doc2Recert = dcc2Recert.getNextDocument(doc2Recert);
				docRecycle.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, "Error while get next document");
				log.logActionLevel(LogLevel.SEVERE, e.getMessage());
				e.printStackTrace();
				doc2Recert = null;
			}
			icount ++;
			if (icount % 200 == 0)System.out.println ("Working on " + icount + " document after "+ (System.currentTimeMillis()-lstart ) + " millisec");
		}



	}

	private DateTime getRecertTime(Session sess, CertificationData.CertificateConf conf){


		String stRecertDate = conf.getCertifierExpirationDate();
		DateTime datReturn = null;
		Date recertDate = new Date();

		if (stRecertDate.trim().isEmpty()){
			try {
				log.logActionLevel(LogLevel.FINE, "Date is empty in certification config. Create default date today + 730 days");
				datReturn = sess.createDateTime(recertDate);
				datReturn.setNow();
				datReturn.adjustDay(730);
			} catch (NotesException e) {
				log.logActionLevel(LogLevel.SEVERE, "Error while creating date.");
				log.logActionLevel(LogLevel.SEVERE, e.getMessage());
				e.printStackTrace();
			}
		}else{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
			try {
				log.logActionLevel(LogLevel.INFO, "Date is set to " + stRecertDate);
				recertDate = sdf.parse(stRecertDate);
				datReturn = sess.createDateTime(recertDate);

			} catch (ParseException e) {
				log.logActionLevel(LogLevel.SEVERE, "Error while parsing the date.");
				log.logActionLevel(LogLevel.SEVERE, e.getMessage());
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NotesException e) {
				log.logActionLevel(LogLevel.SEVERE, "Error while creating date.");
				log.logActionLevel(LogLevel.SEVERE, e.getMessage());
				e.printStackTrace();
			}
		}

		return datReturn;

	}

	private void makeAdminp(Session sess, String user, CertificationData.CertificateConf conf, DateTime reCertDate){
		String sRegistrationDir = null; 
		AdministrationProcess ap =null;
		try {
			sRegistrationDir = confMachPro.getRegistrationDir()[0] ;
			ap = sess.createAdministrationProcess(conf.getServer());
			ap.setCertifierFile(confMachPro.getRegistrationDir()[0] + "\\" + conf.getCertIdFile());
			ap.setCertifierPassword(conf.getCertPW());
			ap.setCertificateExpiration(reCertDate);
			//Date t = reCertDate.toJavaDate();
			ap.recertifyUser(user);
			ap.recycle();
			log.logActionLevel(LogLevel.FINE, "requested recertification of " + user + " recert date " + reCertDate.getDateOnly() + " successful ");


		} catch (NotesException e) {
			log.logActionLevel(LogLevel.SEVERE, "Error while starting Adminp process (NotesError) for " +  user + " error msg= "  + e.text  );
			log.logActionLevel(LogLevel.SEVERE, "Certification details: " +  sRegistrationDir + "\\" +
					conf.getCertIdFile() + "-----" + conf.getCertPW() );			// TODO Auto-generated catch block
			if(ap != null) {

				try {
					ap.recycle();
					log.logActionLevel(LogLevel.SEVERE, "AdministrationProcess recycled "   );
				} catch (NotesException e1) {
					// TODO Auto-generated catch block
					log.logActionLevel(LogLevel.SEVERE, " Error while recycling AdministrationProcess : " + e1.text   );
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
		} catch (Exception e) {
			log.logActionLevel(LogLevel.SEVERE, "Error while starting Adminp process (Common Error) for " +  user  );
			log.logActionLevel(LogLevel.SEVERE, "Cerfication details:" +  sRegistrationDir + "\\" +
					conf.getCertIdFile() + "-----" + conf.getCertPW() );	
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			if(ap != null) {

				try {
					ap.recycle();
					log.logActionLevel(LogLevel.SEVERE, "AdministrationProcess recycled "   );
				} catch (NotesException e1) {
					// TODO Auto-generated catch block
					log.logActionLevel(LogLevel.SEVERE, " Error while recycling AdministrationProcess : " + e1.text   );
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
		}
	}
	private void makeAdminpSer(Session sess, String user, CertificationData.CertificateConf conf, DateTime reCertDate){
		AdminpParam.AdminpP apData = aParam.new AdminpP();



		try {
			apData.setServer(conf.getServer());
			apData.setCertIdFile(confMachPro.getRegistrationDir()[0] + "\\" + conf.getCertIdFile());
			apData.setPw(conf.getCertPW());
			apData.setExpireDate(reCertDate.toJavaDate());
			apData.setUser(user);
			aParam.getAlApinp().add(apData);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}






	}

	private String getRecertAllClause(){
		if(confRecert.getAryRecertAll() == null) return "";
		Iterator<String> it = confRecert.getAryRecertAll().iterator(); 
		StringBuilder sb = new StringBuilder();
		sb.append("@LowerCase(@Name([Abbreviate];@Certificate([Issuer];Certificate))) = ");
		while (it.hasNext()){
			sb.append("\"/");
			sb.append(it.next());
			sb.append("\":");
		}
		int iLen = sb.length() -1 >0 ?  sb.length() -1: 0;
		return sb.substring(0, iLen);
	}

	private String getDoNotRecertClause(){
		if(confRecert.getAryDoNotRecert() == null) return "";
		Iterator<String> it = confRecert.getAryDoNotRecert().iterator(); 
		StringBuilder sb = new StringBuilder();
		sb.append("@IsNotMember(@LowerCase(@Name([Abbreviate];@Certificate([Issuer];Certificate)));");
		while (it.hasNext()){
			sb.append("\"/");
			sb.append(it.next());
			sb.append("\":");
		}
		int iLen = sb.length() -1 >0 ?  sb.length() -1: 0;
		return sb.substring(0, iLen) + ")";
	}
	private void pln(String s){
		System.out.println(s);
	}

	public InputOutputLogger getLog() {
		return log;
	}

	public void setLog(InputOutputLogger log) {
		this.log = log;
	}

	private void serOut(String filename) {
		FileOutputStream fout;
		try {
			fout = new FileOutputStream(filename);
			ObjectOutputStream Oout = new ObjectOutputStream(fout);
			Oout.writeObject(aParam);
			Oout.flush();
			Oout.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}

}
