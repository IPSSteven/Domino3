package com.ibm.ereg.sync;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.Enumeration;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjDatabase;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.EmbeddedObject;
import lotus.domino.NotesException;
import lotus.domino.NotesThread;
import lotus.domino.RichTextItem;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntryCollection;

//TODO Is there a better way to deal with @SuppressWarnings?
@SuppressWarnings({"rawtypes", "unchecked"})
public class SyncGateway extends NotesThread {
	
	private InputOutputLogger logger;
	private ConfigObjDatabase cfgNABDB;
	private ConfigObjNCOUAR cfgUAR;
	private Database dbLog;
	private Database dbNab;
	private Session session;
	private Vector encryptionKey, uarViewColumns;
	private View vwNABLookup, vwUARSearch;
	boolean idFileAttached, passwordExists, mailChanges, saveDoc;
	boolean domainChanges, upFlag1 ,upFlag2, upFlagMissing;
	ViewEntryCollection vec;
	String searchKey, mailDomain, mailSystem, idFileInVault;
	double hasAttachment;
	
	public static void main(String[] args) {
		//SyncGateway sg = new SyncGateway();
		//sg.start();
	}
	
	@Override
	public void runNotes() throws NotesException {
		//super.runNotes();
	}
	
	public SyncGateway(Session sess) {
		session = sess;
		Document docNAB, docUAR;
		String stClassName;
		//Get Log Document for SyncGateway
		try {
			getTheLogger();
			encryptionKey = new Vector() ;
			encryptionKey.addElement(AllConstants.NCOUAR_ENCRYPTION_KEY);
		} catch (Exception e1) {
			e1.printStackTrace();
			return;
		}
		LogDocStatus lds = new LogDocStatus(logger.getDocLog());
		lds.setOKRunning();
		
		lds.setOKDone();
		logger.closeLog(lds);

		try {
			//Initialize Variables
			docNAB = null;
			
			logger.logActionLevel(LogLevel.INFO, "Agent Running as : " + session.getEffectiveUserName());
			getDatabases();
			
			vwNABLookup = dbNab.getView(AllConstants.NABVIEWFORSYNCGATEWAY);
			vwUARSearch = cfgUAR.getVwITIMEXPORT("IBM");
			
			logger.logActionLevel(LogLevel.INFO, "NAB Entry Collection Count : " + vwNABLookup.getEntryCount());
			
			// Loop through vwNABLookup, Search vwUARSearch for Match and process
			docNAB = vwNABLookup.getFirstDocument();
			logger.logActionLevel(LogLevel.INFO, "Looping through NAB Lookup View");
			
			while (docNAB != null) {
				docUAR = null;
				idFileAttached = false;
				mailChanges = false;
				domainChanges = false;
				upFlag1 = false;
				upFlag2 = false;
				upFlagMissing = false;
				saveDoc = false;
				searchKey = (String) docNAB.getItemValue("ShortName").lastElement();
				vec = vwUARSearch.getAllEntriesByKey(searchKey, true);
				String uarHistory = "";
				
				if ((vec != null) && (vec.getCount() == 1 )) {
					logger.logActionLevel(LogLevel.INFO, "######");
					logger.logActionLevel(LogLevel.INFO, "Found Match for : " + searchKey);
					
					uarViewColumns = vec.getFirstEntry().getColumnValues();
					mailDomain = (String) uarViewColumns.get(3); 
					hasAttachment = (Double) uarViewColumns.get(10);
					mailSystem = (String) uarViewColumns.get(14);
					idFileInVault = (String) uarViewColumns.get(16);
					
					logger.logActionLevel(LogLevel.INFO, "   - Mail Domain Before                 : " + mailDomain);
					logger.logActionLevel(LogLevel.INFO, "   - Mail System Before                 : " + mailSystem);
					logger.logActionLevel(LogLevel.INFO, "   - Has Attachment Before              : " + hasAttachment);
					logger.logActionLevel(LogLevel.INFO, "   - Upload Flag (idFileInVault) Before : " + idFileInVault);
					
					if (mailSystem.equalsIgnoreCase("Notes")) {
						logger.logActionLevel(LogLevel.INFO, "   - mailSystem = Notes                 : Changing to 'Other' (3)");
						mailChanges = true;
					}
					if (mailDomain.startsWith("IDP") || mailDomain.startsWith("OCEAN")){
						logger.logActionLevel(LogLevel.INFO, "   - mailDomain = " + mailDomain + "               : Changing to IBM");
						domainChanges = true;
					}
					
					// TODO - What do we need to do if the upload flag is missing.
					if(idFileInVault.equalsIgnoreCase("")) {upFlagMissing = true;}
					
					
					// ID File Attached AND "Upload" flag is 1 - change "Upload" flag to 0.
					if (idFileAttached && (idFileInVault.equalsIgnoreCase("1"))) {
						logger.logActionLevel(LogLevel.INFO, "   - ID File Attached & Upload Flag = 1 : Changing Upload Flag to 0");
						upFlag1 = true;
					}
					
					// ID File NOT Attached AND "Upload" flag is 0 - change "Upload" flag to 1.
					if (!idFileAttached && (idFileInVault.equalsIgnoreCase("0"))) {
						logger.logActionLevel(LogLevel.INFO, "   - ID File NOT Attached & Upload Flag = 0 : Changing Upload Flag to 1");
						upFlag2 = true;
					}
					
					// ID File Attached AND "Upload" flag is 0 - do nothing.
					// ID File NOT Attached AND "Upload" flag is 1 - do nothing.
					
					// Process changes
					if (mailChanges || domainChanges || upFlag1 || upFlag2) {
						docUAR = vec.getFirstEntry().getDocument();
						
						checkIDFileExists(vec.getFirstEntry().getDocument());
						logger.logActionLevel(LogLevel.INFO, "   - User ID File Attached              : " + idFileAttached);
						
						// TODO - Removing this for now due to encryption issue.
						//if (idFileAttached) {passwordExists = checkPassword(docUAR);}
						
						//Something needs to be changed in NCOUAR Document so need to save it.
						saveDoc = true;
						
						if (mailChanges) {
							docUAR.replaceItemValue("MailSystem", "3"); // 3 = Other
							uarHistory = uarHistory + "Mail System is 'Notes' so changing field MailSystem to Other (3).  ";
						}
						
						if (domainChanges) {
							docUAR.replaceItemValue("Domain", "IBM");
							docUAR.replaceItemValue("ASODomain", "IBM");
							uarHistory = uarHistory + "The Mail Domain is IDP* or OCEAN so changing fields Domain and ASODomain to 'IBM'.  ";
						}
						
						if (upFlag1) {
							docUAR.replaceItemValue("idFileInVault", "0");
							uarHistory = uarHistory + "ID File Attached AND 'Upload' flag is 1 - change 'Upload' flag to 0 - Field idFileInVault change to 0.  ";
						}
						if (upFlag2) {
							docUAR.replaceItemValue("idFileInVault", "1");
							uarHistory = uarHistory + "ID File NOT Attached AND 'Upload' flag is 0 - change 'Upload' flag to 1 - Field idFileInVault change to 1.  ";
						}
					}
					
					/*
 					// Can remove this block of code as I replaced it with all the boolean flags above.
					if (idFileAttached) {
						//If idFileInVault is not in doc, create it then set value.
						if(!docUAR.hasItem("idFileInVault")) {
							docUAR.appendItemValue("idFileInVault");
							logger.logActionLevel(LogLevel.INFO, "Changed : 'idFileInVault' not found, adding blank item placeholder.");
							saveDoc = true;
						}
						//If ID File is attached AND idFileInValut is 1 or empty then change it to 0 and Save.
						if (idFileAttached && (idFileInVault.equalsIgnoreCase("1") || idFileInVault.equalsIgnoreCase(""))) {
							docUAR.replaceItemValue("idFileInVault", "0");
							logger.logActionLevel(LogLevel.INFO, "Changed : ID File is Attached AND idfileInVault from 1/empty to 0");
							saveDoc = true;
						}
					} else { 
						//If ID File is NOT attached AND idFileInValut is 0 or empty then change it to 1 and Save.
						if (!idFileAttached && (idFileInVault.equalsIgnoreCase("0") || idFileInVault.equalsIgnoreCase(""))) {
							
							logger.logActionLevel(LogLevel.INFO, "Changed : ID File is NOT Attached AND idfileInVault from 0/empty to 1");
							saveDoc = true;
						}
					} // idFileAttached
					*/
					
					// NCOUAR Document has been altered so append history and save it.
					if (saveDoc) {
						// TODO - Append to the document History field.
						// TODO - Prepend Date/Time stamp to new history item appending.
						Timestamp timestamp = new Timestamp(System.currentTimeMillis());
						Vector historyItems = docUAR.getItemValue("History");
						historyItems.addElement(timestamp + ":  " + uarHistory);
						docUAR.replaceItemValue("History", historyItems);
						
						if (!docUAR.isEncrypted()) {
							// Doc is not encrypted.
							encryptionKey = new Vector() ;
							encryptionKey.addElement(AllConstants.NCOUAR_ENCRYPTION_KEY);
							docUAR.setEncryptionKeys(encryptionKey);
							docUAR.encrypt();
							docUAR.save() ;
							logger.logActionLevel(LogLevel.INFO, "   - UAR Doc Encrypted & Saved");
						} else {
							// Doc is encrypted
							docUAR.save();
							logger.logActionLevel(LogLevel.INFO, "    - UAR Doc Saved");
						}
					} // saveDoc
					
					docUAR.recycle();
					docNAB = vwNABLookup.getNextDocument(docNAB);
				} else if (vec.getCount() > 1) {
					logger.logActionLevel(LogLevel.INFO, "Duplicate ShortName : " + searchKey +" : Matches Found : " + vec.getCount());
					docNAB = vwNABLookup.getNextDocument(docNAB);
				} else if (vec.getCount() == 0) {
					//No Match Found - Move to next NAB Document
					docNAB = vwNABLookup.getNextDocument(docNAB);
				}// if ((vec != null) && (vec.getCount() == 1 )) 
			} // While
		} catch (NotesException ne) {
			//StringWriter writer = new StringWriter();
            //PrintWriter printWriter= new PrintWriter(writer);
			//ne.printStackTrace(printWriter);
			//logger.logActionLevel(LogLevel.SEVERE, writer.toString());
			logger.logActionLevel(LogLevel.SEVERE, "SyncGateway - Main - NotesExcepction: " + ne.toString());
			ne.printStackTrace();
		} catch (Exception ex) {
			logger.logActionLevel(LogLevel.SEVERE, "SyncGateway - Excepction: " + ex.toString());
			ex.printStackTrace();
		} // Try/Catch
		
		stClassName = "com.ibm.ereg.sync.SyncGateway";
		logger.logActionLevel(LogLevel.INFO, "Process finished for : " + stClassName);
		
		try {
			session.recycle();
			recyleDominoObjects();
			logger.closeLog(lds);
		} catch (NotesException e) {
			logger.logActionLevel(LogLevel.SEVERE, "SyncGateway - Recycle - NotesExcepction: " + e.toString());
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unused")
	private boolean checkPassword(Document uarDoc) {
		boolean returnValue = false;
		try {
			if (uarDoc.isEncrypted()) {
				logger.logActionLevel(LogLevel.INFO, "   - checkPassword - uarDoc Encrypted? : True");
			} else {
				logger.logActionLevel(LogLevel.INFO, "   - checkPassword - uarDoc Encrypted? : False");
			}
			
			if (uarDoc.getItemValueString("Password").length() > 0 ){
				logger.logActionLevel(LogLevel.INFO, "   - checkPassword - Password.length > 0? : True");
				passwordExists = true;
			} else {
				logger.logActionLevel(LogLevel.INFO, "   - checkPassword - Password.length > 0? : False");
			}
		} catch (NotesException e) {
			logger.logActionLevel(LogLevel.SEVERE, "checkPassword - NotesExcepction: " + e.toString());
			e.printStackTrace();
		}
		return returnValue;
	}

	private void recyleDominoObjects() throws NotesException {
		try {
			vec.recycle();
			vwNABLookup.recycle();
			vwUARSearch.recycle();
			cfgUAR.recycle();
			cfgNABDB.recycle();
			//dbLog.recycle();
			//dbNab.recycle();
			//docNAB.recycle();
			logger.logActionLevel(LogLevel.INFO, "Finished Recycling ViewEntryCollectoin vec, NotesView vwNABLookup, NotesView vwUARSearch, Config DBs for cfgUAR & cfgNABDB.");
		} catch (NotesException ne) {
			StringWriter writer = new StringWriter();
            PrintWriter printWriter= new PrintWriter(writer);
			ne.printStackTrace(printWriter);
			logger.logActionLevel(LogLevel.SEVERE, writer.toString());
			ne.printStackTrace();
		}
	}

	private void checkIDFileExists(Document uarDoc) {
		Vector eoVector;
		Enumeration vectorList;
		RichTextItem idFile;
		String uarIDFileName = null;
		
		try {
			if (uarDoc.hasItem("IdFile")) {
				idFile = (RichTextItem) uarDoc.getFirstItem("IdFile");
				eoVector = idFile.getEmbeddedObjects();
				vectorList = eoVector.elements();
				
				while (vectorList.hasMoreElements()) {
					EmbeddedObject eo = (EmbeddedObject) vectorList.nextElement();
					switch (eo.getType()) {
					case EmbeddedObject.EMBED_ATTACHMENT:
						uarIDFileName = eo.getName();
						if ((uarIDFileName.endsWith(".ID"))) {
							idFileAttached = true;
						}
						break;
					}
				}
			}
		} catch (NotesException e) {
			e.printStackTrace();
		}
	}

	private void getTheLogger() throws Exception {
		try {
			dbLog = CommonFunctions.getLogDB(session);
			logger = new InputOutputLogger(session, dbLog, "Sync Gateway", LogLevel.FINEST);
			logger.setAgent("ID Vault Uploads for Mail Gateway Users");
		} catch (Exception e1) {
			e1.printStackTrace();
			throw e1;
		}
	}
	
	private void getDatabases() throws Exception {
		cfgNABDB = new ConfigObjDatabase(session, "4>IBM");
		cfgUAR = new ConfigObjNCOUAR(session, logger);
		String nabServer = cfgNABDB.getFilePath();
		String nabFilename = cfgNABDB.getFilePath1Rep();
		dbNab =  CommonFunctions.getDatabase(session, nabServer, nabFilename);
		//logger.logActionLevel(LogLevel.INFO, "NAB DB : " + nabServer + " : " + nabFilename);
		//logger.logActionLevel(LogLevel.INFO, "UAR DB : " + cfgUAR.getDbNCOUAR("IBM").getFileName() + " : " + cfgUAR.getDbNCOUAR("IBM").getFilePath());
	}

/*	
	private void setupSession() throws NotesException {
		ph = new PasswordHandler();
		pw = this.ph.getPw("Notes");
		session = NotesFactory.createSessionWithFullAccess(pw);
		encryptionKey = new Vector() ;
		encryptionKey.addElement(AllConstants.NCOUAR_ENCRYPTION_KEY);
	}
*/	
}