package com.ibm.ereg.terminator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObj;
import com.ibm.ereg.config.ConfigObjTerminate;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Item;
import lotus.domino.NotesException;
import lotus.domino.RichTextItem;
import lotus.domino.Session;

public class EregRequestTerminator {
	private static boolean DEBUG = true;
	public final String TERMINATE_SUBJECT = "46>Terminate_Unresolved"; 
	private InputOutputLogger log;
	private Database dbLog;
	private Session session;
	private Document docRecyle;
	private LogDocStatus lds;
	public ArrayList<ConfigObjTerminate> arycfgTerms;
	private DateTime dteNow;


	public EregRequestTerminator(Session s){
		session = s;
		try {
			dteNow = s.createDateTime("ToDay");
			dbLog = CommonFunctions.getLogDB(s);
			log = new InputOutputLogger(s, dbLog, "Terminate Iimeout Request", LogLevel.INFO);
			if (DEBUG) log.setAgent("TerminateTimeoutRequests");
			lds = new LogDocStatus(log.getDocLog());
			lds.setOKRunning();
			log.logActionLevel(LogLevel.INFO,"Found the configuration");
			ConfigObj cb = new ConfigObj(s); 

			DocumentCollection dcc = cb.getVwConfig().getAllDocumentsByKey(TERMINATE_SUBJECT, false);
			Document docConf = dcc.getFirstDocument();
			log.logActionLevel(LogLevel.INFO, "Found " + dcc.getCount() + "configurations");
			String stSearch = null;
			arycfgTerms = new ArrayList<ConfigObjTerminate>();


			while (docConf != null){
				stSearch = docConf.getItemValueInteger("Type")+ ">" +docConf.getItemValueString("Subject");
				arycfgTerms.add(new ConfigObjTerminate(s,stSearch, log));
				docRecyle = docConf;
				docConf = dcc.getNextDocument(docConf);
				docRecyle.recycle();

			}
			
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void terminateRequests(){
		String stformula = null;
		String stReturnFormula = null;
		String stUpdate = null;
		DocumentCollection dcc = null;
		Document docLog = null;
		Vector<String> vRes;
		int iCounter = 0;
	
		ConfigObjTerminate cfg;
		if(arycfgTerms== null){
			log.logActionLevel(LogLevel.WARNING, "No configuration found");
			return;
		}
		Iterator<ConfigObjTerminate> it = arycfgTerms.iterator();
		while(it.hasNext()){
			cfg = it.next();
		
	
				log.logActionLevel(LogLevel.INFO, "Searchformula ; " + stformula);
				try {
					stformula = cfg.getSearchFormula();
					stReturnFormula = cfg.getReturnFormula();
					dcc = dbLog.search(stformula);
					log.logActionLevel(LogLevel.INFO, "Found " + dcc.getCount() + " documents for "+ cfg.getSubject() );
					docLog = dcc.getFirstDocument();
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					log.logActionLevel(LogLevel.SEVERE, "Notes Exception during search : " + e.getMessage());
	
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					log.logActionLevel(LogLevel.SEVERE, "Exception during search : " + e.getMessage());
					
					e.printStackTrace();
				}

				iCounter = 0;
				while(docLog != null){
					try {
						vRes= session.evaluate(stReturnFormula, docLog);
						stUpdate = vRes.firstElement();
						if(docLog.getFirstItem("Body").getType() == Item.RICHTEXT){
							RichTextItem body = (RichTextItem)docLog.getFirstItem("Body");
							body.addNewLine(2);
							 body.appendText( "*   *   *   *   *   *   *   *   *");
							 dteNow.setNow();
							 body.appendText(dteNow.getDateOnly() + " " + dteNow.getLocalTime() + " >>>> update by: " +  session.getUserName() + ": " + stUpdate);
						}else{
							docLog.appendItemValue("Body", "\n\n" + "*   *   *   *   *   *   *   *   *" +"\n\n" + dteNow.getDateOnly() + " " + dteNow.getLocalTime() +
								" >>> update by: "  + session.getUserName() + ": " + stUpdate);
						}
						//docLog.replaceItemValue("UpdateStatus", stUpdate);
						log.logActionLevel(LogLevel.INFO, "Terminated request for ID: Type=" + docLog.getItemValueString("Type") + " Domain=" + docLog.getItemValueString("MailDomain") + ", ShortName="+
								docLog.getItemValueString("ShortName"));
						docLog.replaceItemValue("Status_old", docLog.getItemValueString("Status"));
						docLog.replaceItemValue("Status", "Update");
			
						docLog.replaceItemValue("UpdateStatus_old", docLog.getItemValueString("UpdateStatus"));
						docLog.replaceItemValue("UpdateStatus", stUpdate);
						
						docLog.replaceItemValue("ErrorCode_old", docLog.getItemValueString("ErrorCode"));
						docLog.replaceItemValue("ErrorCode", "");
						docLog.save();
						
					} catch (NotesException e) {
						// TODO Auto-generated catch block
						log.logActionLevel(LogLevel.SEVERE, "NotesException during processing : " + e.getMessage());
						
						e.printStackTrace();
					}
					
					
					try {
						docLog = dcc.getNextDocument(docLog);
						docRecyle = docLog;
						docRecyle.recycle();
						iCounter++;
					} catch (NotesException e1) {
						// TODO Auto-generated catch block
						log.logActionLevel(LogLevel.SEVERE, "NotesException during get next document -> leave loop : " + e1.getMessage());
						
						e1.printStackTrace();
						break;
					}
			
					
					try {
						log.logActionLevel(LogLevel.INFO, "Terminated sucessful " + iCounter+ " documents for "+ cfg.getSubject() );
					} catch (Exception e) {
						// TODO Auto-generated catch block
						log.logActionLevel(LogLevel.SEVERE, "NotesException during logging : " + e.getMessage());
						
						e.printStackTrace();
					}
				} 
			
				
	
		} 
	}

	public void close (){
		lds.setOKDone();
		log.closeLog(lds);
	}

}
