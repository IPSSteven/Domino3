package com.ibm.ereg.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

public class AnalyseLog {
	public BufferedReader bf =null;
	HashMap<String,String> hmlog= null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnalyseLog al = new AnalyseLog();
		al.hmlog = new HashMap<String, String>();
		String line;
		boolean bfirst = false;
		String[] Dummy;
		StringBuffer sb = null;
		String IdOld = null; 
		try {
			al.bf = new BufferedReader(new FileReader("c:\\temp\\upload.txt"));
			sb = new StringBuffer();
			while((line = al.bf.readLine()) != null){
				if(line.indexOf("@")>0){
					
					Dummy = line.split(" ");
					
					
					
					if (!bfirst){
						bfirst = true;
						IdOld = Dummy[5];
						sb = new StringBuffer();
						for (int i= 6; i< Dummy.length; i++){
							sb.append(Dummy[i] + " ");
						}
					}else{
						
						if (al.hmlog.get(IdOld) == null){
							al.hmlog.put(IdOld,sb.toString());
						}
						IdOld =  Dummy[5];
						sb = new StringBuffer();
						for (int i= 6; i< Dummy.length; i++){
							sb.append(Dummy[i] + " ");
						}
					}
				}else{
					sb.append(line + ",");
				}
				
			}
			if (al.hmlog.get(IdOld) == null){
				al.hmlog.put(IdOld,sb.toString());
			}
			
			BufferedWriter bf = new BufferedWriter(new FileWriter("c:/temp/upload.out"));
			Iterator<String> it = al.hmlog.keySet().iterator();
			while(it.hasNext()){
				String key = it.next();
				bf.write(key + ":" + al.hmlog.get(key)+ "\r\n");
			}
			bf.flush();
			bf.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
