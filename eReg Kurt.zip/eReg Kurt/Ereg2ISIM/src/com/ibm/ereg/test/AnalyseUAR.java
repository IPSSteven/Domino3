package com.ibm.ereg.test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjCountryTable;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;
import lotus.domino.Name;

public class AnalyseUAR extends NotesThread {
	private Session session;
	private Database dbLog;
	private String pw;
	//private Document docLog;
	private InputOutputLogger log;
	private String [] domains;


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnalyseUAR aUar = new AnalyseUAR();
		aUar.pw = args[0];
		aUar.domains = new String[args.length-1];
		for(int i = 1; i < args.length; i++){
			aUar.domains[i-1] = args[i];
		}

		aUar.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		session = NotesFactory.createSessionWithFullAccess(this.pw);
		String stFullName;
		String stASODomain;
		String stCountry;
		String stC;
		String [] dummy;
		Document doc;
		try {
			getLogDoc();

			BufferedWriter bw = new BufferedWriter(new FileWriter("c:/ereg/UAR/AnalyseUAR.txt"));

			ConfigObjNCOUAR cfgNCOUAR = new ConfigObjNCOUAR(session,log);
			ConfigObjCountryTable cfgCTable = new ConfigObjCountryTable(session);
			//View vwExport = cfgNCOUAR.getVwITIMEXPORT();
			//ViewEntryCollection vec = vwExport.getAllEntries();

			for(String sDom:domains){
				View vwExport = cfgNCOUAR.getVwITIMEXPORT(sDom);

				ViewEntryCollection vec = vwExport.getAllEntriesByKey(sDom);
				long lcount = vec.getCount();
				long l = 0;
				ViewEntry veRec = null;
				ViewEntry ve = vec.getFirstEntry();
				int iPos;
				Name nName  = null;
				String stClassification  = null;
				String stCountryNumber = null;
				String stOwner = null;
				String stShortname = null;
				String stEmpNum = null;
				StringBuffer sb = null;
				String stComment;
				boolean bUpdate = false;
				boolean bUpdateDomain = false;
				String [] stArray;
				String stService;
				while (ve != null){


					stFullName = (String)ve.getColumnValues().elementAt(1);

					nName = session.createName(stFullName);
					if (nName != null){
						stFullName = nName.getAbbreviated();
						nName.recycle();
					}
					stClassification = (String)ve.getColumnValues().elementAt(9);
					stASODomain = (String)ve.getColumnValues().elementAt(5);
					stCountryNumber = cfgCTable.getCountryNumber(stASODomain);
					stOwner = (String)ve.getColumnValues().elementAt(6);
					if (stOwner.length() >6){
						stComment = "Owner already 9 digit long";
						bUpdate = false;
					}else{
						stOwner = (String)ve.getColumnValues().elementAt(6) + stCountryNumber;
						if (stOwner.length() ==9){
							bUpdate = true;
							stComment = "";
						}else{
							stComment = "Owner already 9 digit <> 9";
						}

					}

					stArray = stFullName.split("/");
					if (stArray.length >=2 ){
						stCountry = stArray[1];
						if (stCountry.contains("=")){
							stArray = stCountry.split("=");
							stCountry = stArray[1];
						}
						stService = cfgCTable.getIBMCodeByCountryName(stCountry);

					}else{
						stService = "N/A";
					}

					if (stService == null){
						bUpdateDomain = false;
					}else{
						if(stService.equals(stASODomain)){

							bUpdateDomain = false;
						}else{
							if (stASODomain.equalsIgnoreCase("IBMGBLMS")){
								bUpdateDomain = false;
							}else{
								bUpdateDomain = true;
							}
							
						}
					}



					stShortname = (String)ve.getColumnValues().elementAt(2);
					stEmpNum = (String)ve.getColumnValues().elementAt(7);
					//bw.write(stFullName + "," + stASODomain + "," + stC + "\r\n");
					sb = new StringBuffer();
					sb.append(stFullName);
					sb.append(",");
					sb.append(stClassification);
					sb.append(",");
					sb.append(stOwner);
					sb.append(",");
					sb.append(stShortname);
					sb.append(",");
					sb.append(stEmpNum);
					sb.append(",");


					if(bUpdate | bUpdateDomain){
						doc = ve.getDocument();
						if(bUpdate) doc.replaceItemValue("Dept_ID", stOwner);
						if(bUpdateDomain)doc.replaceItemValue("ASODomain", stService);
						doc.save();
						doc.recycle();
						sb.append(" updated sucessfull");
						sb.append(",");
					}else{
						sb.append(" not updated sucessfull");
						sb.append(",");
						sb.append(stComment);
					}
					sb.append( "\r\n");
					//pln("found :" + sb.toString());
					bw.write(sb.toString());
					log.logActionLevel(LogLevel.INFO, sb.toString());

					/*
				dummy = stFullName.split("/");
				stCountry = (dummy.length > 2)? dummy[1]:null;
				iPos = stCountry.indexOf("=");
				if (iPos>0){
					stCountry = stCountry.substring(iPos+1);
				}
				if (stCountry == null) {
					continue;
				}

				stC = cfgCTable.getIBMCodeByCountryName(stCountry);
				if(stC == null){
					pln (stFullName + "," + stASODomain + "," + stC);
					bw.write(stFullName + "," + stASODomain + "," + stC);
				}else{
					if( !stC.equals(stASODomain)){
						bw.write(stFullName + "," + stASODomain + "," + stC + "\r\n");
						pln("found :" + stFullName + "," + stASODomain + "," + stC);
					}
				}*/
					veRec = ve;
					ve = vec.getNextEntry(ve);
					veRec.recycle();
					l++;
					if(l % 500 == 0)pln("working on " + l + "/"+ lcount);
				}
			}
			bw.close();
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKDone();
			log.closeLog(lds);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}

	private void getLogDoc() throws Exception{

		dbLog  = CommonFunctions.getLogDB(session);
		log = new InputOutputLogger(session, dbLog, "OSM Export - " + CommonFunctions.getActDateRecon(),
				LogLevel.FINEST);
	}

	private void pln(String s){
		System.out.println(s);
	}

}
