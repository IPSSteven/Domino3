package com.ibm.ereg.test;

import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.NoReuseData.CheckReuseOfNames;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class CheckReuseOfNamesTester extends NotesThread {
	public Session s;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CheckReuseOfNamesTester NameTest = new CheckReuseOfNamesTester();
		NameTest.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		String stNotesID = null;
		Document doclog; 
		Database dbLog = null;
		try {
			s = NotesFactory.createSessionWithFullAccess("jac2mac.");
			try {
				dbLog = CommonFunctions.getLogDB(s);
				InputOutputLogger iol = new InputOutputLogger(s, dbLog, "TestAgent pls delete log or disregard", LogLevel.FINEST);
				doclog = iol.getDocLog();
				Vector<String> vecNames = new Vector<String>();
				vecNames.add("Kurt Raiser");
				vecNames.add("Kurt Raiser1");
				vecNames.add("Kurt Raiser2");
				doclog.replaceItemValue("NameToCheck", vecNames);
				doclog.save();
				stNotesID = doclog.getNoteID();
				doclog.recycle();
				doclog = null;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			CheckReuseOfNames cnN = new CheckReuseOfNames(s, stNotesID);
			try {
				cnN.run();
				doclog = dbLog.getDocumentByID(stNotesID);
				Vector vectemp0 = doclog.getItemValue("NoReuseError");
				Vector vectemp1 = doclog.getItemValue("PersonUnid");
				Vector vectemp2 = doclog.getItemValue("LastUsedTime");		
				Vector vectemp3 = doclog.getItemValue("NamesFailed");	
				
				System.out.println("end");
						
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
