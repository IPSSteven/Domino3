package com.ibm.ereg.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.DocumentCollection;

public class Correct extends NotesThread {
	private Session session;
	private Database dbNcour;
	private View vwShort;
	private View vwDom;
	private Database dbNab = null;
	private View vwNab = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Correct c = new Correct();
		c.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		session = NotesFactory.createSessionWithFullAccess("sum16mer.");

		try {
			getDB();
			FileReader fr = new FileReader(new File("c:\\temp\\correct.txt"));
			BufferedReader br = new BufferedReader(fr);
			String line = null;
			String domain;
			String domainOld= null;
			String shortname;
			String [] dummy;
			boolean bfirstline = true;
			while ((line=br.readLine()) != null){
				if (bfirstline){
					bfirstline = false;
				}else{
					dummy = line.split(",");
					domain = dummy[0];
					shortname = dummy[1];
					if (!domain.equals(domainOld)){
						if(dbNab != null){
							dbNab.recycle();
						}
						dbNab = getNab(domain);
						if (vwNab != null){
							vwNab.recycle();
						}
						vwNab = dbNab.getView("People\\People by Shortname");
						domainOld = domain;
					}

					System.out.println(domain +"-" + shortname);
					handleDocument(domain, shortname);
				}
			}
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void getDB(){
		try {
			dbNcour = session.getDatabase("D06DBL048", "n_dir/ncouaruk.nsf");
			vwShort = dbNcour.getView("Person\\by Shortname");
			vwDom = dbNcour.getView("SearchDomain");
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private Database getNab(String stDomain){
		String stServer;
		Database dbNab = null;
		try {
			Document docDom = vwDom.getDocumentByKey(stDomain);
			stServer = docDom.getItemValueString("SearchHub");
			dbNab = session.getDatabase(stServer, "names.nsf");

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dbNab;
	}

	private void handleDocument(String domain, String shortname){
		String stInternetAddress;
		String stCountry = domain.substring(3).toLowerCase();
		//LinkedHashSet<String> hsShortname = new LinkedHashSet<String>();
		Vector<String> vShortNameNew = new Vector();
		int idxV = 0;
		try {
			DocumentCollection col = vwNab.getAllDocumentsByKey(shortname);
			Document docNab = col.getFirstDocument();
			
			while (docNab != null){
				String domNam = null;
				domNam = docNab.getItemValueString("MailDomain");
				if(domNam.equals(domain)) break;
			}
			stInternetAddress = docNab.getItemValueString("InternetAddress");
			if(stInternetAddress.indexOf("@") < 0){
				stInternetAddress = stInternetAddress + "@" + stCountry + ".ibm.com";
				vShortNameNew.add(idxV, stInternetAddress);
				idxV++;
				Vector vShortname = docNab.getItemValue("Shortname");
				Iterator<String> it = vShortname.iterator();
				while (it.hasNext()){
					vShortNameNew.add(idxV, it.next());
					idxV++;
				}
				docNab.replaceItemValue("ShortName",vShortNameNew);
				docNab.replaceItemValue("InternetAddress", stInternetAddress);
				docNab.save();
			}
			
			
			
			
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
	}

}
