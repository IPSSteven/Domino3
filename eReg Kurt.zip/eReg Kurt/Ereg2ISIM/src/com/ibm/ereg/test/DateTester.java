package com.ibm.ereg.test;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjCountryTable;
import com.ibm.ereg.config.ConfigObjDocuments;

import lotus.domino.DateTime;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class DateTester  extends NotesThread{

	public static void main (String [] argv) {
		DateTester dt = new DateTester();
		dt.start();
	}



	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("Used2know.");

		//DateTime  dteTest = s.createDateTime("14/09/2020 10:30:00");
		//DateTime  dteTest = s.createDateTime("");
		//System.out.println(dteTest.getLocalTime());
		//DateTime dteRes = CommonFunctions.getNextStart(s, "2 day", dteTest);
		//System.out.println(dteRes.getLocalTime());
		ConfigObjCountryTable cfgCt;
		try {
			cfgCt = new ConfigObjCountryTable(s);
			HashSet<String> hs= cfgCt.getAllOrgforDoamin("IBMZA");
			for(String stD:hs) {
				System.out.println(stD);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}



}
