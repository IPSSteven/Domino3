package com.ibm.ereg.test;

import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjISIMRecon;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class EvaluateTest extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EvaluateTest et = new EvaluateTest();
		et.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		String prefix;
		Session  s = NotesFactory.createSessionWithFullAccess("Used2know.");
		//Vector vr = s.evaluate("@true");
		Vector vr = s.evaluate("@Return(\"D20\")");
		System.out.println(vr.firstElement().toString());
		vr = s.evaluate("@false");
		System.out.println(vr.firstElement().toString());

		String dom ="IDPEM";
		ConfigObjISIMRecon isimRecon;
		try {
			isimRecon = new ConfigObjISIMRecon(s, "12>ISIMRecon");
			Database dbLog = CommonFunctions.getLogDB(s);
			InputOutputLogger log = new InputOutputLogger(s, dbLog, "Test for recon", LogLevel.FINEST);
			String stReconUser =isimRecon.getISIMUser();
			String stPw = isimRecon.getPw();
			String formula = isimRecon.getFormulaServicePrefix();
			Document docLog = log.getDocLog();
			docLog.replaceItemValue("RecDomain", dom);
			docLog.save();
			Vector vRes =s.evaluate(formula, docLog);
			System.out.println(vRes.firstElement().toString());
			if(vRes != null && !vRes.isEmpty()) {
				dom = vRes.firstElement().toString();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}

}
