package com.ibm.ereg.test;

import com.ibm.ereg.common.CommonFunctionGeneral;
import com.ibm.ereg.common.CommonFunctions;

public class GetActDate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(CommonFunctions.getActDateRecon());
		System.out.println(CommonFunctionGeneral.getActDate());

	}

}
