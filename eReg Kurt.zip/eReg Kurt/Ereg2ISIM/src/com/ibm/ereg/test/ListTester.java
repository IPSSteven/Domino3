package com.ibm.ereg.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;

import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.FileLoger;
import com.ibm.mediator.NoReuseLogic.NoReuseDB2Connector;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.notes.secure.PasswordHandler;

public class ListTester {
	private DB2ConnectData db2Conn;
	private NoReuseDB2Connector nrDb2Con;
	private BufferedReader br;
	private BufferedWriter bw;

	private HashSet<String> hsNoReuse;
	private HashSet<String> hsFile;

	public ListTester(DB2ConnectData db2con) {
		// TODO Auto-generated constructor stub

		this.db2Conn = db2con;
		FileLoger flog = new FileLoger("c:/temp/log", "txt");

		nrDb2Con = new NoReuseDB2Connector(flog, db2Conn);
		try {
			FileReader fr = new FileReader(new File("c:/temp/inp.txt"));
			FileWriter fw = new FileWriter(new File("c:/temp/out.txt"));
			br = new BufferedReader(fr);
			bw = new BufferedWriter(fw);


		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Reader fReader;
		DB2ConnectData  dbcon  = null;
		String passwd = null;

		try {
			fReader = new FileReader(AllConstants.DB2PROPERTIES);

			PasswordHandler ph = new PasswordHandler();
			Properties propDb2 = new Properties();
			propDb2.load(fReader);

			dbcon = new DB2ConnectData();
			dbcon.setClass(propDb2.getProperty("Class"));
			dbcon.setDB2Database(propDb2.getProperty("Database"));
			dbcon.setdb2Lookup(propDb2.getProperty("Lookupview"));
			//dbcon.setDb2SerialLookupView(propDb2.getProperty("SerialLookupView"));
			dbcon.setURL(propDb2.getProperty("URL"));
			dbcon.setLogLevel(Byte.parseByte(propDb2.getProperty("LogLevel")));
			dbcon.setIPAddress(propDb2.getProperty("IPAddressProd")); // PROD
			dbcon.setUserid(propDb2.getProperty("UserIdProd")); // PROD
			//dbcon.setPassword(propDb2.getProperty("PasswordProd"));
			passwd = ph.getPw(PasswordHandler.kindOfPwDB2);
			dbcon.setPassword(passwd);
			dbcon.setPort(Integer.parseInt(propDb2.getProperty("PortProd"))); // PROD
			dbcon.setIPAddressBackup(propDb2.getProperty("IPAddressBackupProd"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}

		ListTester lt = new ListTester(dbcon);
		lt.getFileContent();
		lt.getNoReuseContent();
		lt.compare();

	}

	private void getFileContent(){
		long lcount = 0;
		hsFile = new HashSet<String>();
		String line;
		try {
			while ((line = br.readLine()) != null){
				hsFile.add(line);
				lcount ++;
			}

			System.out.println("added " + lcount + " from file");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private void getNoReuseContent(){
		long lcount =0;
		String sql = "SELECT * FROM NOREUSE.NOREUSE_LOOKUP WHERE MAILADDRESS LIKE '%@%'";
		hsNoReuse = new HashSet<String>();
		try {
			nrDb2Con.connect();
			ResultSet rs =nrDb2Con.getEregCon().excuteQuery(sql);
			while (rs.next()){
				hsNoReuse.add(rs.getString(1));
				lcount ++;
				if(lcount % 5000 == 0){
					System.out.println("added " + lcount + " from Noreuse");
				}
			}
			System.out.println("added " + lcount + "from Noreuse");
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void compare(){
		long lcount = 0;
		String nl = System.getProperty("line.separator");
		Iterator<String> it = hsFile.iterator(); 
		String stName;
		while(it.hasNext()){
			stName = it.next().toLowerCase();
			if (!hsNoReuse.contains(stName)){
				try {
					bw.write( stName + nl);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		try {
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}
