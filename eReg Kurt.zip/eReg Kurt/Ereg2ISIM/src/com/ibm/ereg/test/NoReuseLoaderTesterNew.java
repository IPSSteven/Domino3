package com.ibm.ereg.test;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import com.ibm.mediator.NoReuseDataLoader.NoReuseLoaderRunnerNew;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class NoReuseLoaderTesterNew extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoReuseLoaderTesterNew nrt = new NoReuseLoaderTesterNew();
		nrt.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		String pw = "Jac2mac.";
		Session session = NotesFactory.createSessionWithFullAccess(pw);
		
		NoReuseLoaderRunnerNew nrr = new NoReuseLoaderRunnerNew();
		nrr.setSession(session);
		nrr.setPasswd(pw);
		
		Properties ph = new Properties();
		try {
			ph.load(new FileReader("NotesProperties.txt"));
			nrr.setNoReuseSingleConf(ph.getProperty("NoReuseSingleConf"));
			nrr.setNoReuseMultiConfig(ph.getProperty("NoReuseMultiConf"));
			nrr.setAgentName("(NoReuseLoaderRunner)|agNoReuseLoaderRunner");
			nrr.runLoader();;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		nrr.setNoReuseSingleConf("Notes_NoReuse_SingleVal");
		nrr.setNoReuseMultiConfig("Notes_NoReuse_MultiVal");
		nrr.setAgentName("(NoReuseLoaderRunner)|agNoReuseLoaderRunner");
		nrr.runLoader();

		
	}

}
