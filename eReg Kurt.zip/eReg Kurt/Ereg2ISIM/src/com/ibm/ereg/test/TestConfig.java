package com.ibm.ereg.test;

import java.util.HashMap;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjCountryTable;
import com.ibm.ereg.config.ConfigObjMailSystem;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class TestConfig extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestConfig tc = new TestConfig();
		tc.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("Part0fbody!");
		try {
			ConfigObjCountryTable cfgCountryTable = new ConfigObjCountryTable(s);
			String sr =cfgCountryTable.getCountryCode("CA3");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Database dbLog;
		try {
			dbLog = CommonFunctions.getLogDB(s);
			InputOutputLogger log = new InputOutputLogger(s, dbLog, "Test", LogLevel.FINEST);
			//ConfigObjMailSystem ms = new ConfigObjMailSystem(s, AllConstants.MAIL_SYSTEM, log);
			ConfigObjNCOUAR cfgtst = new ConfigObjNCOUAR(s, log);
			View vw = cfgtst.getVwITIMEXPORT("IDPAM", log.getDocLog());
			System.out.println(vw.getParent().getServer() +":" +vw.getParent().getFileName() +
					"-" + vw.getName());
			vw = cfgtst.getVwITIMEXPORT("IDPAP", log.getDocLog());
			System.out.println(vw.getParent().getServer() +":" +vw.getParent().getFileName() +
					"-" + vw.getName());
			vw = cfgtst.getVwITIMEXPORT("IDPEM", log.getDocLog());
			System.out.println(vw.getParent().getServer() +":" +vw.getParent().getFileName() +
					"-" + vw.getName());
			vw = cfgtst.getVwITIMEXPORT("IDPIN", log.getDocLog());
			System.out.println(vw.getParent().getServer() +":" +vw.getParent().getFileName() +
					"-" + vw.getName());
			vw = cfgtst.getVwITIMEXPORT("IDPUS", log.getDocLog());
			System.out.println(vw.getParent().getServer() +":" +vw.getParent().getFileName() +
					"-" + vw.getName());
			vw = cfgtst.getVwITIMEXPORT("IBM", log.getDocLog());
			System.out.println(vw.getParent().getServer() +":" +vw.getParent().getFileName() +
					"-" + vw.getName());
			vw = cfgtst.getVwITIMEXPORT("IBMDE", log.getDocLog());
			System.out.println(vw.getParent().getServer() +":" +vw.getParent().getFileName() +
					"-" + vw.getName());
			
			//HashMap<String, String> httes = ms.getReconcileMailSystem();
			///String result = httes.get("1");
			//System.out.println(result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
