package com.ibm.ereg.test;


import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.mediator.NoReuseLogic.NoReuseNameProposalHandler;
import com.ibm.mediator.NoReuseLogic.NoReuseNotesConfiguration;
import com.ibm.mediator.connector.DB2ConnectData;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class TestLogging extends NotesThread {

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("g00dtimes4ever!");
		Database dbLog;
		try {
			dbLog = CommonFunctions.getLogDB(s);
			/*BasicData bd = new TRData();
			bd.setEndTime("");
			bd.setEregMailDomain("IBMDE");
			bd.setEregShortName("test");
			bd.setItimRequestID("xxx");
			bd.setLNUnId("");
			bd.setReturnCode("");
			bd.setReturnCodeDescription("");
			bd.setRTyp("tss");
			bd.setStartTime("");
			bd.setStatus("");*/
			
			Document doc = dbLog.createDocument();
			RequestLogger rl = new RequestLogger(s,doc);
			NoReuseNotesConfiguration nconf = new NoReuseNotesConfiguration(s, rl.getDocLog());

			String []stDummy = nconf.getCfgNotes_Noreuse_Multival().getIpAddressPort()[0].split(":");
			String stIP = stDummy[0];
			String stClass =nconf.getCfgNotes_Noreuse_Multival().getClassName()[0];
			String stDatabase = nconf.getCfgNotes_Noreuse_Multival().getDatabase()[0];
			String stUrl = nconf.getCfgNotes_Noreuse_Multival().getUrl()[0];
			String stPort = stDummy[1];
			String stUser = nconf.getCfgNotes_Noreuse_Multival().getUser()[0];
			String stPassword = nconf.getCfgNotes_Noreuse_Multival().getPassword()[0];
			
			DB2ConnectData  dbcon= new DB2ConnectData();
			dbcon.setIPAddress(stIP);
			dbcon.setClass(stClass);
			dbcon.setDB2Database(stDatabase);
			dbcon.setURL(stUrl);
			dbcon.setPort(Integer.parseInt(stPort));
			dbcon.setdb2Lookup("NOREUSE.NOREUSE_LOOKUP");
			dbcon.setUserid(stUser);
			dbcon.setPassword(stPassword);
			NoReuseNameProposalHandler ph = new NoReuseNameProposalHandler(rl, dbcon);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestLogging tl = new TestLogging();
		tl.start();
	}

}
