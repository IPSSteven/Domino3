package com.ibm.ereg.test;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.logger.FileLoger;
import com.ibm.mediator.NoReuseInterface.NoReuseCountryData;
import com.ibm.mediator.NoReuseInterface.ResponseNameProposal;
import com.ibm.mediator.NoReuseLogic.NoReuseNameProposalHandler;
import com.ibm.mediator.connector.DB2ConnectData;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class TestProposal extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestProposal tp = new TestProposal();
		tp.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session session = NotesFactory.createSessionWithFullAccess("ja13komo");
		Database dbLog = CommonFunctions.getDatabase(session, "D06DBL090", "e_dir/ereglog6.nsf");
		View vw = dbLog.getView("User History");
		DocumentCollection dcc = vw.getAllDocumentsByKey("JW513655");
		Document doc = dcc.getFirstDocument();
		Document docR;
		
		DB2ConnectData  dbcon= new DB2ConnectData();
		dbcon.setIPAddress("prdbcraw3gen05.w3-969.ibm.com");
		dbcon.setClass("com.ibm.db2.jcc.DB2Driver");
		dbcon.setDB2Database("MEDIATOR");
		dbcon.setURL("jdbc:db2://");
		dbcon.setPort(60000);
		dbcon.setdb2Lookup("NOREUSE.NOREUSE_LOOKUP");
		dbcon.setUserid("ereg");
		dbcon.setPassword("W0rkhard4themoney!");
		
		String firstName;
		String middleInitial = "";
		String lastName;
		String owner;
		NoReuseCountryData nrcd;
		FileLoger fl = new FileLoger("testlog", "log");
		while(doc != null) {
			
			firstName = doc.getItemValueString("FirstName");
			lastName = doc.getItemValueString("LastName");
			owner = doc.getItemValueString("Owner");
			try {
				nrcd = new NoReuseCountryData(owner,NoReuseCountryData.CountryDefSerialPSC, NoReuseCountryData.ContextGlobal);
				NoReuseNameProposalHandler ph = new NoReuseNameProposalHandler(fl, dbcon);
				ResponseNameProposal rnp = ph.getNameProposal(firstName, middleInitial, lastName,nrcd);
				System.out.println("----------------------Proposed Name ---------------- " + rnp.getProposedNames()[0]);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			docR =doc;
			doc = dcc.getDocument(doc);
			docR.recycle();
		}
		
	}
	

}
