package com.ibm.ereg.test;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class TestUnid extends NotesThread {

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestUnid tu = new TestUnid();
		tu.start();
	}
	
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session session = NotesFactory.createSessionWithFullAccess("jac2mac.");
		Database dbDE = CommonFunctions.getDatabase(session, "D06HBM03", "names.nsf");  // NAB on premise
		Database dbED03 =  CommonFunctions.getDatabase(session, "D06HBM03", "dircat/edcww.nsf"); //Extended dir auf D06HBM03
		Database dbED10 =  CommonFunctions.getDatabase(session, "D06EDC10", "dircat/edcww.nsf");  //Extended dir auf D06HBM10
		View vwDE = dbDE.getView("($Users)");
		View vwED03 = dbED03.getView("($Users)");
		View vwED10 = dbED10.getView("($Users)");
		Document docDE = vwDE.getDocumentByKey("grudzin", true); // universal id of person document on on prem
		Document docED03 = vwED03.getDocumentByKey("grudzin", true);  //universal id of person document on on 03
		Document docED10 = vwED10.getDocumentByKey("grudzin", true); //universal id of person document on on 10
		
		pln ("DE-" + docDE.getUniversalID());
		pln ("ED03-" + docED03.getUniversalID());
		pln ("ED10-" + docED10.getUniversalID());
		
	}
	
	void pln(String s){
		System.out.println(s);
	}

}
