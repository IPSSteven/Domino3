package com.ibm.ereg.test;

import java.rmi.RemoteException;


import com.ibm.ereg.logger.TraceLogger;



public class TraceLogTester{
	
	public String firstname;
	public String middlename;
	public String lastname;
	public String Threadname;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TraceLogTester tt = new TraceLogTester();
		tt.run();
		/*tt.firstname = "Kurt";
		tt.middlename = "von";
		tt.lastname = "Raiser";
		tt.Threadname = "t1";
		TraceLogTester ttt = new TraceLogTester();
		ttt.firstname = "Kurt";
		ttt.middlename = "von";
		ttt.lastname = "Raiser1";
		ttt.Threadname = "t2";
		tt.start();
		ttt.start()*/;
		

	}

	//@Override
	public void run() {
		// TODO Auto-generated method stub
	//	super.run();
		TraceLogger tl;
		
		try {
			tl = new TraceLogger(this.getClass().getName(), "NoReuse", "TestFirstNameTestLastName");
			tl.logActionLevel(tl.getRcSuccess(), "this is a sucessful test log pls ingnore it");
			tl.logActionLevel(tl.getRcSuccessWithWarnung(), "this is a successful test log with warnings pls ingnore it");
			tl.logActionLevel(tl.getRcError(), "this is a sucessful test log with errors pls ingnore it");
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	
		/*	try {
			LogEntry le = new LogEntry();
			le.setProcessName("RESERVE_NOTES_ID"); 
			le.setComponentName("Notes_Reservation");
			StringBuffer fn = new StringBuffer();
			fn.append(firstname.isEmpty()?"":firstname + ".");
			fn.append(middlename.isEmpty()?"":middlename + ".");
			fn.append(lastname.isEmpty()? "":lastname);		
			le.setTransaktionParam(fn.toString());
			String entry = CommonFunctions.getActDate()+ "-" + "Start Reserveration";
			le.setLogEntry(entry);
			le.setSenderIdentification("Kurt Raiser");
			le.setDebug(true);
			String v = le.verifyEntry();
			pln(Threadname + "-" + v);
			
				
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
	}
	public void pln(String s){
		System.out.println(s);
	}

}
