package com.ibm.helper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;



public class Empnum4Monika extends NotesThread{
	private HashSet<String> hsvalidEmnum = new HashSet<String> ();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Empnum4Monika em = new Empnum4Monika();
		em.start();
	}

	@Override
	public void runNotes() throws NotesException  {
		// TODO Auto-generated method stub
		super.runNotes();
		try {
			String line;
			BufferedReader br1 = new BufferedReader(new FileReader("C:\\Temp\\validempNum.txt"));
			try {
				while ((line = br1.readLine()) != null) {
					hsvalidEmnum.add(line);
				}
				br1.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return;
			}


			String []dummy;
			String empnum;
			String psc;
			String fullname;
			String shortname;
			String domain;
			br1 = new BufferedReader(new FileReader("C:\\Temp\\List.txt"));
			BufferedWriter bw1 = new BufferedWriter(new FileWriter("C:\\Temp\\Out.txt"));
			BufferedWriter bw2 = new BufferedWriter(new FileWriter("C:\\Temp\\OutNotFound.txt"));
			Session session = NotesFactory.createSessionWithFullAccess("1Bestfriend!");
			Database dbLog;
			try {
				dbLog = CommonFunctions.getLogDB(session);
				InputOutputLogger log = new InputOutputLogger(session, dbLog, "Test disredarad", LogLevel.INFO);
				ConfigObjNCOUAR cfgUAR = new ConfigObjNCOUAR(session, log);
				View vwNcouar = cfgUAR.getVwByFullName("IDMDE");
				ViewEntry ve  = null;
				int icount = 0;
						
				while ((line = br1.readLine()) != null) {
					dummy = line.split(";");
					fullname = dummy[0];
					empnum = dummy[1].substring(0, 6);
					psc = dummy[1].substring(6);
					
					if(hsvalidEmnum.contains(dummy[1])) {
						
						ve = vwNcouar.getEntryByKey(fullname);
						if (ve == null) {
							System.out.println("Fullname:" + fullname + " not found");
							bw2.write("Fullname:" + fullname + " not found");
							bw2.newLine();
						}else {
							domain = ve.getColumnValues().elementAt(2).toString();
							shortname = ve.getColumnValues().elementAt(1).toString();
							//bw1.write(fullname + ";" + empnum + ";" + psc);
							bw1.write(domain + ";" + shortname +";"+ empnum + ";" + psc);
							bw1.newLine();
						}
						
						
					}
					icount++;
					if( icount%200 ==0) {
						System.out.println("working on line " + icount);
					}
				}
				br1.close();
				bw1.close();
				bw2.close();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			


		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("done");
	}


}
