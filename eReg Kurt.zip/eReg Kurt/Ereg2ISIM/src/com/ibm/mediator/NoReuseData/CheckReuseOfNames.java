package com.ibm.mediator.NoReuseData;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnectorNotes;
import lotus.domino.Agent;
import lotus.domino.AgentContext;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;

public class CheckReuseOfNames {
	Session session;
	private Database dbLog;
	private Document docLog;
	private AgentContext agCon;
	private Agent ag;
	private RequestLogger rl;
	private ConfigObjMediatorDB cfgNotes_Noreuse_IDS;
	private TheEregConnectorNotes theConnect;

	public CheckReuseOfNames(Session s){
		try {
			session = s;
			dbLog  = CommonFunctions.getLogDB(s);
			agCon = s.getAgentContext();
			ag = agCon.getCurrentAgent();
			String stUnid = ag.getParameterDocID();
			docLog= dbLog.getDocumentByID(stUnid);
			rl = new RequestLogger(s, docLog);
			rl.setCheckLogLevel(LogLevel.FINEST);
			rl.logActionLevel(LogLevel.INFO, "Init of Check no reuse agent successfull finished.");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public  CheckReuseOfNames(Session s, String stUnid){
		session = s;
		try {
			dbLog  = CommonFunctions.getLogDB(s);
			docLog= dbLog.getDocumentByID(stUnid);
			rl = new RequestLogger(s, docLog);
			rl.setCheckLogLevel(LogLevel.FINEST);
			rl.logActionLevel(LogLevel.INFO, "Init of Check no reuse agent successfull finished.");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void run() throws Exception { //
		String st_Search;
		Vector <String> vNameToCheck;
		Vector <String> vUnids = null;
		Vector<String> vDate = null;
		HashSet<String> hsNameFound = null;
		HashSet<String> hsNameSearch = null;
		String stNameSearch = null;
		String stName = null;
		String OwnerID = null;
		//String stQuery = null;

		rl.logActionLevel(LogLevel.INFO, "Try to get the config of Notes_NoReuse_IDS val");
		try {
			cfgNotes_Noreuse_IDS = new  ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_IDS, rl);
			rl.logActionLevel(LogLevel.INFO, "Got the config of NoReuse Single val - set loglevel");
			rl.setCheckLogLevel(Byte.parseByte(cfgNotes_Noreuse_IDS.getLogLevel()[0]));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			rl.logActionLevel(LogLevel.SEVERE, "Error while try to find the configuration");
			rl.logActionLevel(LogLevel.SEVERE,e.getMessage());
			docLog.replaceItemValue("NoReuseError", "1");
			docLog.save();
			e.printStackTrace();
			throw e;
		}

		// get the search value
		try {
			vNameToCheck = docLog.getItemValue("NamesToCheck");
			OwnerID = docLog.getItemValueString("OwnerUID");
			Iterator<String> it = vNameToCheck.iterator();
			StringBuffer sb = new StringBuffer();
			hsNameSearch = new HashSet<String>();
			int iLen = 0;
			while(it.hasNext()){
				stNameSearch = it.next().toLowerCase();
				stNameSearch = getNamePart(stNameSearch, "/");
				//stNameSearch = getNamePart(stNameSearch, "@");
				
				
				stNameSearch = stNameSearch.replaceAll("'","''"); //for sql
				iLen = stNameSearch.length();
				hsNameSearch.add(stNameSearch);
				sb.append("SELECT * FROM " +  cfgNotes_Noreuse_IDS.getTable()[0] + " WHERE (SUBSTR (FULLNAME,1,");
				sb.append(iLen);
				sb.append(") = '");
				sb.append(stNameSearch);
				sb.append("' OR SUBSTR (INTERNETADDRESS,1,");
				sb.append(iLen);
				sb.append(") = '");
				sb.append(stNameSearch);
				sb.append("' OR SUBSTR (NAMEALIAS,1,");
				sb.append(iLen);
				sb.append(") = '");
				sb.append(stNameSearch);
				sb.append("') AND UNID != '");
				sb.append(OwnerID);
				sb.append( "' UNION ");

			}
			if (sb.length() > 5){ // remove the last union
				st_Search = sb.substring(0, sb.length()-7);
			}
			else{ 
				st_Search = null;
				throw (new IllegalArgumentException("no Input Parameter"));
			}
			sb = null;
			//st_Search = docLog.getItemValueString("NameToCheck");
			//if (st_Search != null)st_Search = st_Search.toLowerCase(); else st_Search = "" ;
			rl.logActionLevel(LogLevel.INFO, "Name to Check: "  + st_Search);
		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			rl.logActionLevel(LogLevel.SEVERE, "Error while try to get the name to check from log document");
			rl.logActionLevel(LogLevel.SEVERE,e1.getMessage());
			docLog.replaceItemValue("NoReuseError", "1");

			docLog.save();
			e1.printStackTrace();
			throw e1;
		}catch (Exception e){
			rl.logActionLevel(LogLevel.SEVERE, "Error while try to get the name to check from log document");
			rl.logActionLevel(LogLevel.SEVERE,e.getMessage());
			docLog.replaceItemValue("NoReuseError", "1");
			docLog.save();
			e.printStackTrace();
			throw new Exception("Error while try to get the name to check from log document");
		}
		
		
		// connect to db2
		try {
			theConnect = new TheEregConnectorNotes(rl, cfgNotes_Noreuse_IDS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			rl.logActionLevel(LogLevel.SEVERE, "Error while try to connect to db2");
			rl.logActionLevel(LogLevel.SEVERE,e.getMessage());
			docLog.replaceItemValue("NoReuseError", "1");
			docLog.save();
			e.printStackTrace();
			throw e;
		}


		int iHits = 0;
		/*try{*/
		ResultSet rs = theConnect.excuteQuery(st_Search);
		if (rs != null){
			hsNameFound = new HashSet<String>();
			vUnids = new Vector<String>();
			vDate = new Vector<String>();
			try {
				while (rs.next()){
					vUnids.add(rs.getString(1));
					//String dummy = rs.getString(5).trim();
					//dummy =  rs.getString(4);
					//String dummy = rs.getString(5);
					//dummy = rs.getString(4);
					if (rs.getString(6) == null ||  rs.getString(5).trim().equals("")){ // deletion date empty
						if (rs.getString(5) != null){
							vDate.add(rs.getString(5));
						}

					}else{
						vDate.add(rs.getString(5));
					}
					stName = rs.getString(2);//fullname
					if (stName != null && stName.indexOf("/") > -1){
						hsNameFound.add(stName.substring(0,stName.indexOf("/"))); 
						iHits ++;
					}
					stName = rs.getString(3);// internet address	
					if (stName != null && stName.indexOf("@") > -1){
						hsNameFound.add(stName.substring(0,stName.indexOf("@"))); 
						iHits ++;
					}

					stName = rs.getString(4);//name alias
					if (stName != null){
						if(stName.indexOf("/")> -1){
							hsNameFound.add(stName.substring(0,stName.indexOf("/"))); 
							iHits ++;
						}
						if(stName.indexOf("@")> -1){
							hsNameFound.add(stName.substring(0,stName.indexOf("@"))); 
							iHits ++;
						}
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				rl.logActionLevel(LogLevel.SEVERE, "Error while read resultset");
				rl.logActionLevel(LogLevel.SEVERE,e.getMessage());
				docLog.replaceItemValue("NoReuseError", "1");
				docLog.save();
				e.printStackTrace();
				throw e;
			}
			//docLog.
		}

		try {
			String [] stNameSearchArr = hsNameSearch.toArray(new String [hsNameSearch.size()]);
			Vector<String> vecNotFound = new Vector<String>();
			for(String s : stNameSearchArr){
				if(! hsNameFound.contains(s)){
					vecNotFound.add(s);
				}
			}

			docLog.replaceItemValue("NoReuseHits", Integer.valueOf(iHits));
			if (docLog.hasItem("PersonUnid"))docLog.removeItem("PersonUnid");
			if (docLog.hasItem("LastUsedTime"))docLog.removeItem("LastUsedTime");
			if (docLog.hasItem("NamesFailed"))docLog.removeItem("NamesFailed");
			docLog.appendItemValue("PersonUnid").setValues(vUnids);
			docLog.appendItemValue("LastUsedTime",vDate);
			docLog.appendItemValue("NamesFailed", vecNotFound);
			docLog.replaceItemValue("NoReuseError", "0");
			docLog.save();
			rl.logActionLevel(LogLevel.INFO, "Search finished succesful");

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			rl.logActionLevel(LogLevel.SEVERE, "Error while write items to log document");
			rl.logActionLevel(LogLevel.SEVERE,e.getMessage());
			docLog.replaceItemValue("NoReuseError", "1");
			docLog.save();
			e.printStackTrace();
		}


		//docLog.appendItemValue("PersonUnid").appendToTextList(vUnids);
		//docLog.appendItemValue("LastUsedTime").appendToTextList(vDate);

		/*}catch(Exception e){
			rl.logActionLevel(LogLevel.SEVERE, "Error while excute Sql Statment: "+ stQuery);
			docLog.replaceItemValue("NoReuseError", "1");
			docLog.save();
			e.printStackTrace();
			throw e;
		}*/
		theConnect.close(false);
		try {
			docLog.recycle();
			//	dbLog.recycle();
			//	session.recycle();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	private String getNamePart (String stName ,String regex){
		//int ind = stName.indexOf(regex);
		int ind = stName.lastIndexOf(regex);
	
		return (ind < 0 && ind < stName.length())? stName : stName.substring(0, ind+1);
	
	}
}
