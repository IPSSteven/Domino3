package com.ibm.mediator.NoReuseData;

public class DeleteNoReuseDataInputExt {
	private boolean hasError = false;
	private String ErrorDescription = null;
	private DeleteNoReuseData.DeleteNoReuseDataInput NoReuseData = null;
	
	public DeleteNoReuseDataInputExt() {
		// TODO Auto-generated constructor stub
		
	
	}

	public boolean isHasError() {
		return hasError;
	}

	public void setHasError(boolean hasError) {
		this.hasError = hasError;
	}

	public String getErrorDescription() {
		return ErrorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		ErrorDescription = errorDescription;
	}

	public  DeleteNoReuseData.DeleteNoReuseDataInput getNoReuseDataInput() {
		return NoReuseData;
	}

	public void setNoReuseDataInput( DeleteNoReuseData.DeleteNoReuseDataInput noReuseData) {
		NoReuseData = noReuseData;
	}
	
	public boolean isValid(){
		if ( NoReuseData != null && ! NoReuseData.isValid()){
			ErrorDescription = NoReuseData.getStNoValidReason();
			return false;
		}else{
			if(hasError) return false;
		}
		return true;
	}
	

}
