package com.ibm.mediator.NoReuseData;

import java.util.HashSet;

public class NoReuseDataHolder {
	private HashSet<String> hsAddress;
	private HashSet<String> hsUnidsDeleted;
	private HashSet<String> hsUnidsActive;
	private HashSet<String> hsUnidsClearDeletionDate;
	
	public HashSet<String> gethsAddress() {
		return hsAddress;
	}

	public void sethsAddress(HashSet<String> hsAddress) {
		this.hsAddress = hsAddress;
	}

	public HashSet<String> gethsUnidsDeleted() {
		return hsUnidsDeleted;
	}

	//public void setHsNABUnidsDeleted(HashSet<String> hsNABUnids) {
	//	this.hsNABUnidsDeleted = hsNABUnids;
	//}
	public HashSet<String> gethsUnidsActive() {
		return hsUnidsActive;
	}
	
	public HashSet<String> gethsUnidsClearDeletionDate() {
		return hsUnidsClearDeletionDate;
	}

	public NoReuseDataHolder() {
		super();
		hsAddress = new HashSet<String>();
		hsUnidsDeleted = new HashSet<String>();
		hsUnidsActive = new HashSet<String>();
		hsUnidsClearDeletionDate = new HashSet<String>();
		// TODO Auto-generated constructor stub
	}

	
	
}
