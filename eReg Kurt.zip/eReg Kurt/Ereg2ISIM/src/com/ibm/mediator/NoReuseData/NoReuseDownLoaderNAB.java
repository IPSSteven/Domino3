package com.ibm.mediator.NoReuseData;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.DocumentCollection;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigNoReuseMasterDatabase;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

public class NoReuseDownLoaderNAB {
	private Session sess;
	private final int MEMBERLIMIT = 512;
	
	private String stDom;
	private HashSet<String> hsNoResuseInternetAddress;
	private InputOutputLogger log = null;
	private TreeMap<String,Vector> tmGroups = null;
	private GroupData topLevelGroup = null;
	private Database dbNab; 

	private class GroupData{
		private  String stUnid;
		private Vector<String> veAddress;
		public String getStUnid() {
			return stUnid;
		}
		public void setStUnid(String stUnid) {
			this.stUnid = stUnid;
		}
		public Vector getVeAddress() {
			return veAddress;
		}
		public void setVeAddress(Vector veAddress) {
			this.veAddress = veAddress;
		}
	}
	
	public NoReuseDownLoaderNAB(Session session, String stDomain) {
		// TODO Auto-generated constructor stub

		this.sess = session;
		this.stDom = stDomain;
		initClass();

	}
	public NoReuseDownLoaderNAB(Session session, String stDomain,  InputOutputLogger log){
		this.sess = session;
		this.stDom = stDomain;
		this.log = log;
		initClass();
	}


	public Session getSess() {
		return sess;
	}


	public HashSet<String> getHsNoResuseInternetAddress() {
		return hsNoResuseInternetAddress;
	}
	private void initClass(){
		ConfigNoReuseMasterDatabase cfgNoReuseMasterDB;
		try {
			cfgNoReuseMasterDB = new ConfigNoReuseMasterDatabase(sess);

			dbNab = CommonFunctions.getDatabase(sess, cfgNoReuseMasterDB.getStServer() ,cfgNoReuseMasterDB.getStFilePath());
			if (dbNab == null){
				dbNab = CommonFunctions.getDatabase(sess, cfgNoReuseMasterDB.getStReplicServer() ,cfgNoReuseMasterDB.getStReplicFilePath());
			}
			if (dbNab == null){
				logaction(LogLevel.SEVERE, "Source Database not found");
				throw(new Exception("Source database not found"));
			}
			logaction(LogLevel.INFO, "connected to: " + dbNab.getServer() + ":" + dbNab.getFilePath()+"/"+ dbNab.getFileName());
			System.out.println("Connected to: " + dbNab.getServer() + ":" + dbNab.getFilePath()+"/"+ dbNab.getFileName());

			String stSearch = "Type = 'Group' & GroupType = '3' & Form = 'Group' &  @Contains(ListName;'" +
					AllConstants.GROUPIDENTIFIER + stDom + "')";
			logaction (LogLevel.INFO, "Search: " + stSearch);
			DocumentCollection dccSearch = dbNab.search(stSearch);
			logaction (LogLevel.INFO, "Found " + dccSearch.getCount() + " entries");
			Document docCol = dccSearch.getFirstDocument();
			Document docRecycle = null;
			hsNoResuseInternetAddress = new HashSet<String>();
			tmGroups = new TreeMap<String, Vector>();
			Vector<String> vMembers = null;
			Iterator<String> it = null;
			String stName = null;
			String stGroupName = null;
			//int iElements =0;
			while(docCol != null){
				vMembers = docCol.getItemValue("Members");
				stGroupName = docCol.getItemValueString("ListName");
				if (stGroupName.endsWith(stDom)){
					this.topLevelGroup = this.new GroupData();
					this.topLevelGroup.setStUnid(docCol.getUniversalID());
					this.topLevelGroup.setVeAddress(vMembers);		
				}

				it = vMembers.iterator();
				while(it.hasNext()){
					stName = (String)it.next();
					if(stName.indexOf("@")> 0){
						hsNoResuseInternetAddress.add(stName.toLowerCase());
					}
				}
				tmGroups.put(docCol.getUniversalID(),vMembers );
				docRecycle = docCol;
				docCol = dccSearch.getNextDocument(docCol);
				docRecycle.recycle();
			}
			dccSearch.recycle();
			logaction (LogLevel.INFO, "Load of no Reused ids finished successful");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void addAddress (String[] stNames){
		int iLimit;
		int iCount;
		Vector<String> vMember;
		Document docGroup = null;

		// get the first free group
		GroupData gdFree = getFreeGroup();
		if (gdFree == null){
			gdFree=createGroup();
		}

		vMember = gdFree.getVeAddress();
		iLimit = MEMBERLIMIT - vMember.size();
		iCount = 0;
		for (String stNam: stNames){
			if(iCount < iLimit){
				vMember.add(stNam);
			}else{
				// store old group
				try {
					docGroup = dbNab.getDocumentByUNID(gdFree.getStUnid());
					docGroup.replaceItemValue("Members", vMember);
					docGroup.save();
					this.tmGroups.put(gdFree.getStUnid(), vMember); // replace the vector in the group
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// get new group
				gdFree = getFreeGroup();
				if (gdFree == null){
					gdFree = createGroup();
				}
				vMember = gdFree.getVeAddress();
				vMember.add(stNam);
				iLimit = MEMBERLIMIT - vMember.size();
				iCount = 0;
			}
			iCount ++;
		}
		if(iCount > 0){
			try {
				docGroup = dbNab.getDocumentByUNID(gdFree.getStUnid());
				docGroup.replaceItemValue("Members", vMember);
				docGroup.save();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

	private GroupData getFreeGroup(){

		Vector<String> veMembers = null;
		String stKey = null;
		String stToplevelUnid = null;
		if (tmGroups.isEmpty()) return null;

		GroupData gd = this.new GroupData();

		Set<String> tsUnids = tmGroups.keySet();
		Iterator<String> it = tsUnids.iterator();
		if(this.topLevelGroup != null){
			stToplevelUnid = this.topLevelGroup.getStUnid();
		}
		while (it.hasNext()){
			stKey = it.next();
			if(stToplevelUnid != null && !stToplevelUnid.equals(stKey)){
				veMembers = tmGroups.get(stKey);
				if (veMembers.size() < MEMBERLIMIT){
					gd.setStUnid(stKey);
					gd.setVeAddress(veMembers);
					return gd;
				}
			}
		}

		return null;
	}

	private GroupData createGroup(){
		// do we have a top level Group Document ?
		Document docGroup;
		DocumentCollection dccGroup;
		int ilastGroupNumber = 1;
		Vector vMembers;
		String ListName = null;
		GroupData gd =null;

		if (this.topLevelGroup == null || this.topLevelGroup.getStUnid().isEmpty()){
			// try to search again
			String stSearch = "Type = 'Group' & GroupType = '3' & Form = 'Group' &  ListName ='" + AllConstants.GROUPIDENTIFIER + stDom + "'";
			try {
				dccGroup = dbNab.search(stSearch);
				if(dccGroup == null || dccGroup.getCount() == 0) {
					docGroup = dbNab.createDocument();
					docGroup.replaceItemValue("DenyDAATWrite", "1");
					docGroup.replaceItemValue("Form", "Group");
					docGroup.replaceItemValue("GroupType", "3");
					docGroup.replaceItemValue("Type", "Group");
					docGroup.replaceItemValue("ListDescription", "Update in EREG ONLY* Master Internet Address Reuse Group for " + stDom);
					docGroup.replaceItemValue("ListName", "Internet Address Reuse-"+ stDom);
					vMembers = new Vector<String>();
					//docGroup.replaceItemValue("ListOwner", "Group");
					//docGroup.replaceItemValue("LocalAdmin", "Group");
					//vMembers.add(GROUPIDENTIFIER + stDom + "-"+ String.format("%04d", ilastGroupNumber));
					docGroup.replaceItemValue("Members",vMembers);
					docGroup.computeWithForm(false, false);
					docGroup.save();
				}else{
					docGroup = dccGroup.getFirstDocument();
					vMembers = docGroup.getItemValue("Members");
				}
				this.topLevelGroup = this.new GroupData();
				this.topLevelGroup.setStUnid(docGroup.getUniversalID());
				this.topLevelGroup.setVeAddress(docGroup.getItemValue("Members"));
				tmGroups.put(docGroup.getUniversalID(),vMembers );
				docGroup.recycle();
				dccGroup.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// get the last index of the groups
		Set keyset = tmGroups.keySet();
		ilastGroupNumber = keyset.size();

		// create the group document:
		try {
			docGroup = dbNab.createDocument();
			docGroup.replaceItemValue("DenyDAATWrite", "1");
			docGroup.replaceItemValue("Form", "Group");
			docGroup.replaceItemValue("GroupType", "3");
			docGroup.replaceItemValue("Type", "Group");
			docGroup.replaceItemValue("ListDescription", "Update in EREG ONLY* "+ stDom +" Internet Address Reuse Group");
			ListName = AllConstants.GROUPIDENTIFIER + stDom + "-"  +  String.format("%04d", ilastGroupNumber) ;
			docGroup.replaceItemValue("ListName", ListName );
			vMembers = new Vector<String>();
			//docGroup.replaceItemValue("ListOwner", "Group");
			//docGroup.replaceItemValue("LocalAdmin", "Group");
			docGroup.replaceItemValue("Members",vMembers);
			docGroup.computeWithForm(false, false);
			docGroup.save();
			gd = this.new GroupData();
			gd.setStUnid(docGroup.getUniversalID());
			gd.setVeAddress(docGroup.getItemValue("Members"));
			docGroup.recycle();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// update the to level group document
		if(ListName != null){
			try {
				docGroup = dbNab.getDocumentByUNID(topLevelGroup.getStUnid());
				vMembers = docGroup.getItemValue("Members");
				vMembers.add(ListName);
				docGroup.replaceItemValue("Members", vMembers);
				docGroup.save();
				docGroup.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return gd;





	}


	private void logaction(byte ll, String stlogAction){
		if (this.log == null){
			System.out.println (stlogAction);
		}else{

			this.log.logActionLevel(ll, stlogAction);
		}
	}

}
