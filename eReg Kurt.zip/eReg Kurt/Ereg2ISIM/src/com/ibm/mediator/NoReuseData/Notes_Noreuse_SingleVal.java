package com.ibm.mediator.NoReuseData;

import com.ibm.mediator.config.ConfigObjMediatorDB;

public class Notes_Noreuse_SingleVal {
	private final String TABLENAME;

	private String FullName;
	private String Domain;
	private String PersonUnid;
	private String InternetAddress;
	private String BlockDate;
	private String CreationDate;
	private String DeletionDate;
	private String sqlInsertState;
	private String LockOutOnly;
	private String SerialPSC;
	private String SuppressFlag = "0";


	public String getSerialPSC() {
		if (SerialPSC == null)return "N/A";
		if (SerialPSC.length() < 11){
			return SerialPSC;
		}else{
			return "N/A";
		}
	}

	public void setSerialPSC(String serialPSC) {
		SerialPSC = serialPSC;
	}

	public Notes_Noreuse_SingleVal(ConfigObjMediatorDB cfg) throws Exception {
		super();
		TABLENAME = cfg.getTable()[0];
		// TODO Auto-generated constructor stub
	}

	public String getFullName() {
		return FullName.replaceAll("'", "''");
	}
	public void setFullName(String fullName) {
		FullName = fullName;
	}
	public String getDomain() {
		return Domain;
	}
	public void setDomain(String domain) {
		Domain = domain;
	}
	public String getPersonuinid() {
		return PersonUnid;
	}
	public void setPersonuinid(String personuinid) {
		PersonUnid = personuinid;
	}

	public String getInternetAddress() {
		return InternetAddress.replaceAll("'", "''");
	}

	public void setInternetAddress(String internetAddress) {
		InternetAddress = internetAddress;
	}

	public String getBlockDate() {
		if (BlockDate.length() >8 ){
			return BlockDate.substring(0,8);
		}else{
			return BlockDate;
		}
	}
	public void setBlockDate(String blockDate) {
		BlockDate = blockDate;
	}
	public String getCreationDate() {
		if (CreationDate.length()>8){
			return CreationDate.substring(0,8);
		}else{
			return CreationDate;
		}

	}
	public void setCreationDate(String creationDate) {
		CreationDate = creationDate;
	}
	public String getDeletionDate() {
		if(DeletionDate.length() > 8 ){
			return DeletionDate.substring(0,8);
		}else{
			return DeletionDate;
		}
	}

	public void setDeletionDate(String deletionDate) {

		DeletionDate = deletionDate;
	}

	public String getLockOutOnly() {
		return LockOutOnly;
	}

	public void setLockOutOnly(String lockOutOnly) {
		LockOutOnly = lockOutOnly;
	}

	public String getsqlInsertState(){
		sqlInsertState = "INSERT INTO " + TABLENAME + "(FULLNAME, DOMAIN, PERSONUNID, INTERNETADDRESS, BLOCKDATE, CREATIONDATE, DELETIONDATE, LOCKOUTONLY, SERIALPSC, SUPPRESSFLAG) VALUES ('" +
				getFullName() + "', '"	+ getDomain() + "', '" + getPersonuinid() + "', '" + getInternetAddress() + "', '"	+ getBlockDate() + "', '"	+
				getCreationDate() + "', '" 	+ getDeletionDate() + "', '" 	+ getLockOutOnly() + "', '" 	+ getSerialPSC() + "', '" + getSuppressFlag() + "')";
		return sqlInsertState;
	}

	public String getSuppressFlag() {
		return SuppressFlag;
	}

	public void setSuppressFlag(String suppressFlag) {
		SuppressFlag = suppressFlag;
	}
	
	

}
