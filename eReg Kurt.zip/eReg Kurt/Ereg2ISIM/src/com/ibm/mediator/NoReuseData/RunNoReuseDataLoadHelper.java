package com.ibm.mediator.NoReuseData;



import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Properties;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.mediator.NoReuseInterface.ResponseNameProposal;
import com.ibm.mediator.NoReuseLogic.NoReuseNameProposalHandler;
import com.ibm.mediator.NoReuseLogic.NoReuseNotesConfiguration;
import com.ibm.mediator.NoReuseLogic.NoReuseNotesReservationHandler;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.notes.secure.PasswordHandler;

import lotus.domino.Agent;
import lotus.domino.AgentContext;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class RunNoReuseDataLoadHelper extends NotesThread {
	private Database dbLog;
	private AgentContext agCon;
	private Agent ag;
	private Session session;
	private Document docLog;
	private RequestLogger rl;

	//private static final String implName = "NoReuseServer"; 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunNoReuseDataLoadHelper rh = new RunNoReuseDataLoadHelper();
		rh.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		//String host = "localhost";
		//RequestLogger log ;
		String passwd = null;
		//int port = 4811;
		super.runNotes();
		System.out.println("start");
		DB2ConnectData  dbcon  = null;

		//Session s = NotesFactory.createSessionWithFullAccess("hug4jaco!");
		session = NotesFactory.createSessionWithFullAccess("sum16mer.");

		String env = "p";
		Reader fReader;
		try {
			fReader = new FileReader(AllConstants.DB2PROPERTIES);

			PasswordHandler ph = new PasswordHandler();
			Properties propDb2 = new Properties();
			propDb2.load(fReader);
			
			dbcon = new DB2ConnectData();
			dbcon.setClass(propDb2.getProperty("Class"));
			dbcon.setDB2Database(propDb2.getProperty("Database"));
			//dbcon.setdb2LookupView(propDb2.getProperty("Lookupview"));
			dbcon.setdb2Lookup(propDb2.getProperty("Lookupview"));
			//dbcon.setDb2SerialLookupView(propDb2.getProperty("SerialLookupView"));
			dbcon.setURL(propDb2.getProperty("URL"));
			dbcon.setLogLevel(Byte.parseByte(propDb2.getProperty("LogLevel")));

			if (env.toLowerCase().equals("p") || env.toLowerCase().equals("production")){
				dbcon.setIPAddress(propDb2.getProperty("IPAddressProd")); // PROD
				dbcon.setUserid(propDb2.getProperty("UserIdProd")); // PROD
				//dbcon.setPassword(propDb2.getProperty("PasswordProd"));
				passwd = ph.getPw(PasswordHandler.kindOfPwDB2);
				dbcon.setPassword(passwd);
				dbcon.setPort(Integer.parseInt(propDb2.getProperty("PortProd"))); // PROD
				dbcon.setIPAddressBackup(propDb2.getProperty("IPAddressBackupProd"));

			}else if(env.toLowerCase().equals("t") || env.toLowerCase().equals("test")){
				dbcon.setIPAddress(propDb2.getProperty("IPAddressTest")); // INT
				dbcon.setUserid(propDb2.getProperty("UserIdTest")); // INT
				passwd = ph.getPw(PasswordHandler.kindOfPwDB2);
				dbcon.setPassword(passwd);
				dbcon.setPort(Integer.parseInt(propDb2.getProperty("PortTest"))); // INT
			}else{
				System.out.println ("parm3 must be production, p, test or t");
				return;
			}

		} catch (FileNotFoundException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// gets the log doc
		try {
			getLogDoc();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return;
		}



		String stReservedMetod =docLog.getItemValueString("ReservedMethod");
		if(stReservedMetod.equals("DEL1")){
			try {
				NoReuseNotesReservationHandler nrH = new NoReuseNotesReservationHandler(session, docLog);
				nrH.delReservationAdd2NoReuse();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}


		if(stReservedMetod.equals("DEL")){
			try {
				GetReservationOrPorposalForEreg grfe = new GetReservationOrPorposalForEreg(session, rl);
				int iRes = grfe.getReservationVAL();
				if(iRes == 0){
					// we found no reservation we have to make as proposal
					rl.logActionLevel(LogLevel.INFO, "Found no reservation -> try to make a proposal");
					NoReuseNotesConfiguration nconf = new NoReuseNotesConfiguration(session, docLog);
					String []stDummy = nconf.getCfgNotes_Noreuse_Multival().getIpAddressPort()[0].split(":");
					String stIP = stDummy[0];
					String stClass =nconf.getCfgNotes_Noreuse_Multival().getClassName()[0];
					String stDatabase = nconf.getCfgNotes_Noreuse_Multival().getDatabase()[0];
					String stUrl = nconf.getCfgNotes_Noreuse_Multival().getUrl()[0];
					String stPort = stDummy[1];
					String stUser = nconf.getCfgNotes_Noreuse_Multival().getUser()[0];
					String stPassword = nconf.getCfgNotes_Noreuse_Multival().getPassword()[0];

					dbcon.setIPAddress(stIP);
					dbcon.setClass(stClass);
					dbcon.setDB2Database(stDatabase);
					dbcon.setURL(stUrl);
					dbcon.setPort(Integer.parseInt(stPort));
					dbcon.setdb2Lookup("NOREUSE.NOREUSE_LOOKUP");
					dbcon.setUserid(stUser);
					dbcon.setPassword(stPassword);

					NoReuseNameProposalHandler npH  = new NoReuseNameProposalHandler(rl,dbcon);


					String firstName =  docLog.getItemValueString("firstname");
					String middleInitial =  docLog.getItemValueString("middleInitial");
					String lastName =  docLog.getItemValueString("lastname");
					ResponseNameProposal rnp = npH.getNameProposal(firstName, middleInitial, lastName);
					rl.logActionLevel(LogLevel.INFO, "got the name proposal");
					if (rnp.getHasError().booleanValue()){
						rl.logActionLevel(LogLevel.SEVERE, "Error while get the proposal");
						rl.logActionLevel(LogLevel.SEVERE, "Error Description: " + rnp.getErrDescription()) ;

						System.out.println("Error while get proposal request");
						System.out.println(rnp.getErrDescription());
					}else{
						ResponseNameProposal.ProposedName pn[] = rnp.getProposedNames();
						docLog.replaceItemValue("FirstName", pn[0].getProposedFirstName());
						docLog.replaceItemValue("MiddleInitial", pn[0].getProposedMiddleInitial());
						docLog.replaceItemValue("LastName", pn[0].getProposedLastName());
						rl.logActionLevel(LogLevel.INFO, "Proposed name: "+ pn[0].getProposedFirstName() +
								( pn[0].getProposedMiddleInitial() == null ||  pn[0].getProposedMiddleInitial().isEmpty() ? "":" "+ pn[0].getProposedMiddleInitial() + " " ) +
								pn[0].getProposedLastName());

						//docLog.replaceItemValue("ReservedFullName", pn[0].getProposedFullName());
						//docLog.replaceItemValue("ReservedShortName", pn[0].get);
						docLog.replaceItemValue("InterNetAddress", pn[0].getProposedEMail());
						docLog.save();
						//docLog.recycle();
						//docLog =null;

					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/*
		Document docLog = grfe.getDocLog();
		if (docLog.getItemValueString("ResGetSuccefull").equals("1")){
			if(Integer.parseInt(docLog.getItemValueString("ResFound")) > 0){
				// get  proposal
				Registry r;
				try {
					r = LocateRegistry.getRegistry(host, port);
					NoReuseInterface nrRMIClient = (NoReuseInterface)r.lookup(implName);
					String stFirstName = (docLog.getItemValueString("FirstName") == null) ? "": docLog.getItemValueString("FirstName");
					String stMiddleInitial = (docLog.getItemValueString("MiddleInital") == null) ? "": docLog.getItemValueString("MiddleInitial");
					String stLastName =(docLog.getItemValueString("LastName") == null) ? "": docLog.getItemValueString("LastName");
					ResponseNameProposal np = nrRMIClient.getNameProposal(stFirstName, stMiddleInitial,stLastName);
					if (np.getHasError().booleanValue()){
						System.out.println("Error while get proposal request");
						System.out.println(np.getErrDescription());
					}else{
						ResponseNameProposal.ProposedName pn[] = np.getProposedNames();
						docLog.replaceItemValue("FirstName", pn[0].getProposedFirstName());
						docLog.replaceItemValue("MiddleInitial", pn[0].getProposedMiddleInitial());
						docLog.replaceItemValue("LastName", pn[0].getProposedLastName());
						docLog.replaceItemValue("ReservedFullName", pn[0].getProposedFullName());
						//docLog.replaceItemValue("ReservedShortName", pn[0].get);
						docLog.replaceItemValue("InterNetAddress", pn[0].getProposedEMail());
					}
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (NotBoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}




		//NoReuseLoaderRunner nrlr = new NoReuseLoaderRunner(s);
		Database dbLog;
		dbLog = CommonFunctions.getDatabase(s, "ITIMTEST", "e_dir/ereglog6.nsf");

		try {
			InputOutputLogger log = new InputOutputLogger(s, dbLog, "TEST Load ids for no reuse - " + CommonFunctions.getActDate(),
					LogLevel.FINEST);
			ConfigObjMediatorDB cfgNotes_Noreuse_Multival = new  ConfigObjMediatorDB(s, AllConstants.MEDIATOR_NOTES_NOREUSE_MULTIVAL, log);
			TheConnector theConnect = new TheConnector(log, cfgNotes_Noreuse_Multival);
			NoReuseDownLoaderNAB nrNABDl = new NoReuseDownLoaderNAB(s,"IBMAU");
			NoReuseDownLoaderDB2 nrDB2Dl = new NoReuseDownLoaderDB2(s,theConnect,log,"IBMAU");
			HashSet<String> hsNAB = nrNABDl.getHsNoResuseInternetAddress() ;
			HashSet<String> hsDB2Active =  nrDB2Dl.getHsDB2IdsActive();
			HashSet<String> hsDeleted =  nrDB2Dl.getHsDB2IdsDeleted();
					//View vwl = dbLog.getView("Logs\\by Agent");
			//Document doc = dbLog.getDocumentByID("2ACAE");
			//doc.replaceItemValue("NameToCheck", "Kurt Raiser/Germany/IBM");
			//doc.save();
			//CheckReuseOfNames crn = new CheckReuseOfNames(s, doc.getNoteID());
			//crn.run();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	private void getLogDoc() throws Exception{
		try {
			String stUnid;
			dbLog  = CommonFunctions.getLogDB(session);
			agCon = session.getAgentContext();
			if (agCon == null){
				stUnid = "1296BDA";
				stUnid ="12D4C8A";
			}else{
				ag = agCon.getCurrentAgent();
				stUnid = ag.getParameterDocID();
			}

			docLog= dbLog.getDocumentByID(stUnid);
			rl = new RequestLogger(session, docLog);

			rl.setCheckLogLevel(LogLevel.FINEST);
			rl.logActionLevel(LogLevel.INFO, "Init of GetReservationForEREG successfull finished.");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
	}

}
