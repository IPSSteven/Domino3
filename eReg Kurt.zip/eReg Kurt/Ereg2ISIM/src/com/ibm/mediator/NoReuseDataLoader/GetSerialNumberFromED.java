package com.ibm.mediator.NoReuseDataLoader;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class GetSerialNumberFromED extends NotesThread {
	public String pw;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GetSerialNumberFromED us = new GetSerialNumberFromED();
		us.pw = args[0];
		us.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess(pw);
		long lcount =0;
		long l =0 ;
		try {
			FileWriter fw = new FileWriter("c:/temp/UnidsSerialPSC.txt");
			BufferedWriter bf = new BufferedWriter(fw);
			Database db = CommonFunctions.getDatabase(s, "", "dircat/edcww.nsf");
			View vwP = db.getView("People");
			Document docRec = null;
			String stLine = null;
			Document doc = vwP.getFirstDocument();
			lcount = vwP.getEntryCount();
			while (doc != null){
				stLine = doc.getUniversalID() + "," + doc.getItemValueString("Empnum") + doc.getItemValueString("Empcc") +"\r\n";
				bf.write(stLine);
				docRec = doc;
				doc = vwP.getNextDocument(doc);
				docRec.recycle();
				l++;
				if(l%500 == 0 ){
					bf.flush();
					System.out.println("Entry: " + l + " from " + lcount);
				}
				
			}
			bf.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
