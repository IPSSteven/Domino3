package com.ibm.mediator.NoReuseDataLoader;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnectorNotes;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class NoReuseDenyAccessListLoadRunner extends NotesThread {

	private Session session;
	private Database dbLog;
	private InputOutputLogger log;
	private TheEregConnectorNotes  theConnect;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoReuseDenyAccessListLoadRunner loadRunner = new NoReuseDenyAccessListLoadRunner();
		loadRunner.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		int icount = 0;
		long iSum = 0;
		super.runNotes();
		session = NotesFactory.createSessionWithFullAccess("mac2jac.");
		

		
		try {
			// 1. Get the Log
			dbLog  = CommonFunctions.getLogDB(session);
			log = new InputOutputLogger(session, dbLog, "Load ids for no reuse - " + CommonFunctions.getActDateRecon(),
					LogLevel.FINEST);
			//pln("Got the log.");
			String sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);
			log.logActionLevel(LogLevel.INFO, "start No Reuse Loader on machine "+ sMachineKey);
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKRunning();
			
			// 2. config data for DB2
			Properties ph = new Properties();
			ph.load(new FileReader("NotesProperties.txt"));
			String NoReuseSingle = ph.getProperty("NoReuseSingleConf");
			 ConfigObjMediatorDB cfgNotes_Noreuse_SingleVal = new  ConfigObjMediatorDB(session, NoReuseSingle, log);
			 theConnect = new TheEregConnectorNotes(log, cfgNotes_Noreuse_SingleVal);
			log.setCheckLogLevel(Byte.parseByte(cfgNotes_Noreuse_SingleVal.getLogLevel()[0]));
			
			//3. get the configuration for the machine (domain which should be handle by this machine) s.
			ConfigObjReConcileITIM cr = new ConfigObjReConcileITIM(session,
					AllConstants.MEDIATOR_NOTES_NOREUSE_DOMAINS + sMachineKey, log);
			
			// 4. get the deny access list in buffer
			NoReuseDenyAccessListLoader loader = new NoReuseDenyAccessListLoader(log, cr, cfgNotes_Noreuse_SingleVal);
			HashSet<String> hmtmp =loader.getDenyAccessListFromDatabase();
			BufferedWriter bf = new BufferedWriter(new FileWriter("C:/temp/out.txt"));
			Iterator<String> it = hmtmp.iterator();
			while(it.hasNext()){
				bf.write(it.next() + "\r\n");
				icount++;
				if (icount >= 1000){
					bf.flush();
					iSum = iSum + icount;
					icount = 0;
					System.out.println ("Done:   " + iSum );
					
				}
			}
			bf.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
