package com.ibm.mediator.NoReuseDataLoader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Properties;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjCountryTable;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.NoReuseData.Notes_Noreuse_SingleVal;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnectorNotes;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class NoReuseFileLoader extends NotesThread {
	private Database dbLog;
	private InputOutputLogger log;
	private ConfigObjCountryTable  cfgCountryTable;
	private TheEregConnectorNotes theConnect;

	public NoReuseFileLoader() {
		// TODO Auto-generated constructor stub

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoReuseFileLoader nrfl = new NoReuseFileLoader();
		nrfl.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session session = NotesFactory.createSessionWithFullAccess("wurst4jac.");

		try {
			// 1 . get the log
			dbLog  = CommonFunctions.getLogDB(session);
			log = new InputOutputLogger(session, dbLog, "File Load ids for no reuse - " + CommonFunctions.getActDateRecon(),
					LogLevel.FINEST);
			//pln("Got the log.");
			String sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);
			log.logActionLevel(LogLevel.INFO, "start No Reuse File Loader on machine "+ sMachineKey);
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKRunning();

			// 2. config data for DB2
			Properties ph = new Properties();
			ph.load(new FileReader("NotesProperties.txt"));
			String NoReuseSingle = ph.getProperty("NoReuseSingleConf");
			
			ConfigObjMediatorDB cfgNotes_Noreuse_SingleVal = new  ConfigObjMediatorDB(session, NoReuseSingle, log);

			//3. get the DB2 Connector
			this.theConnect = new TheEregConnectorNotes(log, cfgNotes_Noreuse_SingleVal);
			log.setCheckLogLevel(Byte.parseByte(cfgNotes_Noreuse_SingleVal.getLogLevel()[0]));

			//4. get the InputFile
			Notes_Noreuse_SingleVal NrSv;
			String stDom;
			String stLine = null;
			long count = 0;
			String sCreationdate = CommonFunctions.getActDateRecon();
			BufferedReader br = new BufferedReader(new FileReader("c:/EREG/NoReuse/suspended.txt"));
			while ((stLine = br.readLine()) !=null){
				if (stLine.indexOf("@") >0 ){
					NrSv = new Notes_Noreuse_SingleVal(cfgNotes_Noreuse_SingleVal);

					NrSv.setCreationDate(CommonFunctions.getActDateRecon());
					NrSv.setBlockDate(CommonFunctions.getActDateRecon());
					NrSv.setDeletionDate("");

					stDom = "IBM" + stLine.split("@")[1].substring(0, 2).toUpperCase();

					NrSv.setDomain(stDom);
					NrSv.setFullName(stLine);
					NrSv.setInternetAddress(stLine);
					NrSv.setPersonuinid("N/A-NoReuseInternet-"+ count);
					NrSv.setCreationDate(sCreationdate);
					NrSv.setLockOutOnly("S");
					theConnect.executeUpdate(NrSv.getsqlInsertState());
					System.out.println(stLine + count);
					count ++;
				}
			}
			br.close();
			lds.setOKDone();
			log.closeLog(lds);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}

}
