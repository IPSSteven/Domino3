package com.ibm.mediator.NoReuseDataLoader;

import java.io.FileNotFoundException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Vector;

//import com.ibm.db2.jcc.am.hd;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjCountryTable;
import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.notesdata.Connect;
import com.ibm.ereg.notesdata.ConnectConfig;
import com.ibm.ereg.rmi.data.denyAccess.DenyAccessData;
import com.ibm.ereg.rmi.data.denyAccess.DenyAccessDataLoader;
import com.ibm.mediator.NoReuseData.NoReuseDataHolder;
import com.ibm.mediator.NoReuseData.NoReuseLoadThreadData;
import com.ibm.mediator.NoReuseData.Notes_NoReuse_MultiVal;
import com.ibm.mediator.NoReuseData.Notes_Noreuse_SingleVal;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnectorNotes;
import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewNavigator;

public class NoReuseLoaderThread extends NotesThread {

	private String pw;
	private String domain;
	private String stMachineKey;
	private String stHandleDenyAccess;
	private String Agentname;
	private String NoReuseSingleConf;
	private String NoReuseMultiConfig;

	int linsertMulti = 0;
	int linsertSingle = 0;
	long iMillis  = 0;
	Session s;
	private Database dbNab;
	
	

	//private ConfigObjMailDomainServer cfgMailDomainServer;
	private ConfigObjMediatorDB cfgNotes_Noreuse_SingleVal;
	private ConfigObjMediatorDB cfgNotes_Noreuse_Multival;
	//private ConfigObjReConcileITIM crNoEMEA;
	private  InputOutputLogger log;

	private TheEregConnectorNotes theConnect;
	private NoReuseDataHolder nrDH;

	public NoReuseLoaderThread (NoReuseLoadThreadData nrtd) {
		this.pw = nrtd.getPassword();
		this.domain = nrtd.getDomain();
		this.stMachineKey = nrtd.getStMachineKey();
		this.stHandleDenyAccess = nrtd.getStHandleDenyAccess();
		this.Agentname = nrtd.getAgentName();
		this.NoReuseSingleConf = nrtd.getNoReuseSingleConf();
		this.NoReuseMultiConfig = nrtd.getNoReuseMultiConfig();
	
	}



	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		iMillis = System.currentTimeMillis();


		synchronized (this.getClass()) {
			s = CommonFunctions.getNewSession(pw);
		}



		// 2. config data for DB2
		try {
			//	this.cfgMailDomainServer = new ConfigObjMailDomainServer(s);
			//	Set<String> oEMEADomains = this.cfgMailDomainServer.getNabServers_domain().keySet();
			//	crNoEMEA = new ConfigObjReConcileITIM(s, AllConstants.MEDIATOR_NOTES_NOREUSE_NOEMA_DOMAINS , log);
			Database dbLog = CommonFunctions.getLogDB(s);
			log = new InputOutputLogger(s, dbLog, "Load ids for no reuse  multithread- domain "  + domain,
					LogLevel.FINEST);
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKRunning();
			log.refreshLog(lds);
			log.getDocLog().replaceItemValue("Agent",this.Agentname);
			
			// db2 config
			//this.cfgNotes_Noreuse_SingleVal = new  ConfigObjMediatorDB(s, AllConstants.MEDIATOR_NOTES_NOREUSE_SINGLEVAL, log);
			//this.cfgNotes_Noreuse_Multival = new  ConfigObjMediatorDB(s, AllConstants.MEDIATOR_NOTES_NOREUSE_MULTIVAL, log);
			log.logActionLevel(LogLevel.INFO, "Configuration for Noreuse Single=" + NoReuseMultiConfig + " Configuration for NoreuseMulti="+  NoReuseMultiConfig);
			
			this.cfgNotes_Noreuse_SingleVal = new  ConfigObjMediatorDB(s, NoReuseSingleConf, log);
			this.cfgNotes_Noreuse_Multival = new  ConfigObjMediatorDB(s, NoReuseMultiConfig, log);
			
			this.theConnect = new TheEregConnectorNotes(log, cfgNotes_Noreuse_Multival);
			log.setCheckLogLevel(Byte.parseByte(cfgNotes_Noreuse_Multival.getLogLevel()[0]));

			log.logActionLevel(LogLevel.INFO,Thread.currentThread().getName() + " started for domain " + domain);
			if (bgetDatafromDB2()){

				//find the database
				//if (oEMEADomains.contains(domain)){
				//	server = this.cfgMailDomainServer.getNabServers_domain().get(domain);
				//	dbNab = CommonFunctions.getDatabase(s, server,AllConstants.NABDBNAME);	

				//}else{

				dbNab = CommonFunctions.getDatabase(s,AllConstants.EXTENDED_DIRNEW_SERVER,AllConstants.EXTENDED_DIRNEW);
				//}

				handleDomainNew(s);
				setDeletionDate();

			}
			log.logActionLevel(LogLevel.INFO,Thread.currentThread().getName() + " for domain " + domain + " done after " + (System.currentTimeMillis()- iMillis) + " millis");

			pln(Thread.currentThread().getName() + " for domain " + domain + " done after " + (System.currentTimeMillis()- iMillis) + " millis");



			if (stHandleDenyAccess.equals("Y")){
				log.logActionLevel(LogLevel.INFO,Thread.currentThread().getName() + " get deny access");

				ConfigObjReConcileITIM cr = new ConfigObjReConcileITIM(s,
						AllConstants.MEDIATOR_NOTES_NOREUSE_DOMAINS + stMachineKey, log);
				//HashSet<String> denyListTermination = getDenyAccessList(cr);
				HashSet<String> denyListTermination = getDenyAccessListFromDatabase();
				if (denyListTermination != null) getDatafromDenyAccess(denyListTermination);

			}

			lds = new LogDocStatus(log.getDocLog());
			lds.setOKDone();
			log.closeLog(lds);
			
			if(dbNab != null) {
				dbNab.recycle();
			}
			
			if(s != null) {
				s.recycle();
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}


	private boolean bgetDatafromDB2(){
		String LeftTable;
		String RightTable;
		try {
			LeftTable = cfgNotes_Noreuse_SingleVal.getTable()[0];
			RightTable = cfgNotes_Noreuse_Multival.getTable()[0];
		} catch (Exception e) {
			log.logActionLevel(LogLevel.SEVERE, "Error while try to get the tables for db2 from configuration" );
			e.printStackTrace();
			return false;
		}

		long lRow = 0;

		this.nrDH = new NoReuseDataHolder();

		HashSet<String> hsUnidsDeleted= this.nrDH.gethsUnidsDeleted();
		HashSet<String> hsUnidsActive= this.nrDH.gethsUnidsActive();
		HashSet<String> hsAddress  = this.nrDH.gethsAddress();;

		String sql = "Select " +
				LeftTable + ".FULLNAME, " +
				LeftTable + ".DOMAIN, " +
				LeftTable + ".PERSONUNID ," +
				LeftTable + ".DELETIONDATE ," +
				LeftTable + ".LOCKOUTONLY ," +
				RightTable + ".FIELDVALUE FROM " + LeftTable + " LEFT JOIN " +
				RightTable + " ON " + LeftTable + ".PERSONUNID = " + RightTable + ".PERSONUNID WHERE " +
				LeftTable + ".DOMAIN = '" + domain + "'";
		//LeftTable + ".DOMAIN = '" + Domain + "'" + "AND DELETIONDATE = ''" ;
		log.logActionLevel(LogLevel.FINE, "Try to execute sql " + sql);
		ResultSet rs = this.theConnect.excuteQuery(sql);

		if ( rs == null){return false;
		}else{
			try {
				while (rs.next()){
					try{
						lRow++;
						/*String dummy = rs.getString(3);
					dummy = rs.getString(3);
					dummy = rs.getString(4);
					dummy = dummy.replaceAll("\\s", "");*/
						// getString (4) deletion data
						if (rs.getString(4) == null || rs.getString(4).trim().equals("")  ){ //deletion date and LOCKOUTONLY
							if(rs.getString(5) != null && rs.getString(5).equals("N")){
								hsUnidsActive.add(rs.getString(3)); // put the unid in the active hashset
								hsAddress.add(rs.getString(1)); // Fullname
								hsAddress.add(rs.getString(6)); // Fieldvalue (internetaddreses)
							}

						}else{
							hsUnidsDeleted.add(rs.getString(3));
						}
					}catch(SQLException e){
						log.logActionLevel(LogLevel.SEVERE, "Error while reading data from row " + rs.toString()+  " -> " + e.getMessage());
						e.printStackTrace();
					}

				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, "Error reading next from SQL Table ->" + e.getMessage());
				e.printStackTrace();
			}

		}
		log.logActionLevel(LogLevel.FINE, "Found " +lRow+ " entries for " + domain + " in db2");
		return true;


	}
	private void checkNoReuseList(Session s, ViewEntry vecCheck){
		Name NotesName = null;
		Notes_Noreuse_SingleVal NrNa;
		Notes_NoReuse_MultiVal NrAl;
		String stShortNameAddress;
		HashSet<String> hsUnique;
		String stUniversalId = "";
		boolean bHandleMulti = true;
		Object o;

		// the fullname
		Vector<String> Itimvalue = null;
		try {


			//Itimvalue = doc.getItemValue("FullName");
			o = vecCheck.getColumnValues().elementAt(7); // fullname
			Itimvalue = getVectorFromObj(o);
			if(Itimvalue == null) {
				return;
			}else if(Itimvalue.size() == 0) {
				return;
			}
			//Iterator it = Itimvalue.iterator();
			//while(it.hasNext()){
			//NotesName = session.createName((String)it.next());

			// The fullname
			try{

				NotesName = s.createName(Itimvalue.firstElement());
			}catch(NoSuchElementException e){
				log.logActionLevel(LogLevel.SEVERE,"Error while handling Fullname:" + Itimvalue == null? "N/A":Itimvalue.firstElement() );
				log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
				if (NotesName != null) NotesName.recycle();
				return;
			}

			//stUniversalId = doc.getUniversalID();
			stUniversalId = (String)vecCheck.getColumnValues().elementAt(13);


			if (this.nrDH.gethsAddress().contains(NotesName.getAbbreviated())){
				if(nrDH.gethsUnidsDeleted().contains(stUniversalId)){ // the id might be rebuild
					bHandleMulti= false;
				}else {
					nrDH.gethsUnidsActive().remove(stUniversalId); // remove it (remainder are all deleted ids)
				}

			}else{
				//if nrDH.
				try {
					if(nrDH.gethsUnidsDeleted().contains(stUniversalId)){
						// in this case the deletion date in the db2 is wrong !. It will be cleared. Short name should not be handled. They are not loaded
						nrDH.gethsUnidsDeleted().remove(stUniversalId);
						nrDH.gethsUnidsClearDeletionDate().add(stUniversalId);
						bHandleMulti= false;
					}else{
						// insert row in noreuse notes address
						linsertSingle ++;
						NrNa = new Notes_Noreuse_SingleVal(cfgNotes_Noreuse_SingleVal);
						NrNa.setBlockDate(CommonFunctions.getYYYYMMDD((DateTime)vecCheck.getColumnValues().elementAt(3))); // datetime
						NrNa.setCreationDate(CommonFunctions.getActDateRecon());
						NrNa.setDeletionDate("");
						//NrNa.setDomain(stDom);
						NrNa.setDomain((String)vecCheck.getColumnValues().elementAt(5));
						NrNa.setFullName(NotesName.getAbbreviated());
						//NrNa.setInternetAddress(doc.getItemValueString("InternetAddress"));
						NrNa.setInternetAddress(((Vector)vecCheck.getColumnValues().elementAt(6)).elementAt(0).toString());
						NrNa.setPersonuinid((String)vecCheck.getColumnValues().elementAt(13));
						NrNa.setLockOutOnly("N");
						NrNa.setSerialPSC((String)vecCheck.getColumnValues().elementAt(1)+ (String)vecCheck.getColumnValues().elementAt(2) );
						theConnect.executeUpdate(NrNa.getsqlInsertState());
					}
				} catch (Exception e) {
					log.logActionLevel(LogLevel.SEVERE,"Error while handling Fullname:" + NotesName.getAbbreviated() );
					log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
					e.printStackTrace();
				}
			}
			if
			(NotesName != null) NotesName.recycle();

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while handling Fullname: " + (Itimvalue == null ? "N/A":Itimvalue.firstElement()));
			log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
			e.printStackTrace();
		}

		if (bHandleMulti){
			// the fullname multi values (aliases)
			try {
				hsUnique = new HashSet<String>();
				o = vecCheck.getColumnValues().elementAt(7);
				Itimvalue = getVectorFromObj(o); // fullname
				if (Itimvalue != null) {
					int size = Itimvalue.size();
					for(int i = 1; i <size; i++ ){ // get the 2 - last element
						NotesName = s.createName(Itimvalue.get(i));
						hsUnique.add(NotesName.getAbbreviated());
						NotesName.recycle();
					}
					String [] stFullNames = hsUnique.toArray(new String[hsUnique.size()]);
					for(String stFull:stFullNames){
						if (!this.nrDH.gethsAddress().contains(stFull)){
							// insert row multivalues
							try {
								NrAl = new Notes_NoReuse_MultiVal(cfgNotes_Noreuse_Multival);
								NrAl.setPersonUnid((String)vecCheck.getColumnValues().elementAt(13));
								NrAl.setFieldName("FNA");
								NrAl.setFieldValue(stFull);
								theConnect.executeUpdate(NrAl.getSqlInsertState());
								linsertMulti ++;
							} catch (Exception e) {
								log.logActionLevel(LogLevel.SEVERE,"Error while handling fullname alias " + stFull );
								log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
								e.printStackTrace();
							}

						}

					}
				}
			} catch (NotesException e1) {
				log.logActionLevel(LogLevel.SEVERE,"Error while handling fullname alias" );
				log.logActionLevel(LogLevel.SEVERE,e1.getLocalizedMessage());
				e1.printStackTrace();
			}

			// the short name .. the multi values

			try {
				// short names are not all unique
				hsUnique = new HashSet<String>();
				o = vecCheck.getColumnValues().elementAt(6);
				if (o != null) {
					Itimvalue = getVectorFromObj(o);
					Iterator<String> it = Itimvalue.iterator();
					while(it.hasNext()){
						stShortNameAddress = (String)it.next();
						hsUnique.add(stShortNameAddress);
					}
					for( String stShort : (String[])hsUnique.toArray(new String[hsUnique.size()])){
						if (stShort.indexOf("@") > 0){
							if (!this.nrDH.gethsAddress().contains(stShort)){
								// insert row in noreuse internetaddress
								try {
									NrAl = new Notes_NoReuse_MultiVal(cfgNotes_Noreuse_Multival);
									NrAl.setPersonUnid((String)vecCheck.getColumnValues().elementAt(13));
									NrAl.setFieldName("SN");
									NrAl.setFieldValue(stShort);
									theConnect.executeUpdate(NrAl.getSqlInsertState());
									linsertMulti ++;
								} catch (Exception e) {
									log.logActionLevel(LogLevel.SEVERE,"Error while handling short name alias" );
									log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
									e.printStackTrace();
								}

							}
						}	
					}
				}

			} catch (NotesException e) {
				log.logActionLevel(LogLevel.SEVERE,"Error while handling short name alias" );
				log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
				e.printStackTrace();
			}
		}

		// remvove the univeralid from Hset. The remaining universalids in the hashset are deleted documents (only if the deletion date is empty)
		//nrDH.getHsNABUnidsDeleted().remove(stUniversalId);

	}
	private void setDeletionDate(){
		Iterator<String> it = null;
		String stsql = null;
		HashSet<String> hsunids = nrDH.gethsUnidsActive();
		String stActdate =  CommonFunctions.getActDateRecon();
		int i = 0;
		String stSqlUpdate;
		StringBuffer stsqlb = null; 
		if (stActdate.length() > 8) stActdate = stActdate.substring(0,8); 
		try {
			stsql =  "UPDATE " + cfgNotes_Noreuse_SingleVal.getTable()[0] + " SET DELETIONDATE = '" +  stActdate + "' where PERSONUNID IN ('";
			it = hsunids.iterator();
			stsqlb = new StringBuffer();
			while (it.hasNext()){
				stsqlb.append(it.next() + "', '");
				// limit the update string
				if (i > 15) {
					stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.length()-3) + ")";
					theConnect.executeUpdate(stSqlUpdate);
					i = 0;
					stsqlb = new StringBuffer();
				}
				i++;

			}
			if (i >0 && stsqlb.length()>3){
				stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.length()-3) + ")";
				theConnect.executeUpdate(stSqlUpdate);
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			hsunids = nrDH.gethsUnidsClearDeletionDate();
			stsql =  "UPDATE " + cfgNotes_Noreuse_SingleVal.getTable()[0] + " SET DELETIONDATE = '' where PERSONUNID IN ('";
			it = hsunids.iterator();
			stsqlb = new StringBuffer();
			while (it.hasNext()){
				stsqlb.append(it.next() + "', '");
				// limit the update string
				if (i > 15) {
					if(stsqlb.toString().length() >3){
						stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.toString().length()-3) + ")";
						theConnect.executeUpdate(stSqlUpdate);
						i = 0;
					}
					stsqlb = new StringBuffer();
				}
				i++;

			}
			if (i >1 ){
				if(stsqlb.toString().length() >3){
					stSqlUpdate = stsql + stsqlb.toString().substring(0,stsqlb.toString().length()-3) + ")";
					theConnect.executeUpdate(stSqlUpdate);
				}
			}


		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(stsqlb.toString());
			e.printStackTrace();
		}
	}
	private void pln(String s){
		System.out.println(s);
	}


	private void handleDomainNew(Session s) throws Exception{

		//dbNab = CommonFunctions.getDatabase(session, "","ereg/namesLT.nsf");
		//dbNab = CommonFunctions.getDatabase(session, "D06EDC10","dircat/edcww.nsf");
		linsertMulti = 0;
		linsertSingle = 0;
		long lCount = 0;
		long lloop;

		View vwLookup = dbNab.getView(AllConstants.EXTENDED_DIRNEW_VIEW);
		vwLookup.setAutoUpdate(false);
		ViewNavigator vn = vwLookup.createViewNavFromCategory(domain);
		vn.setCacheGuidance(1024, ViewNavigator.VN_CACHEGUIDANCE_READALL);
		//ViewEntryCollection vecDom = vwLookup.getAllEntriesByKey(domain);
		ViewEntry ve = null;
		ViewEntry veRecycle = null;

		log.logActionLevel(LogLevel.FINE, "Found " + vn.getCount()+ " entries in the for domain " + domain);
		pln("Found " + vn.getCount()+ " entries in the for domain " + domain);
		// get the selection only Person documents


		// loop through the collection
		lloop = 0;
		if (vn != null){
			try {
				ve = vn.getFirst();
				
				while(ve != null){
					checkNoReuseList(s,ve);
					veRecycle = ve;
					ve = vn.getNext();
					veRecycle.recycle();
					lloop ++;
					if(lloop%5000 == 0){
						log.logActionLevel(LogLevel.INFO, "Still alive working " + lloop + " documents for the domain " + domain + " in the NAB after " + 
								((System.currentTimeMillis() - iMillis)/1000) + " seconds");
						pln("Still alive working " + lloop + " documents for the domain " + domain + " in the NAB after " +
								((System.currentTimeMillis() - iMillis)/1000) + " seconds");
					}
				}
				log.logActionLevel(LogLevel.INFO, "Inserted " + linsertSingle + " single values and " + linsertMulti + " multivalues for "+ domain);

			} catch (NotesException e) {
				// TODO Auto-generated catch block
				if(ve != null) ve.recycle();;
				log.logActionLevel(LogLevel.SEVERE,"Error while looping throug the Nab docs");
				e.printStackTrace();
			}
		}

		if (ve != null) ve.recycle();
		if(vn != null){
			try {
				vn.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			dbNab.recycle();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private Vector<String> getVectorFromObj ( Object o){
		Vector<String> Itimvalue;

		if(o == null) return null;

		if(o instanceof String) {
			Itimvalue = new Vector();
			Itimvalue.add((String)o);
		}else {
			Itimvalue = (Vector)o;
		}
		return Itimvalue;
	}
	private void getDatafromDenyAccess(HashSet<String>  denyListTermination){
		//private void getDatafromDenyAccess(String stDomhandled){
		Iterator<String> it;
		Name notesName;
		String stName;
		Notes_Noreuse_SingleVal NrSv;
		String [] stNamepart;
		String stDom;
		long count = 0;
		int insert = 0;
		String stTable;
		ConfigObjCountryTable cfgCountryTable;
		try {
			cfgCountryTable = new ConfigObjCountryTable(s);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Error while loading country table");
			e1.printStackTrace();
			return;
		}

		HashSet<String> hsDenyAccessIds = this.nrDH.gethsAddress();

		// get the existing data in db2 and put i on hsDenyAccess
		try {
			stTable = cfgNotes_Noreuse_SingleVal.getTable()[0];

			String sql = "Select " +
					stTable + ".FULLNAME FROM " + stTable + 
					" WHERE LOCKOUTONLY = 'T' ";

			ResultSet rs = this.theConnect.excuteQuery(sql);
			while (rs.next()){
				hsDenyAccessIds.add(rs.getString(1));
			}
			log.logActionLevel(LogLevel.INFO,"Found " + hsDenyAccessIds.size() + " ids for Deny Access in db2");


		} catch (Exception e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while add deny access");
			log.logActionLevel(LogLevel.SEVERE,e1.getLocalizedMessage());
			e1.printStackTrace();
			return;
		}

		// loop through the list we have form RMI server and compare it with the list we got from DB2
		try {
			int isize = denyListTermination.size();
			it = denyListTermination.iterator();
			log.logActionLevel(LogLevel.INFO,"Termination list has " +  denyListTermination.size() + " ids");
			while(it.hasNext()){
				stName = it.next();
				notesName = s.createName(stName);
				//s.createn
				stNamepart = notesName.getAbbreviated().split("/");
				if(stNamepart.length >1)stDom = cfgCountryTable.getIBMCodeByCountryName(stNamepart[1]); else stDom = "";
				stName = notesName.getAbbreviated();
				//System.out.println(" result " + this.nrDH.getHsIdNoreUse().contains(stName));
				//if (stDom != null & stDom.equals(stDomhandled) && !this.nrDH.getHsIdNoreUse().contains(stName)){
				if (!hsDenyAccessIds.contains(stName)){
					NrSv = new Notes_Noreuse_SingleVal(cfgNotes_Noreuse_SingleVal);
					NrSv.setBlockDate("N/A");
					NrSv.setCreationDate(CommonFunctions.getActDateRecon());
					NrSv.setDeletionDate("");
					NrSv.setDomain(stDom);
					NrSv.setFullName(notesName.getAbbreviated());
					NrSv.setInternetAddress("N/A-Termination");
					NrSv.setPersonuinid("N/A-Termination- "+ count);
					NrSv.setLockOutOnly("T");
					theConnect.executeUpdate(NrSv.getsqlInsertState());
					insert++;
				}

				count++;

				if(count % 5000 == 0){
					System.out.println("Working on "+  count+ " record of " + isize );
				}
				notesName.recycle();
			}
			log.logActionLevel(LogLevel.INFO,"Added " + insert + " ids from Deny Access List");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while handling Deny Access" );
			log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			e.printStackTrace();
		}
	}

	/*private HashSet<String>getDenyAccessList(ConfigObjReConcileITIM cr){
		String stRMIServer;
		String stRMIPort;
		NotesRMIClient nrc;
		ReceiveInterFace nri;
		HashSet<String> denyListTermination = null;

		//  connect to RMI server
		try {
			stRMIServer = cr.getRMIDomin2SearchCorrectNCOUAR()[0];
			stRMIPort = cr.getRMIPortDenyAccess()[0];
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"RMIServer not provided by configuration");
			log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			e.printStackTrace();
			return denyListTermination;

		}

		log.logActionLevel(LogLevel.INFO," Try to connect to RMIServer : " + stRMIServer + " RMIPort :" + stRMIPort);
		//System.out.println("RMIServer :" + stRMIServer + "RMIPort :" + stRMIPort);
		try {
			nrc = new NotesRMIClient(stRMIServer,stRMIPort);
			nri = nrc.notesRMIInterface;
			denyListTermination = nri.getDenyListTermination();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while connect to RMI Server");
			log.logActionLevel(LogLevel.SEVERE,e.getMessage());
			e.printStackTrace();

		}
		log.logActionLevel(LogLevel.INFO," Connection to RMIServer : " + stRMIServer + " RMIPort :" + stRMIPort + " successful");
		return denyListTermination;
	}*/

	private HashSet<String> getDenyAccessListFromDatabase() throws NotesException, FileNotFoundException{
		ConnectConfig connConf = new ConnectConfig();	
		connConf.bOpenNames = true;
		connConf.bopenLogDb = true;
		pln("get Termination");
		Connect eregCon = new Connect(this.s, this.getClass().getSimpleName(), connConf);
		DenyAccessDataLoader dadl = new DenyAccessDataLoader(eregCon, false);
		dadl.loadCountries();
		DenyAccessData dad = DenyAccessData.getInstance();
		return dad.denyListTermination;
	}



}
