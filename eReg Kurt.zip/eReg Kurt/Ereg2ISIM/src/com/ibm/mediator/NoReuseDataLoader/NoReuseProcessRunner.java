package com.ibm.mediator.NoReuseDataLoader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import com.ibm.notes.secure.PasswordHandler;


import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class NoReuseProcessRunner extends NotesThread{
	private String pw;
	private String NoReuseSingleConf;
	private String NoReuseMultiConfig;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoReuseProcessRunner nrpr = new NoReuseProcessRunner();
		if (args.length == 1 && !args[0].isEmpty())	{
			nrpr.pw = args[0];
		}else {
			PasswordHandler ph = new PasswordHandler();
			nrpr.pw = ph.getPw("Notes");
		}
		Properties ph = new Properties();
		try {
			ph.load(new FileReader("NotesProperties.txt"));
			 nrpr.NoReuseSingleConf = ph.getProperty("NoReuseSingleConf");
			 nrpr.NoReuseMultiConfig = ph.getProperty("NoReuseMultiConf");
			 System.out.println("configs ");
			 nrpr.start();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess(pw);
		NoReuseLoaderRunnerNew nrr = new NoReuseLoaderRunnerNew();
		nrr.setSession(s);
		nrr.setPasswd(this.pw);
		nrr.setNoReuseSingleConf(NoReuseSingleConf);
		nrr.setNoReuseMultiConfig(NoReuseMultiConfig);
		nrr.setAgentName("(NoReuseLoaderRunner)|agNoReuseLoaderRunner");
		nrr.runLoader();
	}

	

}
