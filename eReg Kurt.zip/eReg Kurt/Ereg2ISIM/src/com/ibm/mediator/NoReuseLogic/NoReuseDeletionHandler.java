package com.ibm.mediator.NoReuseLogic;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Properties;

import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.FileLogerV16;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.NoReuseData.DeleteNoReuseData;
import com.ibm.mediator.NoReuseData.DeleteNoReuseDataInputExt;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.mediator.connector.TheEregConnector;
import com.ibm.notes.secure.PasswordHandler;

public class NoReuseDeletionHandler {
	private FileLogerV16 log;
	private TheEregConnector eregCon = null;
	HashSet<String> hsUnids = new HashSet<String>();

	//private final String NO_REUSE_QUERY = "SELECT UNID, DATASOURCE FROM NOREUSE.NOTES_NOREUSE_SEARCH WHERE ";
	private final String NO_REUSE_QUERY = "SELECT * FROM NOREUSE.NOTES_NOREUSE_SEARCH WHERE ";
	private final String NO_REUSE_UPDATE_SINGLEVAL = "UPDATE  NOREUSE.NOTES_NOREUSE_SINGLEVAL SET SUPPRESSFLAG = '1'  WHERE PERSONUNID = '";
	private final String NO_REUSE_UPDATE_MULTIVAL = "UPDATE  NOREUSE.NOTES_NOREUSE_MULTIVAL SET SUPPRESSFLAG = '1'  WHERE PERSONUNID = '";
	private final String NO_REUSE_DEL_RESERVATION = "DELETE FROM NOREUSE.NOTES_RESERVATION_SINGLEVAL WHERE SERIALNUMBERPSC ='";
	private final String NO_REUSE_REASON_TABLE = "NOREUSE.SUPPRESSION_REASON";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String passwd = null;
		Reader fReader = null;
		DB2ConnectData dbcon = null;
		try {
			
		
		
			fReader = new FileReader(AllConstants.DB2PROPERTIES);
			

			PasswordHandler ph = new PasswordHandler();
			Properties propDb2 = new Properties();
			propDb2.load(fReader);
			dbcon = new DB2ConnectData();
			dbcon.setClass(propDb2.getProperty("Class"));
			dbcon.setDB2Database(propDb2.getProperty("Database"));
			//dbcon.setdb2LookupView(propDb2.getProperty("Lookupview"));
			dbcon.setdb2Lookup(propDb2.getProperty("Lookupview"));
			//dbcon.setDb2SerialLookupView(propDb2.getProperty("SerialLookupView"));
			dbcon.setURL(propDb2.getProperty("URL"));
			dbcon.setLogLevel(Byte.parseByte(propDb2.getProperty("LogLevel")));
			//dbcon.setIPAddress(propDb2.getProperty("IPAddressTest")); // Int
			dbcon.setIPAddress(propDb2.getProperty("IPAddressProd")); // Prod
			//dbcon.setUserid(propDb2.getProperty("UserIdTest")); // INT
			dbcon.setUserid(propDb2.getProperty("UserIdProd")); // Prod
			
			passwd = ph.getPw(PasswordHandler.kindOfPwDB2);
			dbcon.setPassword(passwd);
		//	dbcon.setPort(Integer.parseInt(propDb2.getProperty("PortTest"))); // INT
			dbcon.setPort(Integer.parseInt(propDb2.getProperty("PortProd"))); // PRod
		


		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		try {
			NoReuseDeletionHandler ndh = new NoReuseDeletionHandler(dbcon);
			DeleteNoReuseData dnrd = new DeleteNoReuseData();
			DeleteNoReuseData.DeleteNoReuseDataInput[] nInput = new DeleteNoReuseData.DeleteNoReuseDataInput[1];
			nInput[0] = dnrd.new DeleteNoReuseDataInput();
			//nInput[1] = dnrd.new DeleteNoReuseDataInput();
			//nInput[2] = dnrd.new DeleteNoReuseDataInput();

			nInput[0].setStName2Delete("erick gudmundsen/canada/ibm");
			nInput[0].setStReason("Request from Ceronia wrong name");
			nInput[0].setStRequestor("Kurt Raiser/Germany/IBM");
			
			
			DeleteNoReuseDataInputExt[] nInputExt = new DeleteNoReuseDataInputExt[1];
			nInputExt[0] = new DeleteNoReuseDataInputExt();

			/*nInput[1].setStName2Delete("Edith Finster/Germany/IBM");
			nInput[1].setStReason("Test");
			nInput[1].setStRequestor("Kurt Raiser/Germany/IBM");

			nInput[2].setStName2Delete("David Stokes/UK/IBM");
			nInput[2].setStReason("Test");
			nInput[2].setStRequestor("Kurt Raiser/Germany/IBM"); 
			*/
			DeleteNoReuseData.DeleteNoReuseDataInputResult[] results = ndh.clearNoReuseDatabase(nInputExt);

			for(DeleteNoReuseData.DeleteNoReuseDataInputResult res :results){
				System.out.println("Result for " + res.getInput().getStName2Delete() +":" + res.isBhasError()+ "-" + res.getStErrorDescription());

			}

			//ndh.clearNoReuseDatabase("Kurt Raiser/Germany/IBM");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public NoReuseDeletionHandler(DB2ConnectData db2ConDat) throws Exception{
		//dbLog  = CommonFunctions.getLogDB(session);
		//session = NotesFactory.createSessionWithFullAccess("sum16mer.");
		//log = new InputOutputLogger(session, dbLog, "Remove from noreuse - " + CommonFunctions.getActDate(),
		//		LogLevel.FINEST);
		log = new FileLogerV16("c:/temp/NoReuseSuppressionlog", "txt");


		NoReuseDB2Connector db2Con = new NoReuseDB2Connector(log, db2ConDat);
		db2Con.connect();
		eregCon = db2Con.getEregCon();
	}

	public DeleteNoReuseData.DeleteNoReuseDataInputResult[] clearNoReuseDatabase( DeleteNoReuseDataInputExt [] dInput){
		//SELECT * FROM NOREUSE."NOTES_NOREUSE_SINGLEVAL" WHERE LOWER(FULLNAME) = 'kurt raiser/germany/ibm';
		// search the fullname
		int iRet = 0;
		int iRow = 0;
		
		String unid = "";
		String source = "";
		
		int iCount = 0;
		HashSet<String> hsSuppressedNames = null;
		HashSet<String> hsReserverdID = null;

		
		if (dInput == null) {
			DeleteNoReuseData.DeleteNoReuseDataInputResult[] result = new DeleteNoReuseData.DeleteNoReuseDataInputResult[1];
			result[iCount].setBhasError(true);
			result[iCount].setStErrorDescription("Input null no suppression possible");
			log.logActionLevel(LogLevel.INFO, "Input null no suppression possible");
			iCount ++;
			return result;
		}
		int iLen = dInput.length;
		DeleteNoReuseData dnrd = new  DeleteNoReuseData();
		DeleteNoReuseData.DeleteNoReuseDataInputResult[] result = new DeleteNoReuseData.DeleteNoReuseDataInputResult[iLen];
		
		for  (DeleteNoReuseDataInputExt dInp: dInput){

			result[iCount] = dnrd.new DeleteNoReuseDataInputResult();
			result[iCount].setInput(dInp.getNoReuseDataInput());
			
				if(!dInp.isValid()){
					result[iCount].setBhasError(true);
					result[iCount].setStErrorDescription(dInp.getErrorDescription());
					iCount++;
					log.logActionLevel(LogLevel.INFO, "Input not valid");
					continue;
					
				
			}

			// check whether the name is reserved
			String myName = dInp.getNoReuseDataInput().getStName2Delete().replaceAll("'", "''").toLowerCase();
			String sql = NO_REUSE_QUERY + "FULLNAME ='" + myName + "' OR INTERNETADDRESS ='" +  myName +"'";
			ResultSet rs = eregCon.excuteQuery(sql);
			if(rs == null){
				result[iCount].setBhasError(true);
				result[iCount].setStErrorDescription("No such name found");
				return result;
			}else{	
				try{
					iRow = 0;
					hsSuppressedNames = new HashSet<String>();
					hsReserverdID = new HashSet<String>();
					String sFullName;
					String sInternetAddress;
					String sFieldVal;
					while (rs.next()){

						if (!rs.getString(1).equals(unid)){

							unid = rs.getString(1);
							sFullName = rs.getString(3);
							sInternetAddress = rs.getString(4);
							sFieldVal = rs.getString(9);
							source = rs.getString(7);
							if (source.equals("R")){
								if(hsReserverdID.add(unid)){ 
									sql = NO_REUSE_DEL_RESERVATION + unid + "'";
									iRet = eregCon.executeUpdate(sql);
									log.logActionLevel(LogLevel.INFO, "delete reservation-> " + "unid=" + unid + " Fullname=" + sFullName + "InternetAddress=" +sInternetAddress);
								}
							}
							/*if (source.equals("R")){
								result[iCount].setBhasError(true);
								result[iCount].setStErrorDescription("Name is reserverd !");
								return result;
							}*/
							
							
							hsSuppressedNames.add(sFullName);
							hsSuppressedNames.add(sInternetAddress);
							hsSuppressedNames.add(sFieldVal);
							sql = NO_REUSE_UPDATE_SINGLEVAL + unid  + "'";
							iRet = eregCon.executeUpdate(sql);
							sql = NO_REUSE_UPDATE_MULTIVAL + unid  + "'";
							iRet = eregCon.executeUpdate(sql);
							
							log.logActionLevel(LogLevel.INFO, "suppressed  " + "unid=" + unid + " Fullname=" + sFullName + "InternetAddress=" +sInternetAddress);
							
							sql = getInsertSql(dInp.getNoReuseDataInput(), unid);
							iRet = eregCon.executeUpdate(sql);
							iRow++;
						}
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					result[iCount].setBhasError(true);
					result[iCount].setStErrorDescription("Sql errror:" + e.getLocalizedMessage());
					e.printStackTrace();
				}
			}

			// if id is not in noReuse exit
			result[iCount].setSuppressedNames(null);
			if (iRow <1) {
				result[iCount].setBhasError(true);
				result[iCount].setStErrorDescription(myName +": Name not found in NoReuse!");
			}else{
				result[iCount].setBhasError(false);
				if (hsSuppressedNames != null){
					String [] sSuppressedNames = hsSuppressedNames.toArray(new String [hsSuppressedNames.size()]);
					result[iCount].setSuppressedNames(sSuppressedNames);
				}
				result[iCount].setStErrorDescription(myName + " is suppressed from NoReuse now");
			}

			iCount ++;
		}
		
		
		if(eregCon != null){
			eregCon.close(true);
		}
		return result;
	}




	private String getInsertSql(DeleteNoReuseData.DeleteNoReuseDataInput dInput, String stUnid){
		String sql = "INSERT INTO " + NO_REUSE_REASON_TABLE + "(PERSONUNID, SUPPRESSIONDATE, REQUESTED_BY, REASON) VALUES ('" +
				stUnid + "', '"	+ dInput.getStDate() + "', '" + dInput.getStRequestor() + "', '" + dInput.getStReason() + "')";
		return sql;
	}



}
