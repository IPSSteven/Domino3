package com.ibm.mediator.NoReuseLogic;

import lotus.domino.Document;
import lotus.domino.Session;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

//import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.mediator.config.ConfigObjMediatorDB;

public class NoReuseNotesConfiguration {
	private ConfigObjMediatorDB cfgNotes_Noreuse_SingleVal = null;
	private ConfigObjMediatorDB cfgNotes_Noreuse_Multival = null;
	private String NoReuseSingleConf;
	private String NoReuseMultiConfig;
	
	public NoReuseNotesConfiguration(Session session, Document docLog) throws Exception{
		RequestLogger log = new RequestLogger(session, docLog);
		Properties ph = new Properties();
		try {
			ph.load(new FileReader("NotesProperties.txt"));
			 NoReuseSingleConf = ph.getProperty("NoReuseSingleConf");
			 NoReuseMultiConfig = ph.getProperty("NoReuseMultiConf");
			log.logActionLevel(LogLevel.INFO, "configuration for Noreuse Single=" + NoReuseMultiConfig + " Configuration for NoreuseMulti="+  NoReuseMultiConfig);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"NotesProperties.txt not found: " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"NotesProperties.txt not found: " + e.getMessage());
			e.printStackTrace();
		}
		//this.cfgNotes_Noreuse_SingleVal = new  ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_SINGLEVAL, log);
		//this.cfgNotes_Noreuse_Multival = new  ConfigObjMediatorDB(session, AllConstants.MEDIATOR_NOTES_NOREUSE_MULTIVAL, log);
		this.cfgNotes_Noreuse_SingleVal = new  ConfigObjMediatorDB(session,  NoReuseSingleConf, log);
		this.cfgNotes_Noreuse_Multival = new  ConfigObjMediatorDB(session, NoReuseMultiConfig, log);
		
	}

	public ConfigObjMediatorDB getCfgNotes_Noreuse_SingleVal() {
		return cfgNotes_Noreuse_SingleVal;
	}

	

	public ConfigObjMediatorDB getCfgNotes_Noreuse_Multival() {
		return cfgNotes_Noreuse_Multival;
	}


}
