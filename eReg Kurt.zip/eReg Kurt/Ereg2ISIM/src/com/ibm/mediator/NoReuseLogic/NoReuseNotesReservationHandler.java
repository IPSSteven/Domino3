package com.ibm.mediator.NoReuseLogic;

import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.ereg.logger.TraceLogger;
import com.ibm.mediator.NoReuseData.Notes_NoReuse_MultiVal;
import com.ibm.mediator.NoReuseData.Notes_Noreuse_SingleVal;
import com.ibm.mediator.NoReuseData.ReservationData;
import com.ibm.mediator.NoReuseData.ReservationDataPrepare;
import com.ibm.mediator.NoReuseInterface.ResponseBasic;
import com.ibm.mediator.connector.TheEregConnectorNotes;


public class NoReuseNotesReservationHandler  {
	private ResponseBasic rb;
	private RequestLogger log;
	private TheEregConnectorNotes theConnect;
	private NoReuseNotesConfiguration nrConf;
	private Document docLog;
	private Session session;
	private TraceLogger tl = null;
	private final String component = "NoReuse";

	public NoReuseNotesReservationHandler(Session s, Document docL) throws Exception {
		this.session = s;
		this.docLog = docL;
		nrConf = new NoReuseNotesConfiguration(session, docLog);
		log = new RequestLogger(session, docLog);
		theConnect = new TheEregConnectorNotes(log, nrConf.getCfgNotes_Noreuse_Multival());
		// TODO Auto-generated constructor stub
	}

	public ResponseBasic delReservationAdd2NoReuse(){
		String stOwnerUid; 
		rb = new ResponseBasic();
		if (tl == null){
			try {
				tl = new TraceLogger("GID Delete Reservation", component, docLog.getItemValueString("OwnerUID"));

			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.logActionLevel(LogLevel.SEVERE, "Error while initialise trace log");
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, "Error while initialise trace log - log document can not be read");
				e.printStackTrace();
			}
		}
		if (createNoReUseEntry()){
			try {
				// delete reservation
				stOwnerUid = docLog.getItemValueString("OwnerUId");
				ReservationData rd = new ReservationData();
				rd.setSerialNumberPSC(stOwnerUid);
			
				ReservationDataPrepare rdSQL = new ReservationDataPrepare(log,nrConf.getCfgNotes_Noreuse_Multival().getDB2ConnectionData(), rd);
				String stSql = rdSQL.getDeleteSQL();
				log.logActionLevel(LogLevel.INFO, "try to execute : " + stSql);
				theConnect.executeUpdate(stSql);
				log.logActionLevel(LogLevel.INFO, "execution done" );
				docLog.replaceItemValue("ResGetSuccefull", "1");
				docLog.save();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				rb.setHasError(new Boolean(true));
				rb.setErrDescription("Error while delete reservation :" + e.getLocalizedMessage());
				tl.logActionLevel(tl.getRcError(),rb.getErrDescription());
				e.printStackTrace();
			}
		}

		return rb;
	}

	private boolean createNoReUseEntry(){
		Vector<String> Itimvalue = null;
		HashSet<String>hsUnique = null;
		String stShortNameAddress = null;
		Document docNab= null; 

		Notes_Noreuse_SingleVal NrNa;
		Notes_NoReuse_MultiVal NrAl;
		Name NotesName;
		
		if (tl == null){
			try {
				tl = new TraceLogger("GID Create Reservation", component, docLog.getItemValueString("OwnerUID"));
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.logActionLevel(LogLevel.SEVERE, "Error while initialise trace log");
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, "Error while initialise trace log - log document can not be read");
				e.printStackTrace();
			}
		}
		tl.logActionLevel(tl.getRcSuccess(), "9.3 Start create new NoReuse entry with the values of the reservation");

		String stServer;
		try {
			stServer = docLog.getItemValueString("RegServer");
			Database dbNab = CommonFunctions.getDatabase(session, stServer, AllConstants.NABDBNAME);
			View vwShortName = dbNab.getView(AllConstants.NABVIEWFORRECONCILE);
			String stShortName = docLog.getItemValueString("ShortName");
			log.logActionLevel(LogLevel.INFO, "try to get the NAB document, Server:"+ stServer +
					" ShortName + " + stShortName);
			docNab = vwShortName.getDocumentByKey(stShortName);
			if (docNab == null){
				log.logActionLevel(LogLevel.SEVERE, "NAB document not found");
				return false;
			}else{
				log.logActionLevel(LogLevel.INFO, "got the NAB document");
			}
			
		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,e1.getLocalizedMessage());
			rb.setHasError(new Boolean(true));
			rb.setErrDescription("Error while try to get docNab");
			tl.logActionLevel(tl.getRcError(),rb.getErrDescription());
			e1.printStackTrace();
			e1.printStackTrace();
			return false;
		}
		

		// try to insert singleVal for NoReuse
		try{
			// insert the single val 
			Itimvalue = docNab.getItemValue("FullName");
			NotesName = session.createName(Itimvalue.firstElement());

			NrNa = new Notes_Noreuse_SingleVal(nrConf.getCfgNotes_Noreuse_SingleVal());
			NrNa.setBlockDate(CommonFunctions.getYYYYMMDD(docNab.getCreated()));
			NrNa.setCreationDate(CommonFunctions.getActDateRecon());
			NrNa.setDeletionDate("");
			//NrNa.setDomain(stDom);
			NrNa.setDomain(docNab.getItemValueString("MailDomain"));
			NrNa.setFullName(NotesName.getAbbreviated());
			NrNa.setInternetAddress(docNab.getItemValueString("InternetAddress"));
			NrNa.setPersonuinid(docNab.getUniversalID());
			NrNa.setLockOutOnly("N");
			NrNa.setSerialPSC(docNab.getItemValueString("EmpNum")+ docNab.getItemValueString("Empcc"));
			String dummy = NrNa.getsqlInsertState();
			log.logActionLevel(LogLevel.INFO, "try execute the sql statement: " + NrNa.getsqlInsertState());
			theConnect.executeUpdate(NrNa.getsqlInsertState());
			log.logActionLevel(LogLevel.INFO, "execution sucessful");
		}catch(NotesException e){
			log.logActionLevel(LogLevel.SEVERE,"Error while handling fullname single val" );
			log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
			e.printStackTrace();
			rb.setHasError(new Boolean(true));
			rb.setErrDescription("Error Notes exception while get multival for full name :" + e.getLocalizedMessage());
			tl.logActionLevel(tl.getRcError(),rb.getErrDescription());
			return false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while handling fullname single val" );
			log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
			e.printStackTrace();
			rb.setHasError(new Boolean(true));
			rb.setErrDescription("Error generall exception while get multival for full name :" + e.getLocalizedMessage());
			tl.logActionLevel(tl.getRcError(),rb.getErrDescription());
			return false;
		}

		// insert the multi values for full name
		hsUnique = new HashSet<String>();
		try {
			Itimvalue = docNab.getItemValue("FullName");
			int size = Itimvalue.size();
			for(int i = 1; i <size; i++ ){ // get the 2 - last element
				NotesName = session.createName(Itimvalue.get(i));
				hsUnique.add(NotesName.getAbbreviated());
				NotesName.recycle();
			}
		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"Error while get the fullname:" + e1.getLocalizedMessage() );
			rb.setHasError(new Boolean(true));
			rb.setErrDescription("Error while get the fullname :" + e1.getLocalizedMessage());
			tl.logActionLevel(tl.getRcError(),rb.getErrDescription());
			e1.printStackTrace();
			return false;
		}

		String [] stFullNames = hsUnique.toArray(new String[hsUnique.size()]);
		for(String stFull:stFullNames){
			// insert row multivalues
			try {
				NrAl = new Notes_NoReuse_MultiVal(nrConf.getCfgNotes_Noreuse_Multival());
				NrAl.setPersonUnid(docNab.getUniversalID());
				NrAl.setFieldName("FNA");
				NrAl.setFieldValue(stFull);
				log.logActionLevel(LogLevel.INFO, "try execute the sql statement: " + NrAl.getSqlInsertState());
				theConnect.executeUpdate(NrAl.getSqlInsertState());
				log.logActionLevel(LogLevel.INFO, "execution sucessful");
			} catch (Exception e) {
				log.logActionLevel(LogLevel.SEVERE,"Error while handling fullname alias " + stFull );
				log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
				rb.setHasError(new Boolean(true));
				rb.setErrDescription("Error create no reuse multival for full name :" + e.getLocalizedMessage());
				e.printStackTrace();
				tl.logActionLevel(tl.getRcError(),rb.getErrDescription());
			}
		}


		// insert the multi value for short name
		try {
			// short names are not all unique
			hsUnique = new HashSet<String>();
			Itimvalue = docNab.getItemValue("ShortName");
			Iterator<String> it = Itimvalue.iterator();
			while(it.hasNext()){
				stShortNameAddress = (String)it.next();
				hsUnique.add(stShortNameAddress);
			}
			for( String stShort : (String[])hsUnique.toArray(new String[hsUnique.size()])){
				if (stShort.indexOf("@") > 0){
					// insert row in noreuse internetaddress
					try {
						NrAl = new Notes_NoReuse_MultiVal(nrConf.getCfgNotes_Noreuse_Multival());
						NrAl.setPersonUnid(docNab.getUniversalID());
						NrAl.setFieldName("SN");
						NrAl.setFieldValue(stShort);
						log.logActionLevel(LogLevel.INFO, "try execute the sql statement: " + NrAl.getSqlInsertState());
						theConnect.executeUpdate(NrAl.getSqlInsertState());
						log.logActionLevel(LogLevel.INFO, "execution sucessful");

					} catch (Exception e) {
						log.logActionLevel(LogLevel.SEVERE,"Error while handling short name alias" );
						log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
						rb.setHasError(new Boolean(true));
						rb.setErrDescription("Error create no reuse multival for short name " + e.getLocalizedMessage());
						tl.logActionLevel(tl.getRcError(),rb.getErrDescription());
						e.printStackTrace();
					}

				}
			}

		} catch (NotesException e) {
			log.logActionLevel(LogLevel.SEVERE,"Error while handling short name alias" );
			log.logActionLevel(LogLevel.SEVERE,e.getLocalizedMessage());
			e.printStackTrace();
			rb.setHasError(new Boolean(true));
			rb.setErrDescription("Error while get no reuse multival for short name " + e.getLocalizedMessage());
			tl.logActionLevel(tl.getRcError(),rb.getErrDescription());
			return false;
		}

		tl.logActionLevel(tl.getRcSuccess(),"9.4 NoReuse reservation created successfully");

		return true;
	}

}
