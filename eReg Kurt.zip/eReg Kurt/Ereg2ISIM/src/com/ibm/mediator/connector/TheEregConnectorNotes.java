package com.ibm.mediator.connector;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.FileWriter;
//import java.io.IOException;
import java.io.IOException;
import java.sql.Connection;
//import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;

import lotus.domino.NotesException;

import com.ibm.ereg.logger.AbstractLogger;
import com.ibm.ereg.logger.BasicLogger;
import com.ibm.ereg.logger.FileLoger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.config.ConfigObjMediatorDB;


public class TheEregConnectorNotes {
	private Connection MediatorConnection;
	private AbstractLogger log;
	private ResultSet rs = null;
	private Statement sqlstatment = null;
	private SQLWarning sqlWarning = null;
	private String stUser = null;
	private String stPasswd = null;
	private String stClass = null;
	private String stUrl = null;


	public SQLWarning getSqlWarning() {
		return sqlWarning;
	}

	public TheEregConnectorNotes(AbstractLogger log, DB2ConnectData db2con) throws IllegalAccessException, InstantiationException, ClassNotFoundException, SQLException{
		boolean bSuccess = true;
		this.log = log;
		//pln("Begin connector");
		stUrl = db2con.getURL() + db2con.getIPAddress() + ":" + db2con.getPort()+ "/"+ db2con.getDB2Database();
		stUser = db2con.getUserid();
		stPasswd = db2con.getPassword();
		stClass = db2con.getDB2Class();
		try {
			connect();
		} catch (IllegalAccessException e) {
			pln("Error +++ Illegal Access exception");
			log.logActionLevel(LogLevel.SEVERE, "Error +++ Illegal Access exception ... try connect to backup");
			// TODO Auto-generated catch block
			e.printStackTrace();
			bSuccess = false;
			//throw e;
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			pln("Error +++ InstantiationException");
			log.logActionLevel(LogLevel.SEVERE, "Error +++ InstantiationException... try connect to backup");
			e.printStackTrace();
			throw e;
		} catch (ClassNotFoundException e) {
			pln("Error +++ ClassNotFoundException");
			log.logActionLevel(LogLevel.SEVERE, "Error +++ ClassNotFoundException... try connect to backup");
			e.printStackTrace();
			bSuccess = false;
			//throw e;
		} catch (SQLException e) {
			pln( "Error while connecting:" + stUrl);
			log.logActionLevel(LogLevel.SEVERE, "Error while connecting:" + stUrl + "... try connect to backup" );
			log.logActionLevel(LogLevel.SEVERE, "Error +++ SQLException " + e.getMessage());
			pln(  "Error +++ SQLException");
			//e.printStackTrace();
			bSuccess = false;
			//throw e;
		}
		if (! bSuccess){
			stUrl = db2con.getURL() + db2con.getIPAddressBackup() + ":" + db2con.getPort()+ "/"+ db2con.getDB2Database();
			stUser = db2con.getUserid();
			stPasswd = db2con.getPassword();
			stClass = db2con.getDB2Class();
			try {
				connect();
			} catch (IllegalAccessException e) {
				pln("Error +++ Illegal Access exception");
				log.logActionLevel(LogLevel.SEVERE, "Error +++ Illegal Access exception ... in backup");
				// TODO Auto-generated catch block
				e.printStackTrace();
				bSuccess = false;
				//throw e;
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				pln("Error +++ InstantiationException");
				log.logActionLevel(LogLevel.SEVERE, "Error +++ InstantiationException ... in backup");
				e.printStackTrace();
				throw e;
			} catch (ClassNotFoundException e) {
				pln("Error +++ ClassNotFoundException");
				log.logActionLevel(LogLevel.SEVERE, "Error +++ ClassNotFoundException ... in backup");
				e.printStackTrace();
				bSuccess = false;
				//throw e;
			} catch (SQLException e) {
				pln( "Error while connecting:" + stUrl);
				log.logActionLevel(LogLevel.SEVERE, "Error while connecting:" + stUrl + "... in backup");
				log.logActionLevel(LogLevel.SEVERE, "Error +++ SQLException " + e.getMessage());
				pln(  "Error +++ SQLException");
				//e.printStackTrace();
				bSuccess = false;
				//throw e;
			}
		}
	}

	public TheEregConnectorNotes(BasicLogger blog, ConfigObjMediatorDB conf) throws Exception{
		this.log = blog;
		//this.session = log.sess;
		try {
			//conf  = new ConfigObjMediatorDB(log.sess,stType, log);
			stUrl = conf.getUrl()[0] + conf.getIpAddressPort()[0] + "/" + conf.getDatabase()[0];
			stUser = conf.getUser()[0];
			stPasswd = conf.getPassword()[0];
			stClass = conf.getClassName()[0];
			connect();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			pln("Error +++ NotesExeption/Config no valid");
			log.logActionLevel(LogLevel.SEVERE, "Error +++ NotesExeption/Config no valid");
			pln("Error +++ NotesExeption/Config no valid");
			//e.printStackTrace();
			throw e;
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			pln("Error +++ Illegal Access exception");
			log.logActionLevel(LogLevel.SEVERE, "Error +++ Illegal Access exception");
			//e.printStackTrace();
			throw e;
		} catch (InstantiationException e) {
			pln("Error +++ InstantiationException");
			log.logActionLevel(LogLevel.SEVERE, "Error +++ InstantiationException");
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw e;
		} catch (ClassNotFoundException e) {
			pln("Error +++ ClassNotFoundException");
			log.logActionLevel(LogLevel.SEVERE, "Error +++ ClassNotFoundException");
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			pln( "Error while connecting:" + stUrl);
			log.logActionLevel(LogLevel.SEVERE, "Error while connecting:" + stUrl );
			log.logActionLevel(LogLevel.SEVERE, "Error +++ SQLException " + e.getMessage());
			pln(  "Error +++ SQLException");
			//e.printStackTrace();
			throw e;
		}
	}

	public int executeUpdate(String stSql){
		//PreparedStatement ps = null;
		//ResultSet rs = null;
		int iRows =0;
		try {

			//boolean bSuccess = sqlstatment.execute(stSql);
			sqlstatment.execute(stSql);
			//System.out.println("success:" + bSuccess);
			iRows = sqlstatment.getUpdateCount();
			sqlWarning = sqlstatment.getWarnings();


			/*
			 if (iCommitControl > iCommitlimit){
				 iCommitControl = 0;
				 MediatorConnection.commit();
				 System.out.println("committed");
			 } 
			 */
			//MediatorConnection.commit();
			return iRows;
			//rs = ps.executeQuery();

		} catch (SQLException e) {
			System.out.println(stSql);
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, stSql+ " could not be executed"); 
			log.logActionLevel(LogLevel.SEVERE,e.toString());
			sqlWarning = new SQLWarning(e.getLocalizedMessage() + " ErrorCode = " + e.getErrorCode());
			return -1; 
		}
	}
	public ResultSet excuteQuery(String stQuery){
		PreparedStatement ps = null;
		try {
			ps = MediatorConnection.prepareStatement(stQuery);
			
			rs = ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			log.logActionLevel(LogLevel.SEVERE, stQuery+ " could not be executed"); 
			log.logActionLevel(LogLevel.SEVERE,e.toString());
			System.out.println(stQuery);
			e.printStackTrace();
			return null;
		}

	}
	
	public ResultSet excuteQuery(String sql, int resultSetType, int resultSetConcurrency){
		PreparedStatement ps = null;
		
		try {
			ps = MediatorConnection.prepareStatement(sql, resultSetType, resultSetConcurrency);
			rs = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return rs;
	}

	public void close(boolean bCloseLogDoc){
		try {
			if(rs != null && !rs.isClosed()){
				rs.close();
			}

			if ((MediatorConnection != null) &&  ! MediatorConnection.isClosed()){
				MediatorConnection.close();
			}
			if (BasicLogger.class.isInstance(log)){
				BasicLogger blog = (BasicLogger)(log);
				LogDocStatus lds = new LogDocStatus(blog.getDocLog());
				if (log != null && bCloseLogDoc){
					lds.setOKDone();
					blog.closeLog(lds);
				}
			}else{
				if(FileLoger.class.isInstance(log)){
					FileLoger fl = (FileLoger)log;
					if (fl.getfW() != null && bCloseLogDoc){
						try {
							fl.getfW().flush();
							fl.getfW().close();
							fl.setfW(null);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}



					}
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	private void connect() throws IllegalAccessException, InstantiationException, ClassNotFoundException, SQLException {

		Class.forName(stClass).newInstance();


		pln("Try to begin connect");
		MediatorConnection = java.sql.DriverManager.getConnection(
				stUrl, 
				stUser, 
				stPasswd);
		
		MediatorConnection.setAutoCommit(true);
		sqlstatment = MediatorConnection.createStatement();
		pln("End connect successful");
	}
	public boolean isClosed(){
		try {
			if (MediatorConnection == null || MediatorConnection.isClosed()) return true;
			else return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return true;
		}
	}
	void pln(String stData){
		System.out.println(stData);
	}
}
