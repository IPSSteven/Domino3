package com.ibm.mediator.constants;

public class MediatorRequestStatusConstants {
	public final static String INITIAL = "Initial";
	public final static String INWORK = "Inwork";
	public final static String EXECUTED = "Executed";
	public final static String FINISHED = "Finished";
	public final static String ERROR = "Error";
	/*public final static String INITIALDES = "Initial";
	public final static String EXECUTIONDES = "Execution";
	public final static String FINISHEDDES = "Finished";
	public final static String CHECKEDDES = "Checked"; */

}
