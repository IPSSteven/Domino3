package com.ibm.mediator.eregreconcile;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;

import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

public class DenyAccessExtractor {
	private FileWriter fw = null;
//	private CommonFunctions cf = null;
	private InputOutputLogger log = null;
	public DenyAccessExtractor(Session session, ConfigObjMaschineProfile mp,
			String stDomain, InputOutputLogger log) throws Exception{
		this.log = log;
		String stFile;
		//cf = new CommonFunctions(session);
		if (stDomain.equals("IBMGMSR")) {
			stFile = "deny" +"00" + ".script";
		} else {
			stFile = "deny_" + stDomain.substring(stDomain.length() - 2, stDomain
					.length())
					+ ".script";
		}
		try {
			stFile = mp.getExportDir()[0]+ "\\\\" + stFile;
			fw = new FileWriter(stFile);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, e.toString());
			e.printStackTrace();
			throw e;
			
		}
	
		
	}
	public void writeDenyAcc(Document docGroup){
		try {
			@SuppressWarnings("unchecked")
			Vector<String> vecGroup = docGroup.getItemValue("Members");
			Iterator<String> it = vecGroup.iterator();
			String stGroup = null;
			while(it.hasNext()){
				stGroup = (String)it.next() + "\r\n";
				writeDenyAcc(stGroup);
			}
			writeDenyAcc("\r\n");
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void writeDenyAcc(String stLine){
		try {
			fw.write(stLine);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, e.toString());
			e.printStackTrace();
			e.printStackTrace();
		}
	}
	public void closeFile(){
		try {
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
