package com.ibm.mediator.eregreconcile;

import java.io.FileWriter;
import java.io.IOException;

import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.Session;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

public class FlatFileExtractor {

	private FileWriter fw = null;
	private InputOutputLogger log;
	private String stId = null;
	
	private String stCert = null;
	private String stFullName = null;
	private String stLine = null;
	
	public FlatFileExtractor(Session session, String stDomain, ConfigObjMaschineProfile mp,
			InputOutputLogger log) throws Exception {
		String stFile;
		String stPersonFile=  "";
		this.log = log;
		if (stDomain.equals("IBMGMSR")) {
			stFile = "00" + "_nab.script";
		} else {
			stFile = stDomain.substring(stDomain.length() - 2, stDomain
					.length())
					+ "_nab.script";
		}

		try {
			stPersonFile = mp.getExportDir()[0]+ "\\\\" + stFile;
			fw = new FileWriter(stPersonFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "++++ Error +++ File "
					+ stPersonFile + " could not be opened");
			log.logActionLevel(LogLevel.SEVERE, e.toString());
			throw e;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			log.logActionLevel(LogLevel.SEVERE, e.toString());
			throw e;
		}
	}

	public void writeLine(Document docNab) throws IOException {
		try {
			stId = (String) CommonFunctions.getLastItemEntry(docNab, "Shortname");
			if (stId.trim().equals("")){
				return;	
			}
				
			stCert = docNab.getItemValueString("Certificate");
			if (stCert.trim().equals(""))
				stCert = "TASK";
			else
				stCert = "CERT";
			
			stFullName = (String) CommonFunctions.getFirstItemEntry(docNab, "FullName");
			stLine = stId + ";" + docNab.getItemValueString("FirstName")
					+ ";" + docNab.getItemValueString("MiddleInitial")
					+ ";" + docNab.getItemValueString("LastName") + ";"
					+ stFullName + ";" + docNab.getItemValueString("EmpCC")
					+ ";" + docNab.getItemValueString("EmpNum") + ";"
					+ docNab.getItemValueString("MailServer") + ";"
					+ docNab.getItemValueString("MailFile") + ";" + stCert + "\n";
			
			fw.write(stLine);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "++++ Error ++++ Line "
					+ stLine + " can not be writen to file");
			log.logActionLevel(LogLevel.SEVERE, e.toString());
			throw e;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "++++ Error ++++ Line "
					+ stLine + " can not be writen to file");
			log.logActionLevel(LogLevel.SEVERE, e.toString());
			e.printStackTrace();
		}
	}
	public void closeFile(){
		try {
			fw.flush();
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "+++ Error  +++ Error while closing the flat file");
			log.logActionLevel(LogLevel.SEVERE, e.toString());
			//e.printStackTrace();
		}
		
	}

}
