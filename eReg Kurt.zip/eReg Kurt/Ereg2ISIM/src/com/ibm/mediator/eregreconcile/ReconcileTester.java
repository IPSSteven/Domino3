package com.ibm.mediator.eregreconcile;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class ReconcileTester extends NotesThread {

	private String pw;
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReconcileTester rt = new ReconcileTester();
		rt.pw = args[0];
		rt.start();

	}
	
	public ReconcileTester() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		
		Session  session = NotesFactory.createSessionWithFullAccess(pw);
		
		// Notes part
		// get the logger
		Database dbLog;
		try {
			
			dbLog = CommonFunctions.getLogDB(session);
			InputOutputLogger log = new InputOutputLogger(session, dbLog, "Reconcile ITIM - " + CommonFunctions.getActDateRecon(),
					LogLevel.FINEST);
			//create the log document for the reconcile
			
			// get Ereg password
			ConfigObjNCOUAR cfgUAR = new ConfigObjNCOUAR(session, log);
			View vwNCOUARITIMEXP = cfgUAR.getVwITIMEXPORT(AllConstants.EREG_NOTESID_DOMAIN);
			Document docNCOUAR =vwNCOUARITIMEXP.getDocumentByKey(AllConstants.EREG_NOTESID_DOMAIN.toUpperCase()+AllConstants.EREG_NOTESID_SHORTNAME.toUpperCase());
			pw = docNCOUAR.getItemValueString("Password");
			
			String fp = getNotesPath(session);
			List<String> sComm = new ArrayList<String>();
			sComm.add(fp+ "\\jvm\\bin\\java");
			sComm.add("-Xmx1536m");
			sComm.add("-Xms1024m");
			sComm.add("com.ibm.mediator.eregreconcile.multithreading.ReconcicleProccessRunner");  
			sComm.add(pw);   
			
			ProcessBuilder pb = new ProcessBuilder(sComm);
			//ProcessBuilder pb = new ProcessBuilder("C:\\Notes\\jvm\\bin\\java", "com.ibm.mediator.eregreconcile.multithreading.ReconcicleProccessRunner", pw);
			Map<String,String> environ = pb.environment();
			environ.put("Path", environ.get("Path")+ ";C:\\notes");
			//environ.put("NOTES, value)
			pb.redirectErrorStream(true);
			//Map<String,String> environ = pb.environment();
			Set k = environ.keySet();
			Iterator<String> it = k.iterator();
			while(it.hasNext()){
				String key = it.next();
				String value = environ.get(key);
				System.out.println(key + "=====" + value);
			}
			
			
			Process process = pb.start();
			InputStream is = process.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
		
			String line;
			while((line= br.readLine()) != null){
				System.out.println(line);
			}
			br.close();
			System.out.println("ready!");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
		
		
		//ReconcileItimRunner rr = new ReconcileItimRunner(session);
		//rr.runNotes();
	}
	
	private String getNotesPath(Session s){
		try {
			Database dbNames = s.getDatabase("", "names.nsf");
			if (!dbNames.isOpen()){
				dbNames.open();
			}
			
			String sFileP = dbNames.getFilePath();
			int idx = sFileP.indexOf("\\data");
			sFileP = sFileP.substring(0, idx);
			return sFileP;
			
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}	
	}


}
