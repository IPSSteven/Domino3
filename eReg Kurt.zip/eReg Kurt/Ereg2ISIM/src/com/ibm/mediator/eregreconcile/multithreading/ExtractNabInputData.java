package com.ibm.mediator.eregreconcile.multithreading;

import java.lang.reflect.Field;

import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.logger.InputOutputLogger;


public class ExtractNabInputData {
	
		private String passWord = null;
		private int iStartAt  = -1;
		private int iStackSize = -1 ;
		private String DatabaseServer  = null;
		private String Databasefilepath  = null;
		private ConfigObjReConcileITIM confObjReconcile = null;
		private InputOutputLogger log  = null;
		private Integer ThreadNumber  = null;
		private String sError = "";
		private String stDomain = null;
		private String stRunDate = null;
		//private MediatorRawDataExtractor me = null;
		
		public static void main(String [] argv){
			ExtractNabInputData eN = new ExtractNabInputData();
			eN.setPassWord("geheim");
			eN.isValid();
		}
		
		
		public String getPassWord() {
			return passWord;
		}
		public void setPassWord(String passWord) {
			this.passWord = passWord;
		}
		public int getiStartAt() {
			return iStartAt;
		}
		public void setiStartAt(int iStartAt) {
			this.iStartAt = iStartAt;
		}
		public int getiStackSize() {
			return iStackSize;
		}
		public void setiStackSize(int iStackSize) {
			this.iStackSize = iStackSize;
		}
		
		public String getDatabaseServer() {
			return DatabaseServer;
		}
		public void setDatabaseServer(String databaseServer) {
			DatabaseServer = databaseServer;
		}
		public String getDatabasefilepath() {
			return Databasefilepath;
		}
		public void setDatabasefilepath(String databasefilepath) {
			Databasefilepath = databasefilepath;
		}
		public ConfigObjReConcileITIM getConfObjReconcile() {
			return confObjReconcile;
		}
		public void setConfObjReconcile(ConfigObjReConcileITIM confObjReconcile) {
			this.confObjReconcile = confObjReconcile;
		}
		public InputOutputLogger getLog() {
			return log;
		}
		public void setLog(InputOutputLogger log) {
			this.log = log;
		}
		public Integer getThreadNumber() {
			return ThreadNumber;
		}
		public void setThreadNumber(Integer threadNumber) {
			ThreadNumber = threadNumber;
		}
		public String getsError() {
			return sError;
		}
		public String getStDomain() {
			return stDomain;
		}
		public void setStDomain(String stDomain) {
			this.stDomain = stDomain;
		}
		public void setStRunDate(String stRunDate) {
			this.stRunDate = stRunDate;
		}
		public String getStRunDate() {
			return stRunDate;
		}/*
		
		public MediatorRawDataExtractor getMe() {
			return me;
		}
		public void setMe(MediatorRawDataExtractor me) {
			this.me = me;
		}
*/

		public boolean isValid(){
			String sType;
			Field[] fields =this.getClass().getDeclaredFields();
			for(Field f : fields){
				try {
					//System.out.println(f.getType() + ":" + f.get(this));
					sType =f.getType().toString();
					if (sType.startsWith("class") &&  f.get(this) == null ){
						sError = f.getName() +  "is null";
						return false;
					}else if(sType.equals("int") &&  f.getInt(this) < 0) {
						sError = f.getName() +  "<0 or not set";
						return false;
					}
					
				
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return true;
		}
		
		
}
