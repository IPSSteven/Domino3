package com.ibm.mediator.eregreconcile.multithreading;

import java.util.Vector;

import com.ibm.ereg.common.CommonFunctionGeneral;
import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.eregreconcile.MediatorRawDataExtractor;
import com.ibm.mediator.mediatordatabeans.NCOUAR_Data;
import com.ibm.mediator.mediatordatabeans.ReconcileRawData;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class ExtractNabThread extends NotesThread {
	private String passWord;
	private int iStartAt;
	private int iStackSize;
	private ReconcileDataSingleton rds;
	private String DatabaseServer;
	private String Databasefilepath;
	private ConfigObjReConcileITIM confObjReconcile = null;
	private View vwUAR = null;
	private InputOutputLogger log;
	private Integer ThreadNumber;
	private String stDomain;
	private String stRunDate;

	ConfigObjNCOUAR cfgNcouar = null;

	//private MediatorRawDataExtractor me ;


	public ExtractNabThread(ExtractNabInputData in) {

		if (!in.isValid()) throw new IllegalArgumentException("Input data not valid:" + in.getsError());
		iStartAt = in.getiStartAt();
		//if(iStartAt >1 ) iStartAt = iStartAt -2 ;
		iStackSize = in.getiStackSize();
		DatabaseServer = in.getDatabaseServer();
		Databasefilepath = in.getDatabasefilepath();
		confObjReconcile = in.getConfObjReconcile();
		passWord = in.getPassWord();
		ThreadNumber = in.getThreadNumber();
		log = in.getLog();
		stDomain = in.getStDomain();
		stRunDate = in.getStRunDate();
		//me = in.getMe();



		// TODO Auto-generated constructor stub
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		String MailSystemNab;
		String MailSystemNCouar;
		super.runNotes();
		Session s = null;
		Database dbNab = null;
		View vwReg = null;
		String stFullName = null;
		Document docNab = null;
		Document docRecycle = null;
		Vector<String> vFilter = null;
		String stKey = null;
		Vector <String>vecShortname = null;
		int iCount = 0;
		int iCountErr = 0;
		int iReconcileNumber = 0;
		String stMsg;
		long lmilli = System.currentTimeMillis();
		log.logActionLevel(LogLevel.INFO,Thread.currentThread().getName() + " started - working on docmemt " + iStartAt + " stackSize = " + iStackSize);

		MediatorRawDataExtractor me = null; 

		rds = ReconcileDataSingleton.getInstance();

		synchronized (rds) {
			s = CommonFunctions.getNewSession(passWord);
			dbNab = CommonFunctions.getDatabase(s, DatabaseServer, Databasefilepath);
			String stView = AllConstants.NABVIEWFORRECONCILE ;

			// krm:  added the next section to try setting the NAB view
			// from reconcile confg doc, defaulting to above value
			// if not present in config doc
			try {
				stView = confObjReconcile.getNabFilePathAndView(stDomain)[1];
			}
			catch(Exception e) {
				e.printStackTrace();
			}

			vwReg = dbNab.getView(stView);
			try {
				me = new MediatorRawDataExtractor(s, log);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				rds.setSuccessThread(ThreadNumber, new Boolean(false));
				return;
			}   
		}


		String stFormula = null;		
		boolean bHandleDomSep = confObjReconcile.handleDomainSeparated(stDomain);


		try {
			stFormula = confObjReconcile.getFilterFormula()[0];

			//docNab = vwReg.getFirstDocument();
			docNab = vwReg.getNthDocument(iStartAt);
		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Problem(NotesException) while get the config NAB view or the nth document" );
			log.logActionLevel(LogLevel.SEVERE, e1.getLocalizedMessage() );
			e1.printStackTrace();
			rds.setSuccessThread(ThreadNumber, new Boolean(false));
		} catch (Exception e) {
			log.logActionLevel(LogLevel.SEVERE, "Problem(Exception) while get the config NAB view or the nth document" );
			log.logActionLevel(LogLevel.SEVERE, e.getLocalizedMessage() );
			e.printStackTrace();
			rds.setSuccessThread(ThreadNumber, new Boolean(false));
		}


		while (docNab != null && iCount < iStackSize) {	
			//iCount++;
			if(!docNab.hasItem("$Conflict"))iCount++;

			try {
				vFilter = s.evaluate(stFormula,docNab);
			} catch (NotesException e1) {
				log.logActionLevel(LogLevel.SEVERE, "Problem(Exception) while Evaluate" );
				log.logActionLevel(LogLevel.SEVERE, e1.getLocalizedMessage() );
				e1.printStackTrace();
			}
			//System.out.println("type" + vFilter.firstElement().getClass().getName());
			stFullName = (String)CommonFunctions.getFirstItemEntry(docNab, "FullName");
			if(vFilter.firstElement() != null && ((String)vFilter.firstElement()).equals("1")){
				log.logActionLevel(LogLevel.FINER, stDomain + "-" + stFullName + " filtered");
				docRecycle = docNab;
				try {
					docNab = vwReg.getNextDocument(docNab);
					docRecycle.recycle();
				} catch (NotesException e) {
					log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get the next document");
					log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + e.id + ", Text=" + e.text);
				}

				continue;
			}


			// disregard all ids with wrong domain
			try {
				if(bHandleDomSep && !docNab.getItemValueString("MailDomain").equalsIgnoreCase(stDomain) && 
						!docNab.getItemValueString("NodeName").equalsIgnoreCase(stDomain)){
					docRecycle = docNab;
					try {
						docNab = vwReg.getNextDocument(docNab);
						docRecycle.recycle();
					} catch (NotesException e) {
						log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get the next document");
						log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + e.id + ", Text=" + e.text);
						rds.setSuccessThread(ThreadNumber, new Boolean(false));
						return;
					}

					continue;
				}
			} catch (NotesException e1) {
				log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get mail domain");
				log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + e1.id + ", Text=" + e1.text);
			}


			try{
				stKey = "";
				vecShortname= docNab.getItemValue("ShortName");
				if(stDomain.equalsIgnoreCase("IBMGBLMS")){
					stKey = "IBMGB" + vecShortname.lastElement();
				}else{
					stKey = stDomain + vecShortname.lastElement();
				}
				//stKey = stDomain + vecShortname.lastElement();
			}catch(Exception e ){
				log.logActionLevel(LogLevel.WARNING, "Problem with shortName for id with fullname "+ stFullName );
			}

			//NCOUAR_Data ncd = hmNCOUAR.get(stKey.toUpperCase());
			//if (vecShortname.lastElement().equalsIgnoreCase("iuser")) {
			//	pln("here we are");
			//	}
			NCOUAR_Data ncd = rds.getNCOUAR_Data(stKey.toUpperCase());
			if (ncd == null) {
				try {
					String []altService = confObjReconcile.getRMIDomin2SearchCorrectNCOUAR();
					for (String sServ: altService) {
						stKey = sServ + vecShortname.lastElement();
						ncd = rds.getNCOUAR_Data(stKey.toUpperCase());
						if (ncd != null) {
							log.logActionLevel(LogLevel.INFO, "D2020: Issue ncouar doc to correct the domain: Found " + vecShortname.lastElement() + " in service " + sServ + " instead in " + stDomain);
							correctASOinNCOUR(s, stKey, stDomain);
							break;
						}
					}

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					log.logActionLevel(LogLevel.WARNING, "D2020: Errror while try to find the Ncoura data in other domain" + e1.getMessage());

					e1.printStackTrace();
				}
			}

			/*	if(ncd == null) {
				log.logActionLevel(LogLevel.INFO, "Key: "+  stKey + "-----> null");
			}else {
				log.logActionLevel(LogLevel.INFO, "Key: "+  stKey + " service = " + ncd.getService() + ", Owner = " + ncd.getOwner() + ", MailSystem =" + ncd.getMailSystem());
			}*/

			// Bernhard specials
			if(stDomain.equalsIgnoreCase("IBMGBLMS")){
				if (ncd == null || !ncd.getService().equalsIgnoreCase("IBMGBLMS")){
					try {
						docRecycle = docNab;
						docNab = vwReg.getNextDocument(docNab);
						docRecycle.recycle();
					} catch (NotesException e) {
						log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get the next document");
						log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + e.id + ", Text=" + e.text);
					}

					continue;
				}
			}


			// all filters are done

			checkLockoutStatus(s,stFullName,ncd);

			// update UAR from NAB
			MailSystemNab = docNab.getItemValueString("MailSystem");
			MailSystemNCouar = (ncd == null)?null:ncd.getMailSystem();

			if(MailSystemNab != null && MailSystemNCouar != null && (MailSystemNab.equals("1")|| MailSystemNab.equals("3"))) { // 1= Notes, 3= other
				if(MailSystemNCouar.equalsIgnoreCase("Notes")) {
					MailSystemNCouar = "1";
				}else if(MailSystemNCouar.equalsIgnoreCase("Other")) {
					MailSystemNCouar = "3";

				}

				// correct the mail system
				if(!stDomain.equalsIgnoreCase("Ocean")) {
					if(!MailSystemNab.equals(MailSystemNCouar)) {
						if (cfgNcouar == null) {
							try {
								cfgNcouar = new ConfigObjNCOUAR(s, log);
								vwUAR = cfgNcouar.getVwITIMEXPORT(stDomain);

							} catch (Exception e) {
								// TODO Auto-generated catch block
								log.logActionLevel(LogLevel.SEVERE, "Error while opening NCOUAR database/view");
								e.printStackTrace();
							}
						}
						if (vwUAR != null) {
							Document docUAR = vwUAR.getDocumentByKey(stKey);
							if (docUAR != null) {
								docUAR.replaceItemValue("MailSystem", MailSystemNab);
								stMsg = stKey + " Key (ServiceShortName) updated Mail System in UAR doc from " + MailSystemNCouar + " to " + MailSystemNab ;
								if(MailSystemNab.equals("3")) {
									docUAR.replaceItemValue("idFileInVault", "0");
									stMsg = stMsg + " and set idFileInVault flag to 0";
								}
								log.logActionLevel(LogLevel.INFO, stMsg);
								docUAR.save();
								docUAR.recycle();
							}else {
								log.logActionLevel(LogLevel.INFO,"DocUAR not found key = " + stKey + " Mailsystem should be " + MailSystemNab );
							}
						}

					}

				}
			}
			//insert line into db2 table
			//chg1
			if (me.insertReconcileLineNew(docNab, ncd, stRunDate)){
				iReconcileNumber++;
				if(iReconcileNumber%1000 == 0) {
					pln(Thread.currentThread().getName() + " added " + iReconcileNumber + " rows after " + (System.currentTimeMillis() - lmilli));
					log.logActionLevel(LogLevel.INFO,Thread.currentThread().getName() + " added " + iReconcileNumber + " NAB rows after " + (System.currentTimeMillis() - lmilli));

				}

				//iCount++; not a good idea, because this will end up in a loop 
			}else{
				iCountErr ++;
				rds.setbMailWarning(true);
				//rds.set
			}
			//if(docUar != null) docUar.recycle();


			docRecycle = docNab;
			try{
				docNab = vwReg.getNextDocument(docNab); // risk that one doc  is not delete from storage
				docRecycle.recycle();
			}catch(NotesException ne){
				log.logActionLevel(LogLevel.SEVERE, "NotesExecption while get the next document");
				log.logActionLevel(LogLevel.SEVERE, "NotesExecption ID=" + ne.id + ", Text=" + ne.text);
				rds.setSuccessThread(ThreadNumber, new Boolean(false));
				return;
			}

		}

		pln("log Session before recycle:" + log.getSess());
		synchronized (rds) {
			if(vwReg != null)vwReg.recycle();
			if(dbNab != null)dbNab.recycle();
			if(s != null)s.recycle();
			//if(me != null)me.close();
		}
		pln("log Session after recycle" + log.getSess());

		pln(Thread.currentThread().getName() + this.getName() + "-" + " Nab extract ends after " + (System.currentTimeMillis() - lmilli) );
		log.logActionLevel(LogLevel.INFO,Thread.currentThread().getName() + this.getName() + "-" + "Nab extraction ends after " + (System.currentTimeMillis() - lmilli));
		rds.addNumberofReconciledIs(ThreadNumber, new Integer(iReconcileNumber));
		rds.setSuccessThread(ThreadNumber, new Boolean(true));
		log.logActionLevel(LogLevel.INFO, Thread.currentThread().getName() +":"+ stDomain + ":" + iReconcileNumber + " persons (start at:" +
				iStartAt + " end at:" +(iStartAt + iCount) + " after " + (System.currentTimeMillis() - lmilli) + " millis - " + iReconcileNumber + "  successful insertions / " + iCountErr + " failed insertions" );

	}

	private void checkLockoutStatus(Session s, String fullName, NCOUAR_Data ncouar){
		Name nmfullname;
		String stFullname;
		String stState;

		if(ncouar == null) return;

		/*if(denyListPasswordLockout == null || denyListPasswordLockout == null){
			getTerminationLists();

		}*/


		try {
			stState = ncouar.getNABState();
			if (!stState.toUpperCase().equals(ReconcileRawData.STATUS_FREEZE)){
				nmfullname = s.createName(fullName);
				stFullname = nmfullname.getCanonical();
				nmfullname.recycle();

				if(rds.getDenyListPasswordLockout().contains(stFullname) ){
					ncouar.setState(ReconcileRawData.STATUS_PW_EXPIRED);
					return;
				}

				if(rds.getDenyListTermination().contains(stFullname)){
					ncouar.setState(ReconcileRawData.STATUS_TERMINATED);
					return;
				}

			}
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException np){
			log.logActionLevel(LogLevel.SEVERE, "Termination list not found -- > exit");
			throw np;
		}
	}
	private void pln (String s){
		System.out.println(s);
	}

	private void correctASOinNCOUR(Session s,String stKey, String dom) {
		String stMsg;
		String AsoDomain;
		if (cfgNcouar == null) {
			try {
				cfgNcouar = new ConfigObjNCOUAR(s, log);
				vwUAR = cfgNcouar.getVwITIMEXPORT(stDomain);

			} catch (Exception e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.SEVERE, "Error while opening NCOUAR database");
				e.printStackTrace();
			}
		}
		if (vwUAR != null) {

			Document docUAR;
			try {
				docUAR = vwUAR.getDocumentByKey(stKey);
				if (docUAR == null) {
					log.logActionLevel(LogLevel.WARNING, "D2020: Error while try to update NCOUAR document, NCOUAR document not found for" + stKey);

				}else {
					AsoDomain = docUAR.getItemValueString("Domain");
					Vector vHist = docUAR.getItemValue("History");
					docUAR.replaceItemValue("Domain", dom);
					stMsg =  " Key (ServiceShortName) "+ stKey + " updated Aso Domain  UAR doc from " + AsoDomain + " to " + dom  + " by Reconcile";
					log.logActionLevel(LogLevel.INFO, "Domino2020: " +stMsg);

					vHist.addElement(CommonFunctionGeneral.getActDate() + " " + stMsg);
					docUAR.replaceItemValue("History", vHist);
					docUAR.save();
					docUAR.recycle();

				}

			} catch (NotesException e) {
				// TODO Auto-generated catch block
				log.logActionLevel(LogLevel.WARNING, "D2020: Error while try to update NCOUAR document" + e.getMessage());

				e.printStackTrace();
			}

		}

	}
}
