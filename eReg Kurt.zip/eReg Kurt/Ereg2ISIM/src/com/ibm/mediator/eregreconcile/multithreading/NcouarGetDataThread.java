package com.ibm.mediator.eregreconcile.multithreading;

import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.mediatordatabeans.NCOUAR_Data;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

public class NcouarGetDataThread extends NotesThread {

	private String passWord;
	private int iStartAt;
	private int iStackSize;
	private ReconcileDataSingleton rds;
	private String DatabaseServer;
	private String Databasefilepath;
	private String stDomain;
	private Integer ThreadNumber;
	private String UARViewname;
	private InputOutputLogger log;

	public NcouarGetDataThread(NcourGetDataInput in){
		if (! in.isValid()) throw new IllegalArgumentException("Argument input not valid:" + in.getsError());
		iStartAt = in.getiStartAt();
		iStackSize = in.getiStackSize();
		DatabaseServer = in.getDatabaseServer();
		Databasefilepath = in.getDatabasefilepath();
		stDomain = in.getStDomain();
		UARViewname = in.getUarViewName();
		ThreadNumber = in.getThreadNumber();
		rds = ReconcileDataSingleton.getInstance();
		passWord = in.getPassWord();
		log = in.getLog();
	}

	@Override
	public void runNotes() {
		// TODO Auto-generated method stub
		try {
			super.runNotes();
			Session s;
			ViewEntry ve;
			ViewEntryCollection vec = null; 
			Database dbUAR = null;
			View vwUAR = null;
			boolean bSuccess = true;

			long lmilli = System.currentTimeMillis();
			pln(CommonFunctions.getActDate() + ":" +Thread.currentThread().getName() + " started on row " + iStartAt + " name = " + this.getName());

			rds = ReconcileDataSingleton.getInstance();


			synchronized (rds) {
				s = CommonFunctions.getNewSession(passWord);
				dbUAR = CommonFunctions.getDatabase(s, DatabaseServer, Databasefilepath);
				vwUAR = dbUAR.getView(UARViewname);
				vwUAR.setAutoUpdate(false);
				//vwUAR.refresh();
				log.logActionLevel(LogLevel.INFO, CommonFunctions.getActDate() + ": Starting Thread " +Thread.currentThread().getName() + " using view " +  vwUAR.getName() );

			}
			pln(CommonFunctions.getActDate() + ":" +Thread.currentThread().getName() + " Opened database after " +((System.currentTimeMillis() - lmilli))/1000 +" sec name = " + this.getName());

			vec = vwUAR.getAllEntriesByKey(stDomain, true);

			//vec = vwUAR.getAllEntriesByKey(stDomain);
			ve = vec.getNthEntry(iStartAt);

			pln(CommonFunctions.getActDate() + ":" + Thread.currentThread().getName() + " Positioned to start after " +((System.currentTimeMillis() - lmilli))/1000 +" sec name = " + this.getName());



			String stKey  = null;
			int iCount = 0; 
			ViewEntry veRec = null;	
			NCOUAR_Data nd = null;
			Vector vecLine = null;

			if (ve == null){
				pln(CommonFunctions.getActDate() + ":" + Thread.currentThread().getName() + " not found the " + iStartAt + " document vec has " + vec.getCount() + " entries" );
			}

			while(ve != null && iCount < iStackSize){
				try {
					vecLine = ve.getColumnValues();
					stKey = vecLine.elementAt(3).toString() + vecLine.elementAt(2).toString();
					stKey = stKey.toUpperCase();

					nd = new NCOUAR_Data();
					nd.setClassification(vecLine.elementAt(9).toString());

					if (vecLine.elementAt(10).toString().equals("1.0")){
						nd.setIdFile("Y");
					}else{
						nd.setIdFile("N");
					}
					nd.setMailDomain(vecLine.elementAt(3).toString());
					nd.setOwner(vecLine.elementAt(6).toString());
					nd.setOwnerCountry(vecLine.elementAt(5).toString());
					nd.setSerialNumber(vecLine.elementAt(8).toString());
					nd.setService(vecLine.elementAt(5).toString());
					nd.setState(vecLine.elementAt(13).toString());
					if(nd.getClassification().equals("F")){
						nd.setTaskId("Y");
					}else{
						nd.setTaskId("N");
					}


					nd.setMailSystem(vecLine.elementAt(14).toString()); // 1 = Notes, 3 = other
					//pln ("key = " + stKey + " MailSystem = " + nd.getMailSystem() + " --- Load ");

					nd.setIdFileInVault(vecLine.elementAt(16).toString()); 

					if(vecLine.size() > 17) {
						nd.setLnAdapterCustom(vecLine.elementAt(17).toString());
					}
					rds.addNCOUARData(stKey.toUpperCase(),nd);
				}catch (NotesException e1) {
					// TODO Auto-generated catch block
					pln( "*****Error****** while reading line " +CommonFunctions.getActDate() + ":" + Thread.currentThread().getName() +"-" + this.getName()+ "- key = "  + stKey + " Error " + e1.getLocalizedMessage() + "-" + e1.getMessage() );
					log.logActionLevel(LogLevel.SEVERE, "*****Error****** while reading line " +CommonFunctions.getActDate() + ":" + Thread.currentThread().getName() +"-" + this.getName()+ "- key = "  + stKey + " Error " + e1.getLocalizedMessage() + "-" + e1.getMessage());
					e1.printStackTrace();
					//bSuccess = false;
					//break;
				}
				veRec = ve;
				try {
					ve = vec.getNextEntry(ve);
				}catch(NotesException e2) {
					int iPos = iCount + iStartAt;
					log.logActionLevel(LogLevel.INFO, CommonFunctions.getActDate() + ": --- try to get new position because of Notexception on  " + iPos + Thread.currentThread().getName() +"-" + this.getName() + " worked on " + iCount + " UAR entry " + veRec.getColumnValues().toString());
					ve = vec.getNthEntry(iPos);
					log.logActionLevel(LogLevel.INFO, CommonFunctions.getActDate() + ": --- got new position " + Thread.currentThread().getName() +"-" + this.getName() + " working on " + iCount + " UAR entry");

				}
				veRec.recycle();
				iCount ++;
				if(iCount%500 == 0) {
					pln (CommonFunctions.getActDate() + ":" + Thread.currentThread().getName() +"-" + this.getName() + " working on " + iCount + " UAR entry, domain =" + stDomain);
					log.logActionLevel(LogLevel.INFO, CommonFunctions.getActDate() + ":" + Thread.currentThread().getName() +"-" + this.getName() + " working on " + iCount + " UAR entry");
				}

				//if (lcount % 100 ==0)pln("Reading " + lcount +"/" + lsize + "entry");
			}
			if(vec != null)vec.recycle();
			if(vwUAR != null)vwUAR.recycle();
			if(dbUAR != null)dbUAR.recycle();
			if (s !=null)s.recycle();
			pln (CommonFunctions.getActDate() + ":" + Thread.currentThread().getName() + " ends after " + ((System.currentTimeMillis() - lmilli))/1000 + " sec  Ncouar tm entries: "+ rds.getNCOUARSize() + " name = " + this.getName());
			log.logActionLevel(LogLevel.INFO, CommonFunctions.getActDate() + ":" + Thread.currentThread().getName() + " ends after " + ((System.currentTimeMillis() - lmilli))/1000 + " sec  Ncouar tm entries: "+ rds.getNCOUARSize() + " name = " + this.getName());
			
			//rds.setSuccessThread(ThreadNumber, new Boolean(true);
			rds.setSuccessThread(ThreadNumber, new Boolean(bSuccess));


		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE,"*****Error****** while position to entry" + CommonFunctions.getActDate() + ":" + Thread.currentThread().getName() +"-" + this.getName() + " Error " + e1.getLocalizedMessage() + "-" + e1.getMessage());
			if (rds != null)rds.setSuccessThread(ThreadNumber, new Boolean(false));
			e1.printStackTrace();
		}



	}
	private void pln (String s){
		System.out.println(s);
	}
}
