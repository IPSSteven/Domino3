package com.ibm.mediator.eregreconcile.multithreading;

import java.lang.reflect.Field;

import com.ibm.ereg.logger.InputOutputLogger;

public class NcourGetDataInput {
	private String passWord = null;
	private int iStartAt = -1;
	private int iStackSize = -1;
	private String DatabaseServer = null;
	private String Databasefilepath = null;
	private String stDomain = null;
	private Integer ThreadNumber = null;
	private String UarViewName = null;
	private String sError = ""; // must not be null
	private InputOutputLogger log;
	
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	public int getiStartAt() {
		return iStartAt;
	}
	public void setiStartAt(int iStartAt) {
		this.iStartAt = iStartAt;
	}
	public int getiStackSize() {
		return iStackSize;
	}
	public void setiStackSize(int iStackSize) {
		this.iStackSize = iStackSize;
	}
	public String getDatabaseServer() {
		return DatabaseServer;
	}
	public void setDatabaseServer(String databaseServer) {
		DatabaseServer = databaseServer;
	}
	public String getDatabasefilepath() {
		return Databasefilepath;
	}
	public void setDatabasefilepath(String databasefilepath) {
		Databasefilepath = databasefilepath;
	}
	public String getStDomain() {
		return stDomain;
	}
	public void setStDomain(String stDomain) {
		this.stDomain = stDomain;
	}
	public Integer getThreadNumber() {
		return ThreadNumber;
	}
	public void setThreadNumber(Integer threadNumber) {
		ThreadNumber = threadNumber;
	}
	
	public String getsError() {
		return sError;
	}
	public void setsError(String sError) {
		this.sError = sError;
	}
	
	
	public InputOutputLogger getLog() {
		return log;
	}
	public void setLog(InputOutputLogger log) {
		this.log = log;
	}
	public boolean isValid(){
		String sType;
		Field[] fields =this.getClass().getDeclaredFields();
		for(Field f : fields){
			try {
				//System.out.println(f.getType() + ":" + f.get(this));
				sType =f.getType().toString();
				if (sType.startsWith("class") &&  f.get(this) == null ){
					sError = f.getName() +  "is null";
					return false;
				}else if(sType.equals("int") &&  f.getInt(this) < 0) {
					sError = f.getName() +  "<0 or not set";
					return false;
				}
				
			
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	public String getUarViewName() {
		return UarViewName;
	}
	public void setUarViewName(String uarViewName) {
		UarViewName = uarViewName;
	}
	
	
	
}
