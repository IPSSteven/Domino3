package com.ibm.mediator.eregreconcile.multithreading;

import com.ibm.mediator.eregreconcile.ReconcileItimRunner;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class ReconcicleProccessRunner extends NotesThread {
	private String pw;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReconcicleProccessRunner reconProRunner = new ReconcicleProccessRunner();
		reconProRunner.pw = args[0];
		reconProRunner.start();
	
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess(pw);
		ReconcileItimRunner rr = new ReconcileItimRunner(s);
		rr.runNotes();
	}
	
	

}
