package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

public class ACData extends BasicData {
	private String eregChangeType;
	private String eregAliasType;
	private String eregOldAlias;
	private String eregNewAlias;
	
	
	public ACData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ACData(ResultSet rs, Session sess) {
		super(rs, sess);

	}
	
	public String getEregChangeType() {
		return eregChangeType;
	}
	public void setEregChangeType(String eregChangeType) {
		this.eregChangeType = eregChangeType;
	}
	public String getEregAliasType() {
		return eregAliasType;
	}
	public void setEregAliasType(String eregAliasType) {
		this.eregAliasType = eregAliasType;
	}
	public String getEregOldAlias() {
		return eregOldAlias;
	}
	public void setEregOldAlias(String eregOldAlias) {
		this.eregOldAlias = eregOldAlias;
	}
	public String getEregNewAlias() {
		return eregNewAlias;
	}
	public void setEregNewAlias(String eregNewAlias) {
		this.eregNewAlias = eregNewAlias;
	}
}
