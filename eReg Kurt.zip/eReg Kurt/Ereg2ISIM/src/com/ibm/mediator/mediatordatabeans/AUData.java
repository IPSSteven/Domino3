package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

public class AUData extends BasicData {

	public AUData() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AUData(ResultSet rs, Session sess) {
		super(rs, sess);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	private final String empArtifical = "artificial";
	private String eregService;
	private String eregPrimId;
	private String eregFuncId;
	private String teleCNr;
	private String eregASOcc;
	private String eregASOEmpnum;
	private String eregEmpcc;
	private String eregOwnerUID;
	private String eregClassification;
	//private String eregOrg;
	private String eregOwner;
	private String eregItimOwner;
	private String eregLastName;
	private String eregFirstName;
	private String eregMiddleInitial;
	private String eregMgrId;
	private String eregIDReceiver;
	private String eregAdminDomain;
	private String eregAdminID;
	private String eregAdminMailAddress;
	private String eregEmpNum;
	private String eregDepartment;
	private String eregRequestor;
	private String eregMailSystem;


	public String getEregService(){
		return eregService;
	}
	
	public void setEregService(String eregService){
		this.eregService = eregService;
	}
	
	public String getEregASOcc() {
		int digit = eregASOcc.indexOf("~");
		if(digit > 0 ){
			return eregASOcc.substring(0,digit);
		}else{
			return eregASOcc;
		}

	}
	public void setEregASOcc(String eregASOcc) {
		this.eregASOcc = eregASOcc;
	}
	public String getEregASOEmpnum() {
		if (eregASOEmpnum.equals(empArtifical)){
			return eregASOEmpnum;
		}
		int fromPosition =  0;
		int toPosition = eregASOEmpnum.length() - 3;
		if (toPosition < 0){
			return eregASOEmpnum;
		}else{
			return eregASOEmpnum.substring(fromPosition, toPosition);
		}

	}
	public void setEregASOEmpnum(String eregASOEmpnum) {
		this.eregASOEmpnum = eregASOEmpnum;
	}
	public String getEregEmpcc() {
		int toPosition = eregEmpcc.length();
		int fromPosition =  toPosition - 3;
		if (fromPosition < 0 ){
			return eregEmpcc;
		}else{
			return eregEmpcc.substring(fromPosition, toPosition);
		}

	}
	public void setEregEmpcc(String eregASOEmpCC) {
		this.eregEmpcc = eregASOEmpCC;
	}
	public String getEregOwnerUID() {
		return eregOwnerUID;
	}
	public void setEregOwnerUID(String eregOwnerUID) {
		this.eregOwnerUID = eregOwnerUID;
	}
	public String getEregClassification() {
		return eregClassification;
	}
	public void setEregClassification(String eregClassification) {
		this.eregClassification = eregClassification;
	}
	public String getEregOrg() {
		int digit = eregASOcc.indexOf("~");
		if (digit > 0){
			return ("IBM" + eregOrg.split("~")[1]);
		}else{
			return eregOrg;
		}
	}
	public void setEregOrg(String eregOrg) {
		this.eregOrg = eregOrg;
	}
	public String getEregOwner() {
		if(b_serialNpsc){
			return eregOwner;
		}else{
			int fromPosition =  0;
			int toPosition = eregOwner.length() - 3;
			if (toPosition < 0){
				return eregOwner;
			}else{
				return eregOwner.substring(fromPosition, toPosition);
			}
		}
	}
	public void setEregOwner(String eregOwner) {
		this.eregOwner = eregOwner;
	}
	public String getEregItimOwner() {
		return eregItimOwner;
	}
	public void setEregItimOwner(String eregItimOwner) {
		this.eregItimOwner = eregItimOwner;
	}
	public String getEregAdminDomain() {
		return eregAdminDomain;
	}
	public void setEregAdminDomain(String eregAdminDomain) {
		this.eregAdminDomain = eregAdminDomain;
	}
	public String getEregAdminID() {
		return eregAdminID;
	}
	public void setEregAdminID(String eregAdminID) {
		this.eregAdminID = eregAdminID;
	}
	public void setEregIDReceiver(String eregIDReceiver) {
		this.eregIDReceiver = eregIDReceiver;
	}
	public String getEregEmpNum() {

		if (eregEmpNum.equals(empArtifical)){
			return eregEmpNum;
		}
		int fromPosition =  0;
		int toPosition = eregEmpNum.length() - 3;
		if (toPosition < 0){
			return eregEmpNum;
		}else{
			return eregEmpNum.substring(fromPosition, toPosition);
		}

	}
	public void setEregEmpNum(String eregEmpNum) {
		this.eregEmpNum = eregEmpNum;
	}
	public String getEregPrimId() {
		return eregPrimId;
	}
	public void setEregPrimId(String eregSecId) {
		this.eregPrimId = eregSecId;
	}
	public String getEregFuncId() {
		return eregFuncId;
	}

	public void setEregFuncId(String eregFuncId) {
		this.eregFuncId = eregFuncId;
	}

	public String getEregMgrId() {
		return eregMgrId;
	}

	public String getEregIDReceiver() {
		return eregIDReceiver;
	}

	public void setEregMgrId(String idReceiver) {
		this.eregMgrId = idReceiver;
	}

	public String getTeleCNr() {
		return teleCNr;
	}

	public void setTeleCNr(String teleCNr) {
		this.teleCNr = teleCNr;
	}

	public String getEregFirstName() {
		return eregFirstName;
	}

	public void setEregFirstName(String fName) {
		this.eregFirstName = fName;
	}

	public String getEregMiddleInitial() {
		return eregMiddleInitial;
	}

	public void setEregMiddleInitial(String middleIntial) {
		this.eregMiddleInitial = middleIntial;
	}

	public String getEregLastName() {
		return eregLastName;
	}

	public void setEregLastName(String lName) {
		this.eregLastName = lName;
	}

	public String getEregAdminMailAddress() {
		if(eregAdminMailAddress == null) return "";
		else return eregAdminMailAddress.split("@")[0];
	}

	public void setEregAdminMailAddress(String admin) {
		this.eregAdminMailAddress = admin;
	}
	public String getEregDepartment() {
		return eregDepartment;
	}
	public void setEregDepartment(String eregDepartment) {
		this.eregDepartment = eregDepartment;
	}
	public String getEregRequestor() {
		return eregRequestor;
	}
	public void setEregRequestor(String eregRequestor) {
		this.eregRequestor = eregRequestor;
	}
	
	public String getEregMailSystem() {
		return eregMailSystem;
	}
	public void setEregMailSystem(String eregMailSystem) {
		this.eregMailSystem = eregMailSystem;
	}
	
	
	
}
