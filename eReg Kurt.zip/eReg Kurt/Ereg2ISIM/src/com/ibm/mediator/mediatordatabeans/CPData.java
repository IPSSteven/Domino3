package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

//import com.ibm.ereg.config.ConfigObj;
//import com.ibm.ereg.config.ConfigObjCountryTable;

public class CPData extends BasicData {
	
	private String eregNewOrg;
	private String eregNewOwner;
	private String eregNewClassification;
	private String eregASOEmpNum;
	private String eregASOOwnerDep;
	private String eregASOOwnerEmp;
	private String eregITIMPsc;

	public CPData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CPData(ResultSet rs, Session sess) {
		super(rs, sess);

	}

	public String getEregNewOrg() {
		/*String stPSC;
		String stResult = null;
		int iLen = eregNewOrg.length();
		if (iLen > 5) {
			stPSC = eregNewOrg.substring(iLen - 3, iLen);
			stResult = cfgCT.getCountryCode(stPSC);
			//	return stResult;
			//} else {
			//	return null;
		}

		if (stResult == null){
			return this.eregOrg;
		}else{
			return stResult;
		}*/
		
		return this.eregOrg; //change between services = org is not posible

	}

	public void setEregNewOrg(String eregNewOrg) {
		this.eregNewOrg = eregNewOrg;
	}

	public String getEregNewOwner() {
		if (b_serialNpsc){
			return eregNewOwner;
		}else{
			int iLen = eregNewOwner.length();
			if (iLen > 3) {
				return eregNewOwner.substring(0, iLen - 3);
			} else {
				return eregNewOwner;
			}
		}
		


	}

	public void setEregNewOwner(String eregNewOwner) {
		this.eregNewOwner = eregNewOwner;
	}

	public String getEregNewClassification() {
		return eregNewClassification;
	}

	public void setEregNewClassification(String eregNewClassification) {
		this.eregNewClassification = eregNewClassification;
	}

	public String getEregASOEmpNum() {
		// split PSC code and serial number
		int iLen = eregASOEmpNum.length();
		if (iLen > 9){
			return eregASOEmpNum; // not well formatted, but ins some cases ITIM returns things like artifical, and ereg has to act
		}
		if (iLen > 3) {
			return eregASOEmpNum.substring(0, iLen - 3);
		} else {
			return eregASOEmpNum;
		}
	}

	public void setEregASOEmpNum(String eregASOEmpnum) {
		this.eregASOEmpNum = eregASOEmpnum;
	}

	public String getEregASOOwnerDep() {
		return eregASOOwnerDep;
	}

	public void setEregASOOwnerDep(String eregASOOwnerDep) {
		this.eregASOOwnerDep = eregASOOwnerDep;
	}

	public String getEregASOOwnerEmp() {
		return eregASOOwnerEmp;
	}

	public void setEregASOOwnerEmp(String eregASOOwnerEmp) {
		this.eregASOOwnerEmp = eregASOOwnerEmp;
	}

	public String getEregITIMPsc() {
		String stPSC = "";
		int iLen = eregITIMPsc.length();
		if (iLen > 3) {
			stPSC = eregITIMPsc.substring(iLen - 3, iLen);
			;
		}
		return stPSC;
	}

	public void setEregITIMPsc(String eregITIMPsc) {
		this.eregITIMPsc = eregITIMPsc;
	}

}
