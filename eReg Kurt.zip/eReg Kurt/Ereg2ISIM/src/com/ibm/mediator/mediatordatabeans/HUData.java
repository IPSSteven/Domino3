/**
 * 
 */
package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

import com.ibm.mediator.mediatordatabeans.CPData;

/**
 * @author Kurt Raiser
 *
 */
public class HUData extends CPData {

	public HUData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HUData(ResultSet rs, Session sess) {
		super(rs, sess);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sess
	 * @throws Exception
	 */

}
