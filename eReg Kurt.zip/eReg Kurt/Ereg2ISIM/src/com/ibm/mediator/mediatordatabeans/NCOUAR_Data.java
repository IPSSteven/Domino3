/**
 * 
 */
package com.ibm.mediator.mediatordatabeans;

/**
 * @author Kurt Raiser
 *
 */
public class NCOUAR_Data {
	private String Service;
	private String SerialNumber;
	private String Classification;
	private String TaskId;
	private String IdFile;
	private String State;
	private String Owner;
	private String OwnerCountry;
	private String MailSystem;
	private String IdFileInVault;
	private String lnAdapterCustom ;
	private String mailDomain = "" ;

	public String getOwner() {
		return Owner;
	}

	public String getOwnerCountry() {
		return OwnerCountry;
	}

	public void setOwner(String owner) {
		Owner = owner;
	}
	public void setOwnerCountry(String ownerCountry) {
		OwnerCountry = ownerCountry;
	}
	public String getService() {
		return Service;
	}
	public void setService(String service) {
		Service = service;
	}
	public String getSerialNumber() {
		return SerialNumber;
	}
	
	public String getMailSystem() {
		return MailSystem;
	}

	public String getIdFileInVault() {
		return IdFileInVault;
	}

	public void setSerialNumber(String serialNumber) {
		SerialNumber = serialNumber;
	}
	public String getClassification() {
		return Classification;
	}
	public void setClassification(String classification) {
		Classification = classification;
	}
	public String getTaskId() {
		return TaskId;
	}
	public void setTaskId(String taskId) {
		TaskId = taskId;
	}
	public String getIdFile() {
		return IdFile;
	}
	public void setIdFile(String idFile) {
		IdFile = idFile;
	}
	public String getNABState() {
		// NCOUAR state and NAB State are different
		if(State.equals("Only deny access")){
			return "suspended";
		}else{
			return State;
		}

	}
	public String getState() {

		return State;	
	}
	public void setState(String state) {
		State = state;
	}

	public void setMailSystem(String mailSystem) {
		MailSystem = mailSystem;
	}

	public void setIdFileInVault(String idFileInVault) {
		IdFileInVault = idFileInVault;
	}

	public String getLnAdapterCustom() {
		return lnAdapterCustom;
	}

	public void setLnAdapterCustom(String lnAdapterCustom) {
		this.lnAdapterCustom = lnAdapterCustom;
	}

	public String getMailDomain() {
		return mailDomain;
	}

	public void setMailDomain(String mailDomain) {
		this.mailDomain = mailDomain;
	}
	
	
}
