package com.ibm.mediator.mediatordatabeans;

import java.sql.ResultSet;

import lotus.domino.Session;

public class RSData extends BasicData {



	public RSData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RSData(ResultSet rs,Session sess) {
		super(rs, sess);
		// TODO Auto-generated constructor stub
	}

}
