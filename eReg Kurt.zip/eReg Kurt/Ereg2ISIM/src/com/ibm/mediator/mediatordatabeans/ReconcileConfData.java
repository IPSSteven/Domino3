/**
 * 
 */
package com.ibm.mediator.mediatordatabeans;

/**
 * @author Kurt Raiser
 *
 */
public class ReconcileConfData {
	private String runDate = null;
	private String endDate = null;
	private String system = null;
	private String returncode = null;
	private String idnumber = null;
	private String comment = null;
	public final String FIELDCLAUSE = "(rundate, system, returncode, idnumber, finishdate, comment)";
	public final String INSERT = "Insert into ";
	public final String UPDATE = "UpDate  ";
	
	
	public String getValuesClause(){
		String sr =  "values(" +
		this.getRunDate() + "," +
		this.getSystem()+ "," +
		this.getReturncode()+ "," +
		this.getIdnumber()+ "," + 
		this.getEndDate()+ "," + 
		this.getComment() +
		")";
		
		return sr;
	}
	public String getRunDate() {
		return "'" + runDate + "'";
	}
	public void setRunDate(String runDate) {
		this.runDate = runDate;
	}
	
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = "'" + endDate + "'" 
				;
	}
	public String getSystem() {
		return "'" + system + "'";
	}
	public void setSystem(String system) {
		this.system = system;
	}
	public String getReturncode() {
		return returncode;
	}
	public void setReturncode(String returncode) {
		this.returncode = returncode;
	}
	public String getIdnumber() {
		return idnumber;
	}
	public void setIdnumber(String numberIds) {
		this.idnumber = numberIds;
	}
	public String getComment() {
		return "'" + comment + "'";
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	

}
