package com.ibm.mediator.mediatordatabeans;

import java.util.Vector;

import lotus.domino.Session;

import com.ibm.ereg.common.CommonFunctions;

public class ReconcileRawData {
	public String INSERT = "Insert into ";
	//public final String FIELDCLAUSE = "(rundate, domain, service, shortname, firstname, middleinitial, secondname, qualifiedname, serialnumber, nabserial, taskid, idfile, classification, status)";
	//public final String FIELDCLAUSE = "(rundate, domain, service, shortname, firstname, middleinitial, secondname, qualifiedname, serialnumber, nabserial, taskid, idfile, classification, status, usernamealias, shortnamealias, internetaddress)";
	//public final String FIELDCLAUSE = "(rundate, domain, service, shortname, firstname, middleinitial, secondname, qualifiedname, serialnumber, nabserial, taskid, idfile, classification, status, usernamealias, shortnamealias, internetaddress, mailsystem)";
	public final String FIELDCLAUSE = "(rundate, domain, service, shortname, firstname, middleinitial, secondname, qualifiedname, serialnumber, nabserial, taskid, idfile, classification, status, usernamealias, shortnamealias, internetaddress, mailsystem, lnadaptercustom)";
	
	//private final String [] STATUSVALUES = {"! FREEZE !", "! SUSPEND !", "! PARKED !"};
	public static final String STATUS_SUSPEND =  "SUSPENDED";
	public static final String STATUS_PW_EXPIRED =  "PW EXPIRED";
	public static final String STATUS_TERMINATED=  "TERMINATED";
	public static final String STATUS_FREEZE = "FREEZE";
	public static final String STATUS_PARKTED = "PARKED";
	private final String [] STATIFREEZE = {STATUS_FREEZE};
	private final String [] STATIDENIED = {STATUS_SUSPEND,STATUS_PW_EXPIRED,STATUS_TERMINATED};
	private final String [] STATIPARKED = {STATUS_PARKTED};
	private String rundate;
	private String domain;
	private String service;
	private String shortname;
	private String firstname;
	private String middleinitial;
	private String secondname;
	protected String qualifiedname;
	private String serialnumber;
	private String nabserial;
	private String taskid;
	private String idfile;
	protected String status;
	private String classification;
	protected String usernameAlias;
	protected String shortNameAlias;
	private String internetAdress;
	private String mailSystem;
	private String lnAdapterCustom ;
	
	//private String values clause;
	public String getValuesclause() {
		String sr =  "values(" +
				this.getRundate() + "," +
				this.getDomain()+ "," +
				this.getService()+ "," +
				this.getShortname() + "," +
				this.getFirstname() + "," +
				this.getMiddleinitial() + "," +
				this.getSecondname() + "," +
				this.getQualifiedname()+ "," +
				this.getSerialnumber() + "," +
				this.getNabserial() + "," +
				this.getTaskid() + "," +
				this.getIdfile() + "," + 
				this.getClassification() +"," +
				this.getStatus() +"," +
				this.getUsernameAlias()+"," +
				this.getShortNameAlias() +"," +
				this.getInternetAdress() + "," +
				this.getMailSystem() + "," +
				this.getLnAdapterCustom() +
				")"; 
		/*String sr =  "values(" +
		this.getRundate() + "," +
		this.getDomain()+ "," +
		this.getService()+ "," +
		this.getShortname() + "," +
		this.getFirstname() + "," +
		this.getMiddleinitial() + "," +
		this.getSecondname() + "," +
		this.getQualifiedname()+ "," +
		this.getSerialnumber() + "," +
		this.getNabserial() + "," +
		this.getTaskid() + "," +
		this.getIdfile() + "," + 
		this.getClassification() +"," +
		this.getStatus() +"," +
		this.getUsernameAlias()+"," +
		this.getShortNameAlias() +"," +
		this.getInternetAdress() +
		")";
		*/
		return sr;
	}
	public String getRundate() {
		return "'" + rundate + "'" ;
	}
	public void setRundate(String rundata) {
		this.rundate = rundata;
	}
	public String getDomain() {
		return "'" + domain + "'";
	}
	public void setDomain(String domain) {
		if (domain != null){
			this.domain = domain.replaceAll("'", "''");	
		}else{
			this.domain = "N/A";
		}

	}
	public String getService() {
		return  "'" +service + "'";
	}
	public void setService(String service) {
		if(service != null){
			this.service = service.replaceAll("'", "''");
		}else{
			this.service  ="N/A";
		}
	}
	public String getShortname() {
		return "'" + shortname + "'";
	}
	public void setShortname(String shortname) {
		this.shortname = shortname.replaceAll("'", "''");
	}
	public String getFirstname() {
		return "'" + firstname + "'";
	}
	public void setFirstname(String firstname) {
		if (firstname != null){
			this.firstname = firstname.replaceAll("'", "''");
		}else{
			this.firstname  ="N/A";
		}

	}
	public String getMiddleinitial() {

		return "'" + middleinitial + "'";
	}
	public void setMiddleinitial(String middleinitial) {
		if(middleinitial != null){
			this.middleinitial = middleinitial.replaceAll("'", "''");
		}else{
			this.middleinitial ="N/A";
		}

	}
	public String getSecondname() {
		return "'" + secondname + "'";
	}
	public void setSecondname(String secondname) {
		if(secondname != null){
			this.secondname = secondname.replaceAll("'", "''");
		}else{
			this.secondname =  "N/A";
		}
	}
	public String getQualifiedname() {
		return "'" + qualifiedname + "'";
	}
	public void setQualifiedname(String qualifiedname, Session s) {
		if (qualifiedname != null){
			this.qualifiedname = CommonFunctions.getNameAbbrivate(s, qualifiedname);
			this.qualifiedname = this.qualifiedname.replaceAll("'", "''");
		}else{
			this.qualifiedname = "N/A";
		}

	}
	public String getSerialnumber() {
		return "'" + serialnumber + "'";
	}
	public void setSerialnumber(String serialnumber) {
		if(serialnumber != null){
			this.serialnumber = serialnumber.replaceAll("'", "''");
		}else{
			this.serialnumber = "N/A";
		}

	}
	public String getNabserial() {
		return "'" + nabserial + "'";
	}
	public void setNabserial(String nabserial) {
		if(nabserial != null){
			this.nabserial = nabserial.replaceAll("'", "''");
		}else{
			this.nabserial = "N/A";
		}

	}
	public String getTaskid() {
		return "'" + taskid + "'";
	}
	public void setTaskid(String taskid) {
		this.taskid = taskid;
	}
	public String getIdfile() {
		return "'" + idfile + "'";
	}
	public void setIdfile(String idfile) {
		this.idfile = idfile;
	}
	public void setMailSystem(String mailSystem) {
		this.mailSystem = mailSystem;
	}
	
	
	public String getStatus() {
		if (status == null || status.equals("")){
			return "'" +  "Ok" + "'";
		}else{
			String sComp = status.toUpperCase();
			for (String s:STATIFREEZE){
				//if (sComp.contains(s)) return "'" + "! FREEZE !" +"'";
				if (sComp.contains(s)) return "'! " + s +" !'";
			}
			for (String s:STATIDENIED){
				//if (sComp.contains(s)) return "'" + "! SUSPENDED !" + "'";
				if (sComp.contains(s)) return "'! " + s + " !'";

				//if (sComp.contains(s)) return "'" + "! SUSPEND !" + "'";
			}
			for (String s:STATIPARKED){
				if (sComp.contains(s)) return "'! " + s + " !'";
			}
			//for(String s :STATUSVALUES){
			//	if (status.equalsIgnoreCase(s)){
			//		return "'! " +status+ " !'";
			//	} else if (status.equalsIgnoreCase("! " + s + " !")) {
			//		return "'" +status+ "'";
			//	}
			//}	
		}
		// Status other then defined status values
		return "'" +"! EXPIRED !" + "'";
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getClassification() {
		return "'" + classification + "'";
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getUsernameAlias() {
		return "'" + usernameAlias + "'";
	}
	public void setUsernameAlias(Vector<String> vUsernameAlias, Session s) {
		if(vUsernameAlias != null){
			int ilen = vUsernameAlias.size();
			this.usernameAlias = "";
			for (int i = 1; i  <ilen; i++){ // not the first element
				this.usernameAlias = this.usernameAlias + CommonFunctions.getNameAbbrivate(s, vUsernameAlias.get(i)) + ",";
			}
			ilen = this.usernameAlias.length() -1;
			if(ilen >0){
				this.usernameAlias = this.usernameAlias.substring(0, ilen);
			}
			this.usernameAlias = this.usernameAlias.replaceAll("'", "''");
		}
	}
	public String getShortNameAlias() {
		return "'" + shortNameAlias + "'";
	}
	public void setShortNameAlias(Vector<String> vshortNameAlias) {
		if (vshortNameAlias != null){
			int ilen = vshortNameAlias.size()- 1; // not the last element
			this.shortNameAlias = "";
			for (int i = 0; i < ilen; i++){
				this.shortNameAlias = this.shortNameAlias + vshortNameAlias.get(i) + ",";
			}
			ilen = this.shortNameAlias.length() - 1 ;
			if (ilen >0){
				this.shortNameAlias = this.shortNameAlias.substring(0,ilen);		
			}
			this.shortNameAlias = this.shortNameAlias.replaceAll("'", "''");
		}
		
	}
	public String getInternetAdress() {
		return "'" + internetAdress + "'";
	}
	public void setInternetAdress(String internetAdress) {
		if( internetAdress != null){
			this.internetAdress = internetAdress.replaceAll("'", "''");
		}else{
			this.internetAdress = "N/A";
		}
		
	}
	public String getMailSystem() {
		return "'" + mailSystem +  "'";
	}
	public String getLnAdapterCustom() {
		String rtnStr = "''" ;
		if(lnAdapterCustom != null) {
			rtnStr = "'" + lnAdapterCustom + "'";
		}
		return rtnStr ;
	}
	public void setLnAdapterCustom(String lnAdapterCustom) {
		this.lnAdapterCustom = lnAdapterCustom;
	}

	

}
