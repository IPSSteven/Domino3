package com.ibm.mediator.mediatordatabeans;

public class ReconcileRawDataCP extends ReconcileRawData {

	
	public void setUsernameAlias(String ua) {
		// TODO Auto-generated method stub
		super.usernameAlias = ua.replaceAll("'", "''");
	}
	
	
	public void setShortNameAlias(String sa) {
		// TODO Auto-generated method stub
		super.shortNameAlias = sa.replaceAll("'", "''");
	}
	public void setQualifiedname(String sqa) {
		// TODO Auto-generated method stub
		super.qualifiedname = sqa.replaceAll("'", "''");;
	}


	@Override
	public void setStatus(String status) {
		// TODO Auto-generated method stub
		//super.setStatus(status);
		super.status = status.replaceAll("'", "''");
		
	}


	@Override
	public String getStatus() {
		// TODO Auto-generated method stub
		return  "'" +super.status +  "'";
	}
	
	
	
}
