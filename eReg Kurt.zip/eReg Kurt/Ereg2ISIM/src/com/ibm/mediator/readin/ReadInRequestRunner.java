package com.ibm.mediator.readin;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

//import lotus.domino.AgentBase;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.Session;
import lotus.domino.View;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObj;
import com.ibm.ereg.config.ConfigObjBase;
import com.ibm.ereg.config.ConfigObjCommon;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.ereg.logger.RequestLogger;
import com.ibm.mediator.config.ConfigObjMediatorDB;
import com.ibm.mediator.connector.TheEregConnectorNotes;
import com.ibm.mediator.constants.MediatorRequestStatusConstants;
import com.ibm.mediator.mediatordatabeans.BasicData;

public class ReadInRequestRunner {
	private Session session;
	private Database dbLog;
	private Database dbLogRequest;
	private InputOutputLogger logger;
	private RequestBasic ri;
	private TheEregConnectorNotes con;
	private String Formula2CalLogDB = null;
	// private Class cData;
	private String[] stRequests;

	public static void main(String[] argv) {
		/*
		 * String stClassName = "com.ibm.ereg.mediatordatabeans." + "AU" +
		 * "Data"; try { // only test the function main is never used in a notes
		 * Environment Class c = Class.forName(stClassName); Object objData =
		 * c.newInstance(); System.out.println(objData.getClass().getName()); }
		 * catch (ClassNotFoundException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); } catch (InstantiationException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } catch
		 * (IllegalAccessException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

	}

	private void getTheLogger() throws Exception {
		try {
			dbLog = CommonFunctions.getLogDB(session);
			logger = new InputOutputLogger(session, dbLog,
					"ITIM-Requst Read in", LogLevel.FINEST);

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			throw e1;
		}
	}

	@SuppressWarnings("unchecked")
	private void handleRequest(Class cData, ResultSet rs) throws Exception {
		String stQuery;
		int iRow;
		Class[] c1 = new Class[2];
		c1[0] = ResultSet.class;
		c1[1] = Session.class;
		BasicData bd = null;
		Document tmpDoc;
		Vector <String>vRes = null;
		try {
			// 1. make a instance of data bean and leave if the status not correct
			Constructor ct = cData.getDeclaredConstructor(c1); // get the constructor of the data bean
			//initialize the data bean .. it the same as bd = new AUData for example
			bd = (BasicData) ct.newInstance(rs, session); // while creation the fields are filled from result set
			
			// filter the request
			if (bd.getStatus() != null
					&& !bd.getStatus().equals(MediatorRequestStatusConstants.INITIAL)) {
				logger.logActionLevel(LogLevel.FINEST, bd.getRTyp() + " "
						+ bd.getEregMailDomain() + " " + bd.getEregShortName()
						+ " not started because Status != "
						+ MediatorRequestStatusConstants.INITIAL);
				return;
			}
			
			// find the log database
			tmpDoc = logger.getDbLog().createDocument();
			tmpDoc.replaceItemValue("MailDomain", bd.getEregMailDomain());
			if(Formula2CalLogDB != null && !Formula2CalLogDB.isEmpty()) {
				vRes = session.evaluate(Formula2CalLogDB,tmpDoc);
				String stServer = vRes.elementAt(0);
				String stFilePath = vRes.elementAt(1);
				if(dbLogRequest == null || 
						!stServer.equalsIgnoreCase(dbLogRequest.getServer()) ||
						!stFilePath.equalsIgnoreCase(dbLogRequest.getFilePath())) {
					dbLogRequest = CommonFunctions.getDatabase(session, stServer, stFilePath);
					logger.logActionLevel(LogLevel.INFO, " try to create a requst for domain " + bd.getEregMailDomain() + " in db server =" + stServer + " Filepath = "+ stFilePath);
				}
			}
			tmpDoc.recycle();

			// create the log document and write the unid of the document to the data bean
			RequestLogger rl = new RequestLogger(session, dbLogRequest, "ITIM-Typ:"
					+ bd.getRTyp()+"-Dom:" + bd.getEregMailDomain()+ "-Short:" + bd.getEregShortName() 
					+"-ItimID:" + bd.getItimRequestID(), bd);
			logger.logActionLevel(LogLevel.FINEST, "Try to start "
					+ bd.getRTyp() + " " + bd.getEregMailDomain() + " "
					+ bd.getEregShortName());
			
			// move all the data from DB2 to new request and set the request status ready to start
			if (rl.startRequest()) {
				// start successfull
				logger.logActionLevel(LogLevel.FINEST, "Started "
						+ bd.getRTyp() + " " + bd.getEregMailDomain() + " "
						+ bd.getEregShortName() + "sucessfull");
				logger.logActionLevel(LogLevel.FINEST,
				"Try to update the request database");
				// set the status and the unid of the log document
				bd.setLNUnId(rl.getDocLog().getUniversalID());
				bd.setStatus(MediatorRequestStatusConstants.INWORK);
			} else {
				// start goes wrong
				logger.logActionLevel(LogLevel.SEVERE, "Error :" + bd.getRTyp()
						+ " " + bd.getEregMailDomain() + " "
						+ bd.getEregShortName() + "was not successfull");
				logger.logActionLevel(LogLevel.SEVERE, "Error reason: "
						+ rl.getErrorMsg());
				bd.setStatus(MediatorRequestStatusConstants.ERROR);
				bd.setReturnCode("999");
				bd.setReturnCodeDescription(rl.getErrorMsg());
			}

			// build the query to update the SQL database -> in work
			logger.logActionLevel(LogLevel.FINEST,
			"Try to build the update statement");
			stQuery = ri.buildUpdate(bd);
			logger.logActionLevel(LogLevel.FINEST, "Update statement: "
					+ stQuery);
			iRow = con.executeUpdate(stQuery);
			if (iRow < 0) {
				logger.logActionLevel(LogLevel.SEVERE,
				"Error:Update of mediator database does not work. Request will be deleted");
				if (rl.deleteRequest()){
					logger.logActionLevel(LogLevel.SEVERE,"Request deleted successful");
				}{
					logger.logActionLevel(LogLevel.SEVERE,"Request can not be deleted");
				}

			} else {
				logger.logActionLevel(LogLevel.FINEST, "Update sucessful: "
						+ iRow + " records updated");
			}

		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			logger.logActionLevel(LogLevel.SEVERE,
					"Argument exception while handle request: " + e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			logger.logActionLevel(LogLevel.SEVERE,
					"Security exception while handle request: " + e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (InstantiationException e) {
			logger.logActionLevel(LogLevel.SEVERE,
					"InstantiationException exception while handle request: " + e.getMessage());
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			logger.logActionLevel(LogLevel.SEVERE,
					"IIllegalAccessException exception while handle request: " + e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			logger.logActionLevel(LogLevel.SEVERE,
					"Invocation Target exception while handle request: " + e.getMessage());
			e.printStackTrace();
			throw e;
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			logger.logActionLevel(LogLevel.SEVERE,
					"No such method exception while handle request Class: "
					+ bd.getClass().getName() + " " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			logger.logActionLevel(LogLevel.SEVERE,
					"Exception exception while handle request: " + e.getMessage());
			throw e;
		}
		
		
	}

	private void getRequests() {
		try {
			ConfigObjMediatorDB confMDb;
			String stSubject;
			// get the configuration object (settings in EREG Tool)
			// each request type  has one config document, where the sql/table,
			// ip-address etc is stored
			ConfigObjBase obj = new ConfigObj(session);
			View vwConf = obj.getVwConfig();
			ArrayList<String> arl = new ArrayList<String>();
			vwConf.refresh();
			DocumentCollection dcc_requests = vwConf
			.getAllDocumentsByKey(AllConstants.MEDIATOREQUESTDB);

			// we got the config doc .. so loop through all request types
			// and put all the subjects to a array list
			Document doc_req = dcc_requests.getFirstDocument();
			while (doc_req != null) {
				stSubject = doc_req.getItemValueString("Subject");
				confMDb = new ConfigObjMediatorDB(session, "45>" + stSubject,
						logger);
				if (confMDb.getIsActive()[0].equals("1")) {
					arl.add(confMDb.getRequestType());
				}
				doc_req = dcc_requests.getNextDocument(doc_req);
			}

			// fill the request of this class
			int ilen = arl.size();
			stRequests = new String[ilen];
			for (int i = 0; i < ilen; i++) {
				stRequests[i] = arl.get(i);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}



	public ReadInRequestRunner(Session sess){
		super();
		this.session = sess;
		
		// TODO Auto-generated method stub
		String stClassName;
		String stQuery;
	
		// get Log document for read in
		try {
			getTheLogger();
		} catch (Exception e1) {
			e1.printStackTrace();
			return;
		}
		LogDocStatus lds = new LogDocStatus(logger.getDocLog());
		lds.setOKRunning();
		
		// get the formula for the selection of the log database
		try {
			ConfigObjCommon cfgREADIN = new ConfigObjCommon(session, "18>READIN");
			
			Formula2CalLogDB = cfgREADIN.getConfigurationDoc().getItemValueString("V3");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			logger.logActionLevel(LogLevel.SEVERE, "Config document READIN not found");
			lds.setReturnCode("92");
			logger.closeLog(lds);
			return ;
		}

		// get the requests
		this.getRequests();

		for (String str : this.stRequests) {
			ResultSet rs;
			Class<BasicData> cData;
			rs = null;
			cData = null;
			ConfigObjMediatorDB conf = null;
			stClassName = "com.ibm.mediator.mediatordatabeans." + str + "Data";
			try {

				// get the configuration from EREG Tool
				conf = new ConfigObjMediatorDB(session,
						AllConstants.MEDIATOREQUESTDB + str, logger);
				byte bLogLevel = Byte.parseByte(conf.getLogLevel()[0]);// get the log level
				logger.setCheckLogLevel(bLogLevel);

				// get the connection to the mediator SQL database
				try{
					logger.logActionLevel(LogLevel.INFO, "Try to connect for " + str + " requests");
					
					con = new TheEregConnectorNotes(logger, conf);
				}
				catch(Exception e){
					if (e instanceof NotesException) {
						throw e;
					}else{
						logger.logActionLevel(LogLevel.WARNING, e.getMessage());
						logger.logActionLevel(LogLevel.WARNING, "Connection to Mediator database failed. Try to connect to Backup database");
						conf = new ConfigObjMediatorDB(session,
								AllConstants.MEDIATOREQUESTDBBCK + str, logger);
						con = new TheEregConnectorNotes(logger, conf);
					}
				}
				
				cData = (Class<BasicData>) Class.forName(stClassName); // init the class for the databeans e.g AUData
				BasicData bd = (BasicData) cData.newInstance();
				bd.setRTyp(str);

				// build the query .. and execute
				ri = new RequestBasic();
				//the select statement is build with the name of the methods of the beans. so the ordering of the bean is important
				stQuery = ri.buildSelect(bd); 
				logger.logActionLevel(LogLevel.FINE, "Try to execute: "
						+ stQuery);
				rs = con.excuteQuery(stQuery);
				if (rs == null){
					logger.logActionLevel(LogLevel.SEVERE, "Error while excuting Query: " + stQuery);
					logger.logActionLevel(LogLevel.SEVERE, "DB2 Error description " + con.getSqlWarning());
					continue;
				}else{
					logger.logActionLevel(LogLevel.FINE, "Query executed "
							+ rs.getFetchSize() + " rows found.");			
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				logger.logActionLevel(LogLevel.SEVERE,"Error while excute Query for read-in" );
				logger.logActionLevel(LogLevel.SEVERE, e.getMessage());
				lds.setErrorCode("Error while excute Query for read in");
				lds.setRunStatus(LogDocStatus.RunStatusStopped);
				lds.setStatus(LogDocStatus.StatusPending);
				logger.closeLog(lds);
				e.printStackTrace();
				//throw e;

			}

			// Read the result set of the query and create the log document for EREG
			try {
				while (rs != null && rs.next()) {
					handleRequest(cData, rs);
				}
			} catch (SQLException e) {
				logger.logActionLevel(LogLevel.SEVERE, "SqlExcepction: " + e.toString());
				lds.setErrorCode("SQL Exception ");
				lds.setRunStatus(LogDocStatus.RunStatusStopped);
				lds.setStatus(LogDocStatus.StatusPending);
				//e.printStackTrace();
			} catch (Exception e) {
				logger.logActionLevel(LogLevel.SEVERE, "Excepction: " + e.toString());
				lds.setErrorCode("Exception ");
				lds.setRunStatus(LogDocStatus.RunStatusStopped);
				lds.setStatus(LogDocStatus.StatusPending);
				//e.printStackTrace();
			}
			logger.logActionLevel(LogLevel.INFO, "Read in finished for " + stClassName);
			con.close(false);

		}
		lds.setOKDone();
		logger.closeLog(lds);

		try {
			session.recycle();
		} catch (NotesException e) {
			logger.logActionLevel(LogLevel.SEVERE, "NotesExcepction: " + e.toString());
			e.printStackTrace();
		}
	}

	
}
/**
 * @param args
 */

