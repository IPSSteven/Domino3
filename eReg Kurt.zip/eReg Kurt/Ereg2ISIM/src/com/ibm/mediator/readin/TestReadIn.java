package com.ibm.mediator.readin;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class TestReadIn extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 TestReadIn tri = new TestReadIn();
		 tri.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("Jac2mac.");
		ReadInRequestRunner rrn = new ReadInRequestRunner(s);
	}

}
