package com.ibm.AnalyseRegistry;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;

public class RunCheck {
	private HashSet<String> PathFromTree = new HashSet<String>();
	private HashSet<String> IDFromTree = new HashSet<String>();
	private HashSet<String> PathFromFile = new HashSet<String>();
	private HashSet<String> IDFromTask = new HashSet<String>();

	//private static final String PATH_START = "C:\\Temp\\Tasks\\Tasks";
	//private final String FILE_TREE = "C:\\Temp\\Tasks\\tree.reg";
	//private final String FILE_TASK = "C:\\Temp\\Tasks\\task.reg";
	private static final String PATH_START = "C:\\Temp\\tasksValid\\Tasks";
	private final String FILE_TREE = "C:\\Temp\\tasksValid\\tree.reg";
	private final String FILE_TASK = "C:\\Temp\\tasksValid\\task.reg";
	private final String TREE_PRE_PATH = "[HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Tree";
	//private final String TREE_PRE_PATH = "[HKEY_LOCAL_MACHINE";
	private final String TASK_PRE_PATH = "[HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache\\Tasks\\{";


	private final String TREE_PRE_ID = "\"Id\"=\"";
	private int idx = PATH_START.length() + 1;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String stCheck;
		Iterator<String> it ;
		RunCheck rc = new RunCheck();
		rc.fillPathFromFileSystem(PATH_START);
		rc.fillPathfromTree();
		rc.fillFromTaskID();
		
		//it = rc.PathFromFile.iterator();
		

		

		pln("## Tree versus File#################################################################################################################");	
		it = rc.PathFromTree.iterator();
		while (it.hasNext()) {
			//	pln(it.next());
			stCheck = it.next();
			if (!rc.PathFromFile.contains(stCheck)) {
				pln( stCheck +"#### is in Tree but NOt in  file");
			}
		}
		pln("## End Tree versus File#################################################################################################################");	

		pln("## File versus Tree#################################################################################################################");	

		it = rc.PathFromFile.iterator();
		while (it.hasNext()) {
			stCheck = it.next();
			if (!rc.PathFromTree.contains(stCheck)) {
				pln( stCheck +"#### is in file but NOt in  tree");
			}
		}
		pln("## End File versus Tree#################################################################################################################");	

		pln("## ID Tree versus Task#################################################################################################################");	
		it = rc.IDFromTree.iterator();
		while (it.hasNext()) {
			stCheck = it.next();
			if(!rc.IDFromTask.contains(stCheck)) {
				pln( "ID:" +stCheck +"#### is in tree but NOt in  tasks");
			}
		}
		pln("##  End ID Tree versus Task#################################################################################################################");	
		
		pln("## ID Task versus Tre#################################################################################################################");	
		it = rc.IDFromTask.iterator();
		while (it.hasNext()) {
			stCheck = it.next();
			if(!rc.IDFromTree.contains(stCheck)) {
				pln( "ID:" +stCheck +"#### is in task but NOt in  tree");
			}
		}
		
	}

	private void fillPathFromFileSystem(String StartFile) {

		String RelativePath;
		File  f = new File(StartFile);
		File [] fs = f.listFiles();

		for (File file : fs) {


			if (file.isDirectory()) {
				fillPathFromFileSystem(file.getAbsolutePath());
				RelativePath = file.getAbsolutePath();
				RelativePath = RelativePath.substring(idx);
				if (! PathFromFile.add(RelativePath)) {
					pln("#######" +RelativePath + " is duplicate");
				}

			}else {
				RelativePath = file.getAbsolutePath();
				RelativePath = RelativePath.substring(idx);
				if (! PathFromFile.add(RelativePath)) {
					pln("#######" +RelativePath + " is duplicate");
				}
			}
		}
	}

	private void fillPathfromTree() {
		String line;
		String value;

		int idxTree = TREE_PRE_PATH.length() +1;
		int idxID = TREE_PRE_ID.length() + 1;
		int ilen;
		try {
			BufferedReader br = new BufferedReader(new FileReader(FILE_TREE));
			while((line=br.readLine()) != null) {

				value = getPureString(line);

				if (value.startsWith(TREE_PRE_PATH)) {
					ilen = value.length() -1;
					if(ilen > idxTree) {
						value = value.substring(idxTree, ilen);

						if(!PathFromTree.add(value)) {
							pln("PATH in tree ##### "+ value + " duplicated #####");
						}
					}
				}
				if (value.startsWith(TREE_PRE_ID)){
					ilen = value.length() -2;
					if(ilen >idxID) {
						value = value.substring(idxID, ilen);
						

						if(!IDFromTree.add(value)) {
							pln("ID in Tree ##### "+ value + " duplicated #####");
						}
					}
				}
			}
			br.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void fillFromTaskID() {
		try {
			String line;
			String value;
			int ilen = 0;
			int idxID = TASK_PRE_PATH.length();

			BufferedReader br = new BufferedReader(new FileReader(FILE_TASK));

			while((line=br.readLine()) != null) {

				value = getPureString(line);
				if (value.startsWith(TASK_PRE_PATH)) {
					ilen = value.length() -2;
					if(ilen >idxID) {
						value = value.substring(idxID, ilen);
						

						if(!IDFromTask.add(value)) {
							pln("ID in TASK ##### "+ value + " duplicated #####");
						}
					}
				}


			}	

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static void pln(String s) {
		System.out.println(s);
	}

	private String getPureString(String s) {
		if (s == null)return null;
		int ilen = s.length();
		int iChar;
		char c;
		StringBuffer sbResult = new StringBuffer();
		for(int i = 0; i< ilen; i++){
			c = s.charAt(i);
			iChar = c;
			if (iChar >31 && iChar < 127) {
				sbResult.append(c);
			}
		}
		return sbResult.toString();
	}

}
