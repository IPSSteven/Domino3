package com.ibm.AnaylserCleanup;

import java.util.ArrayList;
import java.util.Iterator;

import com.ibm.Divestitures.GetOwnedIds;

public class AnalyseData {
	private final String HEADING = "Fullname, Status,Classification,SerialPscOwner,Shortname,SerialPSCNab,EMail,"
			+ "AccessManager,AccessDesigner,AccessEditor,AccessAuthor,AccessDepositor, AccessNo";
	protected final String SEP = ",";
	protected final String TXTSEP = "\"";
	
	private String FullName;
	private String Status;
	private String Classification;
	private String SerialPscOwner;
	private String Shortname;
	private String SerialPscNab;
	private String EMail;
	private String DUdate;
	private boolean access2MailFile;
	protected String [] sVal;
	
	private String isMailFileAccessable;
	private ArrayList<String> AccessManager = new ArrayList<String>();
	private ArrayList<String> AccessDesigner = new ArrayList<String>();
	private ArrayList<String> AccessEditor = new ArrayList<String>();
	private ArrayList<String> AccessAuthor = new ArrayList<String>();
	private ArrayList<String> AccessReader = new ArrayList<String>();
	private ArrayList<String> AccessDepositor = new ArrayList<String>();
	private ArrayList<String> AccessNo = new ArrayList<String>();
	
	
	protected String strArray2lines(ArrayList<String> inp){
		if(inp == null) return "";
		StringBuilder sb = new StringBuilder();
		for(String s: inp){
			sb.append(s);
			sb.append("\n");
		}
		return sb.toString();
	}
	
	public String getLine(){
		return getFullName() + SEP+ getStatus() +  SEP + getSerialPscOwner() + SEP +
				getShortname() + SEP + getSerialPscNab() + SEP+ getEMail()+ SEP +strArray2lines(getAccessManager()) + SEP
				+strArray2lines(getAccessDesigner()) + SEP + strArray2lines(getAccessEditor()) + SEP + 
				strArray2lines(getAccessAuthor()) + SEP + strArray2lines(getAccessDepositor())+ SEP + strArray2lines(getAccessNo());
	}
	
	public void fillData(String inp){
		sVal = inp.split(SEP); 
		if (sVal.length >0) setFullName(sVal[0]);
		if (sVal.length >1) setStatus(sVal[1]);
		if (sVal.length >2) setClassification(sVal[2]);
		if (sVal.length >3) setSerialPscOwner(sVal[3]);
		if (sVal.length >4) setShortname(sVal[4]);
		if (sVal.length >5) setSerialPscNab(sVal[5]);
		if (sVal.length >6) setEMail(sVal[6]);
	}
	public String getFullName() {
		return FullName;
	}
	public void setFullName(String fullName) {
		FullName = fullName;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getClassification() {
		return Classification;
	}
	public void setClassification(String classification) {
		Classification = classification;
	}
	public String getSerialPscOwner() {
		return SerialPscOwner;
	}
	public void setSerialPscOwner(String serialPscOwner) {
		SerialPscOwner = serialPscOwner;
	}
	public String getShortname() {
		return Shortname;
	}
	public void setShortname(String shortname) {
		Shortname = shortname;
	}
	public String getSerialPscNab() {
		return SerialPscNab;
	}
	public void setSerialPscNab(String serialPscNab) {
		SerialPscNab = serialPscNab;
	}
	public String getEMail() {
		return EMail;
	}
	public void setEMail(String eMail) {
		EMail = eMail;
	}
	public String getHEADING() {
		return HEADING;
	}
	public String getIsMailFileAccessable() {
		return isMailFileAccessable;
	}
	public void setIsMailFileAccessable(String isMailFileAccessable) {
		this.isMailFileAccessable = isMailFileAccessable;
	}
	public ArrayList<String> getAccessManager() {
		return AccessManager;
	}
	public void setAccessManager(String accessManager) {
		this.AccessManager.add(accessManager);
	}
	public ArrayList<String> getAccessDesigner() {
		return AccessDesigner;
	}
	public void setAccessDesigner(String accessDesigner) {
		this.AccessDesigner.add(accessDesigner);
	}
	public ArrayList<String> getAccessEditor() {
		return AccessEditor;
	}
	public void setAccessEditor(String accessEditor) {
		AccessEditor.add(accessEditor);
	}
	public ArrayList<String> getAccessAuthor() {
		return AccessAuthor;
	}
	public void setAccessAuthor(String accessAuthor) {
		AccessAuthor.add(accessAuthor);
	}
	public void setAccessReader(String accessReader) {
		AccessReader.add(accessReader);
	}
	public ArrayList<String> getAccessReader() {
		return AccessReader;
	}
	
	public ArrayList<String> getAccessDepositor() {
		return AccessDepositor;
	}
	
	public void setAccessDepositor(String accessDepositor) {
		AccessDepositor.add(accessDepositor);
	}
	public ArrayList<String> getAccessNo() {
		return AccessNo;
	}
	public void setAccessNo(String accessNo) {
		AccessNo.add(accessNo);
	}

	public String getDUdate() {
		return DUdate;
	}

	public void setDUdate(String dUdate) {
		DUdate = dUdate;
	}

	public boolean isAccess2MailFile() {
		return access2MailFile;
	}

	public void setAccess2MailFile(boolean access2MailFile) {
		this.access2MailFile = access2MailFile;
	}
	
	public String getoutline(){
		StringBuilder sb = new StringBuilder();
		sb.append(TXTSEP);
		sb.append(getFullName());
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getStatus());
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getClassification());
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getSerialPscOwner());
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getShortname());
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getSerialPscNab());
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getEMail());
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getDUdate());
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getArrayList(getAccessManager()));
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getArrayList(getAccessDesigner()));
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getArrayList(getAccessEditor()));
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getArrayList(getAccessAuthor()));
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getArrayList(getAccessReader()));
		sb.append(TXTSEP);
		sb.append(SEP);
		sb.append(TXTSEP);
		sb.append(getArrayList(getAccessNo()));
		sb.append(TXTSEP);
		sb.append("\n");
		return sb.toString();
		
	}
	
	private String getArrayList(ArrayList<String> alin){
		Iterator<String> it = alin.iterator();
		StringBuilder sb = new StringBuilder();
		while(it.hasNext()){
			sb.append(it.next());
			sb.append("\n");
		}
		return sb.toString();		
	}
	
}