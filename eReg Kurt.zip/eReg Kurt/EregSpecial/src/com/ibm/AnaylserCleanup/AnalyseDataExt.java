package com.ibm.AnaylserCleanup;

public class AnalyseDataExt extends AnalyseData {
	private String FreezeDate ;

	
	
	@Override
	public void fillData(String inp) {
		// TODO Auto-generated method stub
		super.fillData(inp);
		if (sVal.length >7) setFreezeDate(sVal[7]);
	}
	

	@Override
	public String getLine() {
		// TODO Auto-generated method stub
		return getFullName() + SEP+ getStatus() + SEP + getSerialPscOwner() + SEP +
		getShortname() + SEP + getSerialPscNab() + SEP+ getEMail()+ SEP + strArray2lines(getAccessManager()) + SEP
		+strArray2lines(getAccessDesigner()) + SEP + strArray2lines(getAccessEditor()) + SEP + 
		strArray2lines(getAccessAuthor()) + SEP + strArray2lines(getAccessDepositor())+ SEP + strArray2lines(getAccessNo());
	}


	public String getFreezeDate() {
		return FreezeDate;
	}

	public void setFreezeDate(String freezeDate) {
		FreezeDate = freezeDate;
	}
	
}
