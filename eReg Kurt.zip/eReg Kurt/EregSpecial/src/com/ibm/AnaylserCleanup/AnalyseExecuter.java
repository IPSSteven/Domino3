package com.ibm.AnaylserCleanup;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;
import lotus.domino.ACL;
import lotus.domino.ACLEntry;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class AnalyseExecuter extends NotesThread {
	private ArrayList<AnalyseData> aryInp = new ArrayList<AnalyseData>();
	/*private static final String [] FILES = {"Accounts_FREEZE2_F", "Accounts_FREEZE2_ISIM_deleted",
			"Accounts_FREEZE2_personal delete.txt", "Accounts_FREEZE2_personal_check.txt"};*/
	
	
	
	private static final String [] FILES = {"Accounts_FREEZE2_personal_check-v2investigate", "Accounts_FREEZE2_personal_delete-v2investigate",};
	private static final String sPath = "Z:\\test\\Analyse\\";
	
	private  String FileName;

	private Database dbExtDir  = null;;
	private Database dbUAR = null;
	private Database dbUAR2 =  null;

	private View vwExtDir = null;
	private View vwUAR = null;
	private View vwUAR2  = null;


	private AnalyseData ad = null;
	private  Session s = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (String sf:FILES){
		AnalyseExecuter ae = new AnalyseExecuter();
		ae.FileName = sf;
		
		try {
			BufferedReader br = new BufferedReader(new FileReader( sPath + ae.FileName+ ".csv"));
			String line;
			br.readLine(); // first line
			while ((line = br.readLine())!= null){
				ae.ad = new AnalyseData();
				ae.ad.fillData(line);
				ae.aryInp.add(ae.ad);
			}
			br.close();
			ae.start();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		s = NotesFactory.createSessionWithFullAccess("getg00djac!");
		dbExtDir = s.getDatabase("D06HBM10", "dircat/edcww.nsf");
		dbUAR =  s.getDatabase("D06DBL051", "n_dir/ncouaruk.nsf");
		dbUAR2 = s.getDatabase("D06DBL051", "n_dir/ncouar2.nsf");
		String sFullName;

		vwExtDir = dbExtDir.getView("($Users)");
		vwUAR = dbUAR.getView("(ITIMExport)");
		vwUAR2 = dbUAR2.getView("(ITIMExport)");
		Database dbMail;
		Iterator it = aryInp.iterator();

		while(it.hasNext()){
			ad = (AnalyseData)it.next();
			sFullName = ad.getFullName();
			System.out.println(sFullName);
			dbMail = getMailDB(sFullName);
			if(dbMail == null){
				ad.setAccess2MailFile(false);
			}else{
				ad.setAccess2MailFile(true);
				analyseACL(s, dbMail, ad);
			}
			getNcouarHistory(ad);
		}
		
		write2File();



	}

	private Database getMailDB(String fullname){
		try {
			Document docNab = vwExtDir.getDocumentByKey(fullname);
			if(docNab == null) return null;
			String Mailserver = docNab.getItemValueString("MailServer");
			String Mailfile = docNab.getItemValueString("MailFile");
			return  s.getDatabase(Mailserver, Mailfile);
			
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}

	private void analyseACL(Session s, Database dbMail, AnalyseData ad){
		try {
			String sNam;
			Name nNam;
			ACL acl = dbMail.getACL();
			ACLEntry acle = acl.getFirstEntry();
			while(acle != null){
				sNam = acle.getName();
				switch(acle.getLevel()) {
				case ACL.LEVEL_NOACCESS:
					ad.setAccessNo(sNam);
					break;
				case ACL.LEVEL_DEPOSITOR:
					ad.setAccessDepositor(sNam);
					break;
				case ACL.LEVEL_READER:
					ad.setAccessReader(sNam);
					break;
				case ACL.LEVEL_AUTHOR:
					ad.setAccessAuthor(sNam);
					break;
				case ACL.LEVEL_EDITOR:
					ad.setAccessEditor(sNam);
					break;
				case ACL.LEVEL_DESIGNER:
					ad.setAccessDesigner(sNam);
					break;
				case ACL.LEVEL_MANAGER:
					ad.setAccessManager(sNam);
					break; }

				acle = acl.getNextEntry(acle);
			}
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void getNcouarHistory(AnalyseData ad){
		String fullName = ad.getFullName();
		String eMail = ad.getEMail();
		Document docNCOUR = null;
		Vector vhistory = null;
		String stVal = null;
		Iterator<String> it = null;
		int idx = 0;
		
		if (eMail.endsWith("@ibm.com")){
			try {
				docNCOUR = vwUAR2.getDocumentByKey(fullName, true);
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			try {
				docNCOUR = vwUAR.getDocumentByKey(fullName, true);
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(docNCOUR != null){
			try {
				vhistory = docNCOUR.getItemValue("History");
				it = vhistory.iterator();
				while (it.hasNext()){
					stVal = it.next();
					if (stVal.indexOf("DU-Dom") >0 || stVal.indexOf("Freeze") >0 ){
						ad.setDUdate(stVal.substring(0,10));
					}
				}
				docNCOUR.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	private void write2File(){
		String lineout;
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(sPath + FileName + "_Out.csv"));
			bw.write("FullName,Status,Classification, SerialOwner,Shortname,SerialNab,e-mail,DU date,AccManager,AccDesigner,AccEditor,AccessAutor,AccReader,AccNo \n");
			Iterator it = aryInp.iterator();

			while(it.hasNext()){
				ad = (AnalyseData)it.next();
				lineout = ad.getoutline();
				bw.write(lineout);
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


}
