package com.ibm.AnaylserCleanup;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

public class CheckIdFileNCOUAR extends NotesThread {
	private final String inFile = "c:\\temp\\EMEA-Users-In.csv";
	private final String OutFile = "c:\\temp\\EMEA-Users-Out.csv";
	private Database Nco;
	private Database Nco2;
	private View ItemEx;
	private View ItemEx2;
	private ViewEntryCollection veC;
	private ViewEntry veCe;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CheckIdFileNCOUAR c = new CheckIdFileNCOUAR();
		c.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		
		long lstart = System.currentTimeMillis();
		Session s = NotesFactory.createSessionWithFullAccess("other1bites2dust.");
		Nco = s.getDatabase("D06DBL090", "n_dir/ncouaruk.nsf");
		Nco2 = s.getDatabase("D06DBL090", "n_dir/ncouar2.nsf");
		ItemEx = Nco.getView("(ITIMExport)");
		ItemEx2 = Nco2.getView("(ITIMExport)");
		String iLine;
		String stKey;
		String oLine;
		String [] dummy;
		int iL = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader(inFile));
			BufferedWriter bw = new BufferedWriter(new FileWriter(OutFile));
			while((iLine = br.readLine())!= null) {
				if(iL == 0) {
					oLine = iLine + "id File available";
				}else {
					dummy = iLine.split(";");
					if(dummy.length < 4) {
						System.out.println(iLine);
						oLine = iLine;
					}else {
						stKey = dummy[3];
						stKey= stKey.split("@")[0];
						oLine = iLine + ";" + getIdInfo(stKey);
					}
						
		
				}
			
				bw.write(oLine);
				bw.newLine();
				iL++;
				if(iL % 100 == 0) {
					System.out.println("still alive at row " + iL + " after " + (System.currentTimeMillis() - lstart) + " millis");
					bw.flush();
				}
			}
			br.close();
			bw.flush();
			bw.close();
			
		} catch (FileNotFoundException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	private String getIdInfo(String key) {
		String val = null;
		Vector vRow;
		Double dval;
		try {
			veC =ItemEx.getAllEntriesByKey(key, true);
			
			if(veC.getCount() == 0) {
				veC.recycle();
				veC= ItemEx2.getAllEntriesByKey(key, true);
			}
			
			if(veC.getCount() == 0) {
				val = "N/A";
			}else {
				if(veC.getCount() > 1) {
					val = "more then 1 entry for " + key;
				}else {
					veCe = veC.getFirstEntry();
					vRow = veCe.getColumnValues();
					val = vRow.elementAt(10).toString();
					veCe.recycle();
				}
			}
			veC.recycle();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return val;
	}

}
