package com.ibm.Divestitures;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class CheckBPEntry {
	private final String BpUrl1 = "http://bluepages.ibm.com/BpHttpApisv3/slaphapi?ibmperson/(uid=";
	private final String BpUrl2 = ").list/bytext";
	private final String stFileIn = "Z:\\Kunden\\IRU_EDERRA\\newSerial.txt";
	private final String stFileOut = "Z:\\Kunden\\IRU_EDERRA\\BPEntries.txt";
	private BufferedReader brBPresult = null;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CheckBPEntry bc = new CheckBPEntry();
		bc.process();

	}
	
	
	private void process(){
		String stLineIn = null;
		String stBPEntries = null;
		try {
			BufferedReader brIn = new BufferedReader(new FileReader(stFileIn));
			BufferedWriter bwOut = new BufferedWriter(new FileWriter(stFileOut));
			bwOut.write("serial,BPentry\n");
			while((stLineIn= brIn.readLine()) != null){
				 stBPEntries = getBPEntry(stLineIn);
				System.out.println(stLineIn + " count BPentry " +   stBPEntries);
				bwOut.write(stLineIn + "," + stBPEntries + "\n");
			}
			 brIn.close();
			 bwOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String getBPEntry (String uid){
		String stUrl  = BpUrl1 + uid +BpUrl2;
		String stLine = null;
		String stCount = null;
		int idx = 0;
		
		try {
			URL url = new URL(stUrl);
			URLConnection con = url.openConnection();
			brBPresult = new BufferedReader(new InputStreamReader(con.getInputStream()));
			while((stLine = brBPresult.readLine()) != null){
				idx = stLine.indexOf("count=");
				if (idx >0){
					stCount = stLine.substring(idx+6, idx+7);
				
				}
			}
			brBPresult.close();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stCount;
		
	}

}
