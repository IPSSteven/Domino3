package com.ibm.Divestitures;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class GetOwnedIds extends NotesThread {
	private Session session;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GetOwnedIds gow = new GetOwnedIds();
		gow.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		BufferedReader bfIn = null;
		BufferedWriter bfout = null;
		String []dummy;
		// get the input file (serial,psc) and the outputfile
		try {
			bfIn = new BufferedReader(new FileReader("c:/temp/in1.txt"));
			bfout = new BufferedWriter(new FileWriter("c:/temp/out1.txt"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// get the Ncouar database
		session = NotesFactory.createSessionWithFullAccess("jacgetg00d!");
		Database dbNC = session.getDatabase("D06DBL048", "n_dir/ncouaruk.nsf");
		Database dbNC2 = session.getDatabase("D06DBL048", "n_dir/ncouar2.nsf");
		View vw = dbNC.getView("Person\\by Owner");
		View vw2 = dbNC2.getView("Person\\by Owner");
		View vwP = dbNC.getView("Person\\by EmpNo");
		View vwP2 = dbNC2.getView("Person\\by EmpNo");
		String line;
		String key;
		String ownedIds;
		String empno;
		DocumentCollection dcc ;
		Document doc;
		Document docP;
		Document docRecycle;
		String mgr ;
		try {
			while((line = bfIn.readLine()) != null){
				dummy = line.split(";");
				key = dummy[0];

				dcc = vw.getAllDocumentsByKey(key); // search in NCOAUR

				if (dcc == null || dcc.getCount() == 0){
					dcc = vw2.getAllDocumentsByKey(key); // search NCOUAR2
					if (dcc == null || dcc.getCount() == 0){
						bfout.write(line + ";" + " nothing found \r\n");
					}else{
						docP = vwP2.getDocumentByKey(key);
						if (docP == null) {
							mgr = "No Found";
						}else{
							mgr= docP.getItemValueString("LotusName");
							docP.recycle();
						}

						doc = dcc.getFirstDocument();
						ownedIds = "";
						if (doc == null){
							bfout.write(line + ";" + " nothing found \r\n");
						}else{
							while (doc != null){
								empno = doc.getItemValueString("EmpNo");
								if(!empno.equals(key.substring(0,empno.length()))){
									//ownedIds = ownedIds + doc.getItemValueString("EmpNo")+ ";" + doc.getItemValueString("LNShortName")+";" +doc.getItemValueString("LotusName")+ ";";
									ownedIds = doc.getItemValueString("EmpNo")+";" + doc.getItemValueString("LNShortName")+";" +doc.getItemValueString("LotusName")+ ";";
									bfout.write(line +";"+ mgr + ";;"+ ownedIds + "\r\n" );
								}
								docRecycle = doc;
								doc = dcc.getNextDocument();
								docRecycle.recycle();
							}
						}
					}

				}else{
					docP = vwP.getDocumentByKey(key);
					if (docP == null) {
						mgr = "No Found";
					}else{
						mgr= docP.getItemValueString("LotusName");
						docP.recycle();

					}
					doc = dcc.getFirstDocument();
					ownedIds = "";
					if (doc == null){
						bfout.write(line + ";" + " nothing found \r\n");
					}else{
						while (doc != null){
							empno = doc.getItemValueString("EmpNo");
							if(!empno.equals(key.substring(0,empno.length()))){
								//ownedIds = ownedIds + doc.getItemValueString("EmpNo")+ ";" + doc.getItemValueString("LNShortName")+";" +doc.getItemValueString("LotusName")+ ";";
								ownedIds = doc.getItemValueString("EmpNo")+";" + doc.getItemValueString("LNShortName")+";" +doc.getItemValueString("LotusName")+ ";";
								bfout.write(line +";"+ mgr + ";;"+ ownedIds + "\r\n" );
							}
							docRecycle = doc;
							doc = dcc.getNextDocument();
							docRecycle.recycle();
						}
					}
					/*if(!ownedIds.equals("")){
						bfout.write(line +";"+ ownedIds + "\r\n" );
					}*/
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			bfout.flush();
			bfout.close();
			bfIn.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
