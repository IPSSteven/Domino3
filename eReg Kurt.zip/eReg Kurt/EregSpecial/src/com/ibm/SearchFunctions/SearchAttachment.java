package com.ibm.SearchFunctions;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.EmbeddedObject;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.RichTextItem;
import lotus.domino.Session;
import lotus.domino.View;



public class SearchAttachment extends NotesThread {
	private Session s;
	private final String TEMPDIR = "C:\\temp\\attachments\\";

	public static void main (String [] argv){
		SearchAttachment sa = new SearchAttachment();
		sa.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		s = NotesFactory.createSessionWithFullAccess("g00dleg4jac.");
		Database db = s.getDatabase("D06ML031", "mail02/DETA7577.nsf");
		String [] stSearch = {"CACVMSU2", "GBY9D61V","CVMSU2"};
		View vw = db.getView("($Inbox)");
		Document docRecyle;
		Document doc = vw.getFirstDocument();
		Vector<EmbeddedObject> vEmbObj;
		Iterator <EmbeddedObject> it;
		RichTextItem rti;
		EmbeddedObject embObj;
		Vector <String>vAttachment;
		String stFileName;
		/*
		while (doc != null){
			try{
			vAttachment = s.evaluate("@AttachmentNames", doc);
			stFileName = vAttachment.elementAt(0);
			embObj = doc.getAttachment(stFileName);

			embObj.extractFile(TEMPDIR + doc.getUniversalID() + ".txt");
			}catch(NotesException ne){
				System.out.println("mail from " + doc.getItemValueString("From") + " " + doc.getLastModified().toString());
			}catch(NullPointerException np){
				System.out.println("mail from " + doc.getItemValueString("From") + " " + doc.getLastModified().toString() + " no attachment");
			}

			/* if(doc.hasEmbedded()){
				rti = (RichTextItem)doc.getFirstItem("Body");
				if ( rti != null){
				vEmbObj =rti.getEmbeddedObjects();
				it = vEmbObj.iterator();
				while (it.hasNext()){
					embObj = it.next();
					if (embObj.getType() == EmbeddedObject.EMBED_ATTACHMENT){
						embObj.extractFile(TEMPDIR + doc.getUniversalID() + ".txt");
						embObj.recycle();
					}
				}
				}
			}
		docRecyle = doc;
		doc = vw.getNextDocument(doc);
		docRecyle.recycle();
	}
		 */
		File f = new File(TEMPDIR);
		String [] stFiles = f.list();
		FileReader fr;
		String stLine;

		for(String stF : stFiles){
			try {
				fr = new FileReader(TEMPDIR + stF);
				BufferedReader br = new BufferedReader(fr);
				while((stLine = br.readLine()) != null){
					for (String sSea: stSearch){
						if(stLine.contains(sSea)){
							System.out.println (sSea + " found in " + stF );
						}
					}
				}
				br.close();

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		


		}


	}





}


