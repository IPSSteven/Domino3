package com.ibm.certfier;

import java.io.File;
import java.util.HashSet;
import java.util.Iterator;

import javax.swing.plaf.basic.BasicScrollPaneUI.HSBChangeListener;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class CheckCertifier extends NotesThread {
	
	private HashSet<String> IBMids = new HashSet<String>();
	private HashSet<String> nonIBMids = new HashSet<String>();
	private HashSet<String> hsFiles = new HashSet<String>();


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CheckCertifier CheckC = new CheckCertifier();
		CheckC.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		String certName;
		String fileName;
		boolean bAdd;
		
		Session sess = NotesFactory.createSessionWithFullAccess("Used2know.");
		Database dTool = CommonFunctions.getDatabase(sess, "D06DBL090", "e_dir/eregtoo6.nsf");
		View vwCert = dTool.getView("Single Types\\type 6");
		Document docR = null;
		Document docC = vwCert.getFirstDocument();
		while(docC != null) {
			certName = docC.getItemValueString("Subject");
			fileName = docC.getItemValueString("V1");
			
			if(certName.contains("IBM")) {
				bAdd = IBMids.add(fileName);
			}else {
				bAdd = nonIBMids.add(fileName);
			}
			if (!bAdd) {
				pln(certName + " can not be added ");
			}
		
			docR = docC;
			docC = vwCert.getNextDocument(docC);
			docR.recycle();
		}
		
		File fdir = new File("S:/Registration");
		String aryFiles [] = fdir.list();
		for(String aFile : aryFiles)
		{
			hsFiles.add(aFile); 
		}
		
		Iterator<String> it = IBMids.iterator();
		while(it.hasNext()) {
			fileName = it.next();
			bAdd = hsFiles.contains(fileName);
			if(!bAdd) pln("**IBM File:" + fileName + " for  not found " );
		}
		it = nonIBMids.iterator();
		while(it.hasNext()) {
			fileName = it.next();
			bAdd = hsFiles.contains(fileName);
			if(!bAdd) pln("**nonIBM File:" + fileName + " not found " );
		}
		
	}
	
	private void pln(String s) {
		System.out.println(s);
	}

}
