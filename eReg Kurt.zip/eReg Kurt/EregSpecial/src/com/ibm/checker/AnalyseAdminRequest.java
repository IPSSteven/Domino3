package com.ibm.checker;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjAdminpAlert;
import com.ibm.ereg.config.ConfigObjMailDomainServer;
import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogDocStatus;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.EmbeddedObject;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.RichTextItem;
import lotus.domino.Session;


public class AnalyseAdminRequest extends NotesThread {
	private Session session;
	private Database dbLog;
	private DateTime dt = null;
	private InputOutputLogger log;
	private BufferedWriter bw;
	private ConfigObjMailDomainServer mailServer;
	private ConfigObjAdminpAlert cfgAdminp;
	private String sFileP;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnalyseAdminRequest al = new AnalyseAdminRequest();
		al.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session sess = NotesFactory.createSessionWithFullAccess("idjwmv89ja.");
		runit(sess);
	

	}
	
	private boolean setBorderDate(String sTime){
		String sNumber = null;
		int timeNumber;
		try {
			
			dt.setNow();
			int idx = sTime.toLowerCase().indexOf("day");
			if (idx >0 ){
				sNumber = sTime.substring(0,idx).trim();
				timeNumber = Integer.parseInt(sNumber);
				dt.adjustDay(0-timeNumber);
				return true;
			}
			idx = sTime.toLowerCase().indexOf("hour");
			if (idx >0 ){
				sNumber = sTime.substring(0,idx).trim();
				timeNumber = Integer.parseInt(sNumber);
				dt.adjustHour(0-timeNumber);
				return true;
			}
			idx = sTime.toLowerCase().indexOf("minutes");
			if (idx >0 ){
				sNumber = sTime.substring(0,idx).trim();
				timeNumber = Integer.parseInt(sNumber);
				dt.adjustMinute(0-timeNumber);
				return true;
			}
			return false;
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Error while calculating the date");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
			return false;
		}
		
	}
	
	private void writetoFile(Document doc){
		StringBuffer sb = new StringBuffer();
		String stService;
		String stServer;
		String stMailDomain;
		
		// the attributes Service, ShortName, FullName, StartTime are in the request AU, CP, KU, RN
		
		try {
			stService = doc.getItemValueString("Service");
			if(stService.trim().isEmpty())stService =  doc.getItemValueString("MailDomain");
			stServer = mailServer.getNabServers_domain().get(stService);
			if(stServer == null){
				stMailDomain = doc.getItemValueString("MailDomain");
				stServer = mailServer.getNabServers_domain().get(stMailDomain);
			}
			
			sb.append(doc.getItemValueString("Type"));
			sb.append(",");
			sb.append(stServer);
			sb.append(",");
			sb.append(stService);
			sb.append(",");
			sb.append(doc.getItemValueString("ShortName"));
			sb.append(",");
			sb.append(doc.getItemValueString("FullName"));
			sb.append(",");
			sb.append(doc.getItemValue("StartTime").firstElement().toString());
			
			bw.write(sb.toString());
			bw.newLine();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Notes Error while write to file");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "I/O while write to file");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
		}
	}
	
	private void writedHeader(){
		try {
			
			bw.write("Type,Server,Service,ShortName,FullName,First start");
			bw.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "I/O while write to header");
			log.logActionLevel(LogLevel.SEVERE, e.getMessage());
			e.printStackTrace();
		}
		
	}
	
	private void mailIt(int iReq){
		String stFormula = cfgAdminp.getRecipients()[0];
		Vector<String> vRes;
		try {
			Vector<String> vSendTo = session.evaluate(stFormula);
			stFormula = cfgAdminp.getRecipientsCC()[0];
			Vector<String> vSendToCC = session.evaluate(stFormula);
			//Document docMail = session.getCurrentDatabase().createDocument();
			Document docMail = dbLog.createDocument();
			docMail.replaceItemValue("Form", "Memo");
			docMail.replaceItemValue("CopyTo",vSendToCC);
			docMail.replaceItemValue("sendTo",vSendTo);
			
			
			docMail.replaceItemValue("Subject", "Overdue Adminp Proceeses");
			RichTextItem rtf = docMail.createRichTextItem("Body");
			rtf.appendText("The attached list contains adminp the name of ids, with adminp proccess should be finished" );
			rtf.addNewLine(2);
			rtf.embedObject(EmbeddedObject.EMBED_ATTACHMENT, null, sFileP, "Extract");
			docMail.save();
			docMail.send();
			rtf.recycle();
			docMail.remove(true);
			docMail.recycle();
			
			
			
		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "Notes while mailing");
			log.logActionLevel(LogLevel.SEVERE, e1.getMessage());
			e1.printStackTrace();
		}
	}
	
	public void runit(Session sess){
		this.session = sess;
		
		try {
			String stFormula = null;
			Vector <String>vRes =null;
			DocumentCollection dcc = null;
			Document doc = null;
			Document docRecycle = null;
			dt = session.createDateTime("Today");
			boolean bFound = false;
		
			dbLog = CommonFunctions.getLogDB(session);
			log = new InputOutputLogger(session, dbLog, "Analyse Adminp Process", LogLevel.FINEST);
			
			String sMachineKey = session.getEnvironmentString(AllConstants.MACHINEKEY);
			ConfigObjMaschineProfile mp = new ConfigObjMaschineProfile(session, "1>" + sMachineKey);
		
			
			mailServer = new ConfigObjMailDomainServer(session); 
			
			cfgAdminp	= new ConfigObjAdminpAlert(session, AllConstants.ADMINP_ALERT, log);
			String[] sTypes = cfgAdminp.getTypes();
			stFormula = cfgAdminp.getTimeLinits()[0];
			vRes =  session.evaluate(stFormula);
			String[] limits =vRes.toArray(new String[vRes.size()]);
			stFormula =cfgAdminp.getRecipients()[0];
			vRes =  session.evaluate(stFormula);
			String[] recipents = vRes.toArray(new String[vRes.size()]);
			int iNum = sTypes.length;
			if(iNum != limits.length || iNum != recipents.length){
				log.logActionLevel(LogLevel.SEVERE, "Error in configuration, Number of elements does not match. Number of elements in typ, limit, recipients needs to be same");
				return;
			}
			
			for (int i = 0; i < iNum; i++){
				 sFileP = mp.getTempDir()[0]+"\\"  + "adminpAlert_" +  sTypes[i]+ ".csv";
				 //sFileP = "c:\\temp\\" + "adminpAlert_" +  sTypes[i]+ ".csv";
				//bw = new BufferedWriter(new FileWriter(mp.getTempDir()+"\\" + "adminpAlert.csv"));
				bw = new BufferedWriter(new FileWriter(sFileP));
				writedHeader();
				setBorderDate(limits[i]);
				stFormula = "(Type = \""+ sTypes[i]+ "\") & (Status = \"AdminP\") & (Form = \"Log\") & (@created < [" + dt.getDateOnly() 
				+ " " + dt.getTimeOnly() + "])" ;
				bFound = false;
				
				dcc = dbLog.search(stFormula);
				doc = dcc.getFirstDocument();
				while (doc != null){
					bFound = true;
					writetoFile(doc);
					docRecycle = doc;
					doc = dcc.getNextDocument(doc);
					docRecycle.recycle();
				}
				bw.close();
				
				if (bFound) mailIt(i);
				
				File f = new File(sFileP);
				f.delete();
			}
			LogDocStatus lds = new LogDocStatus(log.getDocLog());
			lds.setOKDone();
			log.closeLog(lds);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
