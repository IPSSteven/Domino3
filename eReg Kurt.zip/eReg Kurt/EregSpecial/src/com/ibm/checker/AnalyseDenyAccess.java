package com.ibm.checker;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class AnalyseDenyAccess extends NotesThread {
	private final String domServerGlobal = "D51HUB01";
	private final String domServerOnPrem = "D06HBM01";
	private final String denyAccessView = "Server\\Deny Access Groups";
	
	private HashSet<String> hsgroupGlobal = new HashSet<String>();
	private HashSet<String> hsgroupOnPrem = new HashSet<String>();
	private HashSet<String> hsgroupMemberGlobal = new HashSet<String>();
	private HashSet<String> hsgroupMemberOnprem = new HashSet<String>();
	
	long lstart;
	public String pw;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnalyseDenyAccess ar = new AnalyseDenyAccess();
		ar.pw = args[0];
		ar.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess(pw);
		Database dbDenyAccess = s.getDatabase(domServerGlobal, "names.nsf");
		View vwD = dbDenyAccess.getView(denyAccessView);
		Document docRecycle = null;
		Document doc = vwD.getFirstDocument();
		
		lstart = System.currentTimeMillis();
		int iCount = 0;
		//global
		while (doc != null) {
			add2Hs(doc, true);
			docRecycle = doc;
			doc = vwD.getNextDocument(doc);
			docRecycle.recycle();
			iCount ++;
			checkcounter(iCount);
			
		}
		vwD.recycle();
		dbDenyAccess.recycle();
		
		dbDenyAccess = s.getDatabase(domServerOnPrem, "names.nsf");
		vwD = dbDenyAccess.getView(denyAccessView);
		doc = vwD.getFirstDocument();
		
		lstart = System.currentTimeMillis();
		iCount = 0;
		while (doc != null) {
			add2Hs(doc, false);
			docRecycle = doc;
			doc = vwD.getNextDocument(doc);
			docRecycle.recycle();
			iCount ++;
			checkcounter(iCount);
			
		}
		
		analyse("GroupsInGlobalNotInOnprem.txt", hsgroupGlobal, hsgroupOnPrem);
		analyse("GroupsInOnpremNotInGlobal.txt", hsgroupOnPrem,hsgroupGlobal);
		
		analyse("MemberInGlobalNotInOnprem.txt",  hsgroupMemberGlobal,  hsgroupMemberOnprem);
		analyse("MemberInOnpremNotInGlobal.txt",  hsgroupMemberOnprem, hsgroupMemberGlobal);
		
		
		
		
	}
	
	private void add2Hs(Document docInp,boolean bglobal) {
		try {
			
			HashSet<String> hsGroup = bglobal ?  hsgroupGlobal :hsgroupOnPrem;
			HashSet<String> hsMember =  bglobal ?  hsgroupMemberGlobal: hsgroupMemberOnprem;

			String stGroupName = docInp.getItemValueString("ListName");
			Vector<String> vGroups = docInp.getItemValue("Members");
			
			hsGroup.add(stGroupName);
			
			if (vGroups != null) {
				Iterator<String> it = vGroups.iterator();
				while (it.hasNext()) {
					hsMember.add(it.next());
				}
				
			}
			
			} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private void analyse(String fileName, HashSet<String> hsInp, HashSet<String> hsComp) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));
			Iterator<String> itInp = hsInp.iterator();
			String stValue;
			boolean bIsThere;
			while(itInp.hasNext()) {
				stValue = itInp.next();
				bIsThere = hsComp.contains(stValue);
				if(!bIsThere) {
					bw.write(stValue + "\n");
				}
				
			}
			bw.flush();
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	private void checkcounter(int iCount) {
		if(iCount%100 == 0) {
			pln("Still alive " + iCount + " group read " + (System.currentTimeMillis()-lstart)/1000 + " sec");
		}
	}
	
	private void pln(String s) {
		System.out.println(s);
	}

}
