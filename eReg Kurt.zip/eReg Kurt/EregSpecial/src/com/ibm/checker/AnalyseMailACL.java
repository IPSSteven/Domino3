package com.ibm.checker;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.Name;

public class AnalyseMailACL extends NotesThread {
	private TreeMap<String, String> tmOwner = new TreeMap<String, String>();
	private TreeMap<String, String> tmPersnum = new TreeMap<String, String>();
	private final String stFilepath = "c:/temp/UBC.csv"; 
	private Vector veACLEntry = null;
	private Iterator<String> it = null;

	private Session session = null; 

	private String [] stFilterEq = {"-Default-","BackupServers", "LocalDomainServer", "OtherDomainServers", "SaaSLocalDomainServers", "LocalDomainServers", "Anonymous"}; 
	private String [] stFilterBg = {"CN=D06M","NALL"}; 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnalyseMailACL amacl = new AnalyseMailACL();
		amacl.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();

		//loadowner();


		session = NotesFactory.createSessionWithFullAccess("g00dleg4jac.");
		Database dbChecker = session.getDatabase("", "Checker.nsf");
		View vwChecker = dbChecker.getView("OverView");
		Document doc = vwChecker.getFirstDocument();
		Document docRecyle = null;

		while (doc != null){

			getOwner(doc);
			docRecyle = doc;
			doc = vwChecker.getNextDocument(doc);
			docRecyle.recycle();
		}


		vwChecker.recycle();
		dbChecker.recycle();
		session .recycle();

	}

	private void loadowner(){
		String stLine = null;
		String []arrValues = null;
		String stKey = null;
		String stValue = null;
		try {
			BufferedReader br = new BufferedReader(new FileReader( stFilepath));
			while ((stLine = br.readLine())!= null){
				arrValues = stLine.split(";");
				if (arrValues == null || arrValues.length <10){
					System.out.println(stLine + "-" +arrValues.length);
					continue;
				}
				stKey = arrValues[8];
				stValue = arrValues[6];
				tmOwner.put(stKey, stValue);
				if (! arrValues[3].equals(arrValues[6]) && ! arrValues[7].equalsIgnoreCase("functionalPerson")){
					stKey = arrValues[3];
					stValue = arrValues[8];
					tmPersnum.put(stKey, stValue);
				}
			}
			br.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void getOwner(Document doc){
		String stName = null;
		Name nnName = null;
		String stOwnEmpnum = null;

		Vector<String> veOwnerSerial = new Vector<String>();
		Vector<String> veOwnername = new Vector<String>();
		try {
			veACLEntry = doc.getItemValue("MAILACLENTRIES");
			it = veACLEntry.iterator();
			while (it.hasNext()){
				stName = it.next();
				if(isValid(stName)){
					nnName = session.createName(stName);
					stOwnEmpnum = tmOwner.get(nnName.getAbbreviated());

					
					if (stOwnEmpnum == null){
						System.out.println("Nothing found for " + nnName.getAbbreviated());
					}else{
						veOwnerSerial.add(stOwnEmpnum);
						stName = tmPersnum.get(stOwnEmpnum );
						veOwnername.add(stName);
					}
					nnName.recycle();
				}else{
					veOwnerSerial.add("N/A");
					veOwnername.add("N/A");
				}

			}

			doc.replaceItemValue("MailOwnerSerial", veOwnerSerial);
			doc.replaceItemValue("MailOwnerName", veOwnername);
			doc.save();

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private boolean isValid(String stName){
		for(String stCheck: stFilterEq){
			if (stCheck.equalsIgnoreCase(stName)){
				return false;
			}
		}
		for(String stCheck : stFilterBg){
			if(stName.startsWith(stCheck)){
				return false;
			}
		}

		return true;
	}

}
