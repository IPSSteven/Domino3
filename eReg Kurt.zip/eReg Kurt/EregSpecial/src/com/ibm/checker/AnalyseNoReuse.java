package com.ibm.checker;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.TreeMap;


public class AnalyseNoReuse {
	private final String FILE_PATH = "C:\\tmpAD\\NoReuseRMI\\Log";
	//private final String RES_FILE = "Proposal.txt";
	private final String RES_FILE = "isInUse.txt";

	private TreeMap<String,String> tmEntries = new TreeMap<String, String>();
	//private final String START_TAG = "*RCT01*;Start createReservation";
	//private final String END_TAG = ";*RCT20*;end of createReservation";
	//private final String START_TAG = "*PT01*;make a proposal  start"; // proposal
	//private final String END_TAG = "*PT30*;End of try to make a proposal  end#"; // Proposal
	private final String START_TAG = "*IGT01*;Start getIdsInUse"; // proposal
	private final String END_TAG = "*IGT20*;end getIdsInUse"; // Proposal

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnalyseNoReuse anr = new AnalyseNoReuse();
		anr.getData();

	}

	private void getData() {
		int ilen = 0;
		String line;
		String stOut;
		String stStartTime =null;
		String stEntryKey  = null;
		String[] stFields;
		try {
			BufferedReader br = new BufferedReader(new FileReader(FILE_PATH + "\\"+ RES_FILE));
			//BufferedWriter bwComp = new BufferedWriter(new FileWriter(FILE_PATH+ "\\" + RES_FILE + ".Com.xls"));
			while((line=br.readLine())!= null) {
				stFields = line.split(" ");
				stOut= stFields[0]+ ";" + stFields[1] + ";" + stFields[5]+stFields[6]+stFields[7]+ ";"+ stFields[8]+ ";";
				ilen = stFields.length;
				for(int i = 10; i < ilen; i++) {
					stOut = stOut+ stFields[i]  + " ";
				}
				//		";"+ stFields[10]+ " "+ stFields[11]+ " " + stFields[12] + " " + stFields[14];

				stStartTime  = stFields[0] + stFields[1];
				//stEntryConnection = "[" + stFields[7] +stFields[8] +stFields[9]+ stFields[10] + stFields[11] + stFields[12];
				stEntryKey= "[" + stFields[7] + stStartTime + stFields[8];
				//tsEntries.add(stStartTime + ";" + stEntryConnection);
				tmEntries.put(stEntryKey, stOut);
				/*if(stStartTime != null && stEndTime != null) {
					stOut = stStartTime +";" + stEndTime + ";"  + stFields[5]+stFields[6]+stFields[7];
					bwComp.write(stOut);
					bwComp.newLine();
					System.out.println(stOut);
					stStartTime = null;
					stEndTime = null;
				}*/



			}


			br.close();
			write2File();
			compress();

			//bwComp.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void write2File() {
		String stKey = null;
		String stOut = null;
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH+ "\\" + RES_FILE + ".xls"));
			Iterator<String> it = tmEntries.keySet().iterator();

			while(it.hasNext()) {
				stKey = it.next();
				stOut = tmEntries.get(stKey);
				pln(stKey);
				bw.write(stOut);
				bw.newLine();
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private void pln(String s) {
		System.out.println(s);
	}

	private void compress() {
		GregorianCalendar start = null;
		GregorianCalendar end = null;
		String stKey = null;
		String stOut = null;

		String []stFields;
		String startTime = null;
		String endTime = null;
		String stDay;
		String stMonth;
		String stYear;
		String hours;
		String minutes;
		String seconds;
		long timedif;
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_PATH + "\\" + RES_FILE +".comp.xls"));
			Iterator<String> it = tmEntries.keySet().iterator();
			while(it.hasNext()) {
				stKey = it.next();
				stOut = tmEntries.get(stKey);
				if (stOut.indexOf(START_TAG) >0) {
					stFields = stOut.split(";");
					stYear = stFields[0].substring(0, 4);
					stMonth = stFields[0].substring(4,6);
					stDay = stFields[0].substring(6,8);
					hours = stFields[1].substring(0,2);
					minutes = stFields[1].substring(3,5);
					seconds = stFields[1].substring(6,8);
					startTime = stYear + "-" + stMonth + "-" + stDay+ " " + hours+ ":" + minutes+ ":" + seconds;
					start = new GregorianCalendar(Integer.parseInt(stYear), Integer.parseInt(stMonth),Integer.parseInt(stDay),
							Integer.parseInt(hours), Integer.parseInt(minutes), Integer.parseInt(seconds));

				}
				if (stOut.indexOf(END_TAG) >0) {
					stFields = stOut.split(";");
					stYear = stFields[0].substring(0, 4);
					stMonth = stFields[0].substring(4,6);
					stDay = stFields[0].substring(6,8);
					hours = stFields[1].substring(0,2);
					minutes = stFields[1].substring(3,5);
					seconds = stFields[1].substring(6,8);
					seconds = stFields[1].substring(6,8);
					endTime = stYear + "-" + stMonth + "-" + stDay+ " " + hours+ ":" + minutes+ ":" + seconds;

					end = new GregorianCalendar(Integer.parseInt(stYear), Integer.parseInt(stMonth),Integer.parseInt(stDay),
							Integer.parseInt(hours), Integer.parseInt(minutes), Integer.parseInt(seconds));	
					if (start != null) {
						timedif = (end.getTimeInMillis()- start.getTimeInMillis())/1000;
						stOut = startTime + ";" +endTime + ";" + timedif + ";" + stFields[2];
						pln(stOut);
						bw.write(stOut);
						bw.newLine();
					}
				}


			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
