package com.ibm.checker;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class CheckWrongFullNames extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CheckWrongFullNames cwf = new CheckWrongFullNames();
		cwf.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("1Bestfriend!");
		Database dbName = CommonFunctions.getDatabase(s, "D51HUB01", "names.nsf");
		Database dbEreg = CommonFunctions.getDatabase(s, "IDPData1/IDP", "e_dir/ereglog6.nsf");
		View vwEreg = dbEreg.getView("(AUByFullName)");
		String Formula = "Type = \"Person\" & Empnum = \"\"";
		DocumentCollection dcc = dbName.search(Formula);
		System.out.println("Found "+ dcc.getCount() + " documents");

		Document docRec = null;
		Document docEreg = null;
		DocumentCollection dccEreg = null;
		Vector <String >vFullname = null;
		Vector <String >vShort;
		String stFullname;
		BufferedWriter bw;
		Name fNam;
		int iCount = 0;
		boolean bFound = false;
		try {
			bw = new BufferedWriter(new FileWriter("c:/temp/out.txt"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return;
		}
		Document docNab = dcc.getFirstDocument();
		try {
			while (docNab != null) {

				vFullname = docNab.getItemValue("FullName");
				if (vFullname == null) {
					vShort = docNab.getItemValue("ShortName");
					try {
						bw.write("Fullname is empty Short = " + vShort.lastElement() + ", docunid = " + docNab.getUniversalID());
					} catch (NotesException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}else {
					stFullname = vFullname.firstElement();
					fNam = s.createName(stFullname);
					if(fNam != null) {
						stFullname = fNam.getAbbreviated(); 
						fNam.recycle();
					}
					dccEreg = vwEreg.getAllDocumentsByKey(stFullname);
					if(dccEreg == null || dccEreg.getCount() == 0) {
						bw.write(stFullname + ",created :" + docNab.getCreated().getDateOnly()+ " no log found");
						bFound = false;
					}else {
						bFound = true;
						docEreg = dccEreg.getFirstDocument();
						int rcMax = 9999;
						int rc;
						String stRc;
						while (docEreg != null) {
							stRc = docEreg.getItemValueString("ReturnCode");
							if(stRc != null && !stRc.isEmpty()) {
								stRc = stRc.substring(0,4).trim();
								rc = Integer.parseInt(stRc);
								if(rc < rcMax) rcMax = rc;		
							}
							docRec = docEreg;
							docEreg = dccEreg.getNextDocument(docEreg);
							docRec.recycle();
						}
						docEreg = dccEreg.getFirstDocument();
						docEreg.replaceItemValue("Status", "New");
						docEreg.replaceItemValue("ReturnCode", "");
						docEreg.replaceItemValue("FTPok", "");
						docEreg.replaceItemValue("AssignedMKey", "D03");
						docEreg.save();
						docEreg.recycle();

						bw.write(stFullname + "," + docNab.getCreated().getDateOnly()+ ","+  dccEreg.getCount() + "," + rcMax);
						if (dccEreg != null)dccEreg.recycle();
					}	
				}

				bw.newLine();

				docRec = docNab;
				docNab= dcc.getNextDocument(docNab);
				//docRec.recycle();
				if(bFound) {
					docRec.remove(true);
				}
				
				
				iCount ++;
				if(iCount % 20 ==0)System.out.println("working on " + iCount + " document" );
			}

			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



	}

}
