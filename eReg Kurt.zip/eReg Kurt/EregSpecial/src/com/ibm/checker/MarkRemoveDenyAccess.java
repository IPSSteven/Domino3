package com.ibm.checker;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.RichTextItem;
import lotus.domino.Session;

public class MarkRemoveDenyAccess extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MarkRemoveDenyAccess mrdA = new MarkRemoveDenyAccess();
		mrdA.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		RichTextItem rtf;
		String txt;
		int idx;
		Document docR;
		Session s = NotesFactory.createSessionWithFullAccess("tr0409uk.");
		Database dbLog = CommonFunctions.getDatabase(s, "D06DBL090", "e_dir/ereglog6.nsf");
		DocumentCollection dcc = dbLog.search("( (@Text(StartTime) != \"\") & (Form = \"Log\") & @Contains(Subject;\"Remove From Deny Access\") )");
		pln("Found "+ dcc.getCount() + " documents");
		
		Document doc = dcc.getFirstDocument();
		while(doc != null) {
			rtf = (RichTextItem)doc.getFirstItem("Body");
			txt = rtf.getUnformattedText();
			idx = txt.indexOf("0 requests processed");
			if (idx < 0) {
				pln("found mail" + txt);
			}else {
				
			}
			rtf.recycle();
			docR = doc;
			doc = dcc.getNextDocument(doc);
			docR.recycle();
		}
		
	}
	private void pln(String s) {
		System.out.println(s);
	}

	
}
