package com.ibm.checker;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.TreeMap;
import com.ibm.ereg.common.CommonFunctions;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.International;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.DateTime;
import lotus.domino.RichTextItem;

public class RequestCycleTime extends NotesThread {
	int iData = 0;
	private int iDocMax = 1024;
	private TreeMap<String,RequestCycleTimeResultBean> hsrequestBean = new TreeMap<String, RequestCycleTimeResultBean>();

	private final String [] AgentsRunOnce = {"AC - Request Manager", "Agent Manager", "AnonymousMail", "ASO BackEnd",
			"AU - Agent Manager", "CBN Mail", "CP - Agent Manager", "Deletion Warning", "DU - Agent Manager", "DU - Request Manager",
			"HR - Request Manager", "HRBatch", "HRInboxMaintainance|HRInboxMaintainance", "ITIM", "Mailfiles Counting",
			"NoReuseRunner|NoreuseRunner", "Notes_Monitoring", "PW - Request Manager", "ReadUploadResultfromVault|ag_ReadUploadResultfromVault",
			"RecertificationExpiredIds|RecertificationExpiredIds", "Remove From Deny Access", "Repository", "RV - SCNSync", "Statistic", 
			"TerminateTimeoutRequest", "Update IDs","(ITIM\\ReadInNew)", "ITIM\\Reconcile"}; 
	//private final String [] AgentsRunOnce = {"(ITIM\\ReadInNew)", "ITIM\\Reconcile"};

	private final String [] AgentsRunMore = {"AU - Request Manager","CP - Request Manager", "DU - SCNSync","HR - Agent Manager",
			"HR - SCNSync", "HU - Agent Manager", "HU - Request Manager", "HU - SCNSync", "KU - Agent Manager","KU - Request Manager",
			"RB - Agent Manager", "RB - Request Manager", "RB - SCNSync", "RMI DenyAccess Server", "RN - Agent Manager", "RN - Request Manager",
			"RN - SCNSync", "RS - Agent Manager", "RS - Request Manager","RS - SCNSync", "RV - Agent Manager", "RV - Request Manager", "RV - SCNSync",
			"TR - Request Manager", "TR - SCNSync"};
	//private final String [] AgentsRunMore = {"AU - Request Manager"};
	private Session s;
	private String DateSep;
	private String TimeSep;
	private String DateForm;
	private String shortName;
	private class RTimes{
		private DateTime starttime;
		private DateTime endtime;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RequestCycleTime rct = new RequestCycleTime();
		rct.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();

		s = NotesFactory.createSessionWithFullAccess("N0thingelsemat.");
		International Internat = s.getInternational();
		DateSep = Internat.getDateSep();
		TimeSep = Internat.getTimeSep();
		DateForm = Internat.isDateDMY()? "DMY": DateForm;
		DateForm = Internat.isDateMDY()? "MDY": DateForm;
		DateForm = Internat.isDateYMD()? "YMD": DateForm;
		//Database dbE = CommonFunctions.getDatabase(s, "D06DBL090", "e_dir/ereglog6.nsf");
		Database dbE = CommonFunctions.getDatabase(s, "", "e_dir/ereglog6.nsf");
		View vw = dbE.getView("Logs\\by Agent");

		BufferedWriter bwR;
		try {
			bwR = new BufferedWriter(new FileWriter("outRequestCalc.xls"));


			for (String sAg : AgentsRunOnce) {
				iData = 0;
				DocumentCollection dcc = vw.getAllDocumentsByKey(sAg);
				pln(sAg + ":" + dcc.getCount());
				try {
					bwR.write(sAg + ";" + dcc.getCount());
					bwR.newLine();
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

				}
				getData(sAg, dcc);
			}
			for (String sAg : AgentsRunMore) {

				DocumentCollection dcc = vw.getAllDocumentsByKey(sAg);
				pln(sAg + ":" + dcc.getCount());
				try {
					bwR.write(sAg + ";" + dcc.getCount());
					bwR.newLine();
				} catch (NotesException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				getData(sAg, dcc);


			}

			bwR.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		writeResult2Client();




	}
	private void pln(String s) {
		System.out.println(s);
	}

	private void getData(String AgentName ,DocumentCollection dcc) {
		int i = 0;
		Document docR  = null;
		RichTextItem rtf = null;
		String text = null;
		String status = null;


		try {
			DateTime dteBorder = s.createDateTime("Today");
			DateTime dteTest = s.createDateTime("Today");
			dteTest.setNow();
			dteBorder.setNow();
			dteBorder.adjustDay(-58);
			int timDif = dteTest.timeDifference(dteBorder);

			Document doc = dcc.getFirstDocument();
			while (doc != null && i < iDocMax) {
				dteTest = doc.getCreated();
				timDif = dteTest.timeDifference(dteBorder);
				status = doc.hasItem("Status") ? doc.getItemValueString("Status"): null;
				if (timDif >0 && (status == null || status.equalsIgnoreCase("done"))) {


					try {
						rtf = (RichTextItem)doc.getFirstItem("Body");
						if (rtf != null) {
							text = rtf.getUnformattedText();
							if (doc.hasItem("ShortName"))shortName =doc.getItemValue("ShortName").lastElement().toString(); else shortName = "N/A";
							addResultBean(AgentName, (DateTime)doc.getItemValueDateTimeArray("StartTime").firstElement(), (DateTime)doc.getItemValueDateTimeArray("EndTime").firstElement(), text, doc.getItemValueString("Log2File"));
							i++;
							rtf.recycle();
						}

					}catch(ClassCastException ce) {
						//ce.printStackTrace();
					}

				}

				docR = doc;
				doc =dcc.getNextDocument(doc);
				docR.recycle();

			}

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void addResultBean (String AgentName,  DateTime created, DateTime modified, String text, String Log2File) {

		boolean bFirst = true;
		RTimes rTimes;
		String dummy;
		int iTimeMax = 0;
		int iTimeMin = 0;
		int iTimeDiff = 0;
		int iTimeOverall = 0;
		DateTime startTime;
		DateTime endTime;

		RequestCycleTimeResultBean rs;


		try {




			String [] runlog = text.split("\\*   \\*   \\*   \\*   \\*   \\*   \\*   \\*   \\*");

			rs = new RequestCycleTimeResultBean();
			rs.setsAgent(AgentName);
			rs.setShortName(shortName);
			rs.setRuns(runlog.length);
			if (Log2File.equals("1")) {
				//dummy = created.getDateOnly();
				//dummy = modified.getDateOnly();
				//dummy = created.getTimeOnly();
			//	dummy = modified.getTimeOnly();

				iTimeDiff = modified.timeDifference( created);
				iTimeMin = iTimeDiff;
				iTimeMax = iTimeDiff;
				iTimeOverall = iTimeDiff;
			}else {
				for(String rlog: runlog) {
					iData ++;
					if(rlog.indexOf("found Machine Key") >0 ||rlog.indexOf("updated the following fields")> 0 || rlog.indexOf("update by:")> 0 || rlog.indexOf(">>> hrStarter")> 0) {
						rs.setRuns(rs.getRuns() -1);
						continue;
					}



					rTimes = getRT(rlog);
					if (rTimes.starttime == null && rTimes.endtime == null ) {
						rs.setRuns(rs.getRuns() -1);
						continue;
					}

					//startTime = (rTimes.starttime != null) ?rTimes.starttime : created;
					//endTime = (rTimes.endtime != null) ?rTimes.endtime : modified;
					startTime = rTimes.starttime;
					endTime = rTimes.endtime;
					iTimeDiff = endTime.timeDifference(startTime);
					startTime.recycle();
					endTime.recycle();
					if (iTimeDiff < 0) iTimeDiff = 86400+iTimeDiff;
					if (bFirst) {
						iTimeMin = iTimeDiff;
						iTimeMax = iTimeDiff;
						bFirst = false;
					}else {
						iTimeMax = (iTimeMax < iTimeDiff)? iTimeMax = iTimeDiff:iTimeMax;
						iTimeMin = (iTimeMin > iTimeDiff)? iTimeMin = iTimeDiff:iTimeMin;
					}
					iTimeOverall = iTimeOverall + iTimeDiff;
				}
			}


			rs.setMinTime(String.valueOf(iTimeMin));
			rs.setMaxTime(String.valueOf(iTimeMax));
			rs.setOverAllRuntimeNetto(String.valueOf(iTimeOverall));
			hsrequestBean.put(AgentName+ "-" + iData, rs);


		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private RTimes getRT(String text) {
		String timeStart = null;
		String timeEnd = null;
		RTimes rtret = new RTimes();
		int idxF = text.indexOf(">>>");
		int idxL = text.lastIndexOf(">>>");

		if ((idxL - idxF)< 20) {

			rtret.starttime = null;
			rtret.endtime = null;
		}else {
			timeStart = text.substring(0,idxF);
			timeStart = getSTime(timeStart);
			timeEnd = text.substring(idxL-20);
			timeEnd = getSTime(timeEnd);
			timeStart = "01" + DateSep + "01" +  DateSep +"2020" + " " + timeStart;
			timeEnd = "01" + DateSep + "01" +  DateSep +"2020" + " " + timeEnd;
			try {
				rtret.starttime = s.createDateTime(timeStart);
				rtret.endtime = s.createDateTime(timeEnd);
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		return rtret;

	}

	private void writeResult2Client() {
		String AgentgroupName =null;
		String AgentName = null;

		int i = 0;
		int iRuns =0 ;
		int iMin = 0;
		int iMax = 0;
		int iOverall = 0;

		float fRunsAv = (float)0.0;
		float fMinAv = (float)0.0;
		float fMaxAv = (float)0.0;
		float fOverallAv = (float)0.0;

		boolean bFirst = true;
		RequestCycleTimeResultBean rBean;
		String key = null;
		pln("****************************************results *****************************");

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("outRquestCycle.xls"));
			BufferedWriter bwcom = new BufferedWriter(new FileWriter("outRquestCyclecomp.xls"));
			bw.write(RequestCycleTimeResultBean.getTitle());
			bw.newLine();
			pln(RequestCycleTimeResultBean.getTitle());
			Iterator<String> it = hsrequestBean.keySet().iterator();
			while (it.hasNext()) {
				key = it.next();


				rBean = hsrequestBean.get(key);
				AgentName = rBean.getsAgent();
				if(bFirst) {
					AgentgroupName = AgentName;
					i = 0;
					iRuns =  rBean.getRuns();
					iMin = Integer.parseInt(rBean.getMinTime());
					iMax =  Integer.parseInt(rBean.getMaxTime());
					iOverall = Integer.parseInt(rBean.getOverAllRuntimeNetto());
					bwcom.write("Agent;Runs;Min;Max;Overall");
					bwcom.newLine();
					bFirst = false;
				}

				if (! AgentName.equals(AgentgroupName)) {
					fRunsAv = ((float)iRuns) / (float)i;
					fMinAv = ((float)iMin) / (float)i;
					fMaxAv = ((float)iMax) / (float)i;
					fOverallAv =((float)iOverall)/(float)i;
					bwcom.write(AgentgroupName +";"+ fRunsAv + ";"+fMinAv+ ";" + fMaxAv + ";" + fOverallAv);
					bwcom.newLine();
					AgentgroupName = AgentName;
					iMin = Integer.parseInt(rBean.getMinTime());;
					iMax = Integer.parseInt(rBean.getMaxTime());;
					iOverall = Integer.parseInt(rBean.getOverAllRuntimeNetto());
					iRuns = rBean.getRuns();
					i = 0;
				}else {
					iMin = iMin + Integer.parseInt(rBean.getMinTime());
					iMax = iMax + Integer.parseInt(rBean.getMaxTime());
					iOverall = iOverall +Integer.parseInt(rBean.getOverAllRuntimeNetto());
					iRuns = iRuns + rBean.getRuns();
				}

				bw.write(rBean.getSentence());
				bw.newLine();
				pln(rBean.getSentence());
				i++;
			}
			bw.close();
			fRunsAv = ((float)iRuns) / (float)i;
			fMinAv = ((float)iMin) / (float)i;
			fMaxAv = ((float)iMax) / (float)i;
			fOverallAv =((float)iOverall)/(float)i;
			bwcom.write(AgentgroupName +";"+ fRunsAv + ";"+fMinAv+ ";" + fMaxAv + ";" + fOverallAv);
			bwcom.newLine();
			bwcom.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private String getSTime (String sTime) {
		String dummy [];
		dummy = sTime.split(" ");
		int iU = dummy.length;
		if (iU < 2) {
			pln ("********TIME Error *********");
			return ("00:00:00");
		}
		return dummy[1];

	}

}
