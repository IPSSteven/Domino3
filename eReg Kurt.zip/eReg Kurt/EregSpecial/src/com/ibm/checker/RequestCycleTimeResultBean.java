package com.ibm.checker;

public class RequestCycleTimeResultBean {
	private String sAgent;
	private int Runs;
	private String AverageRuntime;
	private String MaxTime;
	private String MinTime;
	private String shortName;
	private String OverAllRuntimeNetto;
	public String getsAgent() {
		return sAgent;
	}
	public void setsAgent(String sAgent) {
		this.sAgent = sAgent;
	}
	public int getRuns() {
		return Runs;
	}
	public void setRuns(int runs) {
		Runs = runs;
	}
	public String getAverageRuntime() {
		return AverageRuntime;
	}
	public void setAverageRuntime(String averageRuntime) {
		AverageRuntime = averageRuntime;
	}
	public String getMaxTime() {
		return MaxTime;
	}
	public void setMaxTime(String maxTime) {
		MaxTime = maxTime;
	}
	public String getMinTime() {
		return MinTime;
	}
	public void setMinTime(String minTime) {
		MinTime = minTime;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getOverAllRuntimeNetto() {
		return OverAllRuntimeNetto;
	}
	public void setOverAllRuntimeNetto(String overAllRuntimeNetto) {
		OverAllRuntimeNetto = overAllRuntimeNetto;
	}
	
	public static String getTitle() {
		return "Agent;Runs;Short name;Runs;Min time;Max time;over all run time netto";
	}
	public String getSentence() {
		StringBuffer sb = new StringBuffer();
		sb.append(sAgent);
		sb.append(";");
		sb.append(Runs);
		sb.append(";");
		sb.append(shortName);
		sb.append(";");
		sb.append(MinTime);
		sb.append(";");
		sb.append(MaxTime);
		sb.append(";");
		sb.append(OverAllRuntimeNetto);
		sb.append(";");
		return sb.toString();
	}

}
