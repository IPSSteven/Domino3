package com.ibm.copyDB;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class CopyMainThread extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CopyMainThread cmt = new CopyMainThread();
		cmt.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		int iStart;

		CopyProperties cp = new CopyProperties();
		Session sess = NotesFactory.createSessionWithFullAccess(cp.getPw());
		int  ilen = cp.getSourceServer().length;
		for (int i = 0 ; i<ilen; i++) {
			Database dbTarget = CommonFunctions.getDatabase(sess, cp.getTargetServer()[i], cp.getTargetfilePath()[i]);
			if (dbTarget.isOpen()){
				dbTarget.remove();
			}
			
			Database dbSource = CommonFunctions.getDatabase(sess, cp.getSourceServer()[i], cp.getSourcefilePath()[i]);
			dbSource.createCopy(cp.getTargetServer()[i], cp.getTargetfilePath()[i]);
			View vwSource = dbSource.getView(cp.getSourceView()[i]);
			double iSize = vwSource.getEntryCount();
			int iThreads = (int)Math.ceil(iSize/cp.getiHeapSize());
			
			ExecutorService eService = Executors.newFixedThreadPool(cp.getiThreadMax());
			for (int j=0;j<iThreads; j++) {
				cp = new CopyProperties();
				iStart = j*cp.getiHeapSize() + 1;
				cp.setiStart(iStart);
				CopyThread cpt = new CopyThread(cp, i);
				cpt.setName("Thread --- " +j);
				eService.execute(cpt);
			}
			eService.shutdown();
		}
		
	}
	
	

}
