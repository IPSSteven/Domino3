package com.ibm.copyDB;

public class CopyProperties {
	//private String[] sourceServer = {"D51HUB01", "D06DBL090", "D06DBL090"};
	//private String[] sourcefilePath = {"names.nsf","n_dir/ncouaruk.nsf", "n_dir/ncouar2.nsf"}; 
	//private String[] sourceView = {"People\\People by Shortname","Person\\Person by Shortname","Person\\Person by Shortname"};
	
	private String[] sourceServer = {"D06HBM03"};
	private String[] sourcefilePath = {"names.nsf"}; 
	private String[] sourceView = {"People\\People by Shortname",};
	
	private String[] targetServer = {"mopbz171053/GIDDev"};
	private String[] targetfilePath = {"test/namesDE.nsf"};
	
	private int iHeapSize = 512;
	private int iStart;
	private int iThreadMax = 24;
	
	private String pw = "Used2know.";
	
	public String[] getSourceServer() {
		return sourceServer;
	}
	public void setSourceServer(String[] sourceServer) {
		this.sourceServer = sourceServer;
	}
	public String[] getSourcefilePath() {
		return sourcefilePath;
	}
	public void setSourcefilePath(String[] sourcefilePath) {
		this.sourcefilePath = sourcefilePath;
	}
	public String[] getSourceView() {
		return sourceView;
	}
	public void setSourceView(String[] sourceView) {
		this.sourceView = sourceView;
	}
	public String[] getTargetServer() {
		return targetServer;
	}
	public void setTargetServer(String[] targetServer) {
		this.targetServer = targetServer;
	}
	public String[] getTargetfilePath() {
		return targetfilePath;
	}
	public void setTargetfilePath(String[] targetfilePath) {
		this.targetfilePath = targetfilePath;
	}
	public int getiHeapSize() {
		return iHeapSize;
	}
	public void setiHeapSize(int iHeapSize) {
		this.iHeapSize = iHeapSize;
	}
	public int getiStart() {
		return iStart;
	}
	public void setiStart(int iStart) {
		this.iStart = iStart;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public int getiThreadMax() {
		return iThreadMax;
	}
	public void setiThreadMax(int iThreadMax) {
		this.iThreadMax = iThreadMax;
	} 
	


}
