package com.ibm.copyDB;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewNavigator;
import lotus.domino.ViewEntry;

public class CopyThread extends NotesThread {
	
	CopyProperties cp;
	int iDatabase;
	public CopyThread(CopyProperties cp, int iDatabase) {
		this.cp = cp;
		this.iDatabase = iDatabase;
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		
		super.runNotes();
		long lStart = System.currentTimeMillis();
		Session sess = NotesFactory.createSessionWithFullAccess(cp.getPw());
		Database dbSource = CommonFunctions.getDatabase(sess, cp.getSourceServer()[iDatabase], cp.getSourcefilePath()[iDatabase]);
		View vwSource = dbSource.getView(cp.getSourceView()[iDatabase]);
		vwSource.setAutoUpdate(false);
		Database dbTarget = CommonFunctions.getDatabase(sess, cp.getTargetServer()[iDatabase], cp.getTargetfilePath()[iDatabase]);
		ViewNavigator vNav = vwSource.createViewNav();
		vNav.setBufferMaxEntries(cp.getiHeapSize());
		ViewEntry ve = vNav.getNth(cp.getiStart());
		ViewEntry veRec;
		int i = 0;
		Document doc;
		while(ve != null && i < cp.getiHeapSize()) {
			if( i%256 == 0) pln(this.getName() + " working on " + i + " document after " + (System.currentTimeMillis() - lStart)/1000 + " sec" );
			doc = ve.getDocument();
			doc.copyToDatabase(dbTarget);
			doc.recycle();
			veRec = ve;
			ve = vNav.getNext(ve);
			veRec.recycle();
			i++;
		}
		pln(this.getName() + "  Ready Started at "+ cp.getiStart()+ " copied " + i + " document after " + (System.currentTimeMillis() - lStart)/1000 + " sec" );
		
		vNav.recycle();
		vwSource.recycle();
		dbTarget.recycle();
		dbSource.recycle();
		sess.recycle();
	}
	private void pln(String s) {
		System.out.println(s);
	}

}
