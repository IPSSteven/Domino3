package com.ibm.correct;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class CorrectEmail extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CorrectEmail ce = new CorrectEmail();
		ce.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("Jac2mac.");
		Database dbNab = CommonFunctions.getDatabase(s, "D51HUB01", "names.nsf");
		View vUser= dbNab.getView("($Users)");
		String line;
		String [] dummy;
		String key;
		Document docNab = null;
		Vector<String> vShort = null;
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("correctEmail.txt"));
			while((line = br.readLine())!=null) {
				dummy = line.split(",");
				key = dummy[0];
				docNab = vUser.getDocumentByKey(key);
				vShort = docNab.getItemValue("ShortName");
				vShort.add(0, dummy[1]);
				docNab.replaceItemValue("ShortName", vShort);
				docNab.replaceItemValue("InternetAddress", dummy[1]);
				docNab.save();
			}
			br.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
