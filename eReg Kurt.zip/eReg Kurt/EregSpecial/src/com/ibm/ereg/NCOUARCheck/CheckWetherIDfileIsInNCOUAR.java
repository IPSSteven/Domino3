package com.ibm.ereg.NCOUARCheck;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewEntryCollection;

public class CheckWetherIDfileIsInNCOUAR extends NotesThread {
	private int iLine = 0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CheckWetherIDfileIsInNCOUAR cwn = new CheckWetherIDfileIsInNCOUAR();
		cwn.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session session = NotesFactory.createSessionWithFullAccess("g00dtimes4ever!");
		Database edc = CommonFunctions.getDatabase(session, "D06EDC10","dircat/edcww.nsf" );
		Database uar =  CommonFunctions.getDatabase(session, "D06DBL090","n_dir/ncouaruk.nsf" );
		Database uar2 =  CommonFunctions.getDatabase(session, "D06DBL090","n_dir/ncouar2.nsf" );
		
		View vwEdc = edc.getView("($Users)");
		View vwUar = uar.getView("(ITIMExport)");
		View vwUar2 = uar2.getView("(ITIMExport)");
		Document doc = null;
		
		ViewEntry ve = null;
		
		String line;
		String key;
		String res;
		String lineOut;
		boolean bFirst = true;
	
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("c:/temp/NotesId2Check.csv"));
			BufferedWriter bw = new BufferedWriter(new FileWriter("c:/temp/NotesId2CheckOut.csv"));
			while ((line = br.readLine())!= null) {
				if(bFirst) {
					lineOut = line + "," + "Is in NCOUAR";
					bw.write(lineOut);
					bw.newLine();
					iLine++;
					pln(lineOut);
					bFirst = false;
					continue;
					
				}
				key = line.split(",")[0];
				doc = vwEdc.getDocumentByKey(key);
				if(doc != null) {
					key =  doc.getItemValue("ShortName").lastElement().toString();
					doc.recycle();
					ve = vwUar.getEntryByKey(key);
					if(ve == null) {
						ve = vwUar2.getEntryByKey(key);
					}
					if(ve == null) {
						lineOut =line + ","+ "Not Found in NCOUAR";
					}else {
						//Object o =  ve.getColumnValues().elementAt(10);
						res = ve.getColumnValues().elementAt(10).toString();
						ve.recycle();
						lineOut =line + ","+ res;
						
						
					}
					bw.write(lineOut);
					bw.newLine();
				}else {
					lineOut =line + ","+ "Not Found in ED";
				}
				iLine++;
				pln(lineOut);
			}
			bw.flush();
			bw.close();
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void pln(String s) {
		System.out.println(iLine + " : " + s);
	}

}
