package com.ibm.ereg.NCOUARCheck;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class DuWithoutKU extends NotesThread {
	private final String stServer = "D06DBL048";
	//private final String stFilePath = "n_dir/ncouaruk.nsf";
	private final String stFilePath = "n_dir/ncouar2.nsf";
	public final String stForm = "((Form = \"User\") & (State != \"Out\") ) & @Contains(History;\"ASO BackEnd:DU\")";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DuWithoutKU duk = new  DuWithoutKU();
		duk.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("g00dleg4jac.");
		Database db = s.getDatabase(stServer, stFilePath);
		DocumentCollection dcc = db.search(stForm);
		Document doc = null;
		Document docRecyle = null;
		String stLine = null;
		Vector<String> vHist = null;
		Iterator<String> it = null;
		String stHist = null;
		
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("c:/temp/DuWithoutKU.csv"));
			stLine = "Domain;LNShortname;Nab Serial;OwnerSerial;Class;State;History";
			bw.write(stLine);
			bw.newLine();
			doc = dcc.getFirstDocument();
			while (doc != null){
				stLine = doc.getItemValueString("Domain") + ";" +
						doc.getItemValueString("LNShortName") + ";" +
						doc.getItemValueString("EmpNo")+ doc.getItemValueString("EmpCC") + ";" +
						doc.getItemValueString("Dept_id") + ";" +
						doc.getItemValueString("Classification") + ";" +
						doc.getItemValueString("State") + ";";
				vHist = doc.getItemValue("History");
				it = vHist.iterator();
				while (it.hasNext()){
					stHist = it.next();
					if(stHist.indexOf("ASO BackEnd:DU") >0) {
						stLine = stLine + stHist;
						break;
					}
				}
				bw.write(stLine);
				bw.newLine();
				
						
				docRecyle = doc;
				doc = dcc.getNextDocument(doc);
				docRecyle.recycle();
			}
			bw.close();
			System.out.println("Ready");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
