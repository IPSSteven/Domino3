package com.ibm.ereg.NCOUARCheck;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;
import com.ibm.ereg.common.CommonFunctions;
import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;

public class NCOUARunner extends NotesThread {

	public NCOUARunner() {
		// TODO Auto-generated constructor stub


	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NCOUARunner ncr = new NCOUARunner();
		ncr.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session session = NotesFactory.createSessionWithFullAccess("jac2mac.");
		Database dbNCOUAR = CommonFunctions.getDatabase(session, "D06DBL048","n_dir/ncouaruk.nsf");
		View vwNC = dbNCOUAR.getView("ITIMExport");
		String[] stSplit = null;
		String[] stSearch = null;
		ViewEntry ve = null;
		String stOut = null;
		FileWriter fw;

		File  fin = new File("c:/temp/20160303VaultAnalysis.csv");
		FileReader fr;
		Vector<Object> vRow = null;

		String line;
		int icount =0;
		try {
			fr = new FileReader(fin);
			fw = new FileWriter("c:/temp/NCOUAout.txt");
			stOut = "Domain;Short name;Searchkey;Fullname;Classification;hasIdFile;State \r\n";
			fw.write(stOut + "/r/n");
			BufferedReader br = new BufferedReader(fr);
			while((line = br.readLine()) != null){
				stSplit = line.split(";");
				stSearch = stSplit[0].split("@");
				ve = vwNC.getEntryByKey(stSearch[0]);
				if(ve ==null && stSplit.length >1){
					stSearch = stSplit[1].split("@");
					ve = vwNC.getEntryByKey(stSearch[0]);
				}
				if(ve != null){
					vRow = ve.getColumnValues();
					stOut =  vRow.elementAt(3).toString() + ";" + vRow.elementAt(2).toString() + ";" + stSearch[0] + ";" +
							vRow.elementAt(1).toString()+ ";" + vRow.elementAt(9).toString() + ";" + vRow.elementAt(10).toString()+ ";"  + vRow.elementAt(13).toString();
				}else{
					if(icount > 0){
						stOut = "+++++++++++++++++++ NOT FOUND +++++++++++++++" + line + "\r\n";
					}
				}
				System.out.println(stOut + "-" + icount);

				fw.write(stOut + "\r\n");
				icount ++;
			}
			br.close();
			fw.close();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		session.recycle();


	}


}
