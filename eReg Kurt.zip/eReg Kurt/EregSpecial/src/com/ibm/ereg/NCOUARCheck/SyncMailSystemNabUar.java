package com.ibm.ereg.NCOUARCheck;

import java.util.HashMap;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjMailDomain;
import com.ibm.ereg.config.ConfigObjNCOUAR;
import com.ibm.ereg.logger.FileLoger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class SyncMailSystemNabUar extends NotesThread {

	private HashMap<String, String> hmMailSystem;
	private Session sess;
	private FileLoger fl;
	private ConfigObjNCOUAR cfgUAR;
	public String pw;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SyncMailSystemNabUar sUar = new SyncMailSystemNabUar();
		sUar.pw = args[0];
		sUar.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		DocumentCollection dcc;
		Document doc;
		Document docRecyle;
		String Domain;
		String Server;

		super.runNotes();

		sess = NotesFactory.createSessionWithFullAccess(pw);
		fl = new FileLoger("logMail", "txt");
		try {
			cfgUAR = new ConfigObjNCOUAR(sess, fl);
			//cfgUAR.
			ConfigObjMailDomain cfgMailDomain = new ConfigObjMailDomain(sess, "4>", fl);
			View conf = cfgMailDomain.getVwConfig();
			dcc = conf.getAllDocumentsByKey("4>");
			doc = dcc.getFirstDocument();
			while (doc != null) {
				Domain = doc.getItemValueString("Subject");
				Server = doc.getItemValueString("V1");
				getNabData(Server);
				checkUpdateNCOUAR(Domain);
				docRecyle = doc;
				doc = dcc.getNextDocument(doc);
				docRecyle.recycle();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	private void getNabData(String nabServer) {
		int icount = 0;
		Document doc;
		Document docRecyle;
		Database dbNab = CommonFunctions.getDatabase(sess, nabServer, "names.nsf");
		Vector <String>vShortName ;
		hmMailSystem = new HashMap<String, String>();
		try {
			View vwNab = dbNab.getView("People\\People by Shortname");
			doc = vwNab.getFirstDocument();
			while(doc != null) {
				vShortName = doc.getItemValue("ShortName");
				if(vShortName != null && !vShortName.isEmpty()) {
					hmMailSystem.put(vShortName.lastElement(),doc.getItemValueString("MailSystem"));
				}
				docRecyle = doc;
				doc = vwNab.getNextDocument(doc);
				docRecyle.recycle();
				icount ++;
				if (icount %50 == 0) pln("Working on " + icount +" NAB  document on Server " + nabServer);
			}
			vwNab.recycle();
			dbNab.recycle();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

	private void checkUpdateNCOUAR(String Domain) {
		View vwUAR = cfgUAR.getVwITIMEXPORT(Domain);
		String Shortname;
		String MailSystemNAB;
		String MailSystemUAR;
		String stMsg;
		int iCount = 0;

		DocumentCollection dcc;
		try {
			dcc = vwUAR.getAllDocumentsByKey(Domain);
			Document doc;
			Document docRecyle;
			doc = dcc.getFirstDocument();
			while(doc != null){
				Shortname = doc.getItemValueString("LNShortname");
				MailSystemNAB = hmMailSystem.get(Shortname);
				MailSystemUAR = doc.getItemValueString("MailSystem");
				if(MailSystemNAB != null && (MailSystemNAB.equals("1")|| MailSystemNAB.equals("3"))) {
					if(!MailSystemNAB.equals(MailSystemUAR)) {
						doc.replaceItemValue("MailSystem", MailSystemNAB);
						stMsg = "ShortName: " + Shortname+ " updated Mail System from NAB";
						if(MailSystemNAB.equals("3")) {
							doc.replaceItemValue("idFileInVault", "0");
							stMsg = stMsg + " and idFileInVault flag";
						}
						fl.logActionLevel(LogLevel.INFO, stMsg);
						doc.save();
				}
				}
				docRecyle =doc;
				doc = dcc.getNextDocument(doc);
				docRecyle.recycle();
				iCount++;
				if (iCount % 100 == 0)pln("Domain:" + Domain + " working on " + iCount + " UAR document");
		
			}

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private void pln(String s) {
		System.out.println(s);
	}

}
