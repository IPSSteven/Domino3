package com.ibm.ereg.check;

import java.util.Date;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.DateTime;
import lotus.domino.DbDirectory;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class EregChecker extends NotesThread {

	private static  String sMachine;
	private static String pw;
	private static long timeLimit;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//"A,B,C,D,E,F,G,H,I,J,K";
		if (args.length == 3) {
			sMachine = args[0];
			timeLimit = Long.parseLong(args[1]);
			pw = args[2];
			EregChecker ec = new EregChecker();
			ec.start();
		}else {
			pln("Usage: com.im.ereg.check.EregChecker param1 param2\n -> param1 machine keys comma separated (A,B,C..)\n -> param2 = timelimit in seconds");
		}
		
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		int machNum = 1;
		super.runNotes();
		DateTime dteNow;
		DateTime dteMotify;
		long ldiff = 0;
		Document docCheck = null;
		//Document docRec = null
		Session s = NotesFactory.createSessionWithFullAccess(pw);
		Database dbEregLog = CommonFunctions.getDatabase(s, "IDPData1/IDP", "e_dir/ereglog6.nsf");
		View vwBMach = dbEregLog.getView("Logs\\by Machine");
		vwBMach.refresh();
		String [] aryMachs = sMachine.split(",");
		dteNow = s.createDateTime(new Date());
		
		for(String stMach: aryMachs) {
			docCheck = vwBMach.getDocumentByKey(stMach);
			dteMotify = docCheck.getLastModified();
			dteNow.setNow();
			ldiff = dteNow.timeDifference(dteMotify);
			pln("Times:" + ldiff + "-" + timeLimit + "-" + (ldiff > timeLimit));
			if(ldiff > timeLimit) {
				mailit(s,stMach,machNum);
			}
			
			pln(stMach + "("+ machNum+ ")***" + ldiff + "***" + docCheck.getLastModified().getDateOnly() + "-" + docCheck.getLastModified().getGMTTime()+ ":" + docCheck.getItemValueString("Subject"));
			docCheck.recycle();
			machNum ++;
		}
		vwBMach.recycle();
		dbEregLog.recycle();
		s.recycle();
	}
	
	private static void pln(String s) {
		System.out.println(s);
	}
	private void mailit(Session s, String stMachine, int machNum) {
		DbDirectory dir;
		try {
			dir = s.getDbDirectory(null);
			Database dbMail = dir.openMailDatabase();
			pln("mail for machine " +stMachine + "("+ machNum +")");
			Document docMail = dbMail.createDocument();
			docMail.replaceItemValue("Subject", "No activitiy on machine " + stMachine + "("+ machNum +")");
			docMail.replaceItemValue("Sendto", "Kurt Raier1/Germany/Bechtle/IDE");
			docMail.send("Kurt Raiser1/Germany/Bechtle/IDE");
			docMail.recycle();
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	

}
