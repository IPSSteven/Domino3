package com.ibm.eregToolAcl;

public class GetAclProperties {
	private String Pw = "Used2know.";
	private String ToolDBServer = "D06DBL090";
	//private String ToolFilePath ="e_dir/eregtoo6.nsf";
	//private String ToolFilePath ="n_dir/ncouaruk.nsf";
	private String ToolFilePath ="e_dir/ereglog6.nsf";
	private String toolNames = "names.nsf";
	private String EDServer = "D51HUB01";
	private String EDNames = "edircat/scnedcww.nsf";
	private String groupView = "Groups";
	private String nameView = "($Users)";
	private String serverView = "($ServersLookup)";
	
	public String getPw() {
		return Pw;
	}
	public void setPw(String pw) {
		Pw = pw;
	}
	public String getToolDBServer() {
		return ToolDBServer;
	}
	public void setToolDBServer(String toolDBServer) {
		ToolDBServer = toolDBServer;
	}
	public String getToolFilePath() {
		return ToolFilePath;
	}
	public void setToolFilePath(String toolFilePath) {
		ToolFilePath = toolFilePath;
	}
	
	public String getGroupview() {
		return groupView;
	}
	
	public String getNameView() {
		return nameView;
	}
	public void setNameView(String nameView) {
		this.nameView = nameView;
	}
	public String getGroupView() {
		return groupView;
	}
	public void setGroupView(String groupView) {
		this.groupView = groupView;
	}
	public String getServerView() {
		return serverView;
	}
	public void setServerView(String serverView) {
		this.serverView = serverView;
	}
	public String getEDServer() {
		return EDServer;
	}
	public void setEDServer(String eDServer) {
		EDServer = eDServer;
	}
	public String getEDNames() {
		return EDNames;
	}
	public void setEDNames(String eDNames) {
		EDNames = eDNames;
	}
	public String getToolNames() {
		return toolNames;
	}
	public void setToolNames(String toolNames) {
		this.toolNames = toolNames;
	}
	
	

}
