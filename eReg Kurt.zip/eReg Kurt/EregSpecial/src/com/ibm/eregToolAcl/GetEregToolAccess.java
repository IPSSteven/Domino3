package com.ibm.eregToolAcl;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.ACL;
import lotus.domino.ACLEntry;
import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class GetEregToolAccess extends NotesThread {
	private Database dbTool;
	Database dbNames;
	Database dbEDNames;
	View  NameGroup;
	View NameUser;
	View ServerView;
	BufferedWriter bw;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GetEregToolAccess geta = new GetEregToolAccess();
		geta.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		try {
			bw = new BufferedWriter(new FileWriter("c:/temp/out.txt"));

			GetAclProperties gap = new GetAclProperties();
			Session session = NotesFactory.createSessionWithFullAccess(gap.getPw());

			//dbtool
			dbTool = CommonFunctions.getDatabase(session, gap.getToolDBServer(), gap.getToolFilePath());
			//names on server of dbtool
			dbNames = CommonFunctions.getDatabase(session, gap.getToolDBServer(), gap.getToolNames());
			NameGroup = dbNames.getView(gap.getGroupview());
			ServerView = dbNames.getView(gap.getServerView());
			dbEDNames = CommonFunctions.getDatabase(session, gap.getEDServer(), gap.getEDNames());
			NameUser = dbEDNames.getView(gap.getNameView());


			// get all Acl entries of DB tool
			ACL acl = dbTool.getACL();
			ACLEntry acle = acl.getFirstEntry();
			ACLEntry acleRec= null;
			String aName;
			Document docGroup = null;

			while (acle!= null) {
				aName = acle.getName();
				docGroup = getGroup(aName);
				if (docGroup != null) {
					pln("--------------------------------------------- Begin resolving group " + aName +" ----------------------------------\n");
					resolveGroup(aName, getAclLevel(acle) + ", Roles:" + getRoles(acle));
					pln("\n--------------------------------------------- End resolving group " + aName +" ----------------------------------\n\n");
					docGroup.recycle();

				}else if (isUser(aName.toLowerCase())) {
					pln (aName + " is a user access =  " + getAclLevel(acle)); 
				}else if (isServer(aName.toLowerCase())){
					pln (aName + " is a user access =  " + getAclLevel(acle)); 
				}
				acleRec = acle;
				acle = acl.getNextEntry(acle);
				acleRec.recycle();
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private Document getGroup(String aName) {
		Document docRet = null;
		try {
			docRet = NameGroup.getDocumentByKey(aName, true);

		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return docRet ;
	}

	private boolean isUser(String aName) {
		boolean bret = false;
		try {
			bret = (NameUser.getDocumentByKey(aName, true) == null) ? false : true;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bret ;
	}
	private boolean isServer(String aName) {
		boolean bret = false;
		try {
			bret = (ServerView.getDocumentByKey(aName, true) == null) ? false : true;
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bret ;
	}

	private String getAclLevel(ACLEntry entry) {
		String lev = "undefined";
		try {
			switch(entry.getLevel()) {
			case ACL.LEVEL_NOACCESS:
				lev = "no"; break;
			case ACL.LEVEL_DEPOSITOR:
				lev = "depositor"; break;
			case ACL.LEVEL_READER:
				lev = "reader"; break;
			case ACL.LEVEL_AUTHOR:
				lev = "author"; break;
			case ACL.LEVEL_EDITOR:
				lev = "editor"; break;
			case ACL.LEVEL_DESIGNER:
				lev = "designer"; break;
			case ACL.LEVEL_MANAGER:
				lev = "manager"; break;
			}
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lev;
	}

	private void resolveGroup(String aName, String access) {
		Document docGroup = null;
		if(isUser(aName)) {
			pln ("User,"+ aName + "," + access + "\n");
			return;
		}
		docGroup = getGroup(aName);
		if(docGroup != null) {
			try {
				Vector vMembers = docGroup.getItemValue("Members");
				Iterator<String> it = vMembers.iterator();
				while(it.hasNext()) {
					String aNameM = it.next();
					resolveGroup(aNameM, access);
				}
				docGroup.recycle();
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return;
		}

		if(isServer(aName)) {
			pln ("Server, "+ aName + "," + access + "\n");
			return;
		}

	}

	private String getRoles(ACLEntry ae) {{
		Vector<String> vRoles;
		String sRole ="";
		try {
			vRoles = ae.getRoles();
			Iterator<String> it = vRoles.iterator();

			while(it.hasNext()) {
				sRole = sRole + it.next() + ",";
			}
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return sRole;


	}

	}
	private void pln(String s){
		System.out.println(s);
		try {
			bw.write(s);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}




