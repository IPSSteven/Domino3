package com.ibm.erg.AnalyseLog;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.RichTextItem;
import lotus.domino.Session;
import lotus.domino.View;


public class UpdateIdLogs extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UpdateIdLogs rl = new UpdateIdLogs();
		rl.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("updateIds.txt"));
			Session s = NotesFactory.createSessionWithFullAccess("Jac2mac.");
			Database dbLog = CommonFunctions.getDatabase(s, "IDPData1/IDP", "e_dir/ereglog6.nsf");
			View vwlogByAgent = dbLog.getView("Logs\\by Agent");
			DocumentCollection dcc = vwlogByAgent.getAllDocumentsByKey("Update IDs");
			pln("count " + dcc.getCount());
			Document doc = dcc.getFirstDocument();
			Document docRec;
			RichTextItem rtf = null;
			String stText = null;
			while(doc != null) {

				rtf = (RichTextItem)doc.getFirstItem("Body");
				stText = rtf.getUnformattedText();
				if(!stText.contains("No notes found")) {
					bw.write("-----------------------beginn note------------------------------------------------------");
					pln(stText);
					bw.write(stText);
					bw.write("-----------------------end note------------------------------------------------------");
					bw.newLine();
				}

				docRec = doc;
				doc = dcc.getNextDocument(doc);
				docRec.recycle();
			}
			bw.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	private void pln(String s) {
		System.out.println(s);
	}

}
