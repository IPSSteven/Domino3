package com.ibm.functionalids;

public class FunctionalData {
	
	
	private String Domain;
	private String FullName;
	private String Email;
	private String Shortname;
	private boolean isInSCN;
	private boolean isInOnPrem;
	private boolean isOnExchange;
	
	
	
	public String getDomain() {
		return Domain;
	}
	public void setDomain(String domain) {
		Domain = domain;
	}
	public String getFullName() {
		return FullName;
	}
	public void setFullName(String fullName) {
		FullName = fullName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getShortname() {
		return Shortname;
	}
	public void setShortname(String shortname) {
		Shortname = shortname;
	}
	public boolean isInSCN() {
		return isInSCN;
	}
	public void setInSCN(boolean isInSCN) {
		this.isInSCN = isInSCN;
	}
	public boolean isInOnPrem() {
		return isInOnPrem;
	}
	public void setInOnPrem(boolean isInOnPrem) {
		this.isInOnPrem = isInOnPrem;
	}
	public boolean isOnExchange() {
		return isOnExchange;
	}
	public void setOnExchange(boolean isOnExchange) {
		this.isOnExchange = isOnExchange;
	}
	
}
