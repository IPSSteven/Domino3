package com.ibm.functionalids;

public class FunctionalDataSum {
	private String Domain;
	private int numFunctionalIds =0;
	private int numPersonalids = 0;
	private int numMailSCN = 0;
	private int numMailOnprem = 0;
	public String getDomain() {
		return Domain;
	}
	public void setDomain(String domain) {
		Domain = domain;
	}
	public int getNumFunctionalIds() {
		return numFunctionalIds;
	}
	public void setNumFunctionalIds(int numFunctionalIds) {
		this.numFunctionalIds = numFunctionalIds;
	}
	public int getNumPersonalids() {
		return numPersonalids;
	}
	public void setNumPersonalids(int numPersonalids) {
		this.numPersonalids = numPersonalids;
	}
	public int getNumMailSCN() {
		return numMailSCN;
	}
	public void setNumMailSCN(int numMailSCN) {
		this.numMailSCN = numMailSCN;
	}
	public int getNumMailOnprem() {
		return numMailOnprem;
	}
	public void setNumMailOnprem(int numMailOnprem) {
		this.numMailOnprem = numMailOnprem;
	}
	
	public void print() {
		System.out.println(this.Domain+ ","+ numFunctionalIds + ","+ numPersonalids + "," + numMailSCN + "," + numMailOnprem);
	}
	
	public static String getHeader() {
		return "Domain,FunctionalIds,PersonalIds,MailinScn,Mailonprem";
	}
	public String getLine() {
		return this.Domain+ ","+ numFunctionalIds + ","+ numPersonalids + "," + numMailSCN + "," + numMailOnprem;
	}
	
}
