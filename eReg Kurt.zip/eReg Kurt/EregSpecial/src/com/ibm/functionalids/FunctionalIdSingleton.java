package com.ibm.functionalids;

import java.util.HashMap;
import java.util.HashSet;

public class FunctionalIdSingleton {
	
	private static FunctionalIdSingleton functionalIdsingleton;
	private HashSet <String> hsSerialPsc;
	private HashMap <String, FunctionalDataSum> hmfSum = new HashMap<String, FunctionalDataSum>();
	
	private FunctionalIdSingleton() {
		
	}
	
	public static FunctionalIdSingleton getInstance(){
		if(functionalIdsingleton == null){
			synchronized (FunctionalIdSingleton.class) {
				if (functionalIdsingleton == null){
					functionalIdsingleton= new FunctionalIdSingleton();
				}
			}
			
		}
		return functionalIdsingleton;
	}
	
	
	public HashSet<String> getHsSerialPsc() {
		return hsSerialPsc;
	}

	public void setHsSerialPsc(HashSet<String> hsSerialPsc) {
		this.hsSerialPsc = hsSerialPsc;
	}

	public void addFunctionalDataSumm(String domain, FunctionalDataSum fds) {
		hmfSum.put(domain, fds);
	}

	public HashMap<String, FunctionalDataSum> getHmfSum() {
		return hmfSum;
	}

	public void setHmfSum(HashMap<String, FunctionalDataSum> hmfSum) {
		this.hmfSum = hmfSum;
	}
	
	
}

