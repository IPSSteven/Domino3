package com.ibm.functionalids;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.ibm.ereg.config.ConfigObjReConcileITIM;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.mediator.NoReuseDataLoader.NoReuseLoaderThread;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;
import lotus.domino.ViewNavigator;

public class Getfunctionalids extends NotesThread {

	private final String stServer = "D51HUB01";
	private final String stFilePath = "edircat/scnedcww.nsf";
	private final String stvw = "ID Mgmt\\Lookup";
	private final String stFile = "C:\\ereg\\FunctionalIds\\ibmperson1.csv";
	public String stdom;
	public String pw;
	private FunctionalIdSingleton fis = FunctionalIdSingleton.getInstance();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int iThreadsMax = 16;
		Getfunctionalids gf;
		boolean bgetSerial = false;
		String line;
		ArrayList<String> al = new ArrayList<String>();
		try {
			BufferedReader bf = new BufferedReader(new FileReader("C:\\ereg\\FunctionalIds\\domains.txt"));
			while ((line = bf.readLine()) != null) {
				al.add(line);
			}
			bf.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		String [] aryDom = al.toArray(new String[al.size()]);
		
		ExecutorService executorServ = Executors.newFixedThreadPool(iThreadsMax);
		
		for(String stdom: aryDom) {
			gf  = new Getfunctionalids();
			gf.setName("Thread-"+stdom);
			gf.stdom = stdom;
			gf.pw = "ja13komo";
			if (!bgetSerial) {
				gf.getSerialNumbers();
				bgetSerial = true;
			}
			executorServ.execute(gf);
		}
		
		
		executorServ.shutdown(); // means not new tasks are accepted anymore
		if(executorServ != null){
			try {
				executorServ.awaitTermination(180, TimeUnit.MINUTES);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} // wait 180 minutes .. this should be sufficient

		}
		
		FunctionalIdSingleton fis = FunctionalIdSingleton.getInstance();
		Set sk = fis.getHmfSum().keySet();
		Iterator<String> it = sk.iterator();
		String dom;
		while(it.hasNext()) {
			dom = (String)it.next();
			fis.getHmfSum().get(dom).print();
		}
		
		BufferedWriter bw;
		try {
			bw = new BufferedWriter(new FileWriter("C:\\ereg\\FunctionalIds\\out.csv"));
			bw.write(FunctionalDataSum.getHeader());
			it = sk.iterator();
			while(it.hasNext()) {
				dom = (String)it.next();
				bw.write(fis.getHmfSum().get(dom).getLine() +"\n");
			}
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		long startime = System.currentTimeMillis();
		super.runNotes();
		String serialpsc;
		String mailServer;
		FunctionalDataSum fds = new FunctionalDataSum();
		fds.setDomain(stdom);
		
		Session s = NotesFactory.createSessionWithFullAccess(pw);
		Database db = s.getDatabase(stServer, stFilePath);
		View vw = db.getView(stvw);
		ViewEntry ve;
		ViewEntry veR;
		ViewNavigator vn = vw.createViewNavFromCategory(stdom);
		vw.setAutoUpdate(false);
		vn.setCacheGuidance(1024, ViewNavigator.VN_CACHEGUIDANCE_READALL);
		
		ve = vn.getFirst();
		while( ve != null) {
			
			try {
				mailServer = ve.getColumnValues().elementAt(11).toString();
				serialpsc = ve.getColumnValues().elementAt(1).toString() + ve.getColumnValues().elementAt(2).toString();
			
				if( mailServer.contains("NALL")){
					fds.setNumMailSCN(fds.getNumMailSCN()+1);
				}else {
					fds.setNumMailOnprem(fds.getNumMailOnprem() +1);
				}
				
				if( fis.getHsSerialPsc().contains(serialpsc)) {
					fds.setNumPersonalids(fds.getNumPersonalids()+1);
				}else {
					fds.setNumFunctionalIds(fds.getNumFunctionalIds() +1);
					//pln(this.getName() + ":" + ve.getColumnValues().elementAt(7).toString() + " is a functional id" );
				}
			
			} catch (NotesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			veR= ve;
			ve = vn.getNext(); 
			veR.recycle();
		}
		
		fis.addFunctionalDataSumm(stdom, fds);
		pln("***************************" + this.getName() + " ended after " + (System.currentTimeMillis() - startime));

	}



	private void getSerialNumbers() {
		int iline = 0;
		String line;
		String []ary;
		String serialPsc;
		fis.setHsSerialPsc(new HashSet<String>());
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(stFile));
			while ((line=br.readLine()) != null) {
				ary = line.split(",,");
				if(ary.length >1) {
					ary = ary[1].replace("\"", "").split(",");
					if (ary.length < 3) {
						pln(line);
					}else {
						serialPsc = ary[1]+ ary[2];
						fis.getHsSerialPsc().add(serialPsc);
					}
				
					iline++;
					if(iline%10000 == 0) {
						pln("working on line " + iline );
					}
				}
			}
			br.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private void pln(String s) {
		System.out.println(s);
	}

}
