package com.ibm.getIsimInfo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CompareWithOld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line;
		String service;
		String shortName;
		String empSerial;
		String mgrserial;
		String [] parts;
		int iLen = 0;
	
		DataSingleton ds = DataSingleton.getInstance();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("UBC.csv"));
			while((line = br.readLine()) != null){
				parts = line.split(";");
				iLen = parts.length;
				if (iLen == 11){
					service = parts[0];
					shortName = parts[1];
					empSerial = parts[3];
					mgrserial = parts[6];
					ds.getSerialIDMgr().put(empSerial, mgrserial);
					//ds.getServiceShortnameMgr().put(service +"$$$" +shortName, mgrserial);
				}
			}
			br.close();
			
			ds.writeResult2File("oldoutput.txt");

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
