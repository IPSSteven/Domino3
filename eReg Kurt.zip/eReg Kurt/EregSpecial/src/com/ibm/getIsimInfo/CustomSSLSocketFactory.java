package com.ibm.getIsimInfo;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Comparator;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class CustomSSLSocketFactory<T> extends SSLSocketFactory implements Comparator<String> {
	private final String[] SECURE_PROTOCOL_LIST = {"TLSv1.2"} ;

	@SuppressWarnings("rawtypes")
	private static final CustomSSLSocketFactory singleton = new CustomSSLSocketFactory();
	private final SSLSocketFactory base;
	
	@SuppressWarnings("rawtypes")
	public static CustomSSLSocketFactory getDefault() {
        return singleton;
    }
	
	public CustomSSLSocketFactory() {
		base = (SSLSocketFactory) SSLSocketFactory.getDefault();
	}
	
	private Socket restrictProtocols(Socket socket) {
        if (!(socket instanceof SSLSocket)) {
            return socket;
        }
        SSLSocket sslSocket = (SSLSocket) socket;
        sslSocket.setEnabledProtocols(SECURE_PROTOCOL_LIST);
        return sslSocket;
    }
	
	@Override
	public Socket createSocket(Socket socket, String host, int port, boolean autoClose) throws IOException {
		return restrictProtocols(base.createSocket(socket, host, port, autoClose));
	}

	@Override
	public String[] getDefaultCipherSuites() {
		return base.getDefaultCipherSuites();
	}

	@Override
	public String[] getSupportedCipherSuites() {
		return base.getSupportedCipherSuites();
	}

	@Override
	public Socket createSocket(String host, int port) throws IOException, UnknownHostException {
		return restrictProtocols(base.createSocket(host, port));
	}

	@Override
	public Socket createSocket(InetAddress address, int port) throws IOException {
		return restrictProtocols(base.createSocket(address, port));
	}

	@Override
	public Socket createSocket(String host, int port, InetAddress localHost, int localPort)
			throws IOException, UnknownHostException {
		return restrictProtocols(base.createSocket(host, port, localHost, localPort)) ;
	}

	@Override
	public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws IOException {
		return restrictProtocols(base.createSocket(address, port, localAddress, localPort));
	}

	public int compare(String myObject, String anotherObject) {
		// TODO Auto-generated method stub
		return 0;
	}

}

/*
 * Note:  taken from examples shown here:  https://discretemkt.wordpress.com/2014/11/08/letting-jndi-disable-sslv3
 */
