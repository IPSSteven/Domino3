package com.ibm.getIsimInfo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;



public class DataSingleton {
	private static DataSingleton  ds = null;
	private TreeMap<String, String> tmID_Mgr = new TreeMap<String, String>(); // serial user/ serial manager and shortname user/serial manager
	//private TreeMap<String, String> tsServiceShortnameMgr = new TreeMap<String, String>();
	private TreeSet<String> tsServiceNames = new TreeSet<String>();
	
	
	private DataSingleton() {
		// TODO Auto-generated constructor stub
	}

	public static DataSingleton getInstance(){
		if(ds == null){
			synchronized (DataSingleton.class) {
				if(ds == null){
					ds = new DataSingleton();
				}	
			}
			
		}
		return ds;
	}

	public TreeMap<String, String> getSerialIDMgr() {
		return tmID_Mgr;
	}

	//public TreeMap<String, String> getServiceShortnameMgr() {
	//	return tsServiceShortnameMgr;
	//}



	public synchronized  void removeService (String serviceName){
		if(this.tsServiceNames != null){
			tsServiceNames.remove(serviceName);
		}
	}

	public synchronized String getnextService(){

		String stRet = null;

		Iterator<String> it = this.tsServiceNames.iterator();
		if(it.hasNext()){
			stRet = it.next();
		}

		return stRet;
	}

	public synchronized void  addService(String service) {
		tsServiceNames.add(service);
	}
	
	public int getSericeNameNumber(){
		return tsServiceNames.size();
	}

	public void addSerialIDMgr(String id, String mgr){
		if(id != null && mgr != null){
			tmID_Mgr.put(id, mgr);
		}
		
	}
	
	//public void addsericeSortnameManager(String service, String shortname, String mgr){
	//	if(service !=null && shortname != null & mgr != null){
	//		tsServiceShortnameMgr.put(service + "$$$" + shortname, mgr);
	//	}
	//}


	public void writeResult2File(String sFile){
		//DataSingleton ds= DataSingleton.getInstance();
		String stKey;
		String stValue;
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("isimSerialMgr" +sFile));
			
			bw.write("serialID serialManager");
			bw.newLine();
			Set<String> s = getSerialIDMgr().keySet();
			Iterator<String> it = s.iterator();
			while(it.hasNext()){
				stKey = it.next();
				stValue = getSerialIDMgr().get(stKey);
				bw.write(stKey + ";" + stValue);
				bw.newLine();
			}
			bw.close();
			
	/*		bw = new BufferedWriter(new FileWriter("isimShortMgr" +sFile));
			s = getServiceShortnameMgr().keySet();
			it = s.iterator();
			while(it.hasNext()){
				stKey =it.next();
				stValue = getServiceShortnameMgr().get(stKey);
				bw.write(stKey + ";" + stValue);
				bw.newLine();
			}
		
			bw.close();
			*/	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}	
	

}
