package com.ibm.getIsimInfo;


import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import javax.naming.NamingException;



public class ExportOwnerInfoNew implements Runnable {

	private HashMap<String, String> hmSearch = null;
	private TreeMap<Long,TreeMap<String, String>> hmResultC = null;
	private IsimLdapReader ilrC = null;
	private String ServiceOrphanglobalID = null;


	public static void main(String[] args) {

		//ExportOwnerInfoNew oie = new ExportOwnerInfoNew();
		//oie.runTheExport();

		runTheExport();

		// TODO Auto-generated method stub
		/*String stLdapBase = null;
		String[] arrSearchAttr = null;
		int iThreadMax = 16;
		long lmillStart = System.currentTimeMillis();

		ExecutorService executor = null;
		DataSingleton ds = null;

		ExportOwnerInfoNew eoi = new ExportOwnerInfoNew();

			try {
				// get all the services
				eoi.ilrC = new IsimLdapReader();
				// 1. get all services
				eoi.hmSearch = new HashMap<String, String>();
				eoi.hmSearch.put("objectClass", "eritim2lnotesservice");
				eoi.hmSearch.put("erServiceName", "IGA*");
				//eoi.hmSearch.put("erServiceName", "IGA:IBMA*");
				stLdapBase ="ou=services,erglobalid=00000000000000000000,ou=IBM,DC=ITIM";
				arrSearchAttr = "erServiceName".split(";");
				eoi.hmResultC =  eoi.ilrC.getResults(eoi.hmSearch, arrSearchAttr,stLdapBase);
				ds = DataSingleton.getInstance();

				executor = Executors.newFixedThreadPool(iThreadMax);
				for(int i =0; i<ds.getSericeNameNumber(); i++){
					ExportOwnerInfoNew eoit = new ExportOwnerInfoNew();
					executor.execute( eoit );
				}

				executor.shutdown();



			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				if(executor != null){
					executor.awaitTermination(90, TimeUnit.MINUTES);
					ds.writeResult2File("idOwner1.txt");
				}


			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("-------------------commplete export time "+ (System.currentTimeMillis()- lmillStart));
		 */



		/*
		 * try {
			ThreadGroup tg = new ThreadGroup("Services");
            int idum = 0;
			while(ds.getSericeNameNumber()>0  ){
				//if (ds.getiThreadAcitve() < iThreadMax){
				idum = tg.activeCount(); 
				if (tg.activeCount() < iThreadMax){
					ExportOwnerInfoNew eoit = new ExportOwnerInfoNew();
					Thread t = new Thread(tg, eoit);
					t.start();
					//ds.changeiThreadAcitve(1);
				}
				idum = tg.activeCount(); 
				if(tg.activeCount() >= iThreadMax && ds.getSericeNameNumber() >0){
					try {
						Thread.sleep(30000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}

			// wait until all threads are finished
			idum = tg.activeCount(); 
			while (tg.activeCount()>0) {
				System.out.println ("active threads = " + tg.activeCount());
				try {
					Thread.sleep(30000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			// all threads are done . wrrite result to file
			System.out.println("------All threads done --- write results to file -------");
			ds.writeResult2File("idOwner1.txt");
			System.out.println("ready");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		System.out.println("-------------------commplete export time "+ (System.currentTimeMillis()- lmillStart));

		 */

	}

	public static void runTheExport(){
		// TODO Auto-generated method stub
		String stLdapBase = null;
		String[] arrSearchAttr = null;
		int iThreadMax = 16;
		long lmillStart = System.currentTimeMillis();

		ExecutorService executor = null;
		DataSingleton ds = null;

		ExportOwnerInfoNew eoi = new ExportOwnerInfoNew();

		try {
			// get all the services
			eoi.ilrC = new IsimLdapReader();
			// 1. get all services
			eoi.hmSearch = new HashMap<String, String>();
			eoi.hmSearch.put("objectClass", "eritim2lnotesservice");
			eoi.hmSearch.put("erServiceName", "IGA*");
			//eoi.hmSearch.put("erServiceName", "IGA:IBMA*");
			stLdapBase ="ou=services,erglobalid=00000000000000000000,ou=IBM,DC=ITIM";
			arrSearchAttr = "erServiceName".split(";"); // trick to get an array

			eoi.hmResultC =  eoi.ilrC.getResults(eoi.hmSearch, arrSearchAttr,stLdapBase);
			eoi.getAllSericeNames(); // reults are written to the DataSingleton
			ds = DataSingleton.getInstance();

			executor = Executors.newFixedThreadPool(iThreadMax);
			for(int i =0; i<ds.getSericeNameNumber(); i++){
			//for(int i =0; i<3; i++){
				ExportOwnerInfoNew eoit = new ExportOwnerInfoNew();
				executor.execute( eoit );
			}

			executor.shutdown();		

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//throw e;
		}

		try {
			if(executor != null){

				System.out.println("Start waiting until all threads are done");
				executor.awaitTermination(240, TimeUnit.MINUTES); // wait 4 hours .. this should be sufficient
				System.out.println("all threads are done now, write result to file");
				ds.writeResult2File("idOwner1.txt");
			}


		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//throw e;
		}
		System.out.println("-------------------commplete export time "+ (System.currentTimeMillis()- lmillStart));


	}



	@Override
	public void run() {
		// TODO Auto-generated method stub

		long lmillStart;
		String [] arrSearchAttr;
		String stLdapBase;
		String sServiceGlobalid;

		DataSingleton ds = DataSingleton.getInstance();
		String handledService = ds.getnextService();
		if(handledService == null){
			return;
		}
		ds.removeService(handledService);

		try {
			ilrC = new IsimLdapReader();
			lmillStart = System.currentTimeMillis();
			System.out.println("start for service "+ handledService);
			// 1. Get Service globalID
			this.hmSearch = new HashMap<String, String>();
			this.hmSearch.put("erServiceName", handledService);
			arrSearchAttr = "erglobalid".split(";"); // Trick to get Array
			stLdapBase = "ou=services,erglobalid=00000000000000000000,ou=IBM,DC=ITIM";
			this.hmResultC =  ilrC.getResults(this.hmSearch, arrSearchAttr,stLdapBase);
			sServiceGlobalid = this.getGlobalid();
			//System.out.println("globalid for service "+ handledService +" after " + (System.currentTimeMillis()- lmillStart));
			//lmillStart = System.currentTimeMillis();

			// 2. Get the orphan global id of the service
			this.hmSearch = new HashMap<String, String>();
			this.hmSearch.put("sn", handledService);
			this.hmSearch.put("uid",handledService + "_orphan");
			arrSearchAttr = "erglobalid".split(";");
			stLdapBase = "ou=people,erglobalid=00000000000000000000,ou=IBM,DC=ITIM";
			this.hmResultC =  ilrC.getResults(this.hmSearch, arrSearchAttr,stLdapBase);
			this.ServiceOrphanglobalID = this.getGlobalid();
			//System.out.println("got orphan id for service " + handledService + " after " + (System.currentTimeMillis()- lmillStart));
			//lmillStart = System.currentTimeMillis();


			// 3. Get all Notes Accounts of the service
			this.hmSearch = new HashMap<String, String>();
			this.hmSearch.put("erService","erglobalid="+ sServiceGlobalid + "*");
			this.hmSearch.put("objectClass", "erAccountItem");
			arrSearchAttr = "erlnserial;erlnnabserial;owner;eruid".split(";");
			stLdapBase = "ou=0,ou=accounts,erglobalid=00000000000000000000,ou=IBM,DC=ITIM";
			this.hmResultC = ilrC.getResults(this.hmSearch, arrSearchAttr);
			//System.out.println("got accounts for service " + handledService + " after " + (System.currentTimeMillis()- lmillStart));
			//lmillStart = System.currentTimeMillis();

			// 3. get the manager info 
			this.enRichtManager();
			//System.out.println("got manager info for service " + handledService + " after " + (System.currentTimeMillis()- lmillStart));
			//lmillStart = System.currentTimeMillis();

			// 4. write to DataSingleton
			String[] arrtmp = handledService.split(":");
			if(arrtmp.length  == 2){
				this.putResults(arrtmp[1]);
			}{
				this.putResults(arrtmp[0]);
			}

			//System.out.println("put findings  for service in map " + handledService + " after " + (System.currentTimeMillis()- lmillStart));

			// 5.close the ldap connection
			ilrC.close();
			System.out.println("end  for service "+ handledService +" after " + (System.currentTimeMillis()- lmillStart));

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String getGlobalid (){
		Set<Long> setKey = this.hmResultC.keySet();
		TreeMap<String, String> hmNameValue;
		Iterator<Long> it = null;
		String result = null;

		it = setKey.iterator();
		while(it.hasNext()){
			Long lnum = it.next();
			hmNameValue =this.hmResultC.get(lnum);
			result = hmNameValue.get("erglobalid");
		}

		return result.trim();
	}

	private void enRichtManager(){
		Set<Long> setKey = this.hmResultC.keySet();
		Set<Long> setKeyNV = null;
		TreeMap<String, String> hmNameValue;
		TreeMap<String,String>hmNameValuePerson;
		Iterator<Long> it = null;
		Iterator<Long>itNV = null;
		Long lKey = null;
		String ownerglobalid = null;
		TreeMap<Long,TreeMap<String, String>> hmResultL = null;
		String stLdapBase = null;

		it = setKey.iterator();
		while (it.hasNext()){
			lKey = it.next();
			hmNameValue = this.hmResultC.get(lKey); // this are the name values of the result, <Long, HashMap<String,String>
			ownerglobalid = hmNameValue.get("owner");
			if (ownerglobalid == null) continue;
			String [] ownerglobalidparts = ownerglobalid.split(",");
			ownerglobalidparts = ownerglobalidparts[0] .split("=");

			// if the id is orphan no search is needed anymore
			if(ownerglobalidparts[1].equals(this.ServiceOrphanglobalID)){
				hmNameValue.put("managerserialnumber", "orphan");
				hmNameValue.put("managercountrycode", "");
				continue;
			}

			// get the person owner
			this.hmSearch = new HashMap<String, String>();
			this.hmSearch.put(ownerglobalidparts[0], ownerglobalidparts[1]);
			//this.hmSearch.put("objectclass","erPersonItem");
			String[] arrSearchAttr = "uid,sn,manager,managerserialnumber,managercountrycode".split(",");
			stLdapBase = "ou=0,ou=people,erglobalid=00000000000000000000,ou=IBM,DC=ITIM";

			hmResultL= this.ilrC.getResults(this.hmSearch, arrSearchAttr,stLdapBase ); // <Lomg, HashMap<String,String>
			setKeyNV = hmResultL.keySet();
			itNV = setKeyNV.iterator();
			if(itNV.hasNext()){
				hmNameValuePerson =  hmResultL.get(itNV.next());
				Set<String> setKeyP = hmNameValuePerson.keySet();
				Iterator<String> itp = setKeyP.iterator();
				String stkey;
				String stvalue;
				while(itp.hasNext()){
					stkey = itp.next();
					stvalue = hmNameValuePerson.get(stkey);
					hmNameValue.put(stkey, stvalue);
				}
			}
		}
	}

	private void putResults(String service){
		Set<Long> setKeys = this.hmResultC.keySet();
		Set<String> setName;
		Iterator<String>itN;
		Iterator<Long>it = setKeys.iterator();
		boolean bHeaderout = false;
		Long lKey = null;
		TreeMap<String, String> hmNameValue = null;
		String stKey;
		String stValue;
		//StringBuilder sbHeader = new StringBuilder();
		//StringBuilder sbLine;
		String serialID = null;
		String serialManager = null;
		String serialNotes = null;
		String pscManager =null;
		String shortName = null;
		String serialPSCManager = null;
		boolean isFunctional = false;
		DataSingleton ds = DataSingleton.getInstance();

		while (it.hasNext()){
			lKey = it.next();
			hmNameValue = this.hmResultC.get(lKey);
			setName = hmNameValue.keySet();
			itN = setName.iterator();
			//sbLine = new StringBuilder();
			serialID = null;
			serialManager = null;
			serialNotes = null;
			pscManager =null;
			shortName = null;
			isFunctional = false;

			while(itN.hasNext()){
				stKey = itN.next();
				stValue = hmNameValue.get(stKey);
				if(stKey.equals("erlnnabserial")&& serialID == null){
					serialID = stValue;
					//sbLine.append(stValue + ";");
				}
				if(stKey.equals("erlnserial")&& serialNotes == null){
					serialNotes  = stValue;
					//sbLine.append(stValue + ";");
				}
				if(stKey.equals("managercountrycode")&&  pscManager == null){
					pscManager = stValue;
					//sbLine.append(stValue + ";");
				}
				if(stKey.equals("managerserialnumber")&&  serialManager == null){
					serialManager = stValue;
					//sbLine.append(stValue + ";");
				}
				if(stKey.equals("sn") && stValue.equals("functionalPerson")){
					isFunctional = true;
					//sbLine.append(stValue + ";");
				}
				if(stKey.equals("eruid") && shortName == null){
					shortName = stValue;
					//sbLine.append(stValue + ";");
				}

			}

			if(isFunctional){
				//bw.write(serialID + ";" + serialNotes );
				ds.addSerialIDMgr(serialID,serialNotes);
				ds.addSerialIDMgr(service + "$$$"+ shortName, serialNotes);
				//ds.addsericeSortnameManager(service, shortName, serialNotes);
			}else{
				//bw.write(serialID + ";" + serialManager + pscManager  );
				serialPSCManager = serialManager + pscManager;
				ds.addSerialIDMgr(serialID,serialPSCManager );
				ds.addSerialIDMgr(service + "$$$"+ shortName,serialPSCManager);
				//ds.addsericeSortnameManager(service, shortName,serialPSCManager);
			}
			//bw.newLine();

		}
		//bw.close();	



	}

	private void getAllSericeNames(){
		DataSingleton ds = DataSingleton.getInstance();
		Long LKey = null;
		Set<Long> keySet = this.hmResultC.keySet(); // results of the service name
		Iterator<Long> it =  keySet.iterator();
		TreeMap<String,String> nameVal = null;
		String stServiceName = null;


		while(it.hasNext()){
			LKey = it.next();
			nameVal = this.hmResultC.get(LKey);
			stServiceName = nameVal.get("erServiceName");
			ds.addService(stServiceName);
		};

	}



}
