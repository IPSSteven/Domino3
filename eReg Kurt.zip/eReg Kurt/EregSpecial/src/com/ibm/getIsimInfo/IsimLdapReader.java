package com.ibm.getIsimInfo;


import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import com.ibm.secure.PasswordHandler;


public class IsimLdapReader {
	private Hashtable<String, String> env;
	public final static String LDAP_READER_PROPERTIES = "IsimLdapReaderProperties.txt";
	public final static String LDAP_SECURITY_CREDENTIALS = "SECURITY_CREDENTIALS";
	private final String LDAP_BASE = "DC=ITIM";
	private DirContext ctx = null;
	//private LdapContext ctx = null;


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			IsimLdapReader il = new IsimLdapReader();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public IsimLdapReader () throws IOException{
		Properties ldapProp = null;
		String pw = null;

		Reader fReader = new FileReader(LDAP_READER_PROPERTIES);
		PasswordHandler ph = new PasswordHandler();
		ldapProp = new Properties();
		ldapProp.load(fReader);
		

		env = new Hashtable<String, String>();
		env.put(Context.PROVIDER_URL,ldapProp.getProperty("PROVIDER_URL"));
		env.put(Context.INITIAL_CONTEXT_FACTORY, ldapProp.getProperty("INITIAL_CONTEXT_FACTORY"));
		env.put(Context.SECURITY_AUTHENTICATION,ldapProp.getProperty("SECURITY_AUTHENTICATION"));
		env.put(Context.SECURITY_PRINCIPAL, ldapProp.getProperty("SECURITY_PRINCIPAL"));
		
		//env.put(Context.SECURITY_PROTOCOL, "TLSv1.1");
		env.put(Context.SECURITY_PROTOCOL, "ssl") ;
		env.put("java.naming.ldap.factory.socket", CustomSSLSocketFactory.class.getName());
		//env.put("java.naming.security.ssl.ciphers", "SSL_RSA_EXPORT_WITH_RC4_40_MD5");

		pw = ldapProp.getProperty("SECURITY_CREDENTIALS");
		pw = ph.getPw(PasswordHandler.kindOfLDAP);
		env.put(Context.SECURITY_CREDENTIALS, pw);
		env.put("com.sun.jndi.ldap.read.timeout", ldapProp.getProperty("SEARCH_TIMEOUT"));



	}

	public TreeMap<Long, TreeMap<String, String>> getResults(HashMap<String,String> hmSearchValues, String[] stResultAttributes) throws NamingException{
		return getResults(hmSearchValues,stResultAttributes,null);
	}


	public TreeMap<Long, TreeMap<String, String>> getResults(HashMap<String,String> hmSearchValues, String[] stResultAttributes, String stLdapBase){
		String ldapSearchFilter;
		Set<String> setKeys;
		String stKey;
		Iterator<String> it;
		StringBuffer sbSearch = null;
		int iTryMax = 5;
		int iTry = 0;

		// 1. get the filter
		if(hmSearchValues == null || hmSearchValues.size() == 0){
			ldapSearchFilter = "";
		}else{
			sbSearch = new StringBuffer();
			sbSearch = new StringBuffer();
			setKeys = hmSearchValues.keySet();
			it = setKeys.iterator();
			while (it.hasNext()){
				stKey = it.next();
				sbSearch.append("(" + stKey+ "=" + hmSearchValues.get(stKey) + ")");
			}
			if(hmSearchValues.size() >1){
				ldapSearchFilter = "(&" + sbSearch.toString() +")";
			}else{
				ldapSearchFilter = sbSearch.toString();
			}
		}

		// 2. the search control
		SearchControls searchControls = new SearchControls();
		searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE); // search the entire subtree
		searchControls.setReturningAttributes(stResultAttributes);

		// 3. do the search
		NamingEnumeration<SearchResult> results;
		SearchResult sRes = null;
		Attributes atts = null;
		Attribute att = null;
		NamingEnumeration<? extends Attribute> attsNamingEnum = null;
		String stValue = null;
		int idx = 0;
		long lcount = 0;
		TreeMap<Long, TreeMap<String, String>> hmResult = new TreeMap<Long, TreeMap<String, String>>();
		TreeMap<String,String> hmNameValue = null;

		iTry = 0;
		while (ctx == null && iTry < iTryMax){
			try {
				ctx = new InitialDirContext(env);
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			iTry ++;
		}

		iTry = 0;
		results = null;
		while (results == null && iTry < iTryMax){
			try {
				if (stLdapBase == null){
					results = ctx.search(LDAP_BASE, ldapSearchFilter, searchControls);

				}else{
					results = ctx.search(stLdapBase, ldapSearchFilter, searchControls);
				}
			}catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		if(results != null){
			while(results.hasMoreElements()){
				try {
					sRes = results.next();


					atts =  sRes.getAttributes(); // get all attributes of the result
					attsNamingEnum = atts.getAll(); // get the enumeration of all attributes of the result;
					// now loop through the results
					hmNameValue = new TreeMap<String, String>();

					while (attsNamingEnum.hasMoreElements()){
						att = attsNamingEnum.next();
						stKey = att.getID();

						stValue = att.toString();
						idx = stValue.indexOf(":") +1;
						stValue = stValue.substring(idx);
						hmNameValue.put(stKey.trim(), stValue.trim());
					}
					hmResult.put(Long.valueOf(lcount), hmNameValue);
					lcount ++;
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}

		return hmResult;

	}
	public void close(){
		if(ctx != null)
			try {
				ctx.close();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
