package com.ibm.helper;

import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;

import lotus.domino.Session;
import lotus.domino.Stream;
import lotus.domino.View;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;


import lotus.domino.Database;

import lotus.domino.Document;

import lotus.domino.DxlExporter;

public class CertifierExtractor extends NotesThread {

	private final String stEregtoolServer = "D06DBL090";
	private final String steregtoolFilepath = "e_dir/eregToo6.nsf";
	private final String stViewCert = "Single Types\\Type 6";
	private final String stFilePath = "c:\\temp\\cert\\";
	private final String stFilePathidfile = "S:\\Registration\\";
	//private final String stFileIn = "a-C.csv";
	//private final String stFileOut = "a-C.log";
	//private final String stFileIn = "D-H.csv";
	//private final String stFileOut = "D-H.log";
	//private final String stFileIn = "I-M.csv";
	//private final String stFileOut = "I-M.log";
	//private final String stFileIn = "N-P.csv";
	//private final String stFileOut = "N-P.log";
	private final String stFileIn = "T-Z.csv";
	private final String stFileOut = "T-Z.log";
	private Database eregTool;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CertifierExtractor ce = new CertifierExtractor();
		ce.start();
	}

	
	public void runNotessic() throws NotesException{
		super.runNotes();
		
		Session s = NotesFactory.createSessionWithFullAccess("Used2know.");
		eregTool =  CommonFunctions.getDatabase(s, stEregtoolServer, steregtoolFilepath);
		View vweregTool = eregTool.getView(stViewCert);
		Document doc;
		String line;
		String []dummy;
		String stCertR;
		String stCertC;
		String pw;
		boolean pwMatch;
	
		try {
			BufferedReader br = new BufferedReader( new FileReader(stFilePath + stFileIn));
			BufferedWriter bw = new BufferedWriter(new FileWriter(stFilePath + stFileOut));
			while((line = br.readLine()) != null){
				dummy = line.split(",");
				stCertR = dummy[0] + "/IBM";
				stCertC = dummy[0] +"/Contr/IBM";
				
				doc = vweregTool.getDocumentByKey(stCertR);
				if(doc == null) {
					bw.write(stCertR + " : document needs to be created \n");
					//createCertDocu(stCertR, dummy[1],dummy[0], "R", bw);
					
				}else {
					
					pw = doc.getItemValueString("V2");
					pwMatch = pw.equals(dummy[1]);
					bw.write(stCertR + " : document already exits " +( pwMatch ? "password identical \n": "password different \n"));
					doc.recycle();		
				}
				
				doc = vweregTool.getDocumentByKey(stCertC);
				if(doc == null) {
					bw.write(stCertR + " : document needs to be created \n");
					//createCertDocu(stCertR, dummy[1],dummy[0], "C", bw);
					
				}else {
					
					pw = doc.getItemValueString("V2");
					pwMatch = pw.equals(dummy[1]);
					bw.write(stCertR + " : document already exits " +( pwMatch ? "password identical \n ": "password different \n"));
					doc.recycle();		
				}
				
			}
			br.close();
			bw.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	private boolean createCertDocu(String subject, String idFile, String pw){
		
		String idF;
		String idfile [] = new String [2];
		
		Vector venCry = new Vector<String>();
		venCry.add("NCOUAR_ITIM");
		
		try {
			Document docCert = eregTool.createDocument();
			docCert.replaceItemValue("Form", "ESetting");
			docCert.replaceItemValue("Type", 6);
			docCert.replaceItemValue("Subject", subject);
			docCert.replaceItemValue("V1", idFile);
			docCert.replaceItemValue("V2", pw);
			docCert.setEncryptionKeys(venCry);
			docCert.getFirstItem("V1").setEncrypted(true);
			docCert.getFirstItem("V2").setEncrypted(true);
			docCert.encrypt();
			docCert.save();
		
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return true;
		
	}
	
	@Override
	public void runNotes() {
		
		Session s;
		try {
			s = NotesFactory.createSessionWithFullAccess("Used2know.");
			eregTool =  CommonFunctions.getDatabase(s, stEregtoolServer, steregtoolFilepath);

		} catch (NotesException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
		String stFile = "C:\\Temp\\cert\\CitiesA-D.csv";
		BufferedReader br;
		String line;
		String [] dummy;
		String stReg;
		String stCont;
		String stRegF;
		String stContF;
		String stPw;
		String stContry;
		try {
			br = new BufferedReader(new FileReader(stFile));
			while((line = br.readLine()) != null) {
				dummy = line.split(",");
				stPw = dummy[1];
				stReg = dummy[0]+ "/IBM";
				stCont = dummy[0] + "/Contr/IBM";
				stContry = dummy[0].replaceAll(" ","");
				stContry = stContry.toUpperCase();
 				stRegF = "IBM_R_" + stContry+ ".ID";
 				stContF = "IBM_C_" + stContry+ ".ID";
 				createCertDocu(stReg, stRegF, stPw);
 				pln("created " + stReg);
 				createCertDocu(stCont, stContF, stPw);
 				pln("created " + stCont);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void runNotesOLD() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		
		Session s = NotesFactory.createSessionWithFullAccess("Used2know.");
		
		Database dbMail = CommonFunctions.getDatabase(s, "NALLN17/40/LLN/IBM", "data2/126/1000869355.nsf");
		View vwCert = dbMail.getView("Cert");
		//DocumentCollection dcc = dbMail.search("Form = \"Memo\" & Subject = \"Countries A-C\"");
		Document docR;
		Document doc = vwCert.getFirstDocument();
		String subject = doc.getItemValueString("Subject");
		String fileName;
		Stream stream = s.createStream();
		DxlExporter exporter;
		while (doc!=null) {
			if(subject.indexOf("Cities")>0) {
				pln(subject);
				fileName = "c:\\temp\\export"+ subject +".dxl";
				stream.open(fileName);
				stream.truncate();
				exporter = s.createDxlExporter();
				stream.writeText(exporter.exportDxl(doc));
				stream.close();
				stream.recycle();
				exporter.recycle();
			}
			docR = doc;
			doc = vwCert.getNextDocument(doc);
			docR.recycle();
			
			
		}
		
		//RichTextItem rtf = (RichTextItem)doc.getFirstItem("Body");
	/*	pln("--------------------------------------------------------------");
		pln(rtf.getText());
		pln("--------------------------------------------------------------");
		
		pln("--------------------------------------------------------------");
		pln(rtf.getFormattedText(true, 0, 0));
		pln("--------------------------------------------------------------");
		
		
		pln("--------------------------------------------------------------");
		pln(rtf.getUnformattedText());
		pln("--------------------------------------------------------------");
		*/
		/*
		RichTextNavigator rtfn =rtf.createNavigator();
		
		//rtfn.findFirstString("CONTRACTOR");
		rtfn.findFirstElement(RichTextItem.RTELEM_TYPE_TABLE);
		RichTextRange rtfr = rtf.createRange();
		rtfr.setBegin(rtfn);
		String sdumm =rtfr.getTextRun();
		pln	(sdumm);
		Base element;
		for (int i = 0 ; i<8 ; i++) {
			//rtfn.findNextElement(RichTextItem.RTELEM_TYPE_TABLECELL);	
			rtfn.findNextElement();
			element = rtfn.getElement();
			
			rtfr.setBegin(rtfn);
		
			pln( "L1 " + i +  element.getClass().getTypeName() +"-->"+  rtfr.getTextRun() + "-"  +	rtfr.getType() );
			element.recycle();
			//sdumm = rtfr.getTextRun();
			//pln (sdumm);
		}
		
		for (int i = 0 ; i<8 ; i++) {
			//rtfn.findNextElement(RichTextItem.RTELEM_TYPE_TABLECELL);	
			rtfn.findNextElement();
			element = rtfn.getElement();
			
		
			rtfr.setBegin(rtfn);
			
			
			pln( "L2 " + i +  element.getClass().getTypeName() +"-->"+  rtfr.getTextRun() + "-"  +	rtfr.getType() );
					element.recycle();
			//sdumm = rtfr.getTextRun();
			//pln (sdumm);
		}
		*/
		
		
	
	}
	private void pln(String s) {
		System.out.println(s);
	}
	

}
