package com.ibm.helper;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Vector;

import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.Document;

public class ChangeShortName extends NotesThread {
	private TreeSet <String> tsShortNames;
	
	public static void main (String [] argv){
		ChangeShortName cn = new ChangeShortName();
		cn.tsShortNames = new TreeSet<String>();
		String sLine;
		String sName;
		try {
			BufferedReader br = new BufferedReader(new FileReader("z:/tmp/BE_In.txt"));
			while((sLine = br.readLine()) != null){
				//sName = sLine.split(";")[2];
				sName = sLine;
				cn.tsShortNames.add(sName);
			}
			br.close();
			cn.start();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("g00dleg4jac.");
		Database db= s.getDatabase("D06ML190", "names.nsf");
		View vw = db.getView("User Admin\\Internetaliases and Shortnames");
		Document docNab;
		
		Vector<String> veSN = null;
		String sKey;
		String firstName;
		String lastName;
		String internetAddress;
		Iterator<String> it = this.tsShortNames.iterator();
		int iSize;
		Vector<String> veNew ;
		while (it.hasNext()){
			sKey = it.next();
			docNab = vw.getDocumentByKey(sKey);
			firstName = docNab.getItemValueString("FirstName");
			lastName = docNab.getItemValueString("LastName");
			internetAddress = firstName + "." + lastName+"@be.ibm.com";
			veSN = docNab.getItemValue("ShortName");
			iSize = veSN.size();
			if (iSize == 2){
				veNew = new Vector<String>();
				veNew.add(internetAddress);
				for(int i = 0; i< iSize; i++){
					veNew.add(veSN.elementAt(i));
				}
				docNab.replaceItemValue("ShortName", veNew);
				docNab.replaceItemValue("ShortName", veNew);
			}
			
			
			docNab.replaceItemValue("InternetAddress", internetAddress);
			docNab.save();
			System.out.println(sKey);
			
		}
		
		
		
	}
	
	
}
