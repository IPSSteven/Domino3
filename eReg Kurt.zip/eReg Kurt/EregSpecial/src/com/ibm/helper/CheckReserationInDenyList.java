package com.ibm.helper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;

import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class CheckReserationInDenyList extends NotesThread{

	
	public static void main(String [] argv){
		CheckReserationInDenyList rc = new CheckReserationInDenyList();
		rc.start();
	}
	
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("jacgetg00d!");
		try {
			BufferedReader dl = new BufferedReader(new FileReader("c:/temp/denylist1.txt"));
			BufferedReader res = new BufferedReader(new FileReader("c:/temp/reserve1.txt"));
			BufferedWriter bw = new BufferedWriter(new FileWriter("c:/temp/reservationsInDenyList"));
			
			// read all deny access ids
			String line;
			String dummy;
	
			HashSet<String> hsNames = new HashSet<String>();
			long l = 0;
			Name n;
			try {
				while ((line = dl.readLine()) != null){
					dummy = line.split(";")[0];
					n = s.createName(dummy);
					hsNames.add(n.getAbbreviated());
					if(l%5000 == 0){
						System.out.println("set " + l);
					}
					n.recycle();
					l++;
				}
				System.out.println("Deny acces loaded");
				dl.close();
				while ((line = res.readLine()) != null){
					if (hsNames.contains(line)){
						System.out.println(line);
					}
				}
				res.close();
				System.out.println("check ready");
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

}
