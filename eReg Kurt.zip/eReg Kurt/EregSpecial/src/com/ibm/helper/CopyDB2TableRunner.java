package com.ibm.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.ibm.ereg.logger.FileLoger;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.mediator.connector.TheEregConnector;

public class CopyDB2TableRunner {
	public final static String DB2CLASS = "com.ibm.db2.jcc.DB2Driver";
	public final static String DB2DATABASE = "MEDIATOR";
	public final static String DB2URL = "jdbc:db2://";
	//public final static String TABLE_NAME ="NOREUSE.\"NOTES_NOREUSE_SINGLEVAL\"";
	public final static String TABLE_NAME ="NOREUSE.\"NOTES_NOREUSE_MULTIVAL\"";
	public final static String KEY = "PERSONUNID";
    public final static	FileLoger fl = new FileLoger("Copylog", "txt");

	public static void main (String[] argv){

		int iThreadsMax = 4;
		//int iHeapSize = 10000;
		int iHeapSize = 3000000;

		DB2ConnectData db2From = new DB2ConnectData();
		DB2ConnectData db2To = new DB2ConnectData();




		db2From.setClass( DB2CLASS);
		db2From.setDB2Database(DB2DATABASE);
		db2From.setURL(DB2URL);
		db2From.setUserid("me114282");
		db2From.setPassword("getg00djac.");
		db2From.setIPAddress("9.149.141.182");
		db2From.setPort(50010);





		db2To.setClass(DB2CLASS);
		db2To.setDB2Database(DB2DATABASE);
		db2To.setURL(DB2URL);
		db2To.setUserid("ereg");
		//db2To.setPassword("Ibmgl0balid");
		//db2To.setIPAddress("9.212.156.50");
		db2To.setPassword("jackp0t18.");
		db2To.setIPAddress("prdbcraw3gen05.w3-969.ibm.com");
		db2To.setPort(60000);


		try {
			clearToDB(db2To);
			
	/*
			TheEregConnector eCon = new TheEregConnector(fl, db2From);
			
			String stQuery = "SELECT COUNT(*) FROM " + TABLE_NAME;
			ResultSet rs =eCon.excuteQuery(stQuery);
	
			rs.next();
			String sCount = rs.getString(1);
			int iCount = Integer.parseInt(sCount);
			int iThreads = (int)Math.ceil(iCount/((double)iHeapSize)); // size of the heaps
			pln("Number of Records to copy="+ iCount + " Number of threads=" + iThreads);

			CopyDB2TableThread [] cpThreads = new CopyDB2TableThread[iThreads];
			long lMilli = System.currentTimeMillis();
			for(int i = 0;i<iThreads; i++){
				cpThreads[i] = new CopyDB2TableThread();
				cpThreads[i].setDb2From(db2From);
				cpThreads[i].setDb2To(db2To);
				cpThreads[i].setiHeapSize(iHeapSize);
				cpThreads[i].setiStart(i*iHeapSize);
				cpThreads[i].setTableName(TABLE_NAME);
				cpThreads[i].setOrderBy("PERSONUNID");
				cpThreads[i].setName("Thread NO="+i +" from " + (i*iHeapSize) + " to " + ((i+1)*iHeapSize));;
			}
			
			ExecutorService executorServ = Executors.newFixedThreadPool(iThreadsMax);

			for(int i = 0; i< iThreads; i++){
				executorServ.execute(cpThreads[i]);
			}
		

			executorServ.shutdown(); // means not new tasks are accepted anymore
			
			if(executorServ != null){
				try {
					executorServ.awaitTermination(90, TimeUnit.MINUTES);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // wait 90 minutes .. this should be sufficient

			}
			pln("All finished after: " +(System.currentTimeMillis() -lMilli));
*/
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		} /*catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}

	private static void pln(String s){
		System.out.println(s);
	}
	
	private static void clearToDB(DB2ConnectData db2To) throws IllegalAccessException, InstantiationException, ClassNotFoundException{
		String stQuery = "SELECT COUNT(*) FROM " + TABLE_NAME;
		String stDelQuery = "DELETE "+ TABLE_NAME + " WHERE " +  KEY + " IN (SELECT PERSONUNID FROM " + TABLE_NAME + " FETCH first 50000 rows only)";
		String sCount ;
		int iCount = 0;
		
		
		try {
			TheEregConnector conTo = new TheEregConnector(fl, db2To);
			ResultSet rs =conTo.excuteQuery(stQuery);
			rs.next();
			sCount = rs.getString(1);
			iCount = Integer.parseInt(sCount);
			
			while(iCount >0){
				conTo.executeUpdate(stDelQuery);
				rs =conTo.excuteQuery(stQuery);
				rs.next();
				sCount = rs.getString(1);
				iCount = Integer.parseInt(sCount);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
