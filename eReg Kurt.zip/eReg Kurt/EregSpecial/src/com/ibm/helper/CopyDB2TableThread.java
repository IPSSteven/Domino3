package com.ibm.helper;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.ibm.ereg.logger.FileLoger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.mediator.connector.TheEregConnector;

public class CopyDB2TableThread extends Thread {
	private int iStart;
	private int iHeapSize;
	
	private DB2ConnectData db2From;
	private DB2ConnectData db2To;
	
	private String TableName;
	private String OrderBy;
	
	
	public int getiStart() {
		return iStart;
	}



	public void setiStart(int iStart) {
		this.iStart = iStart;
	}



	public int getiHeapSize() {
		return iHeapSize;
	}



	public void setiHeapSize(int iHeapSize) {
		this.iHeapSize = iHeapSize;
	}


	public DB2ConnectData getDb2From() {
		return db2From;
	}



	public void setDb2From(DB2ConnectData db2From) {
		this.db2From = db2From;
	}



	public DB2ConnectData getDb2To() {
		return db2To;
	}



	public void setDb2To(DB2ConnectData db2To) {
		this.db2To = db2To;
	}



	public String getTableName() {
		return TableName;
	}



	public void setTableName(String TableName) {
		this.TableName = TableName;
	}

	

	public void setOrderBy(String orderBy) {
		OrderBy = orderBy;
	}



	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		long iMilli = System.currentTimeMillis();
		int iCounter = 0;
		FileLoger fl = new FileLoger(Thread.currentThread().getName(), "txt");
		fl.setCheckLogLevel(LogLevel.FINE);
		TheEregConnector conFrom;
		TheEregConnector conTo;
		String SqlP1;
		String SqlEx;
		String stValue;
		pln("start of Thread: " + Thread.currentThread().getName());
		try {
		
			conFrom = new TheEregConnector(fl, db2From);
			conTo = new TheEregConnector(fl, db2To);
			SqlP1 = "Select * from " + TableName + " ORDER BY " + OrderBy;
			//ResultSet rs = conFrom.excuteQuery(SqlP1, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			
			ResultSet rs = conFrom.excuteQuery(SqlP1);
			ResultSetMetaData rsmd = rs.getMetaData();
			int iUbound = rsmd.getColumnCount() +1;
			StringBuffer bf = new StringBuffer();
		
			for(int i = 1; i< iUbound; i++){
				bf.append(rsmd.getColumnName(i) + ",");
			}
			SqlP1 = "Insert into " + TableName + " (" + bf.toString().substring(0,bf.toString().length()-1) + ") VALUES (";
			
			
			
			//rs.absolute(iStart);
			pln("start of Thread: " + Thread.currentThread().getName());
			while(rs.next()&& iCounter < iHeapSize ){
				bf = new StringBuffer();
				for (int i=1;i<iUbound;i++){
					stValue = rs.getString(i);
					if (stValue == null){
						stValue = "";
					}
					bf.append("'" + stValue.replaceAll("'", "''")+ "'" + ",");
				}
				SqlEx = SqlP1 + bf.toString().substring(0,bf.toString().length()-1) + ")";
				conTo.executeUpdate(SqlEx);
				fl.logActionLevel(LogLevel.INFO, SqlEx);
		
				iCounter++;
			}
			
			conFrom.close(false);
			conTo.close(true);
			pln(Thread.class.getName() + " ends after " + (System.currentTimeMillis() - iMilli));
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	private void pln(String s){
		System.out.println(s);
	}

}
