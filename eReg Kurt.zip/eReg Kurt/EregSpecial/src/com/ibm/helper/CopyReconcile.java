package com.ibm.helper;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.FileLoger;
import com.ibm.ereg.logger.LogLevel;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.mediator.connector.TheEregConnector;
import com.ibm.mediator.mediatordatabeans.ReconcileConfData;
import com.ibm.mediator.mediatordatabeans.ReconcileRawData;
import com.ibm.mediator.mediatordatabeans.ReconcileRawDataCP;

import lotus.domino.Session;

public class CopyReconcile  extends Thread{
	private static final int iDomThread =1;
	private Reader fReader = null;
	private DB2ConnectData  dbconProd  = null;
	private DB2ConnectData  dbconGlob  = null;
	private FileLoger flProd = null;
	private FileLoger flGlobalProd = null;
	private TheEregConnector conProd = null;
	private TheEregConnector conGlobalProd = null;
	private ReconcileRawDataCP rcr = new ReconcileRawDataCP();
	private static final String[] domains ={"IBMAE","IBMAT","IBMBE","IBMBG","IBMCH","IBMCY","IBMCZ","IBMDE","IBMDK","IBMEE","IBMEG","IBMES","IBMFI","IBMFR","IBMGB",
			"IBMGMSR","IBMGR","IBMHR","IBMHU","IBMIE","IBMIL","IBMIT","IBMLT","IBMLV","IBMMA","IBMNL","IBMNO","IBMPK","IBMPL","IBMPT","IBMRO","IBMRU","IBMSE","IBMSI",
			"IBMSK","IBMTN","IBMTR","IBMUA","IBMUS","IBMZA", "IBM"}; 
	//private static final String[] domains ={"IBMAE","IBMAT"};	
	private static HashSet<String> hsDom = new HashSet<String>();
	private static String stRundate;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CopyReconcile cr = null;
		for(String sDom: domains){
			hsDom.add(sDom);
		}
		GregorianCalendar cal = new GregorianCalendar();
		cal.add(Calendar.DAY_OF_MONTH, -1);
		
		stRundate =  Integer.toString(cal.get(Calendar.YEAR)) +CommonFunctions.addLeadingZeros(Integer.toString(cal.get(Calendar.MONTH)+1),2)
		+ CommonFunctions.addLeadingZeros(Integer.toString(cal.get(Calendar.DAY_OF_MONTH)),2);
		
		cr = new CopyReconcile();
		cr.deleteReconcile();
		cr.copyConf();
		cr = null;
		
		
		int iLen = (domains.length/iDomThread) +1;
		//int iLen = domains.length +1;
		System.out.println("treads = " + iLen);
		for(int i =0; i < iLen; i++){
			cr= new CopyReconcile();
			cr.start();
		}
	}
	
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		this.runCopyRawData();
		
		
	}



	private void runCopyRawData(){
		String stDomainClause = "";
		long l = 0;
		try {
			this.fReader = new FileReader(AllConstants.DB2PROPERTIES);
			Properties propDb2 = new Properties();
			propDb2.load(this.fReader);

			this.dbconProd = new DB2ConnectData();

			this.dbconProd.setClass(propDb2.getProperty("Class"));
			this.dbconProd.setDB2Database(propDb2.getProperty("Database"));
			this.dbconProd.setdb2LookupView(propDb2.getProperty("Lookupview"));
			this.dbconProd.setDb2SerialLookupView(propDb2.getProperty("SerialLookupView"));
			this.dbconProd.setURL(propDb2.getProperty("URL"));
			this.dbconProd.setUserid(propDb2.getProperty("UserIdProd"));
			this.dbconProd.setPassword(propDb2.getProperty("PasswordProd"));
			this.dbconProd.setIPAddress(propDb2.getProperty("IPAddressProd")); // PROD
			this.dbconProd.setPort(Integer.parseInt(propDb2.getProperty("PortProd"))); // PROD
			this.dbconProd.setLogLevel(Byte.parseByte(propDb2.getProperty("LogLevel")));

			this.dbconGlob = new DB2ConnectData();
			this.dbconGlob.setClass(propDb2.getProperty("Class"));
			this.dbconGlob.setDB2Database(propDb2.getProperty("Database"));
			this.dbconGlob.setdb2LookupView(propDb2.getProperty("Lookupview"));
			this.dbconGlob.setDb2SerialLookupView(propDb2.getProperty("SerialLookupView"));
			this.dbconGlob.setURL(propDb2.getProperty("URL"));
			this.dbconGlob.setUserid(propDb2.getProperty("GlobalUserIdProd"));
			this.dbconGlob.setPassword(propDb2.getProperty("GlobalPasswordProd"));
			this.dbconGlob.setIPAddress(propDb2.getProperty("GlobalIPAddressProd")); // PROD
			this.dbconGlob.setPort(Integer.parseInt(propDb2.getProperty("GlobalPortProd"))); // PROD
			this.dbconGlob.setLogLevel(Byte.parseByte(propDb2.getProperty("LogLevel")));
			this.fReader.close();
			
			this.flProd = new FileLoger("logProdRaw", "txt");
			flProd.setCheckLogLevel(LogLevel.FINE);
			this.flGlobalProd = new FileLoger("logGlobalProdRaw", "txt");
			flGlobalProd.setCheckLogLevel(LogLevel.FINE);

			this.conProd = new TheEregConnector(this.flProd, this.dbconProd);
			this.conGlobalProd = new TheEregConnector(this.flGlobalProd, this.dbconGlob);	

			// export
			//String stSql =	"EXPORT TO \"c:/temp/Eregreconcile.sql\" OF DEL MESSAGES \"c:/temp/Eregreconcile.sql\" SELECT * FROM MEDIATOR.RAWDATALOTUSNOTES";
			//int i = cr.conProd.executeUpdate(stSql);
			int i =0;
			String sDom;
			HashSet<String> hs2Remove = new HashSet<String>();
			
			synchronized (this.getClass()) {
				Iterator<String> it = hsDom.iterator();
				while (it.hasNext() && i < iDomThread){ // i<1 only one domain
					sDom = it.next();
					stDomainClause = stDomainClause + "'" + sDom + "',";
					hs2Remove.add(sDom);
					i++;
				}	
				hsDom.removeAll(hs2Remove);
			}
			if (i==0){
				return;
			}else{
				stDomainClause = stDomainClause.substring(0, stDomainClause.length() -1);
			}
			
			//String stQuery = "SELECT * FROM MEDIATOR.\"RAWDATALOTUSNOTES\" WHERE RUNDATE LIKE '" +stRundate +"%' AND DOMAIN IN ("+ stDomainClause + ")";
			String stQuery = "SELECT * FROM MEDIATOR.\"RAWDATALOTUSNOTES\" WHERE DOMAIN IN ("+ stDomainClause + ")";

			String sql = null;
			ResultSet rs = this.conProd.excuteQuery(stQuery);
			l =0;
			long lMilliStart = System.currentTimeMillis();
			while(rs.next()){
				this.setReconcileRawdatata(rs);
				sql = this.rcr.INSERT + "MEDIATOR.RAWDATALOTUSNOTES" + this.rcr.FIELDCLAUSE + this.rcr.getValuesclause();
				this.conGlobalProd.executeUpdate(sql);
				if(l%5000 == 0){
					System.out.println("Dataset:" + l + " after " + ((System.currentTimeMillis() - lMilliStart)/1000) );
				}
				l++;
				
			}
			
			stQuery = "SELECT COUNT(*) FROM MEDIATOR.\"RAWDATALOTUSNOTES\" WHERE DOMAIN IN ("+ stDomainClause + ")";
			String sCP1 = null;
			String sCP2 = null;
			rs = this.conProd.excuteQuery(stQuery);
			if(rs.next()){
				 sCP1 = rs.getString(1);
			};
			
			rs = this.conGlobalProd.excuteQuery(stQuery);
			if(rs.next()){
				 sCP2 = rs.getString(1);
			}
		
			flProd.logActionLevel(LogLevel.INFO, "Reconcile line in prod=" + sCP1 + ", Reconcile in globProd="+ sCP2);
			
			
			System.out.println("Finished " + stDomainClause+  " after " +  ((System.currentTimeMillis() - lMilliStart)/60000) + " minutes");
			this.conProd.close(true);
			this.conGlobalProd.close(true);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private  boolean setReconcileRawdatata(ResultSet rs){
		boolean bRet =false;
		try {
			rcr.setRundate(rs.getString(1));
			rcr.setDomain(rs.getString(2));
			rcr.setShortname(rs.getString(3));
			rcr.setFirstname(rs.getString(4));
			rcr.setMiddleinitial(rs.getString(5));
			rcr.setSecondname(rs.getString(6));
			rcr.setQualifiedname(rs.getString(7));
			rcr.setSerialnumber(rs.getString(8));
			rcr.setNabserial(rs.getString(9));
			rcr.setTaskid(rs.getString(10));
			rcr.setIdfile(rs.getString(11));
			rcr.setStatus(rs.getString(12));
			rcr.setClassification(rs.getString(13));
			rcr.setService(rs.getString(14));
			rcr.setUsernameAlias(rs.getString(15));
			rcr.setShortNameAlias(rs.getString(16));
			rcr.setInternetAdress(rs.getString(17));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
		
	}
	
	
	private boolean deleteReconcile(){
		boolean bRet = false;
		try {
			this.fReader = new FileReader(AllConstants.DB2PROPERTIES);
			Properties propDb2 = new Properties();
			propDb2.load(this.fReader);

			this.dbconGlob = new DB2ConnectData();
			this.dbconGlob.setClass(propDb2.getProperty("Class"));
			this.dbconGlob.setDB2Database(propDb2.getProperty("Database"));
			this.dbconGlob.setdb2LookupView(propDb2.getProperty("Lookupview"));
			this.dbconGlob.setDb2SerialLookupView(propDb2.getProperty("SerialLookupView"));
			this.dbconGlob.setURL(propDb2.getProperty("URL"));
			this.dbconGlob.setUserid(propDb2.getProperty("GlobalUserIdProd"));
			this.dbconGlob.setPassword(propDb2.getProperty("GlobalPasswordProd"));
			this.dbconGlob.setIPAddress(propDb2.getProperty("GlobalIPAddressProd")); // PROD
			this.dbconGlob.setPort(Integer.parseInt(propDb2.getProperty("GlobalPortProd"))); // PROD
			this.dbconGlob.setLogLevel(Byte.parseByte(propDb2.getProperty("LogLevel")));
			this.fReader.close();
			
			this.flGlobalProd = new FileLoger("logGlobalProdConf", "txt");
			
			this.conGlobalProd = new TheEregConnector(this.flGlobalProd, this.dbconGlob);
			
			String sql = "DELETE FROM MEDIATOR.\"RAWDATALOTUSNOTES\"";
			this.conGlobalProd.executeUpdate(sql);
			sql = "DELETE FROM MEDIATOR.\"RECONCILECONF\"";
			this.conGlobalProd.executeUpdate(sql);
			
			this.conGlobalProd.close(true);
			
			bRet = true;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return bRet;

	}
	private boolean copyConf(){
		boolean bRet = false;
		long l;
		try {
			this.fReader = new FileReader(AllConstants.DB2PROPERTIES);
			Properties propDb2 = new Properties();
			propDb2.load(this.fReader);

			this.dbconProd = new DB2ConnectData();

			this.dbconProd.setClass(propDb2.getProperty("Class"));
			this.dbconProd.setDB2Database(propDb2.getProperty("Database"));
			this.dbconProd.setdb2LookupView(propDb2.getProperty("Lookupview"));
			this.dbconProd.setDb2SerialLookupView(propDb2.getProperty("SerialLookupView"));
			this.dbconProd.setURL(propDb2.getProperty("URL"));
			this.dbconProd.setUserid(propDb2.getProperty("UserIdProd"));
			this.dbconProd.setPassword(propDb2.getProperty("PasswordProd"));
			this.dbconProd.setIPAddress(propDb2.getProperty("IPAddressProd")); // PROD
			this.dbconProd.setPort(Integer.parseInt(propDb2.getProperty("PortProd"))); // PROD
			this.dbconProd.setLogLevel(Byte.parseByte(propDb2.getProperty("LogLevel")));

			this.dbconGlob = new DB2ConnectData();
			this.dbconGlob.setClass(propDb2.getProperty("Class"));
			this.dbconGlob.setDB2Database(propDb2.getProperty("Database"));
			this.dbconGlob.setdb2LookupView(propDb2.getProperty("Lookupview"));
			this.dbconGlob.setDb2SerialLookupView(propDb2.getProperty("SerialLookupView"));
			this.dbconGlob.setURL(propDb2.getProperty("URL"));
			this.dbconGlob.setUserid(propDb2.getProperty("GlobalUserIdProd"));
			this.dbconGlob.setPassword(propDb2.getProperty("GlobalPasswordProd"));
			this.dbconGlob.setIPAddress(propDb2.getProperty("GlobalIPAddressProd")); // PROD
			this.dbconGlob.setPort(Integer.parseInt(propDb2.getProperty("GlobalPortProd"))); // PROD
			this.dbconGlob.setLogLevel(Byte.parseByte(propDb2.getProperty("LogLevel")));
			this.fReader.close();
			
			this.flProd = new FileLoger("logProdConf", "txt");
			this.flGlobalProd = new FileLoger("logGlobalProdConf", "txt");

			this.conProd = new TheEregConnector(this.flProd, this.dbconProd);
			this.conGlobalProd = new TheEregConnector(this.flGlobalProd, this.dbconGlob);	
			String stQuery = "SELECT * FROM MEDIATOR.\"RECONCILECONF\"";

			String sql = null;
			ResultSet rs = this.conProd.excuteQuery(stQuery);
			l =0;
			long lMilliStart = System.currentTimeMillis();
			ReconcileConfData rcd = new ReconcileConfData();
			while(rs.next()){
				rcd.setRunDate(rs.getString(1));
				rcd.setSystem(rs.getString(2));
				rcd.setReturncode(rs.getString(3));
				rcd.setIdnumber(rs.getString(4));
				
				sql = rcd.INSERT + "MEDIATOR.\"RECONCILECONF\" " + rcd.FIELDCLAUSE + rcd.getValuesClause(); 
				this.conGlobalProd.executeUpdate(sql);
				
				l++;
				
			}
			bRet = true;
			System.out.println("Number of config Rows copied" + l + " after " + ((System.currentTimeMillis() - lMilliStart)/1000) + " second");
			
					
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bRet;
	}

}
