package com.ibm.helper;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Properties;

public class Db2Propertywriter {
	private final String pFile = "db2properties.txt";
	private Writer fWriter = null;
	private Reader fReader = null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Db2Propertywriter db2W = new Db2Propertywriter();
		try {
	
			Properties propDb2 = new Properties(System.getProperties());
			db2W.fWriter = new FileWriter(db2W.pFile);
			propDb2.setProperty("Class", "com.ibm.db2.jcc.DB2Driver");
			propDb2.setProperty("Database", "MEDIATOR");
			propDb2.setProperty("Lookupview", "NOREUSE.NOREUSE_LOOKUP");
			propDb2.setProperty("SerialLookupView", "NOREUSE.NOREUSE_LOOKUP_PSC");
			propDb2.setProperty("URL", "jdbc:db2://");
			propDb2.setProperty("LogLevel", "10"); // finest
			
			propDb2.setProperty("UserIdProd", "med11428"); 
			propDb2.setProperty("IPAddressProd", "9.149.141.182"); 
			propDb2.setProperty("IPAddressBackupProd", "9.149.141.178"); 
			propDb2.setProperty("PasswordProd", "time4tea"); 
			propDb2.setProperty("PortProd", "50010"); 
			
			propDb2.setProperty("UserIdTest", "kraiser"); 
			propDb2.setProperty("IPAddressTest", "9.149.141.208"); 
			propDb2.setProperty("IPAddressBackupProd", ""); 
			propDb2.setProperty("PasswordTest", "time4tea"); 
			propDb2.setProperty("PortTest", "60004"); 
			propDb2.store(db2W.fWriter, "Db2 Properties");
			
			propDb2.setProperty("GlobalUserIdProd", "med4you"); 
			propDb2.setProperty("GlobalIPAddressProd", "prdbcraw3gen05.w3-969.ibm.com"); 
			propDb2.setProperty("GlobalIPAddressBackupProd", ""); 
			propDb2.setProperty("GlobalPasswordProd", "Ibmgl0balid"); 
			propDb2.setProperty("GlobalPortProd", "60000"); 
			
			propDb2.store(db2W.fWriter, "Db2 Properties");
			
			
			db2W.fReader = new FileReader(db2W.pFile);
			propDb2 = new Properties();
			propDb2.load(db2W.fReader);
			System.out.println(propDb2.toString());
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
