package com.ibm.helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;


public class EnrichManagerMailAddress extends NotesThread {
	private final String BPUrl = "http://bluepages.ibm.com/BpHttpApisv3/slaphapi?ibmperson/(uid=#########).list/bytext?notesemail";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EnrichManagerMailAddress emma = new EnrichManagerMailAddress();
		emma.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("g02swim!");
		Database dbEreglog = s.getDatabase("D06DBL051", "e_dir/ereglog6.nsf");
		String stFormula = "((Type != \"\") & (Status = \"Pending\") & (Form = \"Log\")  & (Type = \"AU\"))";
		DocumentCollection dcc = dbEreglog.search(stFormula);
		Document doc = dcc.getFirstDocument();
		Document docRecyle = null;
		String itimOwner = null;
		String MgrEMail = null;
		Name nMgr = null;
		String FullName = null;
		String sEq = null;
		
		while(doc != null){
			itimOwner = doc.getItemValueString("ItimOwner");
			FullName = doc.getItemValueString("FullName");
			MgrEMail = getBPEmailAddress(itimOwner);
			sEq = "0";
			if (MgrEMail != null){
				nMgr = s.createName(MgrEMail);
				if (nMgr != null){
					String dummy = nMgr.getAbbreviated().split("@")[0];
					if (nMgr.getAbbreviated().split("@")[0].equals(FullName)){
						sEq = "1";
					}
				}
				
			}
			
			System.out.println(FullName+ ";" + MgrEMail + ";" + sEq);
			if(sEq.equals("0")){
				doc.replaceItemValue("MgrId",MgrEMail);
				doc.replaceItemValue("MGRMAIL",MgrEMail);
				doc.save();
			}
			
			docRecyle = doc;
			doc = dcc.getNextDocument(doc);
			docRecyle.recycle();
		}
		
	}
	
	private String getBPEmailAddress(String stManagerUid){
		String stBPUrl = BPUrl.replace("#########", stManagerUid);
		String line;
		String eMailMgr = null;
		BufferedReader buf;
		try {
			URL url = new URL(stBPUrl);
			URLConnection con = url.openConnection();
			buf = new BufferedReader(new InputStreamReader(con.getInputStream()));
			while((line = buf.readLine()) != null){
				if(line.startsWith("notesemail")){
					eMailMgr = line.substring(12);
				}
			}
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return eMailMgr;
	}
	

}
