package com.ibm.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ibm.ereg.logger.FileLoger;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.mediator.connector.TheEregConnector;

public class ExportDB2Data {
	public final static String DB2CLASS = "com.ibm.db2.jcc.DB2Driver";
	public final static String DB2DATABASE = "MEDIATOR";
	public final static String DB2URL = "jdbc:db2://";
	
	//public final static String NoReuseExportSV = "Z:\\DayX\\Db2Export\\NoReuseExportSV.sql";
	//public final static String NoReuseExportSVMSG = "Z:\\DayX\\Db2Export\\NoReuseExportSVMSG.sql";
	public final static String NoReuseExportSV = "NoReuseExportSV.sql";
	public final static String NoReuseExportSVMSG = "NoReuseExportSVMSG.sql";
	public final static String NoReuseExportMV = "Z:\\DayX\\Db2Export\\NoReuseExportMV.sql";
	public final static String NoReuseExportMVMSG = "Z:\\DayX\\Db2Export\\NoReuseExportMVMSG.sql";
	
	//public final static String NoReuseReservationSV = "Z:\\DayX\\Db2Export\\NoReuseReservationSV.sql";
	//public final static String NoReuseReservationSVMSG = "Z:\\DayX\\Db2Export\\NoReuseReservationSVMSG.sql";
	public final static String NoReuseReservationSV = "NoReuseReservationSV.sql";
	public final static String NoReuseReservationSVMSG = "NoReuseReservationSVMSG.sql";
	
	public final static String NoReuseReservationMV = "Z:\\DayX\\Db2Export\\NoReuseReservationMV.sql";
	public final static String NoReuseReservationMVMSG = "Z:\\DayX\\Db2Export\\NoReuseReservationMVMSG.sql";
	
	public final static String NoReuseConfig = "Z:\\DayX\\Db2Export\\NoReuseConfig.sql";
	public final static String NoReuseConfigMSG = "Z:\\DayX\\Db2Export\\NoReusConfigMSG.sql";
	
	public final static	FileLoger fl = new FileLoger("Exportlog", "txt");
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DB2ConnectData db2From = new DB2ConnectData();
		db2From.setClass( DB2CLASS);
		db2From.setDB2Database(DB2DATABASE);
		db2From.setURL(DB2URL);
		db2From.setUserid("me114282");
		db2From.setPassword("getg00djac.");
		db2From.setIPAddress("9.149.141.182");
		db2From.setPort(50010);
		
		try {
			TheEregConnector conTo = new TheEregConnector(fl, db2From);
			String sql = "EXPORT TO " + NoReuseReservationSV + " OF DEL MESSAGES " +NoReuseReservationSVMSG + " SELECT * FROM NOREUSE.NOTES_RESERVATION_SINGLEVAL";
			int rs = conTo.executeUpdate(sql);
			conTo.close(true);
			
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
