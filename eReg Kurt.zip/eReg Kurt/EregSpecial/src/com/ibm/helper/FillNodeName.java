package com.ibm.helper;

import java.util.HashMap;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjMailDomainServer;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class FillNodeName extends NotesThread {
	private final  String [] domains = {"IBM","IBMAE","IBMAT","IBMBE","IBMCH","IBMCZ","IBMDE","IBMES","IBMFR","IBMGB","IBMHU","IBMIE",
			"IBMIL","IBMIT","IBMNL","IBMNO","IBMPL","IBMPT","IBMRO","IBMRU","IBMSK","IBMGMSR"};
	private final String SelectFormula = "Type = \"Person\" & NodeName =\"\"";
	
	private String FilterFormula = "@if(@isAvailable($Conflict) |\r\n" + 
			"(@contains(LastName;\"Notes Mail Server\":\"Postmaster\") & Certificate = \"\") |\r\n" + 
			"(@contains(LastName;\"Administrator\":\"Agent Manager\":\"ECL App Signer\") &@contains(@Name([Abbreviate];FullName);\"UK/IBM\")) |\r\n" + 
			"(MailDomain = \"IBMWEB\") | \r\n" + 
			"(FirstName = \"IBM\" & mailAddress != \"\") |\r\n" + 
			"(MailServer = \"\" |  MailFile = \"\") |\r\n" + 
			"(@trim(ShortName )= \"\");\r\n" + 
			"@Return(\"1\");@Return(\"0\"))";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FillNodeName fn = new FillNodeName();
		fn.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		String stServer;
		Database dbNab;
		DocumentCollection dcc;
		Document doc;
		Document docR;
		String stDom;
		int iCount = 0;
		Vector vEval;
		String stDummy;
		
		Session s = NotesFactory.createSessionWithFullAccess("N0thingelsemat.");
		try {
			pln("try to get the config");
			ConfigObjMailDomainServer cfgMS = new ConfigObjMailDomainServer(s);
			HashMap<String, String> hsDomServ = cfgMS.getNabServers_domain();
			pln("got the config");
			for(String dom:domains) {
				pln("working on domain: " + dom);
				stServer = hsDomServ.get(dom);
				dbNab = CommonFunctions.getDatabase(s, stServer, "names.nsf");
				pln("got the nab " + dbNab.getTitle());
				dcc = dbNab.search(SelectFormula);
				pln("Found " + dcc.getCount() + " documents");
				doc = dcc.getFirstDocument();
				while(doc != null) {
					stDummy = doc.getItemValueString("Fullname");
					pln("FullName:" +stDummy);
					vEval = s.evaluate(FilterFormula, doc);
					
					stDummy = vEval.firstElement().toString();
					pln("Result:" + stDummy);
					if(! stDummy.equals("1")) {
						stDom = doc.getItemValueString("MailDomain").trim();
						if(stDom.isEmpty())stDom = dom;
						doc.replaceItemValue("NodeName", stDom);
						doc.save();
						iCount++;
						
					}
					
					docR = doc;
					doc = dcc.getNextDocument(doc);
					docR.recycle();
					
				}
				pln("will update "+ iCount + " documents");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void pln(String s) {
		System.out.println(s);
	}

}
