package com.ibm.helper;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class GetAllEncryptedDocumentFromNCOUAR extends NotesThread {
	
	public static void main(String [] argv) {
		GetAllEncryptedDocumentFromNCOUAR geD = new GetAllEncryptedDocumentFromNCOUAR();
		geD.start();
		
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess("N0thingelsemat.");
		Database db = s.getDatabase("D06DBL090", "e_dir/eregtoo6.nsf");
		View vw = db.getView("All");
		Document doc = vw.getFirstDocument();
		Document docR = null;
		int i = 0;
		
		
		while(doc != null) {
			if(doc.isEncrypted() && doc.getItemValueInteger("Type") != 6) {
				pln(doc.getItemValueString("Subject")  );
			}
			
			docR = doc;
			doc = vw.getNextDocument(doc);
			docR.recycle();
			i++;
			if (i%100 == 0) {
				pln("working on " + i + " document");
			}
		}
		
		
	}
	private void pln(String s) {
		System.out.println(s);
	}

}
