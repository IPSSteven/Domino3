package com.ibm.helper;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import com.ibm.ereg.config.ConfigObjDatabase;
import com.ibm.ereg.config.ConfigObjMaschineProfile;
import com.ibm.ereg.constants.AllConstants;
import com.ibm.ereg.logger.InputOutputLogger;
import com.ibm.ereg.logger.LogLevel;

import lotus.domino.Database;
import lotus.domino.Directory;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.EmbeddedObject;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.RichTextItem;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntryCollection;

public class HRBachInboxMaintance extends NotesThread {
	public InputOutputLogger log = null;
	public ConfigObjMaschineProfile mp = null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HRBachInboxMaintance ef2n = new HRBachInboxMaintance();
		ef2n.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		//Session s = NotesFactory.createSessionWithFullAccess("getg00djac!");
		Session s = NotesFactory.createSessionWithFullAccess("");

		try {
			Database dbLog = CommonFunctions.getLogDB(s);
			log = new InputOutputLogger(s, dbLog, "HR Batch Input Mail box maintainance", LogLevel.FINE);
			String sMachineKey = s.getEnvironmentString(AllConstants.MACHINEKEY);
			mp = new ConfigObjMaschineProfile(s,  AllConstants.TYPE_MACHINEPROFILE + ">" + sMachineKey);

			ConfigObjDatabase ConfigDbMail = new ConfigObjDatabase(s, "9>HR-Batch");
			Database db = s.getDatabase(ConfigDbMail.getServer(), ConfigDbMail.getFilePath());
			writeMailContent(db);
			cleanup(db);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.logActionLevel(LogLevel.SEVERE, "error during init" + e.getMessage());
			e.printStackTrace();
		}

	}



	public void writeMailContent(Database dbMail){
		//String sFilter = "@IsNotMember(\"A\"; ExcludeFromView) & IsMailStationery != 1 & Form != \"Group\" & Form != \"Person\" & Att_Content2Doc != \"1\"";
		String sFilter = "@IsNotMember(\"A\"; ExcludeFromView) & IsMailStationery != 1 & Form != \"Group\" & Form != \"Person\"" +
				"& Att_hrStarterSerial = \"\" & Att_hrStarterUID = \"\"";


		try {
			DocumentCollection dcc = dbMail.search(sFilter);
			System.out.println( "Found " + dcc.getCount() + " documents");
			log.logActionLevel(LogLevel.INFO, "found " + dcc.getCount() + " for writing the contense of the mail file to  mail docuemnt");
			//String stempDir = System.getenv("java.io.tmpdir");
			String stempDir = mp.getTempDir()[0];
			String sFilePath = null;


			Document docMail = dcc.getFirstDocument();
			Document docReycle = null;

			Vector<EmbeddedObject> vecEmb = null;
			Iterator<EmbeddedObject> it = null;
			EmbeddedObject eo = null;
			RichTextItem rtfBody = null;

			while(docMail != null){
				rtfBody = (RichTextItem)docMail.getFirstItem("Body");
				if(rtfBody != null){
					vecEmb = rtfBody.getEmbeddedObjects();
					it = vecEmb.iterator();
					while(it.hasNext()){
						eo = it.next();
						if (eo.getType() == EmbeddedObject.EMBED_ATTACHMENT){
							sFilePath = stempDir + "/" + eo.getName();
							eo.extractFile(sFilePath);
							eo.recycle();
							if(sFilePath.endsWith("txt") | sFilePath.endsWith("csv")){
								writeFileCont2Doc(docMail, sFilePath);
							}
							docMail.save();
						}
					}	

				}

				docReycle = docMail;
				docMail = dcc.getNextDocument(docMail);
				docReycle.recycle();
			}
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			if (log != null)log.logActionLevel(LogLevel.SEVERE, "error during write mail content to mail doc" + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			if (log != null)log.logActionLevel(LogLevel.SEVERE, "error during write mail content to mail doc" + e.getMessage());
			e.printStackTrace();
		}

	}

	private void writeFileCont2Doc(Document docMail, String sFilePath){
		File f = null;
		BufferedReader br = null;
		String sLine = null;
		String [] valueStarter;
		String [] valueAccount;
		String [] dummy;
		f = new File(sFilePath);
		try {
			br = new BufferedReader(new FileReader(f));
			while ((sLine = br.readLine()) != null){
				if(sLine.indexOf("~")>0){
					dummy = sLine.split("~");
					if(dummy.length >=2){
						valueStarter = dummy[0].split(";");
						valueAccount = dummy[1].split(";");
						if(valueStarter.length >= 3){
							docMail.replaceItemValue("Att_hrStarterSerial", valueStarter[1]);
							docMail.replaceItemValue("Att_hrStarterUID", valueStarter[2]);
						}
						if(valueAccount.length >= 3){
							docMail.replaceItemValue("Att_AccountService",valueAccount [0]);
							docMail.replaceItemValue("Att_AccountSerial",valueAccount [1]);
							docMail.replaceItemValue("Att_AccountUid",valueAccount [2]);

							docMail.replaceItemValue("Att_Content2Doc","1");
						}
					}
				}
			}
			br.close();
			f.delete();

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void cleanup(Database dbMail){
		try {
			View vwClean = dbMail.getView("CleanupView");
			ViewEntryCollection vec = vwClean.getAllEntries();
			int iCount = vec.getCount();
			log.logActionLevel(LogLevel.INFO, "deleted " + iCount + "entries during cleanup");

			vec.removeAll(true);
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}



}
