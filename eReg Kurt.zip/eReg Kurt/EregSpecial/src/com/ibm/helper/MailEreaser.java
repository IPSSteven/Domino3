package com.ibm.helper;

import lotus.domino.Database;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntryCollection;


public class MailEreaser extends NotesThread {

	private String stPassword;
	private String stServer;
	private String stFilePath;
	private String stKindOfSearch;
	private String stView;
	private String stFormula;
	
	
	
	public String getStPassword() {
		return stPassword;
	}

	public void setStPassword(String stPassword) {
		this.stPassword = stPassword;
	}

	public String getStServer() {
		return stServer;
	}

	public void setStServer(String stServer) {
		this.stServer = stServer;
	}

	public String getStFilePath() {
		return stFilePath;
	}

	public void setStFilePath(String stFilePath) {
		this.stFilePath = stFilePath;
	}

	public String getStKindOfSearch() {
		return stKindOfSearch;
	}

	public void setStKindOfSearch(String stKindOfSearch) {
		this.stKindOfSearch = stKindOfSearch;
	}

	public String getStView() {
		return stView;
	}

	public void setStView(String stView) {
		this.stView = stView;
	}

	public String getStFormula() {
		return stFormula;
	}

	public void setStFormula(String stFormula) {
		this.stFormula = stFormula;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		for(String s :args){
			String [] l = s.split(",");
			MailEreaser nr = new MailEreaser();
			nr.setStPassword(l[0]);
			
			nr.setStKindOfSearch(l[1]);
			
			String[] dummy = l[2].split(":");
			if (dummy.length ==2 ){
				nr.setStServer(dummy[0]);
				nr.setStFilePath(dummy[1]);
			}else{
				nr.setStServer("");
				nr.setStFilePath(dummy[0]);
			}
			
			if(nr.getStKindOfSearch().equalsIgnoreCase("V")){
				nr.setStView(l[3]);
			}
			if (nr.getStKindOfSearch().equalsIgnoreCase("F")){
				nr.setStFormula(l[3]);
			}
			nr.setName(s);
			nr.start();
			try {
				nr.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		
		
		
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session session = NotesFactory.createSessionWithFullAccess(stPassword);
		Database db_mail = session.getDatabase(stServer, stFilePath, false);
		if (stKindOfSearch.equalsIgnoreCase("V")){
			View vw_delete  = db_mail.getView(stView);
			ViewEntryCollection ve = vw_delete.getAllEntries();
			System.out.println (Thread.currentThread().getName()+ ": Count -" + ve.getCount() );
			ve.removeAll(true);
			ve.recycle();
		}else{
			DocumentCollection dcc = db_mail.search(stFormula);
			dcc.removeAll(true);
			dcc.recycle();
		}
		db_mail.recycle();
		session.recycle();
		
	}
	
	

}
