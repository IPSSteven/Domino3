package com.ibm.helper.MakeBackendFromHR;

public class AllConstants {
	public static final  String pw = "getg00djac!";
	public static final String stDbServer = "D06DBL048";
	public static final String stDBFilePath = "e_dir/eregLog6.nsf";
	public static final String stFileName =  "Au.txt";
	public static final String stBP = "http://bluepages.ibm.com/BpHttpApisv3/slaphapi?ibmperson/(uid=XXXXXXXXX).list/bytext";
}
