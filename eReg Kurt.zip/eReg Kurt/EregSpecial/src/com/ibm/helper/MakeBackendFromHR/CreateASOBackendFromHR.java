package com.ibm.helper.MakeBackendFromHR;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class CreateASOBackendFromHR extends NotesThread {

	private BufferedWriter bw = null; 
	
	public static void main(String [] argv){
		
	}
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Session s = NotesFactory.createSessionWithFullAccess(AllConstants.pw);
		Database dbLog = s.getDatabase(AllConstants.stDbServer,AllConstants.stDBFilePath);
		
		String stSearch = "Type = \"HR\" & Status = \"Pending\":\"New\" & Moved2AsoBacken != \"1\" ";
		DocumentCollection dcc = dbLog.search(stSearch);
		
		try {
			bw = new BufferedWriter(new FileWriter(AllConstants.stFileName));
			Document docEreg = dcc.getFirstDocument();
			Document docRec = null;
			
			
			while (docEreg != null){
				
				docRec = docEreg;
				docEreg = dcc.getNextDocument(docEreg);
				docRec.recycle();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private String getAULine(Document doc){
		String [] arDummy;
		try {
			String Service = doc.getItemValueString("AU_Service");
			Service = getNElement(Service, ":", 1);
			String account = doc.getItemValueString("AU_Account");
			String ownerUid = doc.getItemValueString("AU_OwnerUID");
			String psc = null;
			String serial = null;
			if (ownerUid.length() != 9){
				 ownerUid = doc.getItemValueString("Starter_OwnerUID");
			}
			if (ownerUid.length() == 9){
				psc = ownerUid.substring(ownerUid.length()-3, ownerUid.length());
				serial = ownerUid.substring(ownerUid.length()-3);
			}
			
			String Country =null;
			if(psc.indexOf("CA2,CA3,649") > -1){
				Country = "IBMCa-Fr";
			}else{
				Country = Service;
			}
			
			String Classification = null;
			String emplType = doc.getItemValueString("Starter_employeeType");
			if (emplType.indexOf("PAJIXH") > -1){
				Classification = "I";
			}else if(emplType.indexOf("CVBM") > -1){
				Classification = "E";
			}else{
				return null;
			}
			
			String LastName = doc.getItemValueString("Starter_Lastname");
			String FirstName = doc.getItemValueString("Starter_Firstname");
			
			
			
			
		} catch (NotesException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
	private String getNElement(String s, String sep, int iElem){
		String [] aryDum = s.split(":");
		if(iElem < aryDum.length ){
			return aryDum[iElem];
		}else{
			return null;
		}
	}
	
	private String getBPMgr(String uid){
		String key = "http://bluepages.ibm.com/BpHttpApisv3/slaphapi?ibmperson/(uid=114282724).list/bytext";
		return null;
	}

}
