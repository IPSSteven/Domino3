package com.ibm.helper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;
import lotus.domino.Database;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;
import lotus.domino.ViewEntry;

public class NCOUAR_IDFileChecker extends NotesThread {
	private HashSet<String> hsInputnames = new HashSet<String>();
	private final String FILE_IN = "c:/temp/id4NCOUARCheck.txt";
	private final String FILE_OUT = "c:/temp/id4NCOUARResult.txt";
	
	public static void main(String [] argV){
		NCOUAR_IDFileChecker ncf = new NCOUAR_IDFileChecker();
		if (ncf.getInput()){
			ncf.start();
		}
		
		
	}
	
	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		
		Session session = NotesFactory.createSessionWithFullAccess("jac2mac.");
		Database dbNCOUAR = CommonFunctions.getDatabase(session, "D06DBL048","n_dir/ncouaruk.nsf");
		Database dbNCOUAR2 = CommonFunctions.getDatabase(session, "D06DBL048","n_dir/ncouar2.nsf");
		View vwNCOUAR = dbNCOUAR.getView("(ITIMExport)");
		View vwNCOUAR2 = dbNCOUAR2.getView("(ITIMExport)");
		String stFullName = null;
		ViewEntry ve = null;
		Vector<Object> vRow = null;
		String value = null;
		long counter = 0;
		
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_OUT));
			Iterator<String> it = hsInputnames.iterator();
			while (it.hasNext()){
				counter ++;
				if(counter%500 == 0) System.out.println("Working on:" + counter + " line");
				stFullName = it.next();
				ve = vwNCOUAR.getEntryByKey(stFullName, true);
				if(ve == null){
					ve = vwNCOUAR.getEntryByKey(stFullName, true);
				}
				if(ve == null){
					bw.write(stFullName + ", Not found \n" );
					continue;
				}
				vRow = ve.getColumnValues();
				if(vRow == null){
					bw.write(stFullName + ", Not column value found \n");
					continue;
				}
				value = vRow.elementAt(10).toString() + "\n";
				bw.write(stFullName + ","+	value );
				
				
				
			}
			bw.flush();
			bw.close();
				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
	}
	
	private boolean getInput(){
		BufferedReader bf;
		String line;
		try {
			bf = new BufferedReader(new FileReader(FILE_IN));

			while ((line=bf.readLine())!=null){
				hsInputnames.add(line);
			}
			bf.close();
			return true;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}

}
