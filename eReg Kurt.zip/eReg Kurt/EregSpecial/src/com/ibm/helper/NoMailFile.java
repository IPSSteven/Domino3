package com.ibm.helper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.RichTextItem;
import lotus.domino.Session;
import lotus.domino.View;

public class NoMailFile extends NotesThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoMailFile nf = new NoMailFile();
		nf.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		try {
			BufferedReader br = new BufferedReader(new FileReader("C:/temp/NoMailFiles.txt"));
			BufferedWriter bw = new BufferedWriter( new FileWriter("C:/temp/NoMailFilesHist.txt"));
			Session s = NotesFactory.createSessionWithFullAccess("1Bestfriend!");
			Database ncouar = CommonFunctions.getDatabase(s, "IDPData1/IDP", "e_dir/ncouar2.nsf");
			View vw = ncouar.getView("Person/by Fullname");
			//View vw = ncouar.getView("(ITIMExport)");
			String line;
			Document docUar= null;
			String sOut;
			int iCount = 0;
			while((line = br.readLine()) != null) {
				String []data = line.split(",");
				String fullname = data[6];
				if (fullname.trim().isEmpty())fullname = data[7];
				if (fullname.isEmpty()) continue;
				int idx = fullname.indexOf("@");
				if(idx >0 ) fullname = fullname.substring(0,idx);
				docUar = vw.getDocumentByKey(fullname);
				if(docUar == null) { 
					sOut = fullname + "," + "no Uar doc";
				
				}else {
					Vector <String>vec = docUar.getItemValue("History");
					sOut = fullname + "," + vec.toString();

				}
				System.out.println(sOut);
				bw.write(sOut);
				bw.newLine();
				if (docUar != null) docUar.recycle();	
				iCount++;
				if(iCount % 50 == 0) {
					System.out.println("Working on " + iCount + " row");
					bw.flush();
					
				}
			}
			br.close();
			bw.close();
			
		} catch (FileNotFoundException e) {
			
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
