package com.ibm.helper;

import java.util.Vector;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.DocumentCollection;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;

public class RemoveFromGlobalDenyAccessList extends NotesThread {
	
	private final String SEARCH_TEMPLATE = "SELECT Type = \"Group\" & GroupType = \"3\" & Form = \"Group\" & @Contains(Members;@Name([CN];\"TMPName\"))";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RemoveFromGlobalDenyAccessList rmv = new RemoveFromGlobalDenyAccessList();
		rmv.start();

	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		int icount = 0;
		Document docR;
		Vector vMembers;
		
		Session s = NotesFactory.createSessionWithFullAccess("N0thingelsemat.");
		Database dbNab = CommonFunctions.getDatabase(s, "D51HUB01", "names.nsf");
		String NotesName = "Josef Kral/Czech Republic/IBM";
		
		String stSearch = SEARCH_TEMPLATE.replaceFirst("TMPName",NotesName);
		DocumentCollection dcc = dbNab.search(stSearch);
		pln("Number of groups found: " + dcc.getCount());
		Document docGroup = dcc.getFirstDocument();
		
		
		Name nName = s.createName(NotesName);
		NotesName = nName.getCanonical();
		while(docGroup != null ) {
			
			vMembers = docGroup.getItemValue("Members");
			if(vMembers.contains(NotesName)) {
				vMembers.removeElement(NotesName);
				docGroup.replaceItemValue("Members", vMembers);
				docGroup.save();
				pln("Removed " + docGroup.getItemValueString("ListName") + "- " + NotesName);
				icount ++;
			}
			
			docR = docGroup;
			docGroup = dcc.getNextDocument(docGroup);
			docR.recycle();
		}
		pln ("removed " + NotesName + "  from " + icount + " lists");
		
	}
	
	private void pln(String s) {
		System.out.println(s);
	}

}
