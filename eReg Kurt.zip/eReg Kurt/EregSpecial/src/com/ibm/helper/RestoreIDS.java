package com.ibm.helper;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import com.ibm.ereg.common.CommonFunctions;

import lotus.domino.Database;
import lotus.domino.Document;
import lotus.domino.Name;
import lotus.domino.NotesException;
import lotus.domino.NotesFactory;
import lotus.domino.NotesThread;
import lotus.domino.Session;
import lotus.domino.View;

public class RestoreIDS extends NotesThread {
	//String ids = "US3J1288,CA0G7216,US3J4818,US3J4766,US3J4748,US3J4739,US3J4602,US3J3842,US3J3382,US3J3204,US3J2922";
	//String ids ="US3J3454,US3J3455,FR105954,FR105146,GB122941,GB122774,GB122653,GB122184,GB122692,GB122790";
	//String ids ="CR059,388,US3J4118,US3J5274,US2J3629,US3J3369,US3J4037";
	//String ids = "US3J3496,US3J3417,US3J3375,US3J5151,US3J4527";
	//String ids = "US5J0483";
//	String ids = "US3J3638,US3J3710,US3J3764,US3J3771,US3J3774";
	//String ids = "US3J3781,US3J3819,US3J3996";
	//String ids = "US3J4486";
	//String ids = "C8056713,US3J4741";
	//String ids = "KEY9E2MW,KEY9E2MU,US3J1983,US3J2299";
	//String ids = "FR105954,GB122653,GB122184,US3J3638,US3J3710,US3J3764,US3J3771,US3J3774,US2J5118,US2J5601,US2J5607,US2J6277,US2J6570";
	//String ids = "GRY9DRG5,GRY9DX0A,GRY9CFSJ,GRY9CWMX,GRY9DUJT,GRY9DUJT,GRY9E05M,GRY9DUL4";
	//String ids = "CA0G7239";
	//String ids = "US3J3948,US3J5948,US3J5864,CA0G7235,US3J4741,US3J3609,US3J5703,EC067354,US3J3810,US1J4101,US2J6766";
	String ids ="US3J3976,US3J3484,US3J4203,US3J3988,CA0G7239,US3J3118";
		// TODO Auto-generated method stub
	public static void main ( String[] argv) {
		
		RestoreIDS rids = new RestoreIDS();
		rids.start();
	}

	@Override
	public void runNotes() throws NotesException {
		// TODO Auto-generated method stub
		super.runNotes();
		Document docP;
		//Document docR;
		Document docT;
		Document docUAR;
		BufferedWriter bf;
		String fullname;
		Name nNam;
		String state;
		
		Session session = NotesFactory.createSessionWithFullAccess("ja13komo");
		Database dbFreeze = CommonFunctions.getDatabase(session, "D06DBL051", "n_dir/freeze.nsf");
		View vwFreeze =  dbFreeze.getView("($Users)");
		Database dbNab = CommonFunctions.getDatabase(session, "D51HUB01", "names");
		Database dbUAR = CommonFunctions.getDatabase(session, "d06DBL090", "n_dir/ncouar2.nsf");
		View vwUar = dbUAR.getView("Deleted Person\\by Shortname");
	
		try {
			bf = new BufferedWriter(new FileWriter("c:/tmpAd/rmDenyAccess.txt"));
			String [] aryIds = ids.split(",");
			
			for (String id:  aryIds) {
				docP = vwFreeze.getDocumentByKey(id,true);
				if(docP == null) {
					pln (id + " not found ");
				}else {
					docT = docP.copyToDatabase(dbNab);
					if(docT != null) {
						docP.remove(true);
					}
					docP.recycle();
					fullname = docT.getItemValueString("FullName");
					nNam = session.createName(fullname);
					bf.write(nNam.getAbbreviated()+ "\n");
					nNam.recycle();
					docT.recycle();
					pln(id + " restored successfull");
				}
			}
			
			for (String id:  aryIds) {
				docUAR = vwUar.getDocumentByKey(id);
				if (docUAR == null){
					pln (id + " not found in UAR");
				}else{
					state = docUAR.getItemValueString("state");
					docUAR.replaceItemValue("state", "");
					docUAR.save();
					pln (id + " changed successful in UAR");
					
					docUAR.recycle();
				}
			}
			bf.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	
	private void pln(String s) {
		System.out.println(s);
	}
	

}
