package com.ibm.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ibm.ereg.logger.FileLoger;
import com.ibm.mediator.connector.DB2ConnectData;
import com.ibm.mediator.connector.TheEregConnector;

import lotus.priv.CORBA.iiop.FileLocator;

public class SetSuppressFlagSingle {
	public final static String DB2CLASS = "com.ibm.db2.jcc.DB2Driver";
	public final static String DB2DATABASE = "MEDIATOR";
	public final static String DB2URL = "jdbc:db2://";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileLoger fl = new FileLoger("c:/temp/log", "txt");
		int iborder = 91000;
		int i;
		DB2ConnectData db2con = new DB2ConnectData();
		db2con.setClass( DB2CLASS);
		db2con.setDB2Database(DB2DATABASE);
		db2con.setURL(DB2URL);
		db2con.setUserid("ereg");
		db2con.setPassword("jackp0t18.");
		db2con.setIPAddress("9.220.144.79");
		db2con.setPort(60000);
		
		try {
			TheEregConnector con = new TheEregConnector(fl, db2con);
			String TheSelect = "Select * FROM NOREUSE.NOTES_NOREUSE_SINGLEVAL WHERE SUPPRESSFLAG IS NULL";
			ResultSet rs = con.excuteQuery(TheSelect);
			//rs.last();
			//int lastrow = rs.getRow();
			//System.out.println("number of rows " + lastrow);
			//rs.beforeFirst();
			i= 0;
			String up; 
			int res;
			while (rs.next() && i< iborder ){
				
				//System.out.println (rs.getString(1) + "-" + rs.getString(2));
				//System.out.println (rs.getString(1)+ "-" + rs.getString(2)+ "-" + rs.getString(3) + "-"+ rs.getString(4) + "/");
				if (i%1000 == 0)System.out.println ("Single working on the " + i + " row" );
				up= "UPdate NOREUSE.NOTES_NOREUSE_SINGLEVAL SET SUPPRESSFLAG = '0' WHERE PERSONUNID = '"+ rs.getString(1) + "'";
				res = con.executeUpdate(up);
				i++;
				
				
			}
			rs.close();
			
			
			
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
