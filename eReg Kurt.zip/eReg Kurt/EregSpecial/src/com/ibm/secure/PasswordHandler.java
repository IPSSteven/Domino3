package com.ibm.secure;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Properties;

import com.ibm.getIsimInfo.IsimLdapReader;

public class PasswordHandler {
	public static final String kindOfPwDB2 = "DB2";
	public static final String kindOfPwNotes = "Notes";
	public static final String kindOfLDAP = "LDAP";
	private static final String pFileNotes = "NotesProperties.txt";
	private static final String pFileDB2 = "DB2properties.txt";
	private static final String pFileLDAP = IsimLdapReader.LDAP_READER_PROPERTIES;
	private static final String pKeyNotes = "NotesPw";
	private static final String pKeyDB2Prod = "PasswordProd";
	private static final String pKeyDB2Test =  "PasswordTest";
	private static final String pKeyLDAP =  IsimLdapReader.LDAP_SECURITY_CREDENTIALS;
	private static final String stEncryptPW = "run4Notes";
	private Writer writer = null;
	private Reader reader = null;
	private Properties prop = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*PasswordHandler pw = new PasswordHandler();
		pw.setPw("Notes", "time4tea");
		System.out.println(pw.getPw("Notes"));
		pw.setPw("DB2","time4tea.");
		System.out.println(pw.getPw("DB2"));
		*/

	}


	public boolean setPw (String kindOfPw, String pw){
		StringEncryptDecrypt strEncrypt = new StringEncryptDecrypt();
		String pwEncrypt = null;
		prop = new Properties(System.getProperties());
		try {
			if(kindOfPw.equalsIgnoreCase(kindOfPwNotes)){
				reader = new FileReader(pFileNotes);
			}
			if(kindOfPw.equalsIgnoreCase(kindOfPwDB2)){
				reader = new FileReader(pFileDB2);
			}
			if(kindOfPw.equals(kindOfLDAP)){
				reader = new FileReader(pFileLDAP);
			}
			prop.load(reader);
			reader.close();
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {


			if(kindOfPw.equalsIgnoreCase(kindOfPwNotes)){
				writer = new FileWriter(pFileNotes);
				pwEncrypt = strEncrypt.encrypt(pw, stEncryptPW);
				prop.setProperty(pKeyNotes, pwEncrypt);
			}
			if(kindOfPw.equalsIgnoreCase(kindOfPwDB2)){
				writer = new FileWriter(pFileDB2);
				pwEncrypt = strEncrypt.encrypt(pw, stEncryptPW);
				prop.setProperty(pKeyDB2Prod, pwEncrypt);
				prop.setProperty(pKeyDB2Test, pwEncrypt);
			}
			if(kindOfPw.equalsIgnoreCase(kindOfLDAP)){
				writer = new FileWriter(pFileLDAP);
				pwEncrypt = strEncrypt.encrypt(pw, stEncryptPW);
				prop.setProperty(pKeyLDAP , pwEncrypt);
			}

			prop.store(writer, "pw encrypt");
			writer.flush();
			writer.close();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public String getPw(String kindOfPw){
		StringEncryptDecrypt strEncrypt = new StringEncryptDecrypt();
		String pw = null;
		String pwEncrypt = null;
		prop = new Properties();
		try {

			if(kindOfPw.equalsIgnoreCase("Notes")){
				reader = new FileReader(pFileNotes);
				prop.load(reader);
				pwEncrypt = prop.getProperty(pKeyNotes);
				pw = strEncrypt.decrypt(pwEncrypt, stEncryptPW);
			}
			if(kindOfPw.equalsIgnoreCase("DB2")){
				reader = new FileReader(pFileDB2);
				prop.load(reader);
				pwEncrypt = prop.getProperty(pKeyDB2Prod);
				pw = strEncrypt.decrypt(pwEncrypt, stEncryptPW);
			}
			if(kindOfPw.equalsIgnoreCase(kindOfLDAP)){
				reader = new FileReader(pFileLDAP);
				prop.load(reader);
				pwEncrypt = prop.getProperty(pKeyLDAP);
				pw = strEncrypt.decrypt(pwEncrypt, stEncryptPW);
			}



			return pw;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}


	}

}
