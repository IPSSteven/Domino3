package com.ibm.secure;

public class SetPassword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Number of args: " + args.length);
		if (args.length < 2){
			System.out.println(" Wrong number of arguments. Usage: SetPassword kind of password  password");
			return;
		}
		if(!(args[0].equalsIgnoreCase("db2") || args[0].equalsIgnoreCase("Notes")|| args[0].equalsIgnoreCase("LDAP"))){
			System.out.println("Wrong kind of pw: DB2 or Notes or LDAP are valid");
			return;
		}
		String kindOfPw =  args[0];
		String pw = args[1];
		PasswordHandler ph = new PasswordHandler();
		ph.setPw(kindOfPw, pw);
		System.out.println("password set  to :" + ph.getPw(kindOfPw));
	}

}
