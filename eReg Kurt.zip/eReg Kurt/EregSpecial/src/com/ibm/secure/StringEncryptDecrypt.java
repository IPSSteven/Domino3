package com.ibm.secure;
import java.security.Key;
import java.security.MessageDigest;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import sun.misc.*;

//import com.ibm.crypto.fips.provider.AESKeyGenerator;

public class StringEncryptDecrypt {
	private static final String ALGO = "AES";
	/*private static final byte[] keyValue = 
		        new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't',

		'S', 'e', 'c', 'r','e', 't', 'K', 'e', 'y' };
	/**
	 * @param args
	 */
	private byte[] keyValue;
	public static void main(String[] args) {
		String stPw = "TestPassword|";
		String stEncPw ="TotalSecrect";
		String stPwEncr="";
		String stPwDecr= "";
		pln("PW = " + stPw);
		StringEncryptDecrypt stred = new StringEncryptDecrypt();
		
		
		try {
			stPwEncr = stred.encrypt(stPw, stEncPw);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pln("PW encrypted = " + stPwEncr);
		try {
			stPwDecr=stred.decrypt(stPwEncr, stEncPw);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pln("PW decrypted = " + stPwDecr);

	}
	
	
	public  String encrypt(String Data, String strPassWD) throws Exception {
		//this.keyValue = strPassWD.getBytes();
        Key key = generateKey(strPassWD);
        Cipher c = Cipher.getInstance(ALGO);
       
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encVal = c.doFinal(Data.getBytes());
        String encryptedValue = new BASE64Encoder().encode(encVal);
        return encryptedValue;
    }
	
	   private Key generateKey(String stPw) throws Exception {
		  // KeyGenerator kg = KeyGenerator.getInstance(ALGO);
		  // Key k = kg.
		   MessageDigest digester = MessageDigest.getInstance("SHA-256");
		   digester.update(stPw.getBytes("UTF-8"));
		   keyValue = digester.digest();
		   keyValue = Arrays.copyOf(keyValue, 16);
		   Key key = new SecretKeySpec(keyValue, ALGO);
		   
	       return key;
	}
	   public String decrypt(String encryptedData, String strPassWD) throws Exception {
		
		   
		   this.keyValue = strPassWD.getBytes();
	        Key key = generateKey(strPassWD);
	        Cipher c = Cipher.getInstance(ALGO);
	        c.init(Cipher.DECRYPT_MODE, key);
	        byte[] decordedValue = new BASE64Decoder().decodeBuffer(encryptedData);
	        byte[] decValue = c.doFinal(decordedValue);
	        String decryptedValue = new String(decValue);
	        return decryptedValue;
	    }
	   public static void pln(String str){
		   System.out.println(str);
	   }

}
