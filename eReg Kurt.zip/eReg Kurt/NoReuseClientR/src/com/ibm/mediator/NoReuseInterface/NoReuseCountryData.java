package com.ibm.mediator.NoReuseInterface;

import java.io.Serializable;
import java.lang.reflect.Field;
/** 
 * @version 1.0
 * class to transport the name, country and the context for a Name proposal
 * the data needs to be passed to constructor
 * 
 * The class is used as return parameter by the isSerialinUse method of the NoReuseInterface
 * 
 * @author Kurt Raiser
 */

public class NoReuseCountryData implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	/**
	 * The definition of the country:  <br>
	 *  CountryDefSerialPSC (1) the country information is passed as psc code 3 digits or within the serial number 9 digits <br>
	 *  CountryDefCountryCode(2) the country information is passed as 2 digit value like es for Spain <br>
	 *  CountryDefCountryName(3) the country information is passed as country name like Spain <br>
	 */
	public static final int CountryDefSerialPSC = 1;
	public static final int CountryDefCountryCode = 2;
	public static final int CountryDefCountryName = 3;

	/**
	 * The definition of the country context:  <br>
	 *  ContextGNA(1): country is included in the e-mail search e.g. x.y@cc.ibm.com  <br>
	 *  ContextGlobal(2) country is Not included in the e-mail search e.g. x.y@ibm.com  <br>
	 *  CountryDefCountryName(3) the country information is passed as country name like Spain <br>
	 */
	public static final int ContextGNA = 1;
	public static final int ContextGlobal = 2;

	/**
	 * The kind definition of the country:  <br>
	 * must be one of the constant values:  <br>
	 *CountryDefSerialPSC = 1  <br>
	 *CountryDefCountryCode = 2  <br>
	 *CountryDefCountryName = 3  <br>
	 */
	private int KindOfCountryDefinition;
	private int KindOfContext;
	private String value;


	public static void main (String [] argv){
		try {
			NoReuseCountryData cd = new NoReuseCountryData("724", NoReuseCountryData.CountryDefSerialPSC, NoReuseCountryData.ContextGlobal);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
 
	/**
	 * 
	 * @param CountryDef: the value of the country definition
	 * @param kindofCountryDef specifies how the country is passed: psc code, country code, or country
	 * @param kindOfContext: specfies the context for the search (GNA or global)
	 * @throws Exception
	 */
	public NoReuseCountryData(String CountryDef, int kindofCountryDef, int kindOfContext) throws Exception{
		setKindOfCountryDefinition(kindofCountryDef);
		setKindOfContext(kindOfContext);
		setValue(CountryDef);
	}

	/**
	 * 
	 * @return the kind of country definition: s constants
	 */
	public int getKindOfCountryDefinition() {
		return KindOfCountryDefinition;
	}
	
	/**
	 * 
	 * @param kindOfCountryDefinition s. constants
	 * @throws Exception if contry defintion is not defined
	 */
	private void setKindOfCountryDefinition(int kindOfCountryDefinition) throws Exception {
		if (verifyCountryDef(kindOfCountryDefinition)){
			KindOfCountryDefinition = kindOfCountryDefinition;
		}else{
			throw new Exception("Kind of Country Definition is no valid");
		}
	}


	/**
	 * 
	 * @return the kind of country context (global or GNA
	 */
	public int getKindOfContext() {
		return KindOfContext;
	}

	private void setKindOfContext(int kindOfContext) throws Exception{
		if(!verifyContext( kindOfContext)) throw new Exception("Kind of context definition not valid !");
		KindOfContext = kindOfContext;
	}

	public String getValue() {
		return value;
	}

	private void setValue(String value) {
		this.value = value;
	}

	/**
	 * 
	 * @param idef: kind of country definition
	 * @return: whether the country definition is valid or not
	 */
	private boolean verifyCountryDef(int idef){
		
		Class<NoReuseCountryData> c = (Class<NoReuseCountryData>)this.getClass();
		Field[] fs = c.getFields();

		for (Field f: fs){
		
			if (f.getName().indexOf("CountryDef") > -1 &&f.getType().getName().equals("int")){
				try {
					if (f.getInt(f) == idef){
						return true;
					}
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return false;
	}
	
	/**
	 * 
	 * @param idef : country context
	 * @return: whether the country context is valid or not
	 */
	private boolean verifyContext(int idef){
		String sDummy;
		Class<NoReuseCountryData> c = (Class<NoReuseCountryData>)this.getClass();
		Field[] fs = c.getFields();
		for (Field f: fs){
			sDummy = f.getName();
			if (f.getName().indexOf("Context") > -1 &&f.getType().getName().equals("int")){
				try {
					if (f.getInt(f) == idef){
						return true;
					}
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return false;
	}
}
