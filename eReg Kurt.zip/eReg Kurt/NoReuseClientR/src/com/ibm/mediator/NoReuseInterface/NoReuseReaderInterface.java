package com.ibm.mediator.NoReuseInterface;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface NoReuseReaderInterface extends Remote {
	/**
	 * 
	 * @param id: the name of the id like firstname.lastname@ibm.com, firstname lastname/ibm/com
	 * @return see ResponseIsIdinUse
	 * 
	 * @throws RemoteException
	 */
	public ResponseIsIdinUse isIDinUse(String id) throws RemoteException;

	/**
	 * 
	 * @param id: the name of the id like firstname.lastname@ibm.com, firstname lastname/ibm/com
	 * @return see ResponseIsIdinUse
	 * 
	 * @throws RemoteException
	 */
	//public ResponseIsIdinUse isIDinUse(String[] id) throws RemoteException;
	/** 
	 * Method to check whether an id is in use
	 * 
	 * @param firstName
	 * @param middleInitial
	 * @param lastName
	 * @return see ResponseIsIDinUse
	 * @throws RemoteException
	 */
	
	public ResponseNameProposal getNameProposal(String firstName, String middleInitial, String lastName) throws RemoteException;
	/**
	 * 
	 * @param id: the name of the id like firstname.lastname@ibm.com, firstname lastname/ibm/com
	 * @return see ResponseIsIdinUse
	 * 
	 * @throws RemoteException
	 */
	//public ResponseIsIdinUse isIDinUse(String[] id) throws RemoteException;
	/** 
	 * Method to check whether an id is in use
	 * 
	 * @param firstName
	 * @param middleInitial
	 * @param lastName
	 *  @param nrcd: class that pass the country information as psc code oder country code or country
	 * @return see ResponseIsIDinUse
	 * @throws RemoteException
	 */
	public ResponseNameProposal getNameProposal(String firstName, String middleInitial, String lastName, NoReuseCountryData ncrd) throws RemoteException;
	
	/**
	 * Method to create a reservation
	 * 
	 * @param serialPSC : the serial and PSC code for the reseration check
	 * @return
	 * @throws RemoteException
	 */
	public ResponseIsIdinUse checkReservation(String serialPSC) throws RemoteException;
	/**
	 * Method to create a reservation
	 * 
	 * @param serialPSC : the serial and PSC code for the reservation check
	 * @return
	 * @throws RemoteException
	 */
	
	public ResponseIsSerialInUse isSerialInUse (String serialPsc) throws RemoteException;
	
	/**
	 * Method to create a reservation
	 * 
	 * @param serialPSC : the serial and PSC code for check whether serial is in use
	 * @throws RemoteException
	 */
}
