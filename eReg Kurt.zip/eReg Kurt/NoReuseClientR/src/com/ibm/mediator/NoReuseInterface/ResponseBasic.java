package com.ibm.mediator.NoReuseInterface;

import java.io.Serializable;

public class ResponseBasic implements Serializable {

	/**
	 * @version 1.0
	 * the basic class for all response for the RMINoReuse server
	 */

	private static final long serialVersionUID = 1L;

	private Boolean HasError = null;
	private String ErrDescription = null;

	public ResponseBasic() {
		// TODO Auto-generated constructor stub
	}

	/** 
	 * 
	 * @return : true if an error happens during the execution
	 */
	public Boolean getHasError() {
		return HasError;
	}

	/**
	 * 
	 * @param method to set the error flag of the response
	 */
	public void setHasError(Boolean hasError) {
		HasError = hasError;
	}
	
	/**
	 * 
	 * @return : the error details
	 */
	public String getErrDescription() {
		return ErrDescription;
	}

	/**
	 * 
	 * @param method to set the error description
	 */
	public void setErrDescription(String errDescription) {
		ErrDescription = errDescription;
	}


}
