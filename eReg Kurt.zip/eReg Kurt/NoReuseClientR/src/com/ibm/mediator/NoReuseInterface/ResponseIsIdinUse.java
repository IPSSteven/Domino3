package com.ibm.mediator.NoReuseInterface;

import java.io.Serializable;

public class ResponseIsIdinUse extends ResponseBasic implements Serializable {

	/** 
	 * @version 1.0
	 * class to transport the response value of an id is inUse request
	 * 
	 * The class is used as return parameter by the isIDinUse method of the NoReuseInterface
	 * 
	 * @author Kurt Raiser
	 */
	private static final long serialVersionUID = 1L;
	
	private Boolean isIDinUse = null;
	private String[] idsInuse = null;
	
	/**
	 * 
	 * @return the string of all ids which where found for a wildcard inquiry
	 */
	public String[] getIdsInuse() {
		return idsInuse;
	}

	/**
	 * set method for RMI implementation only
	 * @param idsInuse
	 */
	public void setIdsInuse(String[] idsInuse) {
		this.idsInuse = idsInuse;
	}

	/**
	 * 
	 * @return a boolean which is set to true if the id is in use (only for RMI client)
	 */
	public Boolean getIsIDinUse() {
		return isIDinUse;
	}
	
	/**
	 * method to set the Boolean depending on the check of no reuse (only for the RMI server)
	 * @param isIDinUse 
	 */
	public void setIsIDinUse(Boolean isIDinUse) {
		this.isIDinUse = isIDinUse;
	}
	/**
	 *  standard constructor
	 */
	public ResponseIsIdinUse() {
		// TODO Auto-generated constructor stub
	}
	

}
