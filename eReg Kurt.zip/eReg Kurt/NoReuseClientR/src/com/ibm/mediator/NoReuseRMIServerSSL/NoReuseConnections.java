package com.ibm.mediator.NoReuseRMIServerSSL;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import com.ibm.mediator.NoReuseInterface.NoReuseReaderInterface;
import com.ibm.mediator.NoReuseInterface.ResponseIsIdinUse;
import com.ibm.mediator.NoReuseRMIServerSSL.SocketFactories.ASSLClientSocketFactory;

public class NoReuseConnections {
	private static String host; 
	private static int port;
	private static final String implName = "NoReuseServer"; 

	public static void main(String[] args) {

		//host = "localhost";
		//host = "9.149.105.239"; // production
		//host = "9.149.105.238"; // 
		host = "9.212.156.54"; // dev linux
		//host = "9.212.156.43"; // test linux
		//host = "9.149.100.110"; // test windows behind vlan
		//host = "9.149.100.108"; // ereg09 behind Vlan
		//host = "prdbcraw3gen05.w3-969.ibm.com";
		//host = "9.220.144.79"; //gen05
		//host = "9.209.255.205"; //utility server DR
		port = 4911;
		long lMillis;
		
		
		String [] eMails = {"Max", "Moris", "Molly"};

		System.setProperty("javax.net.ssl.trustStore", "globalIBM.ks");
		System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");

		try {
			lMillis = System.currentTimeMillis();
			
			
			for(String sMail: eMails) { // loop
				// registration for every user
				ASSLClientSocketFactory cf = new ASSLClientSocketFactory();
				Registry r = LocateRegistry.getRegistry(host, port);
				NoReuseReaderInterface nrRMIClient = (NoReuseReaderInterface)r.lookup(implName);
				ResponseIsIdinUse b = nrRMIClient.isIDinUse(sMail);
				
			} //end of loop
			
			
			pln("Worst case time:" + (System.currentTimeMillis()- lMillis));
			{
				
				lMillis = System.currentTimeMillis();
				ASSLClientSocketFactory cf = new ASSLClientSocketFactory();
				Registry r = LocateRegistry.getRegistry(host, port);
				NoReuseReaderInterface nrRMIClient = (NoReuseReaderInterface)r.lookup(implName);
				
				for(String sMail: eMails) { //lo0p

					ResponseIsIdinUse b = nrRMIClient.isIDinUse(sMail);
				} // end of loop
				
				pln("Better case time:" + (System.currentTimeMillis()- lMillis));
			}
			
			

		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private static void pln(String s) {
		System.out.println(s);
	}
}
