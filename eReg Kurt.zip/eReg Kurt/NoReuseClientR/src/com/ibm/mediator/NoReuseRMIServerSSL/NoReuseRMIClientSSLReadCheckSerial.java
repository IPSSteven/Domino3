package com.ibm.mediator.NoReuseRMIServerSSL;


import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Arrays;

import com.ibm.mediator.NoReuseInterface.NoReuseReaderInterface;
import com.ibm.mediator.NoReuseInterface.ResponseIsSerialInUse;

public class NoReuseRMIClientSSLReadCheckSerial {

	/**
	 * @version 1.0
	 * @author Kurt Raiser
	 * @
	 * This is a sample of an RMIClient, to consume the server
	 * The Parameter for Client (command line):
	 * @param param1: kind of request, IIU = check is in use, GNP = get name Proposal");
	 * @param param2: firstname,middleInital,lastname OR email");
	 * @param param3: ipAdress:port (optional");
	 * 
	 * @param : @see description of the class ResponseIsIdinUse and ResponseNameProposal
	 * 
	 */
	private static final String implName = "NoReuseServer"; 

	public NoReuseRMIClientSSLReadCheckSerial() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String stEmail = null;
		String stSerial = null;
		String host = "localhost";
		//String host = "9.149.105.152";
		int port = 4911;
		// name of no the server
		
		if (args.length != 2){
			pln("**********************************USAGE************************");
			pln("PARAM1 = IPAddress:Port");
			pln("PARAM2 = serialPSC");
			System.exit(99);
		}
		
		String [] dummy = args[0].split(":");
		if(dummy.length <2){
			pln("**********************************USAGE************************");
			pln("PARAM1 = IPAddress:Port");
			pln("PARAM2 = serialPSC");
			System.exit(99);
		}
		
		host = dummy[0];
		port = Integer.parseInt(dummy[1]);
		stSerial = args[1];
		// and now act.
		try {
			pln("**********************************BEGIN SHOW PARAM************************");
			pln("Try to register host " + host + " on port " + port );
		
			System.setProperty("javax.net.ssl.trustStore", "globalIBM.ks");
			Registry r = LocateRegistry.getRegistry(host, port);
			NoReuseReaderInterface nrRMIClient = (NoReuseReaderInterface)r.lookup(implName);
			//NoReuseReaderInterface nrRMIClient = (NoReuseReaderInterface)r.lookup(implName);
			
			ResponseIsSerialInUse b = nrRMIClient.isSerialInUse(stSerial);
			if (b.getHasError().booleanValue()){
				pln("Error while get processe request");
				pln(b.getErrDescription());
			}else{
				if (b.getIsIDinUse().booleanValue()){
					pln(stEmail + " is in use by: " + b.getSerialPSCinUse().getSerialPSC() + "::"+ Arrays.toString(b.getSerialPSCinUse().getNames()));
				}else{
					pln(stEmail + " is NOT in use");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static void pln(
			String log){
		System.out.println(log);
	}

}
