package com.ibm.mediator.NoReuseRMIServerSSL;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class PropertyHandler {
	public static final String propRMIClientTimeOut = "RMI_CLIENT_TTIMEOUT";
	private final String PROP_FILE = "config.properties";
	private Properties prop = new Properties();
	private OutputStream output = null;
	private InputStream input= null;
	private static PropertyHandler me;
	public static PropertyHandler getInstance() throws IOException{
		if(me == null){
			me = new PropertyHandler();
		}
		return me;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub


		try {

			PropertyHandler propHandler = getInstance();
			
			if(propHandler.getProperty(propRMIClientTimeOut) != null){
				propHandler.removeProp(propRMIClientTimeOut);
			}
			propHandler.setProperty(propRMIClientTimeOut, "15000");
			System.out.println(propHandler.getProperty(propRMIClientTimeOut ));

			// save properties to project root folder


		}catch(FileNotFoundException fe){
			System.out.println("file  not found");
		}catch (IOException io) {
			io.printStackTrace();
		}
	}

	private PropertyHandler() throws IOException{
		prop = new Properties();
		loadProp();
	}

	public void setProperty (String propName, String propValue) throws IOException{
		
			if (output == null){
				output = new FileOutputStream(PROP_FILE);
			}
			prop.setProperty(propName, propValue);
			prop.store(output, null);
			
	
	}
	public String getProperty (String propName) throws IOException{
		String ret = null;

		if (input == null){
			input = new FileInputStream(PROP_FILE);
		}
		prop.load(input);
		ret = prop.getProperty(propName);


		return ret;

	}
	public void removeProp (String propName) throws IOException{
		if (output == null){
			//output = new FileOutputStream(PROP_FILE,true);
			output = new FileOutputStream(PROP_FILE);
		}
		prop.remove(propName);

		prop.store(output, null);
	}
	
	private void loadProp() throws IOException{
		if (input == null){
			input = new FileInputStream(PROP_FILE);
		}
		prop.load(input);
	}
}
