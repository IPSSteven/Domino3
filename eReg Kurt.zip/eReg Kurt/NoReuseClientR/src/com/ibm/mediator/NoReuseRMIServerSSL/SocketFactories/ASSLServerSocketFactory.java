package com.ibm.mediator.NoReuseRMIServerSSL.SocketFactories;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.rmi.server.RMIServerSocketFactory;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;

public class ASSLServerSocketFactory implements RMIServerSocketFactory {

	private SSLServerSocketFactory ssf = null;
//https://docs.oracle.com/javase/8/docs/technotes/guides/security/jsse/samples/index.html
	public ASSLServerSocketFactory() throws Exception {
		try {
			// set up key manager to do server authentication
			SSLContext ctx;
			KeyManagerFactory kmf;
			KeyStore ks;

			char[] passphrase = "gl0balibm.".toCharArray();
			ks = KeyStore.getInstance("JKS");
			ks.load(new FileInputStream("globalIBM.ks"), passphrase);

			//kmf = KeyManagerFactory.getInstance("SunX509");
			kmf = KeyManagerFactory.getInstance("IBMX509");
			kmf.init(ks, passphrase);

			ctx = SSLContext.getInstance("TLS");
			ctx.init(kmf.getKeyManagers(), null, null);

			ssf = ctx.getServerSocketFactory();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	@Override
	public ServerSocket createServerSocket(int port) throws IOException {
		SSLServerSocket sslf = (SSLServerSocket)ssf.createServerSocket(port);
		sslf.setUseClientMode(false);
		sslf.setEnabledProtocols(new String[]{"TLSv1.1", "TLSv1.2"});
		//return ssf.createServerSocket(port);
		return sslf;
	}

	public int hashCode() {
		return getClass().hashCode();
	}

	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		} else if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		return true;
	}

}
