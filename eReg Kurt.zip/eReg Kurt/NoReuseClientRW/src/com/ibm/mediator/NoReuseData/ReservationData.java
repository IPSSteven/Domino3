package com.ibm.mediator.NoReuseData;

import java.io.Serializable;


public class ReservationData implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String SerialNumberPSC;
	private String ShortName;
	private String FirstName;
	private String MiddleInitial;
	private String LastName;
	private String FullName;
	private String EMailAddress;
	private String CreationDate;
	private String[] FullNameAlias;
	private String[] EMailAlias;

	public String getSerialNumberPSC() {
		return SerialNumberPSC;
	}
	public void setSerialNumberPSC(String serialNumberPSC) {
		SerialNumberPSC = serialNumberPSC;
	}
	public String getShortName() {
		return getPreparedName(ShortName);
	}
	public void setShortName(String shortName) {
		ShortName = shortName;
	}
	public String getFirstName() {
		return getPreparedName(FirstName);
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getMiddleInitial() {
		return getPreparedName(MiddleInitial);
	}
	public void setMiddleInitial(String middleInitial) {
		MiddleInitial = middleInitial;
	}
	public String getLastName() {
		return getPreparedName(LastName);
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getFullName() {
		String fn =  getPreparedName(FullName);
		if(fn.indexOf("/")< 0)
			return fn + "/US/IBM";
		else return fn;		
	}
	public void setFullName(String fullName) {
		FullName = fullName;
	}
	public String getEMailAddress() {
		return getPreparedName(EMailAddress);
	}
	public void setEMailAddress(String eMailAddress) {
		EMailAddress = eMailAddress;
	}
	public String getCreationDate() {
		return getPreparedName(CreationDate);
	}
	public void setCreationDate(String creationDate) {
		CreationDate = creationDate;
	}
	public String[] getFullNameAlias() {
		String []stReturn;
		if (FullNameAlias == null){
			stReturn = new String[1];
			stReturn[0] = "";
		}else{
			stReturn = new String[FullNameAlias.length];
			for(int i = 0; i< FullNameAlias.length; i++){
				stReturn[i] = getPreparedName(FullNameAlias[i]);
			}
		}
		return stReturn;

	}
	public void setFullNameAlias(String[] fullNameAlias) {
		FullNameAlias = fullNameAlias;
	}
	public String[] getEMailAlias() {
		String []stReturn;
		if (EMailAlias == null){
			stReturn = new String[1];
			stReturn[0] = "";
		}else{
			stReturn = new String[EMailAlias.length];
			for(int i = 0; i< EMailAlias.length; i++){
				stReturn[i] = getPreparedName(EMailAlias[i]);
			}
		}
		return stReturn;
	}
	public void setEMailAlias(String[] eMailAlias) {
		EMailAlias = eMailAlias;
	}
	private String getPreparedName(String in){
		if(in ==null){ return "";
		}else{
			return in;
		}
	}
}
