package com.ibm.mediator.NoReuseData;

import java.util.Arrays;
import java.util.HashSet;

public class ReservationDataSQL {
	public static final String FIELNAME_EMAILALIAS = "EMA";
	public static final String FIELNAME_FULLNAMEALIAS = "FMA";
	
	private final String INSERTSINGLE = "INSERT INTO NOREUSE.NOTES_RESERVATION_SINGLEVAL (SERIALNUMBERPSC,"
			+ " FIRSTNAME, MIDDLEINITIAL, LASTNAME, FULLNAME, INTERNETADDRESS, SHORTNAME, CREATIONDATE) VALUES "; 
	private final String INSERTMULTI = "INSERT INTO NOREUSE.NOTES_RESERVATION_MULTIVAL(SERIALNUMBERPSC, FIELDNAME, FIELDVALUE) VALUES "; 
	private final String SELECTSINGLE = "SELECT * FROM NOREUSE.NOTES_RESERVATION_SINGLEVAL WHERE "; 
	private final String SELECTMULTI = "SELECT * FROM NOREUSE.NOTES_RESERVATION_MULTIVAL WHERE "; 
	private final String DELRES = "DELETE FROM  NOREUSE.NOTES_RESERVATION_SINGLEVAL WHERE SERIALNUMBERPSC = ";
	private ReservationData rd;

	public ReservationDataSQL(ReservationData rd) {
		// TODO Auto-generated constructor stub
		this.rd = rd;
	}
	
	public String getSinglValSQL(){
		StringBuilder sbReturn = new StringBuilder(INSERTSINGLE);
		sbReturn.append("('");
		sbReturn.append(rd.getSerialNumberPSC());
		sbReturn.append("', '");
		sbReturn.append(rd.getFirstName().replaceAll("'", "''"));
		sbReturn.append("', '");
		sbReturn.append(rd.getMiddleInitial().replaceAll("'", "''"));
		sbReturn.append("', '");
		sbReturn.append(rd.getLastName().replaceAll("'", "''"));
		sbReturn.append("', '");
		sbReturn.append(rd.getFullName().replaceAll("'", "''"));
		sbReturn.append("', '");
		sbReturn.append(rd.getEMailAddress().replaceAll("'", "''"));
		sbReturn.append("', '");
		sbReturn.append(rd.getShortName().replaceAll("'", "''"));
		sbReturn.append("', '");
		sbReturn.append(rd.getCreationDate());
		sbReturn.append("')");
		return sbReturn.toString();
		
	}
	
	public String getMultiValSQL(){
		StringBuilder sbReturn = new StringBuilder(INSERTMULTI);
		boolean found = false;
		if(rd.getEMailAlias() != null){
			String[] stAll = new HashSet<String>(Arrays.asList(rd.getEMailAlias())).toArray(new String[0]); // remove duplicates
			found = true;
			for(String s : stAll){
				sbReturn.append("('");
				sbReturn.append(rd.getSerialNumberPSC());
				sbReturn.append("', '");
				sbReturn.append(ReservationDataSQL.FIELNAME_EMAILALIAS);
				sbReturn.append("', '");
				sbReturn.append(s.replaceAll("'", "''"));
				sbReturn.append("'),");
				
			}
		}
		if(rd.getFullNameAlias() != null){
			found = true;
			String[] stAll = new HashSet<String>(Arrays.asList(rd.getFullNameAlias())).toArray(new String[0]);
			for(String s : stAll){
				sbReturn.append("('");
				sbReturn.append(rd.getSerialNumberPSC());
				sbReturn.append("', '");
				sbReturn.append(ReservationDataSQL.FIELNAME_FULLNAMEALIAS);
				sbReturn.append("', '");
				sbReturn.append(s.replaceAll("'", "''"));
				sbReturn.append("'),");
			}
		}
		if(found){
			return sbReturn.substring(0,sbReturn.length() -1);
		}else{
			return null;
		}
	}
	public String[] getCheckReservationSQL(){
		String [] res = new String[2];
		res[0] = SELECTSINGLE + "SERIALNUMBERPSC = '" + rd.getSerialNumberPSC() + "'";
		res[1] = SELECTMULTI + "SERIALNUMBERPSC = '" + rd.getSerialNumberPSC() + "'";
		return res;
	}
	
	public String getDeleteSQL(){
		return DELRES + "'" + rd.getSerialNumberPSC() + "'";
	}

}
