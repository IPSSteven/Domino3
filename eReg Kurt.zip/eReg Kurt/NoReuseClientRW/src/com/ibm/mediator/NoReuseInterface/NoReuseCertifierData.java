package com.ibm.mediator.NoReuseInterface;

import java.io.Serializable;
import java.lang.reflect.Field;

public class NoReuseCertifierData implements Serializable {
	/**
	 * This class is not in use at the moment
	 */
	private static final long serialVersionUID = 1L;
	public static final int CountryDefSerialPSC = 1;
	public static final int CountryDefCountryCode = 2;
	public static final int CountryDefCountryName = 3;

	public static final String EmpTypeInternal = "I";
	public static final String EmpTypeContractor = "E";

	private int KindOfCountryDefinition;
	private String EmployeeType;

	public static void main (String [] argv){
		NoReuseCertifierData cd = new NoReuseCertifierData();
		try {
			cd.setEmployeeType(NoReuseCertifierData.EmpTypeContractor);
			cd.setEmployeeType(NoReuseCertifierData.EmpTypeInternal);
			//cd.setEmployeeType("X");
			
			cd.setKindOfCountryDefinition(NoReuseCertifierData.CountryDefCountryCode);
			cd.setKindOfCountryDefinition(NoReuseCertifierData.CountryDefCountryName);
			cd.setKindOfCountryDefinition(NoReuseCertifierData.CountryDefSerialPSC);
			
			//cd.setEmployeeType("X");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public int getKindOfCountryDefinition() {
		return KindOfCountryDefinition;
	}
	
	public void setKindOfCountryDefinition(int kindOfCountryDefinition) throws Exception {
		if (verifyCountryDef(kindOfCountryDefinition)){
			KindOfCountryDefinition = kindOfCountryDefinition;
		}else{
			throw new Exception("Kind of Country Definition is no valid");
		}
	}
	
	public String getEmployeeType() {
		return EmployeeType;
	}
	
	public void setEmployeeType(String employeeType) throws Exception {
		if(veryfiyEmpType(employeeType)){
			EmployeeType = employeeType;
		}else{
			throw new Exception("Kind of Employee is no valid");
		}
		
	}
	
	private boolean verifyCountryDef(int idef){
		Class<NoReuseCertifierData> c = (Class<NoReuseCertifierData>)this.getClass();
		Field[] fs = c.getFields();
		for (Field f: fs){
			if (f.getType().getName().equals("int")){
				try {
					if (f.getInt(f) == idef){
						return true;
					}
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return false;
	}
	
	private boolean veryfiyEmpType(String sETyp){
		Class<NoReuseCertifierData> c = (Class<NoReuseCertifierData>)this.getClass();
		Field[] fs = c.getFields();
		for (Field f: fs){
			if (f.getType().getName().equals("java.lang.String")){
				try {
					if (f.toString().equalsIgnoreCase(sETyp)){
						return true;
					}
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return false;
	}
	
	
	
}
