package com.ibm.mediator.NoReuseInterface;

import java.io.Serializable;
import java.lang.reflect.Field;
/** 
 * @version 1.0
 * class to transport the name, country and the context for a Name proposal
 * the data needs to be passed to constructor
 * 
 * The class is used as return parameter by the isSerialinUse method of the NoReuseInterface
 * 
 * @author Kurt Raiser
 */

public class NoReuseCountryData implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	

	/**
	 *The kind definition of the country:  <br>
	 *must be one of the constant values:  <br>
	 *CountryDefSerialPSC = 1  -> CountryDef in the constructor is passed as PSC e.g 897 or serialnumber+ psc e.g 123456897  for US <br>
	 *CountryDefCountryCode = 2 -> CountryDef in the constructor is passed as 2 digit country code e.g fr for France  <br>
	 *CountryDefCountryName = 3 CountryDef in the constructor is passed as fullname e.gg Germany  <br>
	 */
	public static final int CountryDefSerialPSC = 1;
	public static final int CountryDefCountryCode = 2;
	public static final int CountryDefCountryName = 3;


	/**
	 * The definition of the country context:  <br>
	 * ContextGNA(1): country is included in the e-mail search because countries are reflected in the e-mail address in GNA  <br>
	 * ContextGlobal(2) country is Not included in the e-mail search because the country is not reflected int the e-mail address in Global  <br>
	 */
	public static final int ContextGNA = 1;
	public static final int ContextGlobal = 2;

	private int KindOfCountryDefinition;
	private int KindOfContext;
	private String value;


	public static void main (String [] argv){
		try {
			//NoReuseCountryData cd = new NoReuseCountryData("724", NoReuseCountryData.CountryDefSerialPSC, NoReuseCountryData.ContextGlobal);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
 
	/**
	 * 
	 * @param CountryDef : the value of the country definition
	 * @param kindofCountryDef: specifies how the country is passed: psc code, country code, or country
	 * @param kindOfContext : specifies the context for the search (GNA or global)
	 * @throws Exception
	 */
	public NoReuseCountryData(String CountryDef, int kindofCountryDef, int kindOfContext) throws Exception{
		setKindOfCountryDefinition(kindofCountryDef);
		setKindOfContext(kindOfContext);
		setValue(CountryDef);
	}

	/**
	 * 
	 * @return the kind of country definition: s constants
	 */
	public int getKindOfCountryDefinition() {
		return KindOfCountryDefinition;
	}
	
	/**
	 * 
	 * @param kindOfCountryDefinition s. constants
	 * @throws Exception if contry defintion is not defined
	 */
	private void setKindOfCountryDefinition(int kindOfCountryDefinition) throws Exception {
		if (verifyCountryDef(kindOfCountryDefinition)){
			KindOfCountryDefinition = kindOfCountryDefinition;
		}else{
			throw new Exception("Kind of Country Definition is no valid");
		}
	}


	/**
	 * 
	 * @return the kind of country context (global or GNA
	 */
	public int getKindOfContext() {
		return KindOfContext;
	}
	
	/**
	 * 
	 * set the kind of country context and verifies it.
	 */
	private void setKindOfContext(int kindOfContext) throws Exception{
		if(!verifyContext( kindOfContext)) throw new Exception("Kind of context definition not valid !");
		KindOfContext = kindOfContext;
	}
	
	/**
	 * 
	 * @return the value of the country, which is depending on the context
	 */

	public String getValue() {
		return value;
	}

	/**
	 * 
	 * stet the value of the context
	 */
	private void setValue(String value) {
		this.value = value;
	}

	/**
	 * 
	 * @param idef: kind of country definition
	 * @return: whether the country definition is valid or not
	 */
	private boolean verifyCountryDef(int idef){
		
		Class<NoReuseCountryData> c = (Class<NoReuseCountryData>)this.getClass();
		Field[] fs = c.getFields();

		for (Field f: fs){
		
			if (f.getName().indexOf("CountryDef") > -1 &&f.getType().getName().equals("int")){
				try {
					if (f.getInt(f) == idef){
						return true;
					}
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return false;
	}
	
	/**
	 * 
	 * @param idef : country context
	 * @return: whether the country context is valid or not
	 */
	private boolean verifyContext(int idef){
		String sDummy;
		Class<NoReuseCountryData> c = (Class<NoReuseCountryData>)this.getClass();
		Field[] fs = c.getFields();
		for (Field f: fs){
			sDummy = f.getName();
			if (f.getName().indexOf("Context") > -1 &&f.getType().getName().equals("int")){
				try {
					if (f.getInt(f) == idef){
						return true;
					}
				} catch (IllegalArgumentException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return false;
	}
}
