package com.ibm.mediator.NoReuseInterface;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface NoReuseReaderInterface extends Remote {
	/**
	 * 
	 * @param id : the name of the id like firstname.lastname@ibm.com, firstname lastname/ibm/com wild cards are possible.
	 * @return see ResponseIsIdinUse
	 * 
	 * @throws RemoteException
	 */
	public ResponseIsIdinUse isIDinUse(String id) throws RemoteException;
	//public ResponseIsIdinUse isIDinUse(String[] id) throws RemoteException;
	/**
	 * 
	 * @param id : the name of the id like firstname.lastname@ibm.com, firstname lastname/ibm/com wild cards are possible.
	 * @param nrcd : the country data as psc code or country code or country. It enable to search on country within country inforamtion
	 * @return see ResponseIsIdinUse
	 * 
	 * @throws RemoteException
	 */
	public ResponseIsIdinUse isIDinUse(String id, NoReuseCountryData nrcd) throws RemoteException;
	
	/** 
	 * Method to get a proposal. This method connect each time to no Reuse Database and executes a query
	 * 
	 * @param firstName
	 * @param middleInitial
	 * @param lastName
	 * @return see ResponseIsIDinUse
	 * @throws RemoteException
	 * @return ResponseNameProposal
	 * @throws RemoteException
	 */
	public ResponseNameProposal getNameProposal(String firstName, String middleInitial, String lastName) throws RemoteException;
	
	
	/** 
	 * Method to get a proposal. This method connect each time to no Reuse Database and executes a query
	 * 
	 * @param firstName
	 * @param middleInitial
	 * @param lastName
	 * @param nrcd : class that pass the country information as PSC code oder country code or country
	 * @return see ResponseIsIDinUse
	 * @throws RemoteException
	 */
	public ResponseNameProposal getNameProposal(String firstName, String middleInitial, String lastName, NoReuseCountryData ncrd) throws RemoteException;

	
	/** 
	 * Method to get a proposal. The method buffers the response data for  a time given in the config.properties file. (RMI_BUFFER_TIME=60)
	 * The BUFFER_TIME is in seconds
	 * 
	 * @param identifier
	 * @param firstName
	 * @param middleInitial
	 * @param lastName
	 * @param nrcd : class that pass the country information as PSC code oder country code or country
	 * @return see ResponseIsIDinUse
	 * @throws RemoteException
	 */
	
	public ResponseNameProposal getNameProposalBuffered(String identifier,String firstName, String middleInitial, String lastName, NoReuseCountryData ncrd) throws RemoteException;
	
	/**
	 * Method to checks whether a reservation exits
	 * 
	 * @param serialPSC : the serial and PSC code for the reservation check
	 * @return ResponseIsIdinUse : s description
	 * @throws RemoteException
	 */
	public ResponseIsIdinUse checkReservation(String serialPSC) throws RemoteException;
	
	/**
	 * Method checks whether as serial is in use
	 * 
	 * @param serialPSC : the serial and PSC code for the reservation check
	 * @return ResponseIsSerialInUse 
	 * @throws RemoteException
	 */
	public ResponseIsSerialInUse isSerialInUse (String serialPsc) throws RemoteException;
	
	
}
