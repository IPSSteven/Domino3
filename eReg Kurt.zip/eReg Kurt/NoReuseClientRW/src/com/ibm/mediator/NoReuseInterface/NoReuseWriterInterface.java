package com.ibm.mediator.NoReuseInterface;


import java.rmi.RemoteException;

import com.ibm.mediator.NoReuseData.ReservationData;

public interface NoReuseWriterInterface extends  NoReuseReaderInterface{
	/**
	 * Method to create a reservation
	 * 
	 * @param resDat s. ReservationData
	 * @return  ResponseBasic
	 * @throws RemoteException
	 */
	public ResponseBasic createReservation(ReservationData resDat) throws RemoteException;
	
	
}
