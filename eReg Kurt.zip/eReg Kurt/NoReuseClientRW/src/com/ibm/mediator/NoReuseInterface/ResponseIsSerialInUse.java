package com.ibm.mediator.NoReuseInterface;

import java.io.Serializable;

public class ResponseIsSerialInUse extends ResponseIsIdinUse implements Serializable{

	/** 
	 * @version 1.0
	 * class to transport the response of the RMImethod of the query whether a serial is in use
	 * 
	 * The class is used as return parameter by the isSerialinUse method of the NoReuseInterface
	 * 
	 * @author Kurt Raiser
	 */
	private static final long serialVersionUID = 1L;
	
	private SerialPSCNamesPair SerialPSCinUse;
	
	/**
	 * 
	 * @return the a NamePair. The name pair reflects the serial and the name(s) which are bound to that serial
	 */
	public SerialPSCNamesPair getSerialPSCinUse() {
		return SerialPSCinUse;
	}
	
	/**
	 * 
	 * @param Method is used by the RMI server to set the response of the query for is Serial in use
	 */
	public void setSerialPSCinUse(SerialPSCNamesPair serialPSCinUse) {
		SerialPSCinUse = serialPSCinUse;
	}
	
	/**
	 * 
	 * Inner Class to transport the names which are bound to a serial number
	 */
	public class SerialPSCNamesPair implements Serializable{
		String serialPSC;
		String[] names;
		
		/**
		 * 
		 * @return the serial number 
		 */
		public String getSerialPSC() {
			return serialPSC;
		}
		/**
		 * 
		 * @param  serialPSC to set serial number + PSC
		 */
		public void setSerialPSC(String serialPSC) {
			this.serialPSC = serialPSC;
		}
		/**
		 * 
		 * @return names which are bound to a serial number as String array
		 */
		public String[] getNames() {
			return names;
		}
		/**
		 * 
		 * @param names to set the names which are bound to a serial number
		 */
		public void setNames(String[] names) {
			this.names = names;
		}
	}
	


}
