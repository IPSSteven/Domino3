package com.ibm.mediator.NoReuseInterface;

import java.io.Serializable;

public class ResponseNameProposal extends ResponseBasic implements Serializable{
	
	/**
	 * @verion 1.0
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String[] usedFullNames;
	private String[] usedEMail;
	private ProposedName[] proposedNames;

	public class ProposedName implements Serializable{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String proposedFirstName;
		private String proposedMiddleInitial;
		private String proposedLastName;
		private String proposedFullName;
		private String proposedEMail;
		
		public String getProposedFirstName() {
			return proposedFirstName;
		}
		public void setProposedFirstName(String firstName) {
			this.proposedFirstName = firstName;
		}
		public String getProposedMiddleInitial() {
			return proposedMiddleInitial;
		}
		public void setProposedMiddleInitial(String middleInitial) {
			this.proposedMiddleInitial = middleInitial;
		}
		public String getProposedLastName() {
			return proposedLastName;
		}
		public void setProposedLastName(String lastName) {
			this.proposedLastName = lastName;
		}
		public String getProposedFullName() {
			return proposedFullName;
		}
		public void setProposedFullName(String proposedFullName) {
			this.proposedFullName = proposedFullName;
		}
		public String getProposedEMail() {
			return proposedEMail;
		}
		public void setProposedEMail(String proposedEMail) {
			this.proposedEMail = proposedEMail;
		}
		
		
		
	}
	
	public ResponseNameProposal() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * 
	 * @return all the proposed e-mails 
	 */
	
	/*
	 * method to set all the full names which are in user (only for the server)
	 */
	
	/**
	 * 
	 * @return all the full names which are in use (for the client)
	 */
	public String[] getUsedFullNames() {
		return usedFullNames;
	}
	
	/**
	 * method to set all the fullnames which are in user (only for the server)
	 * @param usedFullNames
	 */
	public void setUsedFullNames(String[] usedFullNames) {
		this.usedFullNames = usedFullNames;
	}
	
	/**
	 * method to get all the e-mails, which are in use (only for the client)
	 * @return String[] the used e-mails
	 */
	public String[] getUsedEMail() {
		return usedEMail;
	}
	
	/**
	 * method to set all the e-mails which are in user (only for the server)
	 * @param usedEMail
	 */
	public void setUsedEMail(String[] usedEMail) {
		this.usedEMail = usedEMail;
	}

	public ProposedName[] getProposedNames() {
		return proposedNames;
	}

	public void setProposedNames(ProposedName[] proposedNames) {
		this.proposedNames = proposedNames;
	}
	
	
	
	

}
