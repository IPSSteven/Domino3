package com.ibm.mediator.NoReuseRMIServerSSL;


import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import com.ibm.mediator.NoReuseInterface.NoReuseCountryData;
import com.ibm.mediator.NoReuseInterface.NoReuseReaderInterface;
import com.ibm.mediator.NoReuseInterface.NoReuseWriterInterface;
import com.ibm.mediator.NoReuseInterface.ResponseIsIdinUse;
import com.ibm.mediator.NoReuseInterface.ResponseNameProposal;

public class NoReuseRMIClientSSL {

	/**
	 * @version 1.0
	 * @author Kurt Raiser
	 * @
	 * This is a sample of an RMIClient, to consume the server
	 * The Parameter for Client (command line):
	 * @param param1: kind of request, IIU = check is in use, GNP = get name Proposal");
	 * @param param2: firstname,middleInital,lastname OR email");
	 * @param param3: ipAdress:port (optional");
	 * 
	 * @param : @see description of the class ResponseIsIdinUse and ResponseNameProposal
	 * 
	 */
	private static final String implName = "NoReuseServer"; 
	
	private static String stFirstName;
	private static String stMiddleInitial;
	private static String stLastName;
	private static String stEmail;
	private static String stSerial;
	private static String stCountry;
	private static String host; 
	private static int port;

	public NoReuseRMIClientSSL() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//host = "localhost";
		//host = "9.149.105.239"; //prod
		//host = "9.149.105.238"; //test
		host = "9.212.156.54"; // dev linux
		//host = "9.212.156.43"; // test linux
		port = 5811;
		
		if (!checkparam(args)) return;
		
		String stKindOfRequest = args[0];
		
		// and now act.
		try {
			
			pln("**********************************BEGIN SHOW PARAM************************");
			pln("Try to register host " + host + " on port " + port );
			pln("Kind of request :" + stKindOfRequest );
			pln("First Name: " + stFirstName);
			pln("Midle Initial: " + stMiddleInitial);
			pln("Last Name : " + stLastName);
			pln("EMail : " + stEmail);
			pln("**********************************BEGIN SHOW PARAM************************");

			System.setProperty("javax.net.ssl.trustStore", "globalIBM.ks");
			Registry r = LocateRegistry.getRegistry(host, port);
			//NoReuseReaderInterface nrRMIClient = (NoReuseReaderInterface)r.lookup(implName);
			NoReuseWriterInterface nrRMIClient = (NoReuseWriterInterface)r.lookup(implName);
			
			// is id in use request
			ResponseIsIdinUse b = null;
			if(stKindOfRequest.equalsIgnoreCase("IIU")){
				if (stCountry.equals("")){
					b = nrRMIClient.isIDinUse(stEmail);
				}else{
					try {
						
						// stCountry should be passed as PSC code
						pln(stCountry);
						NoReuseCountryData ncd =  new NoReuseCountryData(stCountry, NoReuseCountryData.CountryDefSerialPSC, NoReuseCountryData.ContextGlobal);
						b = nrRMIClient.isIDinUse(stEmail, ncd);
						
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						return;
					}
				}
				if (b.getHasError() != null && b.getHasError().booleanValue()){
									pln("Error while get processe request");
					pln(b.getErrDescription());
				}else{
					if (b.getIsIDinUse().booleanValue()){
						pln(stEmail + " is in use");
					}else{
						pln(stEmail + " is NOT in use");
					}
				}

			}

			
			// Generate Name proposal
			if(stKindOfRequest.equalsIgnoreCase("GNP")){
				ResponseNameProposal np = null;
				if (stCountry == null){
					np = nrRMIClient.getNameProposal(stFirstName, stMiddleInitial,stLastName);
				}else{
					NoReuseCountryData nrcd;
					try {
						nrcd = new NoReuseCountryData(stCountry, NoReuseCountryData.CountryDefCountryCode, NoReuseCountryData.ContextGNA);
						nrcd = new NoReuseCountryData(stCountry, NoReuseCountryData.CountryDefCountryCode, NoReuseCountryData.ContextGlobal);
						np = nrRMIClient.getNameProposal(stFirstName, stMiddleInitial,stLastName,nrcd);		
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				if (np.getHasError().booleanValue()){
					pln("Error while get processe request");
					pln(np.getErrDescription());
				}else{
					pln("**********************************BEGIN OF FULLNAMES IN USE************************");
					if (np.getUsedFullNames() == null){
						pln("N/A");
					}else{
						for (String s: np.getUsedFullNames()){
							pln(s);
						}
					}
					pln("**********************************END OF FULLNAMES IN USE************************");
					pln("**********************************BEGIN OF EMAILS IN USE************************");
					if(np.getUsedEMail() == null){
						pln("N/A");
					}else{
						for (String s: np.getUsedEMail()){
							pln(s);
						}
					}
					pln("**********************************END OF EMAILS IN USE************************");

					pln("######### BEGIN OF PROPOSED NAME ############");
					if(np.getProposedNames()[0] == null){
						pln("N/A");
					}else{
						for (ResponseNameProposal.ProposedName pn: np.getProposedNames()){
							pln("Proposed first name: " + pn.getProposedFirstName());
							pln("Proposed middle initial: " + pn.getProposedMiddleInitial());
							pln("Proposed lst name: " + pn.getProposedLastName());
							pln("Proposed E-mail: " + pn.getProposedEMail());
							pln("Proposed full name: " + pn.getProposedFullName());
						}
					}
					pln("######### END OF PROPOSED NAME ############");
				}
			}
			
			
			// check reservation
			if(stKindOfRequest.equalsIgnoreCase("CR")){
				pln("######### BEGIN OF CHECK RESERVATION ############");
				ResponseIsIdinUse rp = nrRMIClient.checkReservation(stSerial);
				if (rp.getHasError().booleanValue()){
					pln("Error while get processe request");
					pln(rp.getErrDescription());
				}else{
					if (rp.getIsIDinUse().booleanValue()){
						pln( "There is a reservation for the serial " + stSerial );
					}else{
						pln( "There NO is a reservation for the serial " + stSerial );
					}
					
				}
				pln("######### END OF CHECK RESERVATION ############");
			}
			
		
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void pln(String log){
		System.out.println(log);
	}
	
	
	private static boolean checkparam(String[] param){
		if (param.length < 2){
			pln("Usage: ...NoReuseRMIClient parm1 parm2 parm3 ");
			pln("parm1: kind of request, IIU = check is in use, GNP = get name Proposal");
			pln("parm2: firstname,middleInital,lastname OR email");
			pln("parm3: ipAdress:port (optional)");
			return false;
		}
		
		String stKindOfRequest = param[0];
		if(stKindOfRequest.equalsIgnoreCase("GNP")){
			String [] stName = param[1].split(",");
			if(stName.length <3){
				pln("Usage: ...NoReuseRMIClientparm1 parm2 parm3 ");
				pln("parm1: kind of request, IIU = check is in use, GNP = get name Proposal CR = CheckReservation");
				pln("parm2: firstname,middleInital,lastname OR email");
				pln("parm3: ipAdress:port (optional");
				pln("----------------------------------");
				pln("Please provide firstname, middleInital, lastname e.g. John,,Smith for first name John and last name Smith");
				return false;
			}else{
				stFirstName = stName[0];
				stMiddleInitial = stName[1];
				stLastName = stName[2];
				if (stName.length >3) stCountry = stName[3];
			}
		}else if(stKindOfRequest.equalsIgnoreCase("IIU")){
			stEmail = param[1];
			if(param.length > 2){
				stCountry = param[2];
			}else{
				stCountry = "";
			}
		} else if(stKindOfRequest.equalsIgnoreCase("CR")){
			stSerial = param[1];
		} else if(stKindOfRequest.equalsIgnoreCase("CRR")){
			String [] stName = param[1].split(",");
			stFirstName = stName[0];
			stMiddleInitial = stName[1];
			stLastName = stName[2];
			stEmail =  stName[3];
			stSerial = stName[4];
		}else{
			pln("Usage: ...NoReuseRMIClient parm1 parm2 parm3 ");
			pln("parm1: kind of request, IIU = check is in use, GNP = get name Proposal CR = CheckReservation");
			pln("parm2: firstname,middleInital,lastname OR email");
			pln("parm3: ipAdress:port (optional");
			pln("----------------------------------");
			pln("Kind of Request "+ stKindOfRequest + " is not valid");
			return false;
		}

		if(param.length == 3){
			String [] stConnect = param[2].split(":");
			if (stConnect.length == 2){
				host = stConnect[0];
				port = Integer.parseInt(stConnect[1]);
			}
		}
		return true;
		
	}
}
