package com.ibm.mediator.NoReuseRMIServerSSL;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import com.ibm.mediator.NoReuseData.ReservationData;
import com.ibm.mediator.NoReuseInterface.NoReuseWriterInterface;
import com.ibm.mediator.NoReuseInterface.ResponseBasic;
public class ReservationRMIClientTest {
private static final String implName = "NoReuseServer"; 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReservationData rd = new ReservationData();
		String [] stEmailAlias = new String[5];
		String [] stFullAlias = new String[5];
		//String host = "localhost";
		//String host = "9.149.105.149";
		//String host = "9.149.105.151"; //ReadWrite Server
		//String host = "9.149.105.238"; //ReadWrite Server
		String host = "9.212.156.54"; // dev linux
		//String host = "9.212.156.43"; // test linux
		int port = 6811;
		
		
		Registry r;
		
		System.setProperty("javax.net.ssl.trustStore", "globalIBM.ks");
		NoReuseWriterInterface nrRMIClient;
		
		try {
			r = LocateRegistry.getRegistry(host, port);
			nrRMIClient = (NoReuseWriterInterface)r.lookup(implName);
			// fill the reservation DATA
			rd.setSerialNumberPSC("ZZ004V655"); // serial number+ psc Code
			rd.setFirstName("FirstNameX");
			rd.setMiddleInitial("");
			rd.setLastName("LastMameX");
			//rd.setFullName(rd.getFirstName() + " " + rd.getMiddleInitial() + " " + rd.getLastName());
			rd.setFullName(rd.getFirstName() + " " + rd.getLastName());
			rd.setEMailAddress(rd.getFirstName() + "." + rd.getLastName() + "@ibm.com");
			rd.setShortName("CLZZ004V"); //country code + serial 
			rd.setCreationDate("20160822");
			// generate some stupid alias
			for(int j=0; j<5; j++){
				stEmailAlias[j] = rd.getEMailAddress() + "_" + j;
				stFullAlias[j] = rd.getFullName() + "_" + j;
				
			}
			
			// create reservation
	ResponseBasic rb = nrRMIClient.createReservation(rd);
			if(rb.getHasError().booleanValue()){
				System.out.println(rb.getErrDescription());
			}else{
				System.out.println("Reservation successful");
			}
			
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		

	}

}
