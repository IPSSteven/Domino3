package com.ibm.mediator.NoReuseRMIServerSSL.SocketFactories;

import java.io.IOException;
import java.io.Serializable;
import java.net.Socket;
import java.rmi.server.RMIClientSocketFactory;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import com.ibm.mediator.NoReuseRMIServerSSL.PropertyHandler;

public class ASSLClientSocketFactory implements RMIClientSocketFactory,
Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private PropertyHandler prop = null;
	@Override
	public Socket createSocket(String host, int port) throws IOException {
		// TODO Auto-generated method stub
		SSLSocketFactory factory =
				(SSLSocketFactory)SSLSocketFactory.getDefault();
		SSLSocket socket = (SSLSocket)factory.createSocket(host, port);
		socket.setEnabledProtocols(new String[]{"TLSv1.1", "TLSv1.2"});
		if (prop == null){
			try{
			prop = PropertyHandler.getInstance();
			String stMill = prop.getProperty(PropertyHandler.propRMIClientTimeOut);
			if (stMill != null){
				int mill = Integer.parseInt(stMill);
				socket.setSoTimeout(mill);
			}
			}catch(IOException ie){
				System.out.println("Properties can not be loaded");
			}
		}
		//     socket.s
		return socket;

	}

	public int hashCode() {
		return getClass().hashCode();
	}

	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		} else if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		return true;
	}

}
